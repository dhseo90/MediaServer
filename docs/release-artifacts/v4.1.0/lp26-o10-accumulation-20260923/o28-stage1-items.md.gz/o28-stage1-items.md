# O28 1번 전수 assertion 정정본

독자: 검증 담당자. historical 실행 증거이며 중앙 기록의 보조자료다. 원로그를 재서식화한 것이며 재실행 결과가 아니다.

| 제목 | 수행내용 | 결과(pass/fail) |
| --- | --- | --- |
| LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH02 timeout preserves last open phase without synthetic completion | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH03 partial malformed unknown and secret-bearing trace rows reject | `o28-diagnostic-profile-green1-20260924.log` | pass |
| O28-D01 child termination classes and bounded metadata remain distinct | `o28-diagnostic-profile-green1-20260924.log` | pass |
| O28-D02 missing partial malformed loss and incomplete traces never synthesize completion | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH05 changed original or unconfirmed child blocks cleanup | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH06 exact instrumentation drift and trace bounds fail closed | `o28-diagnostic-profile-green1-20260924.log` | pass |
| LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH02 timeout preserves last open phase without synthetic completion | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH03 partial malformed unknown and secret-bearing trace rows reject | `o28-diagnostic-profile-green2-20260924.log` | pass |
| O28-D01 child termination classes and bounded metadata remain distinct | `o28-diagnostic-profile-green2-20260924.log` | pass |
| O28-D02 missing partial malformed loss and incomplete traces never synthesize completion | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH05 changed original or unconfirmed child blocks cleanup | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH06 exact instrumentation drift and trace bounds fail closed | `o28-diagnostic-profile-green2-20260924.log` | pass |
| LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH02 timeout preserves last open phase without synthetic completion | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH03 partial malformed unknown and secret-bearing trace rows reject | `o28-diagnostic-profile-green3-20260924.log` | pass |
| O28-D01 child termination classes and bounded metadata remain distinct | `o28-diagnostic-profile-green3-20260924.log` | pass |
| O28-D02 missing partial malformed loss and incomplete traces never synthesize completion | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH05 changed original or unconfirmed child blocks cleanup | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH06 exact instrumentation drift and trace bounds fail closed | `o28-diagnostic-profile-green3-20260924.log` | pass |
| LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS | `o28-diagnostic-profile-red1-20260924.log` | pass |
| LP23-DH02 timeout preserves last open phase without synthetic completion | `o28-diagnostic-profile-red1-20260924.log` | pass |
| LP23-DH03 partial malformed unknown and secret-bearing trace rows reject | `o28-diagnostic-profile-red1-20260924.log` | pass |
| O28-D01 child termination classes and bounded metadata remain distinct | `o28-diagnostic-profile-red1-20260924.log` | pass |
| O28-D02 missing partial malformed loss and incomplete traces never synthesize completion | `o28-diagnostic-profile-red1-20260924.log` | pass |
| LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope | `o28-diagnostic-profile-red1-20260924.log` | pass |
| LP23-DH05 changed original or unconfirmed child blocks cleanup | `o28-diagnostic-profile-red1-20260924.log` | pass |
| LP23-DH06 exact instrumentation drift and trace bounds fail closed | `o28-diagnostic-profile-red1-20260924.log` | fail |
| LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| LP26-O09-A02 identity·clock·pid 불일치 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 | `o28-longrun-diagnostics-green1-20260924.log` | pass |
| S11-O27-01 retired resource mode rejects before setup | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O02 final stopped tail must be complete and fully drained | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O05 initial plus added channels exact disabled on restart | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O01 actual managed writer fixture | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O08 physical archive fixture and logical native rows | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O08 bounded normalization retains count and order under accumulated physical input | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O08 later invalid row rejects the whole batch result | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O01 native exact row count and two channel segments | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O01 compact excludes binding samples source URL and payload | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O02 actual store read preserves original bytes | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| LP26-O05 actual deleted and survivor Catalog recovery twice | `o28-observer-selftest-diagnose2-20260924.log` | pass |
| O28-D03 small native snapshot exposes external and internal phases without changing JSON | `o28-observer-selftest-diagnose2-20260924.log` | fail |
| S11-O27-01 retired resource mode rejects before setup | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 final stopped tail must be complete and fully drained | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O05 initial plus added channels exact disabled on restart | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 actual managed writer fixture | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O08 physical archive fixture and logical native rows | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O08 bounded normalization retains count and order under accumulated physical input | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O08 later invalid row rejects the whole batch result | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 native exact row count and two channel segments | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 compact excludes binding samples source URL and payload | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 actual store read preserves original bytes | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O05 actual deleted and survivor Catalog recovery twice | `o28-observer-selftest-green3-20260924.log` | pass |
| O28-D03 small native snapshot exposes external and internal phases without changing JSON | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope segment_finalized | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope event_link_created | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope observation_put | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope observation_v2_put | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope deletion_requested | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope deletion_completed | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope corruption_detected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope consumer_reference_put | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_reference_accepted | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope referenced_observation_put | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_intent | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_files | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_ready | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_committed | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_complete | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 known envelope derived_job_failed | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject unknown | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject duplicate-key | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject invalid-json | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject unsafe-id | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject bad-segment | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject bad-state | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O01 reject bad-deleted | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 partial line not consumed | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 partial append consumed once | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 exact checkpoint receipt prefix and suffix | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 checkpoint changed refused | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 checkpoint missing refused | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 truncation latched | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 duplicate mutation rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 symlink rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 observer and progress share one total identity budget | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O02 total byte cap and invalid cap cannot be increased | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 actual native order advances independent of UTC | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 huge order unknown UTC new epoch PTS reset accepted | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 duplicate segment rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 persistent order regression rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 completion without pending rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 pending completed physical target once | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O03 changed tombstone rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 stall clock and shortened finish rejected | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 exactly120 argument only | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 monotonic sample independent wallclock | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 pause time cannot satisfy 120 minutes | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 current resources use monotonic not wallclock | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 literal delta gap and insufficient warmup statistics | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource rss | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource fd | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource pid | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource identity | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource counter | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O04 invalid resource clock | `o28-observer-selftest-green3-20260924.log` | pass |
| LP26-O05 current public dispatch avoids legacy longrun prelude | `o28-observer-selftest-green3-20260924.log` | pass |
| wrapper 직접 실행 거부·exit 126 | `o28-observer-selftest-redgreen1-20260924.log` | fail |
| S11-O27-01 retired resource mode rejects before setup | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O02 final stopped tail must be complete and fully drained | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O05 initial plus added channels exact disabled on restart | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O01 actual managed writer fixture | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O08 physical archive fixture and logical native rows | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O08 bounded normalization retains count and order under accumulated physical input | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O08 later invalid row rejects the whole batch result | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O01 native exact row count and two channel segments | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O01 compact excludes binding samples source URL and payload | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O02 actual store read preserves original bytes | `o28-observer-selftest-run1-20260924.log` | pass |
| LP26-O05 actual deleted and survivor Catalog recovery twice | `o28-observer-selftest-run1-20260924.log` | pass |
| O28-D03 small native snapshot exposes external and internal phases without changing JSON | `o28-observer-selftest-run1-20260924.log` | fail |
| S05 개별 동작 등록 exact 연결 (실행 증거 아님) | `o28-stage1-coverage.log` | pass |
| inventory row count is stable | `o28-stage1-coverage.log` | pass |
| inventory uses only the four approved test areas | `o28-stage1-coverage.log` | pass |
| coverage docs and server command are wired | `o28-stage1-coverage.log` | pass |
| exact implementation evidence manifest is valid | `o28-stage1-coverage.log` | pass |
| all feature IDs have exact coverage targets | `o28-stage1-coverage.log` | pass |
| negative missing-ID fixture fails | `o28-stage1-coverage.log` | pass |
| SAFE-200 canonical coverage wording truthfulness boundary | `o28-stage1-coverage.log` | pass |
| README uses only representative product UI screenshots | `o28-stage1-docs-assets.log` | pass |
| English README uses English UI screenshots | `o28-stage1-docs-assets.log` | pass |
| UI guide keeps product screenshots in the shared asset set | `o28-stage1-docs-assets.log` | pass |
| docs UI asset policy documents capture rules | `o28-stage1-docs-assets.log` | pass |
| managed UI asset manifest stays complete | `o28-stage1-docs-assets.log` | pass |
| capture script owns every documented UI asset | `o28-stage1-docs-assets.log` | pass |
| docs capture covers current screenshots | `o28-stage1-docs-assets.log` | pass |
| representative screenshot docs do not point at stale visual baselines | `o28-stage1-docs-assets.log` | pass |
| docs UI asset directory contains managed PNG files | `o28-stage1-docs-assets.log` | pass |
| VA documentation images keep full video frame bounds | `o28-stage1-docs-assets.log` | pass |
| S05 개별 동작 등록 exact 연결 (실행 증거 아님) | `o28-stage1-inventory.log` | pass |
| public docs index excludes internal feature inventory | `o28-stage1-inventory.log` | pass |
| feature inventory pins current release scope | `o28-stage1-inventory.log` | pass |
| required sections exist | `o28-stage1-inventory.log` | pass |
| historical V280 source-of-truth keeps the 2.x runway boundary explicit | `o28-stage1-inventory.log` | pass |
| historical V290 source-of-truth keeps source, published, and roadmap distinct | `o28-stage1-inventory.log` | pass |
| inventory summary count 전체 기능 항목 986 | `o28-stage1-inventory.log` | pass |
| inventory summary count UI 직접 필요 400 | `o28-stage1-inventory.log` | pass |
| inventory summary count UI 간접 필요 36 | `o28-stage1-inventory.log` | pass |
| inventory summary count UI 비대상 550 | `o28-stage1-inventory.log` | pass |
| inventory summary count 테스트 필요 986 | `o28-stage1-inventory.log` | pass |
| inventory summary count 안정화 대상 976 | `o28-stage1-inventory.log` | pass |
| inventory summary count UI 풀테스트 대상 424 | `o28-stage1-inventory.log` | pass |
| inventory summary count 30분 soak 대상 50 | `o28-stage1-inventory.log` | pass |
| inventory summary count 120분 대상 7 | `o28-stage1-inventory.log` | pass |
| summary counts match current feature IDs | `o28-stage1-inventory.log` | pass |
| implementation evidence manifest matches all feature rows | `o28-stage1-inventory.log` | pass |
| feature UI-001 name present | `o28-stage1-inventory.log` | pass |
| feature UI-001 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-002 name present | `o28-stage1-inventory.log` | pass |
| feature UI-002 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-003 name present | `o28-stage1-inventory.log` | pass |
| feature UI-003 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-004 name present | `o28-stage1-inventory.log` | pass |
| feature UI-004 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-005 name present | `o28-stage1-inventory.log` | pass |
| feature UI-005 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature UI-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-006 name present | `o28-stage1-inventory.log` | pass |
| feature UI-006 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature UI-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-007 name present | `o28-stage1-inventory.log` | pass |
| feature UI-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-008 name present | `o28-stage1-inventory.log` | pass |
| feature UI-008 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-009 name present | `o28-stage1-inventory.log` | pass |
| feature UI-009 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-010 name present | `o28-stage1-inventory.log` | pass |
| feature UI-010 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-011 name present | `o28-stage1-inventory.log` | pass |
| feature UI-011 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-012 name present | `o28-stage1-inventory.log` | pass |
| feature UI-012 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-013 name present | `o28-stage1-inventory.log` | pass |
| feature UI-013 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-014 name present | `o28-stage1-inventory.log` | pass |
| feature UI-014 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-015 name present | `o28-stage1-inventory.log` | pass |
| feature UI-015 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-016 name present | `o28-stage1-inventory.log` | pass |
| feature UI-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-017 name present | `o28-stage1-inventory.log` | pass |
| feature UI-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-018 name present | `o28-stage1-inventory.log` | pass |
| feature UI-018 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature UI-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-019 name present | `o28-stage1-inventory.log` | pass |
| feature UI-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-020 name present | `o28-stage1-inventory.log` | pass |
| feature UI-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-021 name present | `o28-stage1-inventory.log` | pass |
| feature UI-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-022 name present | `o28-stage1-inventory.log` | pass |
| feature UI-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-023 name present | `o28-stage1-inventory.log` | pass |
| feature UI-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-024 name present | `o28-stage1-inventory.log` | pass |
| feature UI-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-025 name present | `o28-stage1-inventory.log` | pass |
| feature UI-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-026 name present | `o28-stage1-inventory.log` | pass |
| feature UI-026 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-027 name present | `o28-stage1-inventory.log` | pass |
| feature UI-027 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-028 name present | `o28-stage1-inventory.log` | pass |
| feature UI-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-029 name present | `o28-stage1-inventory.log` | pass |
| feature UI-029 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-030 name present | `o28-stage1-inventory.log` | pass |
| feature UI-030 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-031 name present | `o28-stage1-inventory.log` | pass |
| feature UI-031 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-032 name present | `o28-stage1-inventory.log` | pass |
| feature UI-032 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-033 name present | `o28-stage1-inventory.log` | pass |
| feature UI-033 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-034 name present | `o28-stage1-inventory.log` | pass |
| feature UI-034 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-035 name present | `o28-stage1-inventory.log` | pass |
| feature UI-035 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-036 name present | `o28-stage1-inventory.log` | pass |
| feature UI-036 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-037 name present | `o28-stage1-inventory.log` | pass |
| feature UI-037 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-038 name present | `o28-stage1-inventory.log` | pass |
| feature UI-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-039 name present | `o28-stage1-inventory.log` | pass |
| feature UI-039 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-040 name present | `o28-stage1-inventory.log` | pass |
| feature UI-040 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-041 name present | `o28-stage1-inventory.log` | pass |
| feature UI-041 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-042 name present | `o28-stage1-inventory.log` | pass |
| feature UI-042 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-043 name present | `o28-stage1-inventory.log` | pass |
| feature UI-043 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-044 name present | `o28-stage1-inventory.log` | pass |
| feature UI-044 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-045 name present | `o28-stage1-inventory.log` | pass |
| feature UI-045 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-046 name present | `o28-stage1-inventory.log` | pass |
| feature UI-046 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-047 name present | `o28-stage1-inventory.log` | pass |
| feature UI-047 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-048 name present | `o28-stage1-inventory.log` | pass |
| feature UI-048 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-049 name present | `o28-stage1-inventory.log` | pass |
| feature UI-049 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-050 name present | `o28-stage1-inventory.log` | pass |
| feature UI-050 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-051 name present | `o28-stage1-inventory.log` | pass |
| feature UI-051 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-052 name present | `o28-stage1-inventory.log` | pass |
| feature UI-052 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-053 name present | `o28-stage1-inventory.log` | pass |
| feature UI-053 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-054 name present | `o28-stage1-inventory.log` | pass |
| feature UI-054 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-055 name present | `o28-stage1-inventory.log` | pass |
| feature UI-055 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-056 name present | `o28-stage1-inventory.log` | pass |
| feature UI-056 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-057 name present | `o28-stage1-inventory.log` | pass |
| feature UI-057 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-058 name present | `o28-stage1-inventory.log` | pass |
| feature UI-058 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-059 name present | `o28-stage1-inventory.log` | pass |
| feature UI-059 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-060 name present | `o28-stage1-inventory.log` | pass |
| feature UI-060 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-061 name present | `o28-stage1-inventory.log` | pass |
| feature UI-061 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-062 name present | `o28-stage1-inventory.log` | pass |
| feature UI-062 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-063 name present | `o28-stage1-inventory.log` | pass |
| feature UI-063 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-064 name present | `o28-stage1-inventory.log` | pass |
| feature UI-064 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-065 name present | `o28-stage1-inventory.log` | pass |
| feature UI-065 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-066 name present | `o28-stage1-inventory.log` | pass |
| feature UI-066 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-067 name present | `o28-stage1-inventory.log` | pass |
| feature UI-067 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-068 name present | `o28-stage1-inventory.log` | pass |
| feature UI-068 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-069 name present | `o28-stage1-inventory.log` | pass |
| feature UI-069 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-070 name present | `o28-stage1-inventory.log` | pass |
| feature UI-070 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-071 name present | `o28-stage1-inventory.log` | pass |
| feature UI-071 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-072 name present | `o28-stage1-inventory.log` | pass |
| feature UI-072 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-073 name present | `o28-stage1-inventory.log` | pass |
| feature UI-073 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-074 name present | `o28-stage1-inventory.log` | pass |
| feature UI-074 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-075 name present | `o28-stage1-inventory.log` | pass |
| feature UI-075 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-076 name present | `o28-stage1-inventory.log` | pass |
| feature UI-076 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-077 name present | `o28-stage1-inventory.log` | pass |
| feature UI-077 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-078 name present | `o28-stage1-inventory.log` | pass |
| feature UI-078 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-079 name present | `o28-stage1-inventory.log` | pass |
| feature UI-079 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-080 name present | `o28-stage1-inventory.log` | pass |
| feature UI-080 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-081 name present | `o28-stage1-inventory.log` | pass |
| feature UI-081 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-082 name present | `o28-stage1-inventory.log` | pass |
| feature UI-082 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-083 name present | `o28-stage1-inventory.log` | pass |
| feature UI-083 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-084 name present | `o28-stage1-inventory.log` | pass |
| feature UI-084 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-085 name present | `o28-stage1-inventory.log` | pass |
| feature UI-085 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-086 name present | `o28-stage1-inventory.log` | pass |
| feature UI-086 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-087 name present | `o28-stage1-inventory.log` | pass |
| feature UI-087 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-088 name present | `o28-stage1-inventory.log` | pass |
| feature UI-088 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-088 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-088 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-088 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-089 name present | `o28-stage1-inventory.log` | pass |
| feature UI-089 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-089 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-089 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-089 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-090 name present | `o28-stage1-inventory.log` | pass |
| feature UI-090 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-090 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-090 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-090 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-091 name present | `o28-stage1-inventory.log` | pass |
| feature UI-091 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-091 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-091 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-091 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-092 name present | `o28-stage1-inventory.log` | pass |
| feature UI-092 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-092 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-092 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-092 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-093 name present | `o28-stage1-inventory.log` | pass |
| feature UI-093 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-093 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-093 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-093 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-094 name present | `o28-stage1-inventory.log` | pass |
| feature UI-094 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-094 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-094 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-094 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-095 name present | `o28-stage1-inventory.log` | pass |
| feature UI-095 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-095 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-095 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-095 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-096 name present | `o28-stage1-inventory.log` | pass |
| feature UI-096 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-096 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-096 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-096 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-097 name present | `o28-stage1-inventory.log` | pass |
| feature UI-097 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-097 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-097 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-097 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-098 name present | `o28-stage1-inventory.log` | pass |
| feature UI-098 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-098 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-098 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-098 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-099 name present | `o28-stage1-inventory.log` | pass |
| feature UI-099 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-099 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-099 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-099 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-100 name present | `o28-stage1-inventory.log` | pass |
| feature UI-100 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-100 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-100 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-100 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-101 name present | `o28-stage1-inventory.log` | pass |
| feature UI-101 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-101 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-101 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-101 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-102 name present | `o28-stage1-inventory.log` | pass |
| feature UI-102 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-102 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-102 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-102 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-103 name present | `o28-stage1-inventory.log` | pass |
| feature UI-103 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-103 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-103 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-103 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-104 name present | `o28-stage1-inventory.log` | pass |
| feature UI-104 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-104 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-104 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-104 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-105 name present | `o28-stage1-inventory.log` | pass |
| feature UI-105 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-105 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-105 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-105 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-106 name present | `o28-stage1-inventory.log` | pass |
| feature UI-106 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-106 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-106 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-106 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-107 name present | `o28-stage1-inventory.log` | pass |
| feature UI-107 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-107 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-107 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-107 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-108 name present | `o28-stage1-inventory.log` | pass |
| feature UI-108 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-108 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-108 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-108 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-109 name present | `o28-stage1-inventory.log` | pass |
| feature UI-109 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-109 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-109 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-109 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-110 name present | `o28-stage1-inventory.log` | pass |
| feature UI-110 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-110 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-110 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-110 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-111 name present | `o28-stage1-inventory.log` | pass |
| feature UI-111 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-111 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-111 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-111 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-112 name present | `o28-stage1-inventory.log` | pass |
| feature UI-112 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-112 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-112 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-112 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-113 name present | `o28-stage1-inventory.log` | pass |
| feature UI-113 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-113 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-113 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-113 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-114 name present | `o28-stage1-inventory.log` | pass |
| feature UI-114 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-114 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-114 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-114 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature UI-115 name present | `o28-stage1-inventory.log` | pass |
| feature UI-115 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-115 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature UI-115 test area assigned | `o28-stage1-inventory.log` | pass |
| feature UI-115 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-001 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-001 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-002 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-002 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-003 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-003 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-004 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-004 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-005 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-005 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-006 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-006 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-007 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-008 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-008 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-009 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-009 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-010 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-010 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-011 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-011 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-012 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-012 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-013 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-013 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-014 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-014 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-015 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-015 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-016 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-016 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-017 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-017 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-018 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-019 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-020 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-021 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-022 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-023 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-024 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-025 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-026 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-026 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-027 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-027 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-028 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-028 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-029 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-029 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-030 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-030 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-031 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-031 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-032 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-032 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-033 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-033 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-034 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-034 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-035 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-035 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-036 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-036 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-037 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-037 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-038 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-039 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-039 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-040 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-040 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature AUTH-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-041 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-041 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature AUTH-042 name present | `o28-stage1-inventory.log` | pass |
| feature AUTH-042 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature AUTH-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature AUTH-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature AUTH-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-001 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-001 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-002 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-002 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-003 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-003 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-004 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-004 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-005 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-005 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-006 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-006 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-007 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-008 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-008 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-009 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-009 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-010 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-010 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-011 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-011 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-012 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-012 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-013 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-013 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-014 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-014 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-015 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-015 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-016 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-017 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-018 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-019 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-020 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-021 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-022 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-023 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-024 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-024 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-025 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-026 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-026 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-027 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-027 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-028 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-029 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-029 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-030 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-030 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-031 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-031 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-032 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-032 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-033 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-033 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-034 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-034 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-035 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-035 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-036 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-036 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-037 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-037 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-038 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-039 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-039 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-040 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-040 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-041 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-041 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-042 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-042 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-043 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-043 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-044 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-044 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-045 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-045 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-046 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-046 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-047 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-047 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-048 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-048 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-049 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-049 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-050 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-050 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-051 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-051 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-052 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-052 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-053 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-053 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-054 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-054 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-055 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-055 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-056 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-056 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-057 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-057 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-058 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-058 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-059 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-059 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-060 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-060 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-061 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-061 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-062 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-062 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-063 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-063 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-064 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-064 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SRC-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-065 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-065 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-066 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-066 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-067 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-067 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SRC-068 name present | `o28-stage1-inventory.log` | pass |
| feature SRC-068 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SRC-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SRC-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SRC-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-001 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-001 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-002 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-002 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-003 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-003 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-004 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-004 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-005 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-005 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-006 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-006 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-007 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-008 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-008 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-009 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-009 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-010 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-010 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-011 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-011 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-012 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-012 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-013 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-013 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-014 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-014 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-015 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-015 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-016 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-017 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-018 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-019 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-020 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-021 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-022 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-023 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-024 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-025 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-026 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-026 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-027 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-027 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-028 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-029 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-029 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-030 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-030 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-031 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-031 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-032 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-032 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-033 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-033 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-034 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-034 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-035 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-035 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-036 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-036 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-037 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-037 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-038 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-039 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-039 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-040 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-040 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-041 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-041 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-042 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-042 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-043 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-043 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-044 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-044 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-045 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-045 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-046 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-046 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-047 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-047 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-048 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-048 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-049 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-049 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-050 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-050 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-051 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-051 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-052 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-052 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-053 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-053 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-054 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-054 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-055 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-055 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-056 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-056 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-057 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-057 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-058 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-058 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-059 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-059 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-060 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-060 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-061 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-061 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-062 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-062 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-063 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-063 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-064 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-064 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-065 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-065 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-066 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-066 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-067 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-067 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-068 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-068 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-069 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-069 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-070 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-070 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-071 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-071 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-072 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-072 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-073 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-073 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-074 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-074 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-075 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-075 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-076 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-076 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-077 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-077 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-078 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-078 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-079 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-079 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-080 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-080 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-081 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-081 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-082 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-082 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-083 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-083 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-084 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-084 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-085 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-085 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-086 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-086 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-087 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-087 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-088 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-088 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-088 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-088 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-088 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-089 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-089 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-089 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-089 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-089 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-090 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-090 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-090 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-090 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-090 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-091 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-091 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-091 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-091 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-091 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-092 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-092 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-092 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-092 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-092 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-093 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-093 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-093 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-093 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-093 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-094 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-094 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-094 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-094 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-094 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-095 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-095 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-095 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-095 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-095 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-096 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-096 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-096 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-096 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-096 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-097 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-097 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-097 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-097 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-097 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-098 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-098 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-098 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-098 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-098 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-099 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-099 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature RULE-099 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-099 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-099 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-100 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-100 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-100 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-100 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-100 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-101 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-101 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-101 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-101 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-101 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-102 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-102 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-102 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-102 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-102 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-103 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-103 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-103 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-103 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-103 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-104 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-104 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-104 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-104 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-104 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-105 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-105 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-105 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-105 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-105 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-106 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-106 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-106 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-106 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-106 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-107 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-107 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-107 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-107 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-107 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-108 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-108 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-108 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-108 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-108 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-109 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-109 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-109 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-109 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-109 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-110 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-110 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature RULE-110 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-110 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-110 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-111 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-111 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-111 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-111 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-111 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature RULE-112 name present | `o28-stage1-inventory.log` | pass |
| feature RULE-112 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature RULE-112 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature RULE-112 test area assigned | `o28-stage1-inventory.log` | pass |
| feature RULE-112 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-001 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-001 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-002 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-002 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-003 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-003 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-004 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-004 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-005 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-005 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature EVT-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-006 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-006 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature EVT-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-007 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-008 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-008 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-009 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-009 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-010 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-010 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-011 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-011 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-012 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-012 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-013 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-013 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-014 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-014 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature EVT-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-015 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-015 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-016 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-017 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-018 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-019 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-020 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-021 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-022 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-023 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-024 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-025 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-026 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-026 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-027 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-027 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-028 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-029 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-029 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-030 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-030 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-031 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-031 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-032 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-032 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-033 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-033 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-034 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-034 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-035 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-035 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature EVT-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-036 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-036 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature EVT-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-037 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-037 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-038 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-039 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-039 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-040 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-040 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-041 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-041 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-042 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-042 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-043 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-043 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-044 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-044 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-045 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-045 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-046 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-046 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-047 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-047 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-048 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-048 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-049 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-049 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-050 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-050 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-051 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-051 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-052 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-052 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-053 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-053 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-054 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-054 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-055 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-055 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-056 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-056 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-057 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-057 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-058 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-058 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-059 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-059 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-060 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-060 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-061 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-061 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-062 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-062 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-063 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-063 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-064 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-064 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-065 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-065 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-066 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-066 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-067 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-067 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-068 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-068 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-069 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-069 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-070 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-070 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-071 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-071 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-072 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-072 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-073 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-073 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-074 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-074 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-075 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-075 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-076 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-076 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-077 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-077 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-078 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-078 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-079 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-079 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-080 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-080 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-081 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-081 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-082 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-082 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-083 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-083 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-084 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-084 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-085 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-085 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-086 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-086 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature EVT-087 name present | `o28-stage1-inventory.log` | pass |
| feature EVT-087 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature EVT-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature EVT-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature EVT-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-001 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-001 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-002 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-002 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-003 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-003 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-004 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-004 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-005 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-005 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-006 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-006 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-007 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-007 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-008 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-008 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-009 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-009 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-010 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-010 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-011 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-011 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-012 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-012 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-013 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-013 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-014 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-014 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-015 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-015 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-016 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-017 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-018 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-019 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-020 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-021 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-022 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-022 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-023 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-023 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-024 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-025 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-025 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-026 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-026 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-027 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-027 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-028 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-029 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-029 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-030 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-030 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-031 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-031 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-032 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-032 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-033 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-033 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-034 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-034 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-035 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-035 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-036 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-036 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-037 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-037 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-038 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-038 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-039 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-039 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-040 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-040 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-041 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-041 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-042 name present | `o28-stage1-inventory.log` | pass |
| feature CLIENT-042 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature CLIENT-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature CLIENT-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-001 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-001 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-002 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-002 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-003 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-003 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-004 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-004 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-005 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-005 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-006 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-006 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-007 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-007 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-008 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-008 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-009 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-009 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-010 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-010 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-011 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-011 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-012 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-012 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-013 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-013 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-014 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-014 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-015 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-015 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-016 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-016 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-017 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-017 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-018 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-018 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-019 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-019 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-020 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-020 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-021 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-021 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-022 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-022 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-023 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-023 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-024 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-024 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-025 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-025 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-026 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-026 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-027 name present | `o28-stage1-inventory.log` | pass |
| feature MEDIA-027 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature MEDIA-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature MEDIA-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-001 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-001 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-002 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-002 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-003 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-003 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-004 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-004 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-005 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-005 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-006 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-006 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-007 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-007 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-008 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-008 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-009 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-009 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-010 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-010 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-011 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-011 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-012 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-012 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-013 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-013 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-014 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-014 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-015 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-015 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-016 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-016 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-017 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-017 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-018 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-018 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-019 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-019 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-020 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-020 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-021 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-021 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-022 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-022 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-023 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-023 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-024 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-024 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-025 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-025 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-026 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-026 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-027 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-027 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-028 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-028 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-029 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-029 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-030 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-030 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-031 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-031 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-032 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-032 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-033 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-033 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-034 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-034 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-035 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-035 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-036 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-036 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-037 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-037 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-038 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-038 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-039 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-039 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-040 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-040 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-041 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-041 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-042 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-042 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-043 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-043 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-044 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-044 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-045 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-045 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-046 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-046 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-047 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-047 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-048 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-048 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-049 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-049 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-050 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-050 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-051 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-051 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-052 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-052 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-053 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-053 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-054 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-054 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-055 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-055 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-056 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-056 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-057 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-057 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-058 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-058 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-059 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-059 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-060 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-060 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-061 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-061 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-062 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-062 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-063 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-063 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-064 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-064 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-065 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-065 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-066 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-066 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-067 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-067 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-068 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-068 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-069 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-069 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-070 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-070 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-071 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-071 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-072 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-072 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-073 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-073 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-074 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-074 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-075 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-075 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-076 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-076 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-077 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-077 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-078 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-078 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-079 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-079 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-080 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-080 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-081 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-081 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-082 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-082 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-083 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-083 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-084 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-084 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-085 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-085 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-086 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-086 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-087 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-087 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-088 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-088 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-088 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-088 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-088 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-089 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-089 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-089 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-089 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-089 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-090 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-090 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-090 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-090 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-090 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-091 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-091 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-091 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-091 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-091 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-092 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-092 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-092 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-092 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-092 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-093 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-093 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-093 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-093 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-093 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-094 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-094 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-094 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-094 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-094 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-095 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-095 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-095 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-095 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-095 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-096 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-096 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-096 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-096 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-096 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-097 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-097 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-097 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-097 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-097 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-098 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-098 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-098 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-098 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-098 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-099 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-099 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-099 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-099 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-099 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-100 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-100 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-100 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-100 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-100 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-101 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-101 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-101 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-101 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-101 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-102 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-102 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-102 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-102 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-102 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-103 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-103 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-103 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-103 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-103 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-104 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-104 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-104 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-104 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-104 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-105 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-105 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-105 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-105 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-105 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-106 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-106 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-106 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-106 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-106 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-107 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-107 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-107 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-107 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-107 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-108 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-108 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-108 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-108 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-108 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-109 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-109 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-109 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-109 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-109 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-110 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-110 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-110 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-110 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-110 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-111 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-111 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-111 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-111 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-111 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-112 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-112 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-112 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-112 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-112 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-113 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-113 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-113 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-113 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-113 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-114 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-114 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-114 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-114 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-114 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-115 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-115 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-115 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-115 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-115 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-116 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-116 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-116 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-116 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-116 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-117 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-117 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-117 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-117 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-117 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-118 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-118 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-118 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-118 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-118 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-119 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-119 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-119 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-119 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-119 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-120 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-120 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-120 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-120 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-120 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-121 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-121 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-121 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-121 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-121 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-122 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-122 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-122 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-122 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-122 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-123 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-123 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-123 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-123 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-123 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-124 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-124 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-124 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-124 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-124 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-125 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-125 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-125 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-125 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-125 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature LAB-126 name present | `o28-stage1-inventory.log` | pass |
| feature LAB-126 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature LAB-126 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature LAB-126 test area assigned | `o28-stage1-inventory.log` | pass |
| feature LAB-126 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-001 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-001 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-001 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-001 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-001 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-002 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-002 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-002 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-002 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-002 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-003 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-003 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-003 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-003 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-003 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-004 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-004 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-004 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-004 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-004 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-005 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-005 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-005 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-005 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-005 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-006 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-006 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-006 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-006 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-006 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-007 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-007 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-007 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-007 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-007 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-008 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-008 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-008 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-008 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-008 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-009 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-009 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-009 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-009 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-009 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-010 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-010 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-010 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-010 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-010 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-011 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-011 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-011 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-011 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-011 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-012 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-012 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-012 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-012 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-012 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-013 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-013 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-013 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-013 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-013 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-014 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-014 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-014 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-014 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-014 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-015 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-015 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-015 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-015 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-015 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-016 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-016 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SAFE-016 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-016 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-016 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-017 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-017 UI need 간접 | `o28-stage1-inventory.log` | pass |
| feature SAFE-017 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-017 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-017 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-018 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-018 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-018 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-018 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-018 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-019 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-019 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-019 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-019 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-019 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-020 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-020 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-020 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-020 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-020 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-021 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-021 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-021 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-021 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-021 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-022 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-022 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-022 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-022 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-022 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-023 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-023 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-023 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-023 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-023 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-024 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-024 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-024 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-024 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-024 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-025 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-025 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-025 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-025 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-025 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-026 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-026 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-026 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-026 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-026 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-027 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-027 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-027 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-027 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-027 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-028 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-028 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-028 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-028 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-028 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-029 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-029 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-029 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-029 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-029 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-030 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-030 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-030 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-030 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-030 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-031 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-031 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-031 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-031 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-031 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-032 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-032 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-032 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-032 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-032 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-033 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-033 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-033 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-033 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-033 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-034 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-034 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-034 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-034 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-034 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-035 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-035 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-036 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-036 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-037 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-037 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-038 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-038 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-039 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-039 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-040 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-040 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-041 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-041 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-042 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-042 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-043 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-043 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-044 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-044 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-045 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-045 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-046 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-046 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-047 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-047 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-048 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-048 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-049 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-049 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-050 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-050 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-051 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-051 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-052 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-052 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-053 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-053 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-054 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-054 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-055 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-055 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-056 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-056 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-057 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-057 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-058 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-058 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-059 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-059 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-060 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-060 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-061 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-061 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-062 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-062 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-063 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-063 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-064 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-064 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-065 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-065 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-066 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-066 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-067 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-067 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-068 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-068 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-069 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-069 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-070 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-070 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-071 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-071 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-072 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-072 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-073 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-073 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-074 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-074 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-075 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-075 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-076 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-076 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-077 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-077 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-078 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-078 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-079 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-079 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-080 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-080 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-081 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-081 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-082 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-082 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-083 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-083 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-084 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-084 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-085 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-085 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-086 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-086 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-087 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-087 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-088 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-088 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-088 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-088 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-088 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-089 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-089 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-089 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-089 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-089 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-090 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-090 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-090 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-090 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-090 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-091 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-091 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-091 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-091 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-091 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-092 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-092 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-092 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-092 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-092 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-093 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-093 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-093 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-093 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-093 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-094 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-094 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-094 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-094 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-094 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-095 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-095 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-095 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-095 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-095 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-096 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-096 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-096 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-096 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-096 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-097 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-097 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-097 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-097 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-097 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-098 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-098 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-098 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-098 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-098 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-099 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-099 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-099 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-099 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-099 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-100 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-100 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-100 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-100 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-100 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-101 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-101 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-101 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-101 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-101 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-102 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-102 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-102 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-102 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-102 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-103 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-103 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-103 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-103 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-103 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-104 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-104 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-104 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-104 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-104 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-105 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-105 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-105 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-105 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-105 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-106 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-106 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-106 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-106 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-106 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-107 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-107 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-107 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-107 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-107 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-108 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-108 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-108 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-108 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-108 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-109 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-109 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-109 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-109 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-109 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-110 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-110 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-110 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-110 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-110 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-111 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-111 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-111 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-111 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-111 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-112 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-112 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-112 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-112 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-112 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-113 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-113 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-113 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-113 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-113 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-114 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-114 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-114 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-114 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-114 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-115 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-115 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-115 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-115 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-115 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-116 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-116 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-116 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-116 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-116 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-117 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-117 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-117 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-117 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-117 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-118 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-118 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-118 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-118 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-118 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-119 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-119 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-119 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-119 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-119 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-120 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-120 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-120 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-120 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-120 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-121 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-121 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-121 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-121 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-121 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-122 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-122 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-122 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-122 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-122 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-123 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-123 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-123 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-123 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-123 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-124 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-124 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-124 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-124 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-124 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-125 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-125 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-125 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-125 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-125 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-126 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-126 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-126 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-126 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-126 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-127 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-127 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-127 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-127 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-127 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-128 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-128 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-128 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-128 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-128 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-129 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-129 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-129 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-129 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-129 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-130 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-130 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-130 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-130 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-130 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-131 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-131 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-131 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-131 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-131 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-132 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-132 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-132 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-132 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-132 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-133 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-133 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-133 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-133 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-133 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-134 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-134 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-134 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-134 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-134 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-135 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-135 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-135 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-135 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-135 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-136 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-136 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-136 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-136 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-136 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-137 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-137 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-137 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-137 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-137 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-138 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-138 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-138 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-138 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-138 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-139 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-139 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-139 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-139 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-139 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-140 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-140 UI need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-140 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-140 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-140 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-141 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-141 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-141 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-141 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-141 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-142 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-142 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-142 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-142 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-142 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-143 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-143 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-143 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-143 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-143 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-144 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-144 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-144 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-144 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-144 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-145 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-145 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-145 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-145 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-145 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-146 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-146 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-146 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-146 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-146 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-147 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-147 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-147 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-147 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-147 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-148 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-148 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-148 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-148 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-148 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-149 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-149 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-149 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-149 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-149 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-150 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-150 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-150 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-150 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-150 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-151 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-151 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-151 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-151 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-151 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-152 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-152 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-152 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-152 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-152 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-153 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-153 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-153 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-153 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-153 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-154 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-154 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-154 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-154 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-154 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-155 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-155 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-155 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-155 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-155 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-156 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-156 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-156 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-156 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-156 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-157 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-157 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-157 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-157 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-157 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-158 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-158 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-158 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-158 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-158 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-159 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-159 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-159 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-159 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-159 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-160 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-160 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-160 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-160 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-160 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-161 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-161 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-161 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-161 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-161 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-162 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-162 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-162 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-162 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-162 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-163 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-163 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-163 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-163 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-163 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-164 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-164 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-164 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-164 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-164 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-165 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-165 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-165 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-165 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-165 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-166 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-166 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-166 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-166 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-166 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-167 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-167 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-167 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-167 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-167 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-168 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-168 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-168 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-168 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-168 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-169 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-169 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-169 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-169 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-169 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-170 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-170 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-170 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-170 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-170 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-171 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-171 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-171 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-171 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-171 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-172 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-172 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-172 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-172 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-172 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-173 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-173 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-173 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-173 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-173 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-174 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-174 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-174 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-174 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-174 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-175 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-175 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-175 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-175 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-175 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-176 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-176 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-176 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-176 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-176 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-177 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-177 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-177 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-177 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-177 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-178 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-178 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-178 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-178 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-178 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-179 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-179 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-179 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-179 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-179 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-180 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-180 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-180 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-180 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-180 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-181 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-181 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-181 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-181 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-181 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-182 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-182 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-182 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-182 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-182 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-183 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-183 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-183 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-183 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-183 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-184 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-184 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-184 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-184 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-184 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-185 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-185 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-185 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-185 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-185 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-186 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-186 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-186 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-186 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-186 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-187 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-187 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-187 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-187 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-187 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-188 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-188 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-188 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-188 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-188 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-189 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-189 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-189 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-189 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-189 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-190 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-190 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-190 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-190 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-190 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-191 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-191 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-191 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-191 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-191 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-192 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-192 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-192 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-192 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-192 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-193 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-193 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-193 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-193 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-193 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-194 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-194 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-194 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-194 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-194 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-195 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-195 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-195 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-195 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-195 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-196 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-196 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-196 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-196 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-196 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-197 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-197 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-197 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-197 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-197 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-198 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-198 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-198 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-198 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-198 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-199 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-199 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-199 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-199 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-199 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-200 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-200 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-200 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-200 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-200 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-201 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-201 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-201 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-201 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-201 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-202 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-202 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-202 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-202 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-202 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-203 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-203 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-203 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-203 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-203 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-204 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-204 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-204 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-204 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-204 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-205 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-205 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-205 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-205 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-205 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-206 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-206 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-206 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-206 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-206 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-207 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-207 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-207 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-207 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-207 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-208 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-208 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-208 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-208 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-208 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-209 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-209 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-209 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-209 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-209 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-210 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-210 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-210 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-210 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-210 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-211 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-211 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-211 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-211 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-211 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-212 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-212 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-212 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-212 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-212 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-213 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-213 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-213 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-213 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-213 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-214 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-214 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-214 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-214 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-214 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-215 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-215 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-215 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-215 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-215 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-216 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-216 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-216 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-216 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-216 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature SAFE-217 name present | `o28-stage1-inventory.log` | pass |
| feature SAFE-217 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature SAFE-217 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature SAFE-217 test area assigned | `o28-stage1-inventory.log` | pass |
| feature SAFE-217 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-035 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-035 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-035 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-035 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-035 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-036 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-036 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-036 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-036 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-036 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-037 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-037 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-037 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-037 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-037 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-038 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-038 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-038 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-038 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-038 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-039 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-039 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-039 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-039 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-039 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-040 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-040 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-040 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-040 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-040 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-041 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-041 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-041 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-041 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-041 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-042 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-042 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-042 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-042 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-042 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-043 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-043 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-043 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-043 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-043 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-044 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-044 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-044 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-044 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-044 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-045 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-045 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-045 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-045 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-045 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-046 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-046 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-046 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-046 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-046 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-047 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-047 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-047 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-047 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-047 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-048 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-048 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-048 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-048 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-048 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-049 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-049 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-049 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-049 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-049 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-050 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-050 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-050 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-050 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-050 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-051 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-051 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-051 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-051 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-051 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-052 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-052 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-052 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-052 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-052 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-053 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-053 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-053 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-053 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-053 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-054 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-054 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-054 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-054 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-054 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-055 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-055 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-055 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-055 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-055 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-056 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-056 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-056 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-056 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-056 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-057 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-057 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-057 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-057 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-057 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-058 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-058 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-058 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-058 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-058 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-059 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-059 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-059 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-059 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-059 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-060 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-060 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-060 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-060 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-060 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-061 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-061 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-061 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-061 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-061 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-062 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-062 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-062 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-062 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-062 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-063 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-063 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-063 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-063 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-063 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-064 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-064 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-064 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-064 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-064 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-065 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-065 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-065 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-065 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-065 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-066 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-066 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-066 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-066 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-066 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-067 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-067 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-067 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-067 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-067 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-068 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-068 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-068 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-068 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-068 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-069 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-069 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-069 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-069 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-069 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-070 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-070 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-070 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-070 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-070 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-071 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-071 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-071 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-071 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-071 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-072 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-072 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-072 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-072 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-072 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-073 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-073 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-073 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-073 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-073 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-074 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-074 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-074 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-074 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-074 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-075 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-075 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-075 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-075 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-075 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-076 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-076 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-076 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-076 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-076 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-077 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-077 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-077 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-077 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-077 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-078 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-078 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-078 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-078 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-078 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-079 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-079 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-079 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-079 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-079 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-080 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-080 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-080 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-080 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-080 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-081 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-081 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-081 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-081 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-081 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-082 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-082 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-082 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-082 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-082 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-083 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-083 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-083 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-083 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-083 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-084 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-084 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-084 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-084 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-084 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-085 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-085 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-085 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-085 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-085 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-086 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-086 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-086 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-086 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-086 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-087 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-087 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-087 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-087 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-087 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-088 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-088 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-088 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-088 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-088 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-089 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-089 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-089 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-089 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-089 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-090 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-090 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-090 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-090 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-090 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-091 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-091 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-091 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-091 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-091 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-092 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-092 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-092 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-092 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-092 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-093 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-093 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-093 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-093 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-093 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-094 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-094 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-094 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-094 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-094 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-095 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-095 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-095 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-095 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-095 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-096 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-096 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-096 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-096 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-096 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-097 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-097 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-097 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-097 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-097 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-098 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-098 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-098 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-098 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-098 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-099 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-099 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-099 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-099 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-099 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-100 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-100 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-100 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-100 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-100 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-101 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-101 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-101 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-101 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-101 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-102 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-102 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-102 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-102 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-102 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-103 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-103 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-103 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-103 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-103 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-104 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-104 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-104 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-104 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-104 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-105 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-105 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-105 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-105 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-105 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-106 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-106 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-106 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-106 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-106 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-107 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-107 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-107 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-107 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-107 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-108 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-108 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-108 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-108 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-108 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-109 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-109 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-109 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-109 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-109 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-110 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-110 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-110 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-110 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-110 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-111 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-111 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-111 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-111 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-111 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-112 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-112 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-112 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-112 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-112 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-113 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-113 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-113 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-113 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-113 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-114 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-114 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-114 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-114 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-114 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-115 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-115 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-115 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-115 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-115 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-116 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-116 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-116 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-116 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-116 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-117 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-117 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-117 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-117 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-117 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-118 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-118 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-118 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-118 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-118 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-119 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-119 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-119 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-119 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-119 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-120 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-120 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-120 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-120 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-120 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-121 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-121 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-121 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-121 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-121 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-122 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-122 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-122 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-122 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-122 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-123 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-123 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-123 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-123 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-123 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-124 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-124 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-124 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-124 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-124 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-125 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-125 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-125 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-125 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-125 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-126 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-126 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-126 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-126 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-126 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-127 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-127 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-127 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-127 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-127 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-128 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-128 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-128 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-128 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-128 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-129 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-129 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-129 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-129 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-129 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-130 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-130 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-130 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-130 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-130 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-131 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-131 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-131 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-131 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-131 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-132 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-132 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-132 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-132 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-132 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-133 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-133 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-133 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-133 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-133 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-134 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-134 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-134 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-134 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-134 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-135 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-135 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-135 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-135 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-135 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-136 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-136 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-136 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-136 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-136 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-137 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-137 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-137 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-137 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-137 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-138 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-138 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-138 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-138 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-138 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-139 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-139 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-139 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-139 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-139 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-140 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-140 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-140 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-140 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-140 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-141 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-141 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-141 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-141 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-141 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-142 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-142 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-142 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-142 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-142 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-143 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-143 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-143 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-143 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-143 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-144 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-144 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-144 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-144 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-144 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-145 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-145 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-145 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-145 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-145 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-146 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-146 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-146 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-146 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-146 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-147 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-147 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-147 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-147 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-147 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-148 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-148 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-148 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-148 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-148 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-149 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-149 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-149 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-149 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-149 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-150 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-150 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-150 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-150 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-150 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-151 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-151 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-151 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-151 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-151 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-152 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-152 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-152 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-152 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-152 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-153 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-153 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-153 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-153 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-153 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-154 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-154 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-154 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-154 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-154 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-155 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-155 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-155 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-155 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-155 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-156 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-156 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-156 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-156 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-156 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-157 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-157 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-157 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-157 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-157 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-158 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-158 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-158 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-158 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-158 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-159 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-159 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-159 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-159 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-159 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-160 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-160 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-160 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-160 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-160 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-161 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-161 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-161 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-161 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-161 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-162 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-162 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-162 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-162 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-162 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-163 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-163 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-163 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-163 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-163 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-164 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-164 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-164 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-164 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-164 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-165 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-165 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-165 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-165 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-165 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-166 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-166 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-166 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-166 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-166 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-167 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-167 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-167 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-167 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-167 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-168 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-168 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-168 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-168 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-168 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-169 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-169 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-169 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-169 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-169 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-170 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-170 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-170 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-170 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-170 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-171 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-171 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-171 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-171 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-171 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-172 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-172 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-172 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-172 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-172 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-173 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-173 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-173 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-173 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-173 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-174 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-174 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-174 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-174 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-174 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-175 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-175 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-175 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-175 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-175 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-176 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-176 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-176 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-176 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-176 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-177 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-177 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-177 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-177 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-177 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-178 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-178 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-178 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-178 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-178 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-179 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-179 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-179 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-179 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-179 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-180 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-180 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-180 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-180 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-180 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-181 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-181 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-181 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-181 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-181 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-182 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-182 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-182 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-182 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-182 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-183 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-183 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-183 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-183 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-183 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature OPS-184 name present | `o28-stage1-inventory.log` | pass |
| feature OPS-184 UI need 비대상 | `o28-stage1-inventory.log` | pass |
| feature OPS-184 test need 필요 | `o28-stage1-inventory.log` | pass |
| feature OPS-184 test area assigned | `o28-stage1-inventory.log` | pass |
| feature OPS-184 pass criteria present | `o28-stage1-inventory.log` | pass |
| feature rows have required matrix columns | `o28-stage1-inventory.log` | pass |
| inventory rejects separate test-area labels | `o28-stage1-inventory.log` | pass |
| coverage wording separates mapping from execution | `o28-stage1-inventory.log` | pass |
| current feature expansion rows exist | `o28-stage1-inventory.log` | pass |
| manual UI docs reference inventory | `o28-stage1-inventory.log` | pass |
| manual checklist references seed fixture | `o28-stage1-inventory.log` | pass |
| manual result template references seed fixture | `o28-stage1-inventory.log` | pass |
| VA seed inventory commands select the latest published baseline explicitly | `o28-stage1-inventory.log` | pass |
| AGENTS requires individual future feature test rows | `o28-stage1-inventory.log` | pass |
| manual UI seed account role admin | `o28-stage1-inventory.log` | pass |
| manual UI seed account role operator | `o28-stage1-inventory.log` | pass |
| manual UI seed account role viewer | `o28-stage1-inventory.log` | pass |
| manual UI seed account role integrator | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9101 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9101 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9102 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9102 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9103 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9103 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9104 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9104 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9105 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9105 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9106 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9106 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9107 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed profile 9107 tracking classes present | `o28-stage1-inventory.log` | pass |
| manual UI seed event type presence | `o28-stage1-inventory.log` | pass |
| manual UI seed event type enter | `o28-stage1-inventory.log` | pass |
| manual UI seed event type exit | `o28-stage1-inventory.log` | pass |
| manual UI seed event type line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event type intrusion-dwell | `o28-stage1-inventory.log` | pass |
| manual UI seed event type re-entry | `o28-stage1-inventory.log` | pass |
| manual UI seed event type wrong-direction | `o28-stage1-inventory.log` | pass |
| manual UI seed event type intrusion-after-line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event type loitering | `o28-stage1-inventory.log` | pass |
| manual UI seed event type zone-occupancy | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9201 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9201 event type presence | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9201 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9202 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9202 event type enter | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9202 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9203 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9203 event type exit | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9203 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9204 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9204 event type line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9204 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9205 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9205 event type line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9205 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9206 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9206 event type line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9206 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9207 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9207 event type intrusion-dwell | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9207 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9208 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9208 event type re-entry | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9208 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9209 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9209 event type wrong-direction | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9209 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9210 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9210 event type intrusion-after-line-crossing | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9210 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9211 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9211 event type loitering | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9211 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9212 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9212 event type zone-occupancy | `o28-stage1-inventory.log` | pass |
| manual UI seed event template 9212 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed line direction any | `o28-stage1-inventory.log` | pass |
| manual UI seed line direction forward | `o28-stage1-inventory.log` | pass |
| manual UI seed line direction reverse | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset default | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset road | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset retail | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset park | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset indoor | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset lobby | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset platform | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset entrance | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset doorway | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset parking | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset elevator | `o28-stage1-inventory.log` | pass |
| manual UI seed scenario preset custom | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9301 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9301 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9301 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9302 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9302 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9302 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9303 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9303 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9303 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9304 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9304 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9304 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9305 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9305 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9305 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9306 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9306 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9306 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9307 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9307 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9307 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9308 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9308 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9308 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9309 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9309 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9309 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9310 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9310 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9310 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9311 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9311 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9311 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9312 numeric id | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9312 profile reference | `o28-stage1-inventory.log` | pass |
| manual UI seed vaRule 9312 event template reference | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair none/off | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair lite/off | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair kalman-lite/off | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair bytetrack/off | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair lite/assist | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair kalman-lite/assist | `o28-stage1-inventory.log` | pass |
| manual UI seed tracker Re-ID pair bytetrack/assist | `o28-stage1-inventory.log` | pass |
| manual UI seed invalid policy tracker none Re-ID assist | `o28-stage1-inventory.log` | pass |
| manual UI seed final state minimum vaRules | `o28-stage1-inventory.log` | pass |
| manual UI VA seed matrix covers required current release cases | `o28-stage1-inventory.log` | pass |
| 구문·공백 검사 exit 0 | `o28-syntax-diffcheck-20260924.log` | pass |

## 원출력 총계

| 원출력 | pass | fail |
| --- | --- | --- |
| `o28-diagnostic-profile-green1-20260924.log` | 8 | 0 |
| `o28-diagnostic-profile-green2-20260924.log` | 8 | 0 |
| `o28-diagnostic-profile-green3-20260924.log` | 8 | 0 |
| `o28-diagnostic-profile-red1-20260924.log` | 7 | 1 |
| `o28-longrun-diagnostics-green1-20260924.log` | 8 | 0 |
| `o28-observer-selftest-diagnose2-20260924.log` | 11 | 1 |
| `o28-observer-selftest-green3-20260924.log` | 65 | 0 |
| `o28-observer-selftest-redgreen1-20260924.log` | 0 | 1 |
| `o28-observer-selftest-run1-20260924.log` | 11 | 1 |
| `o28-stage1-coverage.log` | 8 | 0 |
| `o28-stage1-docs-assets.log` | 10 | 0 |
| `o28-stage1-inventory.log` | 5081 | 0 |
| `o28-syntax-diffcheck-20260924.log` | 1 | 0 |
