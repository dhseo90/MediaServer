# O28 2번 개별 실행 결과

원출력의 체크마크/TAP/행 결과를 전수 변환한다. 실패 뒤 실패 상세 재출력은 중복 집계하지 않는다. 빈 원출력은 PASS 근거로 쓰지 않는다. 과거 실행은 당시 코드의 증거이며 최신 focused/native/정적 결과와 분리한다.

## o28-stage2-accumulation-followup-green1-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.721709ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.139166ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.441666ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.279459ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.153458ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (24.448667ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (9.592875ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (8.880958ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.333416ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (17.745333ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 11 | O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.103833ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 12 | O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.950542ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 13 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (7.574458ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 14 | LP23-DH05 changed original or unconfirmed child blocks cleanup (1.144292ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 15 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (509.060625ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 16 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.982375ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 17 | LP26-O09-A02 identity·clock·pid 불일치 (0.096333ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 18 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.28875ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 19 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.264583ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 20 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.073959ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 21 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.234833ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 22 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.141959ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 23 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.090042ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 24 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.073666ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
| 25 | O28-R04 accumulation runner와 EXIT는 사전 manifest·최초 실패·미종료 group을 보존한다 (0.132208ms) | pass | o28-stage2-accumulation-followup-green1-20260924.log |
## o28-stage2-accumulation-followup-static-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
## o28-stage2-accumulation-safety-green1-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.774334ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.141666ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.419ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.325333ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.164417ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (26.247417ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.745792ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (8.9295ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.168583ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.37ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 11 | O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.479042ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 12 | O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (8.884917ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 13 | O28-R04 실제 synthetic descendant group은 guard가 종료·확인 (26.589ms) | fail | o28-stage2-accumulation-safety-green1-20260924.log |
| 14 | O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.878125ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 15 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (7.137ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 16 | LP23-DH05 changed original or unconfirmed child blocks cleanup (0.904541ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 17 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (369.080792ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 18 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.894875ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 19 | LP26-O09-A02 identity·clock·pid 불일치 (0.095709ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 20 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.314084ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 21 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.251791ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 22 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.067167ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 23 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.236083ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 24 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.20075ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 25 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.106ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 26 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.086792ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
| 27 | O28-R04 accumulation runner와 EXIT는 사전 manifest·parent/child 실패·미종료 group을 보존한다 (0.163959ms) | pass | o28-stage2-accumulation-safety-green1-20260924.log |
## o28-stage2-accumulation-safety-green2-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.669458ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.165667ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.724709ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.263584ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.147ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (23.556958ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.536166ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (8.921959ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.151583ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (17.473541ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 11 | O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.360083ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 12 | O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (7.995417ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 13 | O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (2.898667ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 14 | O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.768ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 15 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.570958ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 16 | LP23-DH05 changed original or unconfirmed child blocks cleanup (0.814042ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 17 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (338.395833ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 18 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.837291ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 19 | LP26-O09-A02 identity·clock·pid 불일치 (0.0875ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 20 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.390584ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 21 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.290916ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 22 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.074167ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 23 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.219584ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 24 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.148458ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 25 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.085458ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 26 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.0685ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
| 27 | O28-R04 accumulation runner와 EXIT는 사전 manifest·parent/child 실패·미종료 group을 보존한다 (0.151375ms) | pass | o28-stage2-accumulation-safety-green2-20260924.log |
## o28-stage2-accumulation-safety-static-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
## o28-stage2-final-assets.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | README uses only representative product UI screenshots | pass | o28-stage2-final-assets.log |
| 2 | English README uses English UI screenshots | pass | o28-stage2-final-assets.log |
| 3 | UI guide keeps product screenshots in the shared asset set | pass | o28-stage2-final-assets.log |
| 4 | docs UI asset policy documents capture rules | pass | o28-stage2-final-assets.log |
| 5 | managed UI asset manifest stays complete | pass | o28-stage2-final-assets.log |
| 6 | capture script owns every documented UI asset | pass | o28-stage2-final-assets.log |
| 7 | docs capture covers current screenshots | pass | o28-stage2-final-assets.log |
| 8 | representative screenshot docs do not point at stale visual baselines | pass | o28-stage2-final-assets.log |
| 9 | docs UI asset directory contains managed PNG files | pass | o28-stage2-final-assets.log |
| 10 | VA documentation images keep full video frame bounds | pass | o28-stage2-final-assets.log |
## o28-stage2-final-coverage.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | S05 개별 동작 등록 exact 연결 (실행 증거 아님) | pass | o28-stage2-final-coverage.log |
| 2 | inventory row count is stable | pass | o28-stage2-final-coverage.log |
| 3 | inventory uses only the four approved test areas | pass | o28-stage2-final-coverage.log |
| 4 | coverage docs and server command are wired | pass | o28-stage2-final-coverage.log |
| 5 | exact implementation evidence manifest is valid | pass | o28-stage2-final-coverage.log |
| 6 | all feature IDs have exact coverage targets | pass | o28-stage2-final-coverage.log |
| 7 | negative missing-ID fixture fails | pass | o28-stage2-final-coverage.log |
| 8 | SAFE-200 canonical coverage wording truthfulness boundary | pass | o28-stage2-final-coverage.log |
## o28-stage2-final-diff.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
## o28-stage2-final-focused.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.661666ms) | pass | o28-stage2-final-focused.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.149542ms) | pass | o28-stage2-final-focused.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.580834ms) | pass | o28-stage2-final-focused.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.28025ms) | pass | o28-stage2-final-focused.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.156833ms) | pass | o28-stage2-final-focused.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (23.262166ms) | pass | o28-stage2-final-focused.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (9.971792ms) | pass | o28-stage2-final-focused.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (8.855166ms) | pass | o28-stage2-final-focused.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.56ms) | pass | o28-stage2-final-focused.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (18.343ms) | pass | o28-stage2-final-focused.log |
| 11 | O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.907875ms) | pass | o28-stage2-final-focused.log |
| 12 | O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (7.885208ms) | pass | o28-stage2-final-focused.log |
| 13 | O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (2.590125ms) | pass | o28-stage2-final-focused.log |
| 14 | O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.546834ms) | pass | o28-stage2-final-focused.log |
| 15 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.204ms) | pass | o28-stage2-final-focused.log |
| 16 | LP23-DH05 changed original or unconfirmed child blocks cleanup (0.675542ms) | pass | o28-stage2-final-focused.log |
| 17 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (518.179667ms) | pass | o28-stage2-final-focused.log |
| 18 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.765167ms) | pass | o28-stage2-final-focused.log |
| 19 | LP26-O09-A02 identity·clock·pid 불일치 (0.073583ms) | pass | o28-stage2-final-focused.log |
| 20 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.164958ms) | pass | o28-stage2-final-focused.log |
| 21 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.233166ms) | pass | o28-stage2-final-focused.log |
| 22 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.067542ms) | pass | o28-stage2-final-focused.log |
| 23 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.208833ms) | pass | o28-stage2-final-focused.log |
| 24 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.119458ms) | pass | o28-stage2-final-focused.log |
| 25 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.086792ms) | pass | o28-stage2-final-focused.log |
| 26 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.075083ms) | pass | o28-stage2-final-focused.log |
| 27 | O28-R04 accumulation runner와 EXIT는 사전 manifest·parent/child 실패·미종료 group을 보존한다 (0.144459ms) | pass | o28-stage2-final-focused.log |
## o28-stage2-final-inventory.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | S05 개별 동작 등록 exact 연결 (실행 증거 아님) | pass | o28-stage2-final-inventory.log |
| 2 | public docs index excludes internal feature inventory | pass | o28-stage2-final-inventory.log |
| 3 | feature inventory pins current release scope | pass | o28-stage2-final-inventory.log |
| 4 | required sections exist | pass | o28-stage2-final-inventory.log |
| 5 | historical V280 source-of-truth keeps the 2.x runway boundary explicit | pass | o28-stage2-final-inventory.log |
| 6 | historical V290 source-of-truth keeps source, published, and roadmap distinct | pass | o28-stage2-final-inventory.log |
| 7 | inventory summary count 전체 기능 항목 986 | pass | o28-stage2-final-inventory.log |
| 8 | inventory summary count UI 직접 필요 400 | pass | o28-stage2-final-inventory.log |
| 9 | inventory summary count UI 간접 필요 36 | pass | o28-stage2-final-inventory.log |
| 10 | inventory summary count UI 비대상 550 | pass | o28-stage2-final-inventory.log |
| 11 | inventory summary count 테스트 필요 986 | pass | o28-stage2-final-inventory.log |
| 12 | inventory summary count 안정화 대상 976 | pass | o28-stage2-final-inventory.log |
| 13 | inventory summary count UI 풀테스트 대상 424 | pass | o28-stage2-final-inventory.log |
| 14 | inventory summary count 30분 soak 대상 50 | pass | o28-stage2-final-inventory.log |
| 15 | inventory summary count 120분 대상 7 | pass | o28-stage2-final-inventory.log |
| 16 | summary counts match current feature IDs | pass | o28-stage2-final-inventory.log |
| 17 | implementation evidence manifest matches all feature rows | pass | o28-stage2-final-inventory.log |
| 18 | feature UI-001 name present | pass | o28-stage2-final-inventory.log |
| 19 | feature UI-001 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 20 | feature UI-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 21 | feature UI-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 22 | feature UI-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 23 | feature UI-002 name present | pass | o28-stage2-final-inventory.log |
| 24 | feature UI-002 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 25 | feature UI-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 26 | feature UI-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 27 | feature UI-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 28 | feature UI-003 name present | pass | o28-stage2-final-inventory.log |
| 29 | feature UI-003 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 30 | feature UI-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 31 | feature UI-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 32 | feature UI-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 33 | feature UI-004 name present | pass | o28-stage2-final-inventory.log |
| 34 | feature UI-004 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 35 | feature UI-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 36 | feature UI-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 37 | feature UI-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 38 | feature UI-005 name present | pass | o28-stage2-final-inventory.log |
| 39 | feature UI-005 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 40 | feature UI-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 41 | feature UI-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 42 | feature UI-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 43 | feature UI-006 name present | pass | o28-stage2-final-inventory.log |
| 44 | feature UI-006 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 45 | feature UI-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 46 | feature UI-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 47 | feature UI-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 48 | feature UI-007 name present | pass | o28-stage2-final-inventory.log |
| 49 | feature UI-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 50 | feature UI-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 51 | feature UI-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 52 | feature UI-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 53 | feature UI-008 name present | pass | o28-stage2-final-inventory.log |
| 54 | feature UI-008 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 55 | feature UI-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 56 | feature UI-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 57 | feature UI-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 58 | feature UI-009 name present | pass | o28-stage2-final-inventory.log |
| 59 | feature UI-009 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 60 | feature UI-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 61 | feature UI-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 62 | feature UI-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 63 | feature UI-010 name present | pass | o28-stage2-final-inventory.log |
| 64 | feature UI-010 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 65 | feature UI-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 66 | feature UI-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 67 | feature UI-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 68 | feature UI-011 name present | pass | o28-stage2-final-inventory.log |
| 69 | feature UI-011 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 70 | feature UI-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 71 | feature UI-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 72 | feature UI-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 73 | feature UI-012 name present | pass | o28-stage2-final-inventory.log |
| 74 | feature UI-012 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 75 | feature UI-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 76 | feature UI-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 77 | feature UI-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 78 | feature UI-013 name present | pass | o28-stage2-final-inventory.log |
| 79 | feature UI-013 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 80 | feature UI-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 81 | feature UI-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 82 | feature UI-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 83 | feature UI-014 name present | pass | o28-stage2-final-inventory.log |
| 84 | feature UI-014 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 85 | feature UI-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 86 | feature UI-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 87 | feature UI-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 88 | feature UI-015 name present | pass | o28-stage2-final-inventory.log |
| 89 | feature UI-015 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 90 | feature UI-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 91 | feature UI-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 92 | feature UI-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 93 | feature UI-016 name present | pass | o28-stage2-final-inventory.log |
| 94 | feature UI-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 95 | feature UI-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 96 | feature UI-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 97 | feature UI-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 98 | feature UI-017 name present | pass | o28-stage2-final-inventory.log |
| 99 | feature UI-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 100 | feature UI-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 101 | feature UI-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 102 | feature UI-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 103 | feature UI-018 name present | pass | o28-stage2-final-inventory.log |
| 104 | feature UI-018 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 105 | feature UI-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 106 | feature UI-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 107 | feature UI-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 108 | feature UI-019 name present | pass | o28-stage2-final-inventory.log |
| 109 | feature UI-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 110 | feature UI-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 111 | feature UI-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 112 | feature UI-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 113 | feature UI-020 name present | pass | o28-stage2-final-inventory.log |
| 114 | feature UI-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 115 | feature UI-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 116 | feature UI-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 117 | feature UI-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 118 | feature UI-021 name present | pass | o28-stage2-final-inventory.log |
| 119 | feature UI-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 120 | feature UI-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 121 | feature UI-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 122 | feature UI-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 123 | feature UI-022 name present | pass | o28-stage2-final-inventory.log |
| 124 | feature UI-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 125 | feature UI-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 126 | feature UI-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 127 | feature UI-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 128 | feature UI-023 name present | pass | o28-stage2-final-inventory.log |
| 129 | feature UI-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 130 | feature UI-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 131 | feature UI-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 132 | feature UI-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 133 | feature UI-024 name present | pass | o28-stage2-final-inventory.log |
| 134 | feature UI-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 135 | feature UI-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 136 | feature UI-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 137 | feature UI-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 138 | feature UI-025 name present | pass | o28-stage2-final-inventory.log |
| 139 | feature UI-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 140 | feature UI-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 141 | feature UI-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 142 | feature UI-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 143 | feature UI-026 name present | pass | o28-stage2-final-inventory.log |
| 144 | feature UI-026 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 145 | feature UI-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 146 | feature UI-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 147 | feature UI-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 148 | feature UI-027 name present | pass | o28-stage2-final-inventory.log |
| 149 | feature UI-027 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 150 | feature UI-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 151 | feature UI-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 152 | feature UI-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 153 | feature UI-028 name present | pass | o28-stage2-final-inventory.log |
| 154 | feature UI-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 155 | feature UI-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 156 | feature UI-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 157 | feature UI-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 158 | feature UI-029 name present | pass | o28-stage2-final-inventory.log |
| 159 | feature UI-029 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 160 | feature UI-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 161 | feature UI-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 162 | feature UI-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 163 | feature UI-030 name present | pass | o28-stage2-final-inventory.log |
| 164 | feature UI-030 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 165 | feature UI-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 166 | feature UI-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 167 | feature UI-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 168 | feature UI-031 name present | pass | o28-stage2-final-inventory.log |
| 169 | feature UI-031 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 170 | feature UI-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 171 | feature UI-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 172 | feature UI-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 173 | feature UI-032 name present | pass | o28-stage2-final-inventory.log |
| 174 | feature UI-032 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 175 | feature UI-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 176 | feature UI-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 177 | feature UI-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 178 | feature UI-033 name present | pass | o28-stage2-final-inventory.log |
| 179 | feature UI-033 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 180 | feature UI-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 181 | feature UI-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 182 | feature UI-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 183 | feature UI-034 name present | pass | o28-stage2-final-inventory.log |
| 184 | feature UI-034 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 185 | feature UI-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 186 | feature UI-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 187 | feature UI-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 188 | feature UI-035 name present | pass | o28-stage2-final-inventory.log |
| 189 | feature UI-035 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 190 | feature UI-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 191 | feature UI-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 192 | feature UI-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 193 | feature UI-036 name present | pass | o28-stage2-final-inventory.log |
| 194 | feature UI-036 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 195 | feature UI-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 196 | feature UI-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 197 | feature UI-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 198 | feature UI-037 name present | pass | o28-stage2-final-inventory.log |
| 199 | feature UI-037 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 200 | feature UI-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 201 | feature UI-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 202 | feature UI-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 203 | feature UI-038 name present | pass | o28-stage2-final-inventory.log |
| 204 | feature UI-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 205 | feature UI-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 206 | feature UI-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 207 | feature UI-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 208 | feature UI-039 name present | pass | o28-stage2-final-inventory.log |
| 209 | feature UI-039 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 210 | feature UI-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 211 | feature UI-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 212 | feature UI-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 213 | feature UI-040 name present | pass | o28-stage2-final-inventory.log |
| 214 | feature UI-040 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 215 | feature UI-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 216 | feature UI-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 217 | feature UI-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 218 | feature UI-041 name present | pass | o28-stage2-final-inventory.log |
| 219 | feature UI-041 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 220 | feature UI-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 221 | feature UI-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 222 | feature UI-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 223 | feature UI-042 name present | pass | o28-stage2-final-inventory.log |
| 224 | feature UI-042 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 225 | feature UI-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 226 | feature UI-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 227 | feature UI-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 228 | feature UI-043 name present | pass | o28-stage2-final-inventory.log |
| 229 | feature UI-043 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 230 | feature UI-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 231 | feature UI-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 232 | feature UI-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 233 | feature UI-044 name present | pass | o28-stage2-final-inventory.log |
| 234 | feature UI-044 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 235 | feature UI-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 236 | feature UI-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 237 | feature UI-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 238 | feature UI-045 name present | pass | o28-stage2-final-inventory.log |
| 239 | feature UI-045 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 240 | feature UI-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 241 | feature UI-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 242 | feature UI-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 243 | feature UI-046 name present | pass | o28-stage2-final-inventory.log |
| 244 | feature UI-046 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 245 | feature UI-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 246 | feature UI-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 247 | feature UI-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 248 | feature UI-047 name present | pass | o28-stage2-final-inventory.log |
| 249 | feature UI-047 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 250 | feature UI-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 251 | feature UI-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 252 | feature UI-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 253 | feature UI-048 name present | pass | o28-stage2-final-inventory.log |
| 254 | feature UI-048 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 255 | feature UI-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 256 | feature UI-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 257 | feature UI-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 258 | feature UI-049 name present | pass | o28-stage2-final-inventory.log |
| 259 | feature UI-049 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 260 | feature UI-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 261 | feature UI-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 262 | feature UI-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 263 | feature UI-050 name present | pass | o28-stage2-final-inventory.log |
| 264 | feature UI-050 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 265 | feature UI-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 266 | feature UI-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 267 | feature UI-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 268 | feature UI-051 name present | pass | o28-stage2-final-inventory.log |
| 269 | feature UI-051 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 270 | feature UI-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 271 | feature UI-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 272 | feature UI-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 273 | feature UI-052 name present | pass | o28-stage2-final-inventory.log |
| 274 | feature UI-052 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 275 | feature UI-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 276 | feature UI-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 277 | feature UI-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 278 | feature UI-053 name present | pass | o28-stage2-final-inventory.log |
| 279 | feature UI-053 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 280 | feature UI-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 281 | feature UI-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 282 | feature UI-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 283 | feature UI-054 name present | pass | o28-stage2-final-inventory.log |
| 284 | feature UI-054 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 285 | feature UI-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 286 | feature UI-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 287 | feature UI-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 288 | feature UI-055 name present | pass | o28-stage2-final-inventory.log |
| 289 | feature UI-055 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 290 | feature UI-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 291 | feature UI-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 292 | feature UI-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 293 | feature UI-056 name present | pass | o28-stage2-final-inventory.log |
| 294 | feature UI-056 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 295 | feature UI-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 296 | feature UI-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 297 | feature UI-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 298 | feature UI-057 name present | pass | o28-stage2-final-inventory.log |
| 299 | feature UI-057 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 300 | feature UI-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 301 | feature UI-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 302 | feature UI-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 303 | feature UI-058 name present | pass | o28-stage2-final-inventory.log |
| 304 | feature UI-058 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 305 | feature UI-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 306 | feature UI-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 307 | feature UI-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 308 | feature UI-059 name present | pass | o28-stage2-final-inventory.log |
| 309 | feature UI-059 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 310 | feature UI-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 311 | feature UI-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 312 | feature UI-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 313 | feature UI-060 name present | pass | o28-stage2-final-inventory.log |
| 314 | feature UI-060 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 315 | feature UI-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 316 | feature UI-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 317 | feature UI-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 318 | feature UI-061 name present | pass | o28-stage2-final-inventory.log |
| 319 | feature UI-061 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 320 | feature UI-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 321 | feature UI-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 322 | feature UI-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 323 | feature UI-062 name present | pass | o28-stage2-final-inventory.log |
| 324 | feature UI-062 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 325 | feature UI-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 326 | feature UI-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 327 | feature UI-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 328 | feature UI-063 name present | pass | o28-stage2-final-inventory.log |
| 329 | feature UI-063 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 330 | feature UI-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 331 | feature UI-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 332 | feature UI-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 333 | feature UI-064 name present | pass | o28-stage2-final-inventory.log |
| 334 | feature UI-064 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 335 | feature UI-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 336 | feature UI-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 337 | feature UI-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 338 | feature UI-065 name present | pass | o28-stage2-final-inventory.log |
| 339 | feature UI-065 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 340 | feature UI-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 341 | feature UI-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 342 | feature UI-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 343 | feature UI-066 name present | pass | o28-stage2-final-inventory.log |
| 344 | feature UI-066 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 345 | feature UI-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 346 | feature UI-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 347 | feature UI-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 348 | feature UI-067 name present | pass | o28-stage2-final-inventory.log |
| 349 | feature UI-067 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 350 | feature UI-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 351 | feature UI-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 352 | feature UI-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 353 | feature UI-068 name present | pass | o28-stage2-final-inventory.log |
| 354 | feature UI-068 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 355 | feature UI-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 356 | feature UI-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 357 | feature UI-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 358 | feature UI-069 name present | pass | o28-stage2-final-inventory.log |
| 359 | feature UI-069 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 360 | feature UI-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 361 | feature UI-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 362 | feature UI-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 363 | feature UI-070 name present | pass | o28-stage2-final-inventory.log |
| 364 | feature UI-070 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 365 | feature UI-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 366 | feature UI-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 367 | feature UI-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 368 | feature UI-071 name present | pass | o28-stage2-final-inventory.log |
| 369 | feature UI-071 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 370 | feature UI-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 371 | feature UI-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 372 | feature UI-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 373 | feature UI-072 name present | pass | o28-stage2-final-inventory.log |
| 374 | feature UI-072 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 375 | feature UI-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 376 | feature UI-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 377 | feature UI-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 378 | feature UI-073 name present | pass | o28-stage2-final-inventory.log |
| 379 | feature UI-073 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 380 | feature UI-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 381 | feature UI-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 382 | feature UI-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 383 | feature UI-074 name present | pass | o28-stage2-final-inventory.log |
| 384 | feature UI-074 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 385 | feature UI-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 386 | feature UI-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 387 | feature UI-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 388 | feature UI-075 name present | pass | o28-stage2-final-inventory.log |
| 389 | feature UI-075 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 390 | feature UI-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 391 | feature UI-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 392 | feature UI-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 393 | feature UI-076 name present | pass | o28-stage2-final-inventory.log |
| 394 | feature UI-076 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 395 | feature UI-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 396 | feature UI-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 397 | feature UI-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 398 | feature UI-077 name present | pass | o28-stage2-final-inventory.log |
| 399 | feature UI-077 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 400 | feature UI-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 401 | feature UI-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 402 | feature UI-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 403 | feature UI-078 name present | pass | o28-stage2-final-inventory.log |
| 404 | feature UI-078 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 405 | feature UI-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 406 | feature UI-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 407 | feature UI-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 408 | feature UI-079 name present | pass | o28-stage2-final-inventory.log |
| 409 | feature UI-079 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 410 | feature UI-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 411 | feature UI-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 412 | feature UI-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 413 | feature UI-080 name present | pass | o28-stage2-final-inventory.log |
| 414 | feature UI-080 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 415 | feature UI-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 416 | feature UI-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 417 | feature UI-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 418 | feature UI-081 name present | pass | o28-stage2-final-inventory.log |
| 419 | feature UI-081 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 420 | feature UI-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 421 | feature UI-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 422 | feature UI-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 423 | feature UI-082 name present | pass | o28-stage2-final-inventory.log |
| 424 | feature UI-082 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 425 | feature UI-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 426 | feature UI-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 427 | feature UI-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 428 | feature UI-083 name present | pass | o28-stage2-final-inventory.log |
| 429 | feature UI-083 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 430 | feature UI-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 431 | feature UI-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 432 | feature UI-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 433 | feature UI-084 name present | pass | o28-stage2-final-inventory.log |
| 434 | feature UI-084 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 435 | feature UI-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 436 | feature UI-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 437 | feature UI-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 438 | feature UI-085 name present | pass | o28-stage2-final-inventory.log |
| 439 | feature UI-085 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 440 | feature UI-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 441 | feature UI-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 442 | feature UI-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 443 | feature UI-086 name present | pass | o28-stage2-final-inventory.log |
| 444 | feature UI-086 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 445 | feature UI-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 446 | feature UI-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 447 | feature UI-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 448 | feature UI-087 name present | pass | o28-stage2-final-inventory.log |
| 449 | feature UI-087 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 450 | feature UI-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 451 | feature UI-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 452 | feature UI-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 453 | feature UI-088 name present | pass | o28-stage2-final-inventory.log |
| 454 | feature UI-088 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 455 | feature UI-088 test need 필요 | pass | o28-stage2-final-inventory.log |
| 456 | feature UI-088 test area assigned | pass | o28-stage2-final-inventory.log |
| 457 | feature UI-088 pass criteria present | pass | o28-stage2-final-inventory.log |
| 458 | feature UI-089 name present | pass | o28-stage2-final-inventory.log |
| 459 | feature UI-089 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 460 | feature UI-089 test need 필요 | pass | o28-stage2-final-inventory.log |
| 461 | feature UI-089 test area assigned | pass | o28-stage2-final-inventory.log |
| 462 | feature UI-089 pass criteria present | pass | o28-stage2-final-inventory.log |
| 463 | feature UI-090 name present | pass | o28-stage2-final-inventory.log |
| 464 | feature UI-090 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 465 | feature UI-090 test need 필요 | pass | o28-stage2-final-inventory.log |
| 466 | feature UI-090 test area assigned | pass | o28-stage2-final-inventory.log |
| 467 | feature UI-090 pass criteria present | pass | o28-stage2-final-inventory.log |
| 468 | feature UI-091 name present | pass | o28-stage2-final-inventory.log |
| 469 | feature UI-091 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 470 | feature UI-091 test need 필요 | pass | o28-stage2-final-inventory.log |
| 471 | feature UI-091 test area assigned | pass | o28-stage2-final-inventory.log |
| 472 | feature UI-091 pass criteria present | pass | o28-stage2-final-inventory.log |
| 473 | feature UI-092 name present | pass | o28-stage2-final-inventory.log |
| 474 | feature UI-092 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 475 | feature UI-092 test need 필요 | pass | o28-stage2-final-inventory.log |
| 476 | feature UI-092 test area assigned | pass | o28-stage2-final-inventory.log |
| 477 | feature UI-092 pass criteria present | pass | o28-stage2-final-inventory.log |
| 478 | feature UI-093 name present | pass | o28-stage2-final-inventory.log |
| 479 | feature UI-093 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 480 | feature UI-093 test need 필요 | pass | o28-stage2-final-inventory.log |
| 481 | feature UI-093 test area assigned | pass | o28-stage2-final-inventory.log |
| 482 | feature UI-093 pass criteria present | pass | o28-stage2-final-inventory.log |
| 483 | feature UI-094 name present | pass | o28-stage2-final-inventory.log |
| 484 | feature UI-094 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 485 | feature UI-094 test need 필요 | pass | o28-stage2-final-inventory.log |
| 486 | feature UI-094 test area assigned | pass | o28-stage2-final-inventory.log |
| 487 | feature UI-094 pass criteria present | pass | o28-stage2-final-inventory.log |
| 488 | feature UI-095 name present | pass | o28-stage2-final-inventory.log |
| 489 | feature UI-095 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 490 | feature UI-095 test need 필요 | pass | o28-stage2-final-inventory.log |
| 491 | feature UI-095 test area assigned | pass | o28-stage2-final-inventory.log |
| 492 | feature UI-095 pass criteria present | pass | o28-stage2-final-inventory.log |
| 493 | feature UI-096 name present | pass | o28-stage2-final-inventory.log |
| 494 | feature UI-096 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 495 | feature UI-096 test need 필요 | pass | o28-stage2-final-inventory.log |
| 496 | feature UI-096 test area assigned | pass | o28-stage2-final-inventory.log |
| 497 | feature UI-096 pass criteria present | pass | o28-stage2-final-inventory.log |
| 498 | feature UI-097 name present | pass | o28-stage2-final-inventory.log |
| 499 | feature UI-097 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 500 | feature UI-097 test need 필요 | pass | o28-stage2-final-inventory.log |
| 501 | feature UI-097 test area assigned | pass | o28-stage2-final-inventory.log |
| 502 | feature UI-097 pass criteria present | pass | o28-stage2-final-inventory.log |
| 503 | feature UI-098 name present | pass | o28-stage2-final-inventory.log |
| 504 | feature UI-098 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 505 | feature UI-098 test need 필요 | pass | o28-stage2-final-inventory.log |
| 506 | feature UI-098 test area assigned | pass | o28-stage2-final-inventory.log |
| 507 | feature UI-098 pass criteria present | pass | o28-stage2-final-inventory.log |
| 508 | feature UI-099 name present | pass | o28-stage2-final-inventory.log |
| 509 | feature UI-099 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 510 | feature UI-099 test need 필요 | pass | o28-stage2-final-inventory.log |
| 511 | feature UI-099 test area assigned | pass | o28-stage2-final-inventory.log |
| 512 | feature UI-099 pass criteria present | pass | o28-stage2-final-inventory.log |
| 513 | feature UI-100 name present | pass | o28-stage2-final-inventory.log |
| 514 | feature UI-100 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 515 | feature UI-100 test need 필요 | pass | o28-stage2-final-inventory.log |
| 516 | feature UI-100 test area assigned | pass | o28-stage2-final-inventory.log |
| 517 | feature UI-100 pass criteria present | pass | o28-stage2-final-inventory.log |
| 518 | feature UI-101 name present | pass | o28-stage2-final-inventory.log |
| 519 | feature UI-101 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 520 | feature UI-101 test need 필요 | pass | o28-stage2-final-inventory.log |
| 521 | feature UI-101 test area assigned | pass | o28-stage2-final-inventory.log |
| 522 | feature UI-101 pass criteria present | pass | o28-stage2-final-inventory.log |
| 523 | feature UI-102 name present | pass | o28-stage2-final-inventory.log |
| 524 | feature UI-102 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 525 | feature UI-102 test need 필요 | pass | o28-stage2-final-inventory.log |
| 526 | feature UI-102 test area assigned | pass | o28-stage2-final-inventory.log |
| 527 | feature UI-102 pass criteria present | pass | o28-stage2-final-inventory.log |
| 528 | feature UI-103 name present | pass | o28-stage2-final-inventory.log |
| 529 | feature UI-103 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 530 | feature UI-103 test need 필요 | pass | o28-stage2-final-inventory.log |
| 531 | feature UI-103 test area assigned | pass | o28-stage2-final-inventory.log |
| 532 | feature UI-103 pass criteria present | pass | o28-stage2-final-inventory.log |
| 533 | feature UI-104 name present | pass | o28-stage2-final-inventory.log |
| 534 | feature UI-104 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 535 | feature UI-104 test need 필요 | pass | o28-stage2-final-inventory.log |
| 536 | feature UI-104 test area assigned | pass | o28-stage2-final-inventory.log |
| 537 | feature UI-104 pass criteria present | pass | o28-stage2-final-inventory.log |
| 538 | feature UI-105 name present | pass | o28-stage2-final-inventory.log |
| 539 | feature UI-105 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 540 | feature UI-105 test need 필요 | pass | o28-stage2-final-inventory.log |
| 541 | feature UI-105 test area assigned | pass | o28-stage2-final-inventory.log |
| 542 | feature UI-105 pass criteria present | pass | o28-stage2-final-inventory.log |
| 543 | feature UI-106 name present | pass | o28-stage2-final-inventory.log |
| 544 | feature UI-106 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 545 | feature UI-106 test need 필요 | pass | o28-stage2-final-inventory.log |
| 546 | feature UI-106 test area assigned | pass | o28-stage2-final-inventory.log |
| 547 | feature UI-106 pass criteria present | pass | o28-stage2-final-inventory.log |
| 548 | feature UI-107 name present | pass | o28-stage2-final-inventory.log |
| 549 | feature UI-107 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 550 | feature UI-107 test need 필요 | pass | o28-stage2-final-inventory.log |
| 551 | feature UI-107 test area assigned | pass | o28-stage2-final-inventory.log |
| 552 | feature UI-107 pass criteria present | pass | o28-stage2-final-inventory.log |
| 553 | feature UI-108 name present | pass | o28-stage2-final-inventory.log |
| 554 | feature UI-108 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 555 | feature UI-108 test need 필요 | pass | o28-stage2-final-inventory.log |
| 556 | feature UI-108 test area assigned | pass | o28-stage2-final-inventory.log |
| 557 | feature UI-108 pass criteria present | pass | o28-stage2-final-inventory.log |
| 558 | feature UI-109 name present | pass | o28-stage2-final-inventory.log |
| 559 | feature UI-109 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 560 | feature UI-109 test need 필요 | pass | o28-stage2-final-inventory.log |
| 561 | feature UI-109 test area assigned | pass | o28-stage2-final-inventory.log |
| 562 | feature UI-109 pass criteria present | pass | o28-stage2-final-inventory.log |
| 563 | feature UI-110 name present | pass | o28-stage2-final-inventory.log |
| 564 | feature UI-110 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 565 | feature UI-110 test need 필요 | pass | o28-stage2-final-inventory.log |
| 566 | feature UI-110 test area assigned | pass | o28-stage2-final-inventory.log |
| 567 | feature UI-110 pass criteria present | pass | o28-stage2-final-inventory.log |
| 568 | feature UI-111 name present | pass | o28-stage2-final-inventory.log |
| 569 | feature UI-111 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 570 | feature UI-111 test need 필요 | pass | o28-stage2-final-inventory.log |
| 571 | feature UI-111 test area assigned | pass | o28-stage2-final-inventory.log |
| 572 | feature UI-111 pass criteria present | pass | o28-stage2-final-inventory.log |
| 573 | feature UI-112 name present | pass | o28-stage2-final-inventory.log |
| 574 | feature UI-112 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 575 | feature UI-112 test need 필요 | pass | o28-stage2-final-inventory.log |
| 576 | feature UI-112 test area assigned | pass | o28-stage2-final-inventory.log |
| 577 | feature UI-112 pass criteria present | pass | o28-stage2-final-inventory.log |
| 578 | feature UI-113 name present | pass | o28-stage2-final-inventory.log |
| 579 | feature UI-113 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 580 | feature UI-113 test need 필요 | pass | o28-stage2-final-inventory.log |
| 581 | feature UI-113 test area assigned | pass | o28-stage2-final-inventory.log |
| 582 | feature UI-113 pass criteria present | pass | o28-stage2-final-inventory.log |
| 583 | feature UI-114 name present | pass | o28-stage2-final-inventory.log |
| 584 | feature UI-114 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 585 | feature UI-114 test need 필요 | pass | o28-stage2-final-inventory.log |
| 586 | feature UI-114 test area assigned | pass | o28-stage2-final-inventory.log |
| 587 | feature UI-114 pass criteria present | pass | o28-stage2-final-inventory.log |
| 588 | feature UI-115 name present | pass | o28-stage2-final-inventory.log |
| 589 | feature UI-115 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 590 | feature UI-115 test need 필요 | pass | o28-stage2-final-inventory.log |
| 591 | feature UI-115 test area assigned | pass | o28-stage2-final-inventory.log |
| 592 | feature UI-115 pass criteria present | pass | o28-stage2-final-inventory.log |
| 593 | feature AUTH-001 name present | pass | o28-stage2-final-inventory.log |
| 594 | feature AUTH-001 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 595 | feature AUTH-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 596 | feature AUTH-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 597 | feature AUTH-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 598 | feature AUTH-002 name present | pass | o28-stage2-final-inventory.log |
| 599 | feature AUTH-002 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 600 | feature AUTH-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 601 | feature AUTH-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 602 | feature AUTH-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 603 | feature AUTH-003 name present | pass | o28-stage2-final-inventory.log |
| 604 | feature AUTH-003 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 605 | feature AUTH-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 606 | feature AUTH-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 607 | feature AUTH-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 608 | feature AUTH-004 name present | pass | o28-stage2-final-inventory.log |
| 609 | feature AUTH-004 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 610 | feature AUTH-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 611 | feature AUTH-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 612 | feature AUTH-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 613 | feature AUTH-005 name present | pass | o28-stage2-final-inventory.log |
| 614 | feature AUTH-005 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 615 | feature AUTH-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 616 | feature AUTH-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 617 | feature AUTH-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 618 | feature AUTH-006 name present | pass | o28-stage2-final-inventory.log |
| 619 | feature AUTH-006 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 620 | feature AUTH-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 621 | feature AUTH-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 622 | feature AUTH-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 623 | feature AUTH-007 name present | pass | o28-stage2-final-inventory.log |
| 624 | feature AUTH-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 625 | feature AUTH-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 626 | feature AUTH-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 627 | feature AUTH-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 628 | feature AUTH-008 name present | pass | o28-stage2-final-inventory.log |
| 629 | feature AUTH-008 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 630 | feature AUTH-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 631 | feature AUTH-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 632 | feature AUTH-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 633 | feature AUTH-009 name present | pass | o28-stage2-final-inventory.log |
| 634 | feature AUTH-009 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 635 | feature AUTH-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 636 | feature AUTH-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 637 | feature AUTH-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 638 | feature AUTH-010 name present | pass | o28-stage2-final-inventory.log |
| 639 | feature AUTH-010 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 640 | feature AUTH-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 641 | feature AUTH-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 642 | feature AUTH-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 643 | feature AUTH-011 name present | pass | o28-stage2-final-inventory.log |
| 644 | feature AUTH-011 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 645 | feature AUTH-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 646 | feature AUTH-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 647 | feature AUTH-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 648 | feature AUTH-012 name present | pass | o28-stage2-final-inventory.log |
| 649 | feature AUTH-012 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 650 | feature AUTH-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 651 | feature AUTH-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 652 | feature AUTH-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 653 | feature AUTH-013 name present | pass | o28-stage2-final-inventory.log |
| 654 | feature AUTH-013 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 655 | feature AUTH-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 656 | feature AUTH-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 657 | feature AUTH-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 658 | feature AUTH-014 name present | pass | o28-stage2-final-inventory.log |
| 659 | feature AUTH-014 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 660 | feature AUTH-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 661 | feature AUTH-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 662 | feature AUTH-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 663 | feature AUTH-015 name present | pass | o28-stage2-final-inventory.log |
| 664 | feature AUTH-015 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 665 | feature AUTH-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 666 | feature AUTH-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 667 | feature AUTH-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 668 | feature AUTH-016 name present | pass | o28-stage2-final-inventory.log |
| 669 | feature AUTH-016 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 670 | feature AUTH-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 671 | feature AUTH-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 672 | feature AUTH-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 673 | feature AUTH-017 name present | pass | o28-stage2-final-inventory.log |
| 674 | feature AUTH-017 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 675 | feature AUTH-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 676 | feature AUTH-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 677 | feature AUTH-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 678 | feature AUTH-018 name present | pass | o28-stage2-final-inventory.log |
| 679 | feature AUTH-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 680 | feature AUTH-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 681 | feature AUTH-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 682 | feature AUTH-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 683 | feature AUTH-019 name present | pass | o28-stage2-final-inventory.log |
| 684 | feature AUTH-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 685 | feature AUTH-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 686 | feature AUTH-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 687 | feature AUTH-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 688 | feature AUTH-020 name present | pass | o28-stage2-final-inventory.log |
| 689 | feature AUTH-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 690 | feature AUTH-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 691 | feature AUTH-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 692 | feature AUTH-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 693 | feature AUTH-021 name present | pass | o28-stage2-final-inventory.log |
| 694 | feature AUTH-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 695 | feature AUTH-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 696 | feature AUTH-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 697 | feature AUTH-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 698 | feature AUTH-022 name present | pass | o28-stage2-final-inventory.log |
| 699 | feature AUTH-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 700 | feature AUTH-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 701 | feature AUTH-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 702 | feature AUTH-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 703 | feature AUTH-023 name present | pass | o28-stage2-final-inventory.log |
| 704 | feature AUTH-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 705 | feature AUTH-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 706 | feature AUTH-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 707 | feature AUTH-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 708 | feature AUTH-024 name present | pass | o28-stage2-final-inventory.log |
| 709 | feature AUTH-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 710 | feature AUTH-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 711 | feature AUTH-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 712 | feature AUTH-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 713 | feature AUTH-025 name present | pass | o28-stage2-final-inventory.log |
| 714 | feature AUTH-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 715 | feature AUTH-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 716 | feature AUTH-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 717 | feature AUTH-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 718 | feature AUTH-026 name present | pass | o28-stage2-final-inventory.log |
| 719 | feature AUTH-026 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 720 | feature AUTH-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 721 | feature AUTH-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 722 | feature AUTH-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 723 | feature AUTH-027 name present | pass | o28-stage2-final-inventory.log |
| 724 | feature AUTH-027 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 725 | feature AUTH-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 726 | feature AUTH-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 727 | feature AUTH-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 728 | feature AUTH-028 name present | pass | o28-stage2-final-inventory.log |
| 729 | feature AUTH-028 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 730 | feature AUTH-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 731 | feature AUTH-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 732 | feature AUTH-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 733 | feature AUTH-029 name present | pass | o28-stage2-final-inventory.log |
| 734 | feature AUTH-029 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 735 | feature AUTH-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 736 | feature AUTH-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 737 | feature AUTH-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 738 | feature AUTH-030 name present | pass | o28-stage2-final-inventory.log |
| 739 | feature AUTH-030 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 740 | feature AUTH-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 741 | feature AUTH-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 742 | feature AUTH-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 743 | feature AUTH-031 name present | pass | o28-stage2-final-inventory.log |
| 744 | feature AUTH-031 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 745 | feature AUTH-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 746 | feature AUTH-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 747 | feature AUTH-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 748 | feature AUTH-032 name present | pass | o28-stage2-final-inventory.log |
| 749 | feature AUTH-032 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 750 | feature AUTH-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 751 | feature AUTH-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 752 | feature AUTH-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 753 | feature AUTH-033 name present | pass | o28-stage2-final-inventory.log |
| 754 | feature AUTH-033 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 755 | feature AUTH-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 756 | feature AUTH-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 757 | feature AUTH-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 758 | feature AUTH-034 name present | pass | o28-stage2-final-inventory.log |
| 759 | feature AUTH-034 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 760 | feature AUTH-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 761 | feature AUTH-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 762 | feature AUTH-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 763 | feature AUTH-035 name present | pass | o28-stage2-final-inventory.log |
| 764 | feature AUTH-035 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 765 | feature AUTH-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 766 | feature AUTH-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 767 | feature AUTH-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 768 | feature AUTH-036 name present | pass | o28-stage2-final-inventory.log |
| 769 | feature AUTH-036 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 770 | feature AUTH-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 771 | feature AUTH-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 772 | feature AUTH-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 773 | feature AUTH-037 name present | pass | o28-stage2-final-inventory.log |
| 774 | feature AUTH-037 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 775 | feature AUTH-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 776 | feature AUTH-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 777 | feature AUTH-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 778 | feature AUTH-038 name present | pass | o28-stage2-final-inventory.log |
| 779 | feature AUTH-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 780 | feature AUTH-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 781 | feature AUTH-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 782 | feature AUTH-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 783 | feature AUTH-039 name present | pass | o28-stage2-final-inventory.log |
| 784 | feature AUTH-039 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 785 | feature AUTH-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 786 | feature AUTH-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 787 | feature AUTH-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 788 | feature AUTH-040 name present | pass | o28-stage2-final-inventory.log |
| 789 | feature AUTH-040 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 790 | feature AUTH-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 791 | feature AUTH-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 792 | feature AUTH-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 793 | feature AUTH-041 name present | pass | o28-stage2-final-inventory.log |
| 794 | feature AUTH-041 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 795 | feature AUTH-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 796 | feature AUTH-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 797 | feature AUTH-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 798 | feature AUTH-042 name present | pass | o28-stage2-final-inventory.log |
| 799 | feature AUTH-042 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 800 | feature AUTH-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 801 | feature AUTH-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 802 | feature AUTH-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 803 | feature SRC-001 name present | pass | o28-stage2-final-inventory.log |
| 804 | feature SRC-001 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 805 | feature SRC-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 806 | feature SRC-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 807 | feature SRC-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 808 | feature SRC-002 name present | pass | o28-stage2-final-inventory.log |
| 809 | feature SRC-002 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 810 | feature SRC-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 811 | feature SRC-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 812 | feature SRC-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 813 | feature SRC-003 name present | pass | o28-stage2-final-inventory.log |
| 814 | feature SRC-003 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 815 | feature SRC-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 816 | feature SRC-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 817 | feature SRC-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 818 | feature SRC-004 name present | pass | o28-stage2-final-inventory.log |
| 819 | feature SRC-004 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 820 | feature SRC-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 821 | feature SRC-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 822 | feature SRC-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 823 | feature SRC-005 name present | pass | o28-stage2-final-inventory.log |
| 824 | feature SRC-005 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 825 | feature SRC-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 826 | feature SRC-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 827 | feature SRC-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 828 | feature SRC-006 name present | pass | o28-stage2-final-inventory.log |
| 829 | feature SRC-006 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 830 | feature SRC-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 831 | feature SRC-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 832 | feature SRC-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 833 | feature SRC-007 name present | pass | o28-stage2-final-inventory.log |
| 834 | feature SRC-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 835 | feature SRC-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 836 | feature SRC-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 837 | feature SRC-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 838 | feature SRC-008 name present | pass | o28-stage2-final-inventory.log |
| 839 | feature SRC-008 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 840 | feature SRC-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 841 | feature SRC-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 842 | feature SRC-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 843 | feature SRC-009 name present | pass | o28-stage2-final-inventory.log |
| 844 | feature SRC-009 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 845 | feature SRC-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 846 | feature SRC-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 847 | feature SRC-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 848 | feature SRC-010 name present | pass | o28-stage2-final-inventory.log |
| 849 | feature SRC-010 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 850 | feature SRC-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 851 | feature SRC-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 852 | feature SRC-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 853 | feature SRC-011 name present | pass | o28-stage2-final-inventory.log |
| 854 | feature SRC-011 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 855 | feature SRC-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 856 | feature SRC-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 857 | feature SRC-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 858 | feature SRC-012 name present | pass | o28-stage2-final-inventory.log |
| 859 | feature SRC-012 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 860 | feature SRC-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 861 | feature SRC-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 862 | feature SRC-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 863 | feature SRC-013 name present | pass | o28-stage2-final-inventory.log |
| 864 | feature SRC-013 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 865 | feature SRC-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 866 | feature SRC-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 867 | feature SRC-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 868 | feature SRC-014 name present | pass | o28-stage2-final-inventory.log |
| 869 | feature SRC-014 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 870 | feature SRC-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 871 | feature SRC-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 872 | feature SRC-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 873 | feature SRC-015 name present | pass | o28-stage2-final-inventory.log |
| 874 | feature SRC-015 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 875 | feature SRC-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 876 | feature SRC-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 877 | feature SRC-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 878 | feature SRC-016 name present | pass | o28-stage2-final-inventory.log |
| 879 | feature SRC-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 880 | feature SRC-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 881 | feature SRC-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 882 | feature SRC-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 883 | feature SRC-017 name present | pass | o28-stage2-final-inventory.log |
| 884 | feature SRC-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 885 | feature SRC-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 886 | feature SRC-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 887 | feature SRC-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 888 | feature SRC-018 name present | pass | o28-stage2-final-inventory.log |
| 889 | feature SRC-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 890 | feature SRC-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 891 | feature SRC-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 892 | feature SRC-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 893 | feature SRC-019 name present | pass | o28-stage2-final-inventory.log |
| 894 | feature SRC-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 895 | feature SRC-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 896 | feature SRC-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 897 | feature SRC-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 898 | feature SRC-020 name present | pass | o28-stage2-final-inventory.log |
| 899 | feature SRC-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 900 | feature SRC-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 901 | feature SRC-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 902 | feature SRC-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 903 | feature SRC-021 name present | pass | o28-stage2-final-inventory.log |
| 904 | feature SRC-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 905 | feature SRC-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 906 | feature SRC-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 907 | feature SRC-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 908 | feature SRC-022 name present | pass | o28-stage2-final-inventory.log |
| 909 | feature SRC-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 910 | feature SRC-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 911 | feature SRC-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 912 | feature SRC-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 913 | feature SRC-023 name present | pass | o28-stage2-final-inventory.log |
| 914 | feature SRC-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 915 | feature SRC-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 916 | feature SRC-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 917 | feature SRC-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 918 | feature SRC-024 name present | pass | o28-stage2-final-inventory.log |
| 919 | feature SRC-024 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 920 | feature SRC-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 921 | feature SRC-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 922 | feature SRC-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 923 | feature SRC-025 name present | pass | o28-stage2-final-inventory.log |
| 924 | feature SRC-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 925 | feature SRC-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 926 | feature SRC-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 927 | feature SRC-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 928 | feature SRC-026 name present | pass | o28-stage2-final-inventory.log |
| 929 | feature SRC-026 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 930 | feature SRC-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 931 | feature SRC-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 932 | feature SRC-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 933 | feature SRC-027 name present | pass | o28-stage2-final-inventory.log |
| 934 | feature SRC-027 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 935 | feature SRC-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 936 | feature SRC-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 937 | feature SRC-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 938 | feature SRC-028 name present | pass | o28-stage2-final-inventory.log |
| 939 | feature SRC-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 940 | feature SRC-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 941 | feature SRC-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 942 | feature SRC-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 943 | feature SRC-029 name present | pass | o28-stage2-final-inventory.log |
| 944 | feature SRC-029 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 945 | feature SRC-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 946 | feature SRC-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 947 | feature SRC-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 948 | feature SRC-030 name present | pass | o28-stage2-final-inventory.log |
| 949 | feature SRC-030 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 950 | feature SRC-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 951 | feature SRC-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 952 | feature SRC-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 953 | feature SRC-031 name present | pass | o28-stage2-final-inventory.log |
| 954 | feature SRC-031 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 955 | feature SRC-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 956 | feature SRC-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 957 | feature SRC-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 958 | feature SRC-032 name present | pass | o28-stage2-final-inventory.log |
| 959 | feature SRC-032 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 960 | feature SRC-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 961 | feature SRC-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 962 | feature SRC-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 963 | feature SRC-033 name present | pass | o28-stage2-final-inventory.log |
| 964 | feature SRC-033 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 965 | feature SRC-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 966 | feature SRC-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 967 | feature SRC-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 968 | feature SRC-034 name present | pass | o28-stage2-final-inventory.log |
| 969 | feature SRC-034 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 970 | feature SRC-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 971 | feature SRC-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 972 | feature SRC-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 973 | feature SRC-035 name present | pass | o28-stage2-final-inventory.log |
| 974 | feature SRC-035 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 975 | feature SRC-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 976 | feature SRC-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 977 | feature SRC-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 978 | feature SRC-036 name present | pass | o28-stage2-final-inventory.log |
| 979 | feature SRC-036 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 980 | feature SRC-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 981 | feature SRC-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 982 | feature SRC-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 983 | feature SRC-037 name present | pass | o28-stage2-final-inventory.log |
| 984 | feature SRC-037 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 985 | feature SRC-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 986 | feature SRC-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 987 | feature SRC-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 988 | feature SRC-038 name present | pass | o28-stage2-final-inventory.log |
| 989 | feature SRC-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 990 | feature SRC-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 991 | feature SRC-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 992 | feature SRC-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 993 | feature SRC-039 name present | pass | o28-stage2-final-inventory.log |
| 994 | feature SRC-039 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 995 | feature SRC-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 996 | feature SRC-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 997 | feature SRC-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 998 | feature SRC-040 name present | pass | o28-stage2-final-inventory.log |
| 999 | feature SRC-040 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1000 | feature SRC-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1001 | feature SRC-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 1002 | feature SRC-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1003 | feature SRC-041 name present | pass | o28-stage2-final-inventory.log |
| 1004 | feature SRC-041 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1005 | feature SRC-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1006 | feature SRC-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 1007 | feature SRC-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1008 | feature SRC-042 name present | pass | o28-stage2-final-inventory.log |
| 1009 | feature SRC-042 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1010 | feature SRC-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1011 | feature SRC-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 1012 | feature SRC-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1013 | feature SRC-043 name present | pass | o28-stage2-final-inventory.log |
| 1014 | feature SRC-043 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1015 | feature SRC-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1016 | feature SRC-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 1017 | feature SRC-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1018 | feature SRC-044 name present | pass | o28-stage2-final-inventory.log |
| 1019 | feature SRC-044 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1020 | feature SRC-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1021 | feature SRC-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 1022 | feature SRC-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1023 | feature SRC-045 name present | pass | o28-stage2-final-inventory.log |
| 1024 | feature SRC-045 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1025 | feature SRC-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1026 | feature SRC-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 1027 | feature SRC-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1028 | feature SRC-046 name present | pass | o28-stage2-final-inventory.log |
| 1029 | feature SRC-046 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1030 | feature SRC-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1031 | feature SRC-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 1032 | feature SRC-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1033 | feature SRC-047 name present | pass | o28-stage2-final-inventory.log |
| 1034 | feature SRC-047 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1035 | feature SRC-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1036 | feature SRC-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 1037 | feature SRC-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1038 | feature SRC-048 name present | pass | o28-stage2-final-inventory.log |
| 1039 | feature SRC-048 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1040 | feature SRC-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1041 | feature SRC-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 1042 | feature SRC-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1043 | feature SRC-049 name present | pass | o28-stage2-final-inventory.log |
| 1044 | feature SRC-049 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1045 | feature SRC-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1046 | feature SRC-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 1047 | feature SRC-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1048 | feature SRC-050 name present | pass | o28-stage2-final-inventory.log |
| 1049 | feature SRC-050 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1050 | feature SRC-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1051 | feature SRC-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 1052 | feature SRC-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1053 | feature SRC-051 name present | pass | o28-stage2-final-inventory.log |
| 1054 | feature SRC-051 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1055 | feature SRC-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1056 | feature SRC-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 1057 | feature SRC-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1058 | feature SRC-052 name present | pass | o28-stage2-final-inventory.log |
| 1059 | feature SRC-052 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1060 | feature SRC-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1061 | feature SRC-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 1062 | feature SRC-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1063 | feature SRC-053 name present | pass | o28-stage2-final-inventory.log |
| 1064 | feature SRC-053 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1065 | feature SRC-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1066 | feature SRC-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 1067 | feature SRC-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1068 | feature SRC-054 name present | pass | o28-stage2-final-inventory.log |
| 1069 | feature SRC-054 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1070 | feature SRC-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1071 | feature SRC-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 1072 | feature SRC-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1073 | feature SRC-055 name present | pass | o28-stage2-final-inventory.log |
| 1074 | feature SRC-055 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1075 | feature SRC-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1076 | feature SRC-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 1077 | feature SRC-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1078 | feature SRC-056 name present | pass | o28-stage2-final-inventory.log |
| 1079 | feature SRC-056 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1080 | feature SRC-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1081 | feature SRC-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 1082 | feature SRC-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1083 | feature SRC-057 name present | pass | o28-stage2-final-inventory.log |
| 1084 | feature SRC-057 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1085 | feature SRC-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1086 | feature SRC-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 1087 | feature SRC-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1088 | feature SRC-058 name present | pass | o28-stage2-final-inventory.log |
| 1089 | feature SRC-058 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1090 | feature SRC-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1091 | feature SRC-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 1092 | feature SRC-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1093 | feature SRC-059 name present | pass | o28-stage2-final-inventory.log |
| 1094 | feature SRC-059 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1095 | feature SRC-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1096 | feature SRC-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 1097 | feature SRC-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1098 | feature SRC-060 name present | pass | o28-stage2-final-inventory.log |
| 1099 | feature SRC-060 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1100 | feature SRC-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1101 | feature SRC-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 1102 | feature SRC-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1103 | feature SRC-061 name present | pass | o28-stage2-final-inventory.log |
| 1104 | feature SRC-061 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1105 | feature SRC-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1106 | feature SRC-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 1107 | feature SRC-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1108 | feature SRC-062 name present | pass | o28-stage2-final-inventory.log |
| 1109 | feature SRC-062 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1110 | feature SRC-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1111 | feature SRC-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 1112 | feature SRC-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1113 | feature SRC-063 name present | pass | o28-stage2-final-inventory.log |
| 1114 | feature SRC-063 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1115 | feature SRC-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1116 | feature SRC-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 1117 | feature SRC-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1118 | feature SRC-064 name present | pass | o28-stage2-final-inventory.log |
| 1119 | feature SRC-064 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1120 | feature SRC-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1121 | feature SRC-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 1122 | feature SRC-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1123 | feature SRC-065 name present | pass | o28-stage2-final-inventory.log |
| 1124 | feature SRC-065 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1125 | feature SRC-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1126 | feature SRC-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 1127 | feature SRC-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1128 | feature SRC-066 name present | pass | o28-stage2-final-inventory.log |
| 1129 | feature SRC-066 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1130 | feature SRC-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1131 | feature SRC-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 1132 | feature SRC-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1133 | feature SRC-067 name present | pass | o28-stage2-final-inventory.log |
| 1134 | feature SRC-067 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1135 | feature SRC-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1136 | feature SRC-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 1137 | feature SRC-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1138 | feature SRC-068 name present | pass | o28-stage2-final-inventory.log |
| 1139 | feature SRC-068 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1140 | feature SRC-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1141 | feature SRC-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 1142 | feature SRC-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1143 | feature RULE-001 name present | pass | o28-stage2-final-inventory.log |
| 1144 | feature RULE-001 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1145 | feature RULE-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1146 | feature RULE-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 1147 | feature RULE-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1148 | feature RULE-002 name present | pass | o28-stage2-final-inventory.log |
| 1149 | feature RULE-002 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1150 | feature RULE-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1151 | feature RULE-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 1152 | feature RULE-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1153 | feature RULE-003 name present | pass | o28-stage2-final-inventory.log |
| 1154 | feature RULE-003 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1155 | feature RULE-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1156 | feature RULE-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 1157 | feature RULE-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1158 | feature RULE-004 name present | pass | o28-stage2-final-inventory.log |
| 1159 | feature RULE-004 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1160 | feature RULE-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1161 | feature RULE-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 1162 | feature RULE-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1163 | feature RULE-005 name present | pass | o28-stage2-final-inventory.log |
| 1164 | feature RULE-005 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1165 | feature RULE-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1166 | feature RULE-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 1167 | feature RULE-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1168 | feature RULE-006 name present | pass | o28-stage2-final-inventory.log |
| 1169 | feature RULE-006 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1170 | feature RULE-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1171 | feature RULE-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 1172 | feature RULE-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1173 | feature RULE-007 name present | pass | o28-stage2-final-inventory.log |
| 1174 | feature RULE-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1175 | feature RULE-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1176 | feature RULE-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 1177 | feature RULE-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1178 | feature RULE-008 name present | pass | o28-stage2-final-inventory.log |
| 1179 | feature RULE-008 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1180 | feature RULE-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1181 | feature RULE-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 1182 | feature RULE-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1183 | feature RULE-009 name present | pass | o28-stage2-final-inventory.log |
| 1184 | feature RULE-009 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1185 | feature RULE-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1186 | feature RULE-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 1187 | feature RULE-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1188 | feature RULE-010 name present | pass | o28-stage2-final-inventory.log |
| 1189 | feature RULE-010 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1190 | feature RULE-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1191 | feature RULE-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 1192 | feature RULE-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1193 | feature RULE-011 name present | pass | o28-stage2-final-inventory.log |
| 1194 | feature RULE-011 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1195 | feature RULE-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1196 | feature RULE-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 1197 | feature RULE-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1198 | feature RULE-012 name present | pass | o28-stage2-final-inventory.log |
| 1199 | feature RULE-012 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1200 | feature RULE-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1201 | feature RULE-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 1202 | feature RULE-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1203 | feature RULE-013 name present | pass | o28-stage2-final-inventory.log |
| 1204 | feature RULE-013 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1205 | feature RULE-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1206 | feature RULE-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 1207 | feature RULE-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1208 | feature RULE-014 name present | pass | o28-stage2-final-inventory.log |
| 1209 | feature RULE-014 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1210 | feature RULE-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1211 | feature RULE-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 1212 | feature RULE-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1213 | feature RULE-015 name present | pass | o28-stage2-final-inventory.log |
| 1214 | feature RULE-015 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1215 | feature RULE-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1216 | feature RULE-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 1217 | feature RULE-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1218 | feature RULE-016 name present | pass | o28-stage2-final-inventory.log |
| 1219 | feature RULE-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1220 | feature RULE-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1221 | feature RULE-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 1222 | feature RULE-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1223 | feature RULE-017 name present | pass | o28-stage2-final-inventory.log |
| 1224 | feature RULE-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1225 | feature RULE-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1226 | feature RULE-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 1227 | feature RULE-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1228 | feature RULE-018 name present | pass | o28-stage2-final-inventory.log |
| 1229 | feature RULE-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1230 | feature RULE-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1231 | feature RULE-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 1232 | feature RULE-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1233 | feature RULE-019 name present | pass | o28-stage2-final-inventory.log |
| 1234 | feature RULE-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1235 | feature RULE-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1236 | feature RULE-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 1237 | feature RULE-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1238 | feature RULE-020 name present | pass | o28-stage2-final-inventory.log |
| 1239 | feature RULE-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1240 | feature RULE-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1241 | feature RULE-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 1242 | feature RULE-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1243 | feature RULE-021 name present | pass | o28-stage2-final-inventory.log |
| 1244 | feature RULE-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1245 | feature RULE-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1246 | feature RULE-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 1247 | feature RULE-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1248 | feature RULE-022 name present | pass | o28-stage2-final-inventory.log |
| 1249 | feature RULE-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1250 | feature RULE-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1251 | feature RULE-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 1252 | feature RULE-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1253 | feature RULE-023 name present | pass | o28-stage2-final-inventory.log |
| 1254 | feature RULE-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1255 | feature RULE-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1256 | feature RULE-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 1257 | feature RULE-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1258 | feature RULE-024 name present | pass | o28-stage2-final-inventory.log |
| 1259 | feature RULE-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1260 | feature RULE-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1261 | feature RULE-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 1262 | feature RULE-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1263 | feature RULE-025 name present | pass | o28-stage2-final-inventory.log |
| 1264 | feature RULE-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1265 | feature RULE-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1266 | feature RULE-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 1267 | feature RULE-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1268 | feature RULE-026 name present | pass | o28-stage2-final-inventory.log |
| 1269 | feature RULE-026 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1270 | feature RULE-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1271 | feature RULE-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 1272 | feature RULE-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1273 | feature RULE-027 name present | pass | o28-stage2-final-inventory.log |
| 1274 | feature RULE-027 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1275 | feature RULE-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1276 | feature RULE-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 1277 | feature RULE-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1278 | feature RULE-028 name present | pass | o28-stage2-final-inventory.log |
| 1279 | feature RULE-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1280 | feature RULE-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1281 | feature RULE-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 1282 | feature RULE-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1283 | feature RULE-029 name present | pass | o28-stage2-final-inventory.log |
| 1284 | feature RULE-029 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1285 | feature RULE-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1286 | feature RULE-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 1287 | feature RULE-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1288 | feature RULE-030 name present | pass | o28-stage2-final-inventory.log |
| 1289 | feature RULE-030 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1290 | feature RULE-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1291 | feature RULE-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 1292 | feature RULE-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1293 | feature RULE-031 name present | pass | o28-stage2-final-inventory.log |
| 1294 | feature RULE-031 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1295 | feature RULE-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1296 | feature RULE-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 1297 | feature RULE-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1298 | feature RULE-032 name present | pass | o28-stage2-final-inventory.log |
| 1299 | feature RULE-032 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1300 | feature RULE-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1301 | feature RULE-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 1302 | feature RULE-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1303 | feature RULE-033 name present | pass | o28-stage2-final-inventory.log |
| 1304 | feature RULE-033 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1305 | feature RULE-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1306 | feature RULE-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 1307 | feature RULE-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1308 | feature RULE-034 name present | pass | o28-stage2-final-inventory.log |
| 1309 | feature RULE-034 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1310 | feature RULE-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1311 | feature RULE-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 1312 | feature RULE-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1313 | feature RULE-035 name present | pass | o28-stage2-final-inventory.log |
| 1314 | feature RULE-035 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1315 | feature RULE-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1316 | feature RULE-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 1317 | feature RULE-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1318 | feature RULE-036 name present | pass | o28-stage2-final-inventory.log |
| 1319 | feature RULE-036 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1320 | feature RULE-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1321 | feature RULE-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 1322 | feature RULE-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1323 | feature RULE-037 name present | pass | o28-stage2-final-inventory.log |
| 1324 | feature RULE-037 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1325 | feature RULE-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1326 | feature RULE-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 1327 | feature RULE-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1328 | feature RULE-038 name present | pass | o28-stage2-final-inventory.log |
| 1329 | feature RULE-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1330 | feature RULE-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1331 | feature RULE-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 1332 | feature RULE-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1333 | feature RULE-039 name present | pass | o28-stage2-final-inventory.log |
| 1334 | feature RULE-039 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1335 | feature RULE-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1336 | feature RULE-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 1337 | feature RULE-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1338 | feature RULE-040 name present | pass | o28-stage2-final-inventory.log |
| 1339 | feature RULE-040 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1340 | feature RULE-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1341 | feature RULE-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 1342 | feature RULE-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1343 | feature RULE-041 name present | pass | o28-stage2-final-inventory.log |
| 1344 | feature RULE-041 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1345 | feature RULE-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1346 | feature RULE-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 1347 | feature RULE-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1348 | feature RULE-042 name present | pass | o28-stage2-final-inventory.log |
| 1349 | feature RULE-042 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1350 | feature RULE-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1351 | feature RULE-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 1352 | feature RULE-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1353 | feature RULE-043 name present | pass | o28-stage2-final-inventory.log |
| 1354 | feature RULE-043 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1355 | feature RULE-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1356 | feature RULE-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 1357 | feature RULE-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1358 | feature RULE-044 name present | pass | o28-stage2-final-inventory.log |
| 1359 | feature RULE-044 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1360 | feature RULE-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1361 | feature RULE-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 1362 | feature RULE-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1363 | feature RULE-045 name present | pass | o28-stage2-final-inventory.log |
| 1364 | feature RULE-045 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1365 | feature RULE-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1366 | feature RULE-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 1367 | feature RULE-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1368 | feature RULE-046 name present | pass | o28-stage2-final-inventory.log |
| 1369 | feature RULE-046 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1370 | feature RULE-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1371 | feature RULE-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 1372 | feature RULE-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1373 | feature RULE-047 name present | pass | o28-stage2-final-inventory.log |
| 1374 | feature RULE-047 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1375 | feature RULE-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1376 | feature RULE-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 1377 | feature RULE-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1378 | feature RULE-048 name present | pass | o28-stage2-final-inventory.log |
| 1379 | feature RULE-048 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1380 | feature RULE-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1381 | feature RULE-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 1382 | feature RULE-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1383 | feature RULE-049 name present | pass | o28-stage2-final-inventory.log |
| 1384 | feature RULE-049 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1385 | feature RULE-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1386 | feature RULE-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 1387 | feature RULE-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1388 | feature RULE-050 name present | pass | o28-stage2-final-inventory.log |
| 1389 | feature RULE-050 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1390 | feature RULE-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1391 | feature RULE-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 1392 | feature RULE-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1393 | feature RULE-051 name present | pass | o28-stage2-final-inventory.log |
| 1394 | feature RULE-051 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1395 | feature RULE-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1396 | feature RULE-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 1397 | feature RULE-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1398 | feature RULE-052 name present | pass | o28-stage2-final-inventory.log |
| 1399 | feature RULE-052 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1400 | feature RULE-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1401 | feature RULE-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 1402 | feature RULE-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1403 | feature RULE-053 name present | pass | o28-stage2-final-inventory.log |
| 1404 | feature RULE-053 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1405 | feature RULE-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1406 | feature RULE-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 1407 | feature RULE-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1408 | feature RULE-054 name present | pass | o28-stage2-final-inventory.log |
| 1409 | feature RULE-054 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1410 | feature RULE-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1411 | feature RULE-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 1412 | feature RULE-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1413 | feature RULE-055 name present | pass | o28-stage2-final-inventory.log |
| 1414 | feature RULE-055 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1415 | feature RULE-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1416 | feature RULE-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 1417 | feature RULE-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1418 | feature RULE-056 name present | pass | o28-stage2-final-inventory.log |
| 1419 | feature RULE-056 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1420 | feature RULE-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1421 | feature RULE-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 1422 | feature RULE-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1423 | feature RULE-057 name present | pass | o28-stage2-final-inventory.log |
| 1424 | feature RULE-057 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1425 | feature RULE-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1426 | feature RULE-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 1427 | feature RULE-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1428 | feature RULE-058 name present | pass | o28-stage2-final-inventory.log |
| 1429 | feature RULE-058 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1430 | feature RULE-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1431 | feature RULE-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 1432 | feature RULE-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1433 | feature RULE-059 name present | pass | o28-stage2-final-inventory.log |
| 1434 | feature RULE-059 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1435 | feature RULE-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1436 | feature RULE-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 1437 | feature RULE-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1438 | feature RULE-060 name present | pass | o28-stage2-final-inventory.log |
| 1439 | feature RULE-060 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1440 | feature RULE-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1441 | feature RULE-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 1442 | feature RULE-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1443 | feature RULE-061 name present | pass | o28-stage2-final-inventory.log |
| 1444 | feature RULE-061 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1445 | feature RULE-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1446 | feature RULE-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 1447 | feature RULE-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1448 | feature RULE-062 name present | pass | o28-stage2-final-inventory.log |
| 1449 | feature RULE-062 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1450 | feature RULE-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1451 | feature RULE-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 1452 | feature RULE-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1453 | feature RULE-063 name present | pass | o28-stage2-final-inventory.log |
| 1454 | feature RULE-063 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1455 | feature RULE-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1456 | feature RULE-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 1457 | feature RULE-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1458 | feature RULE-064 name present | pass | o28-stage2-final-inventory.log |
| 1459 | feature RULE-064 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1460 | feature RULE-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1461 | feature RULE-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 1462 | feature RULE-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1463 | feature RULE-065 name present | pass | o28-stage2-final-inventory.log |
| 1464 | feature RULE-065 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1465 | feature RULE-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1466 | feature RULE-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 1467 | feature RULE-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1468 | feature RULE-066 name present | pass | o28-stage2-final-inventory.log |
| 1469 | feature RULE-066 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1470 | feature RULE-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1471 | feature RULE-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 1472 | feature RULE-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1473 | feature RULE-067 name present | pass | o28-stage2-final-inventory.log |
| 1474 | feature RULE-067 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1475 | feature RULE-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1476 | feature RULE-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 1477 | feature RULE-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1478 | feature RULE-068 name present | pass | o28-stage2-final-inventory.log |
| 1479 | feature RULE-068 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1480 | feature RULE-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1481 | feature RULE-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 1482 | feature RULE-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1483 | feature RULE-069 name present | pass | o28-stage2-final-inventory.log |
| 1484 | feature RULE-069 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1485 | feature RULE-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1486 | feature RULE-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 1487 | feature RULE-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1488 | feature RULE-070 name present | pass | o28-stage2-final-inventory.log |
| 1489 | feature RULE-070 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1490 | feature RULE-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1491 | feature RULE-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 1492 | feature RULE-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1493 | feature RULE-071 name present | pass | o28-stage2-final-inventory.log |
| 1494 | feature RULE-071 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1495 | feature RULE-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1496 | feature RULE-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 1497 | feature RULE-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1498 | feature RULE-072 name present | pass | o28-stage2-final-inventory.log |
| 1499 | feature RULE-072 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1500 | feature RULE-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1501 | feature RULE-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 1502 | feature RULE-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1503 | feature RULE-073 name present | pass | o28-stage2-final-inventory.log |
| 1504 | feature RULE-073 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1505 | feature RULE-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1506 | feature RULE-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 1507 | feature RULE-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1508 | feature RULE-074 name present | pass | o28-stage2-final-inventory.log |
| 1509 | feature RULE-074 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1510 | feature RULE-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1511 | feature RULE-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 1512 | feature RULE-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1513 | feature RULE-075 name present | pass | o28-stage2-final-inventory.log |
| 1514 | feature RULE-075 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1515 | feature RULE-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1516 | feature RULE-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 1517 | feature RULE-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1518 | feature RULE-076 name present | pass | o28-stage2-final-inventory.log |
| 1519 | feature RULE-076 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1520 | feature RULE-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1521 | feature RULE-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 1522 | feature RULE-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1523 | feature RULE-077 name present | pass | o28-stage2-final-inventory.log |
| 1524 | feature RULE-077 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1525 | feature RULE-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1526 | feature RULE-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 1527 | feature RULE-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1528 | feature RULE-078 name present | pass | o28-stage2-final-inventory.log |
| 1529 | feature RULE-078 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1530 | feature RULE-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1531 | feature RULE-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 1532 | feature RULE-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1533 | feature RULE-079 name present | pass | o28-stage2-final-inventory.log |
| 1534 | feature RULE-079 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1535 | feature RULE-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1536 | feature RULE-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 1537 | feature RULE-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1538 | feature RULE-080 name present | pass | o28-stage2-final-inventory.log |
| 1539 | feature RULE-080 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1540 | feature RULE-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1541 | feature RULE-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 1542 | feature RULE-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1543 | feature RULE-081 name present | pass | o28-stage2-final-inventory.log |
| 1544 | feature RULE-081 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1545 | feature RULE-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1546 | feature RULE-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 1547 | feature RULE-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1548 | feature RULE-082 name present | pass | o28-stage2-final-inventory.log |
| 1549 | feature RULE-082 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1550 | feature RULE-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1551 | feature RULE-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 1552 | feature RULE-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1553 | feature RULE-083 name present | pass | o28-stage2-final-inventory.log |
| 1554 | feature RULE-083 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1555 | feature RULE-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1556 | feature RULE-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 1557 | feature RULE-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1558 | feature RULE-084 name present | pass | o28-stage2-final-inventory.log |
| 1559 | feature RULE-084 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1560 | feature RULE-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1561 | feature RULE-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 1562 | feature RULE-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1563 | feature RULE-085 name present | pass | o28-stage2-final-inventory.log |
| 1564 | feature RULE-085 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1565 | feature RULE-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1566 | feature RULE-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 1567 | feature RULE-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1568 | feature RULE-086 name present | pass | o28-stage2-final-inventory.log |
| 1569 | feature RULE-086 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1570 | feature RULE-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1571 | feature RULE-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 1572 | feature RULE-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1573 | feature RULE-087 name present | pass | o28-stage2-final-inventory.log |
| 1574 | feature RULE-087 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1575 | feature RULE-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1576 | feature RULE-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 1577 | feature RULE-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1578 | feature RULE-088 name present | pass | o28-stage2-final-inventory.log |
| 1579 | feature RULE-088 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1580 | feature RULE-088 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1581 | feature RULE-088 test area assigned | pass | o28-stage2-final-inventory.log |
| 1582 | feature RULE-088 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1583 | feature RULE-089 name present | pass | o28-stage2-final-inventory.log |
| 1584 | feature RULE-089 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1585 | feature RULE-089 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1586 | feature RULE-089 test area assigned | pass | o28-stage2-final-inventory.log |
| 1587 | feature RULE-089 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1588 | feature RULE-090 name present | pass | o28-stage2-final-inventory.log |
| 1589 | feature RULE-090 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1590 | feature RULE-090 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1591 | feature RULE-090 test area assigned | pass | o28-stage2-final-inventory.log |
| 1592 | feature RULE-090 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1593 | feature RULE-091 name present | pass | o28-stage2-final-inventory.log |
| 1594 | feature RULE-091 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1595 | feature RULE-091 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1596 | feature RULE-091 test area assigned | pass | o28-stage2-final-inventory.log |
| 1597 | feature RULE-091 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1598 | feature RULE-092 name present | pass | o28-stage2-final-inventory.log |
| 1599 | feature RULE-092 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1600 | feature RULE-092 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1601 | feature RULE-092 test area assigned | pass | o28-stage2-final-inventory.log |
| 1602 | feature RULE-092 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1603 | feature RULE-093 name present | pass | o28-stage2-final-inventory.log |
| 1604 | feature RULE-093 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1605 | feature RULE-093 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1606 | feature RULE-093 test area assigned | pass | o28-stage2-final-inventory.log |
| 1607 | feature RULE-093 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1608 | feature RULE-094 name present | pass | o28-stage2-final-inventory.log |
| 1609 | feature RULE-094 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1610 | feature RULE-094 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1611 | feature RULE-094 test area assigned | pass | o28-stage2-final-inventory.log |
| 1612 | feature RULE-094 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1613 | feature RULE-095 name present | pass | o28-stage2-final-inventory.log |
| 1614 | feature RULE-095 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1615 | feature RULE-095 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1616 | feature RULE-095 test area assigned | pass | o28-stage2-final-inventory.log |
| 1617 | feature RULE-095 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1618 | feature RULE-096 name present | pass | o28-stage2-final-inventory.log |
| 1619 | feature RULE-096 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1620 | feature RULE-096 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1621 | feature RULE-096 test area assigned | pass | o28-stage2-final-inventory.log |
| 1622 | feature RULE-096 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1623 | feature RULE-097 name present | pass | o28-stage2-final-inventory.log |
| 1624 | feature RULE-097 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1625 | feature RULE-097 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1626 | feature RULE-097 test area assigned | pass | o28-stage2-final-inventory.log |
| 1627 | feature RULE-097 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1628 | feature RULE-098 name present | pass | o28-stage2-final-inventory.log |
| 1629 | feature RULE-098 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1630 | feature RULE-098 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1631 | feature RULE-098 test area assigned | pass | o28-stage2-final-inventory.log |
| 1632 | feature RULE-098 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1633 | feature RULE-099 name present | pass | o28-stage2-final-inventory.log |
| 1634 | feature RULE-099 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1635 | feature RULE-099 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1636 | feature RULE-099 test area assigned | pass | o28-stage2-final-inventory.log |
| 1637 | feature RULE-099 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1638 | feature RULE-100 name present | pass | o28-stage2-final-inventory.log |
| 1639 | feature RULE-100 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1640 | feature RULE-100 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1641 | feature RULE-100 test area assigned | pass | o28-stage2-final-inventory.log |
| 1642 | feature RULE-100 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1643 | feature RULE-101 name present | pass | o28-stage2-final-inventory.log |
| 1644 | feature RULE-101 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1645 | feature RULE-101 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1646 | feature RULE-101 test area assigned | pass | o28-stage2-final-inventory.log |
| 1647 | feature RULE-101 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1648 | feature RULE-102 name present | pass | o28-stage2-final-inventory.log |
| 1649 | feature RULE-102 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1650 | feature RULE-102 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1651 | feature RULE-102 test area assigned | pass | o28-stage2-final-inventory.log |
| 1652 | feature RULE-102 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1653 | feature RULE-103 name present | pass | o28-stage2-final-inventory.log |
| 1654 | feature RULE-103 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1655 | feature RULE-103 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1656 | feature RULE-103 test area assigned | pass | o28-stage2-final-inventory.log |
| 1657 | feature RULE-103 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1658 | feature RULE-104 name present | pass | o28-stage2-final-inventory.log |
| 1659 | feature RULE-104 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1660 | feature RULE-104 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1661 | feature RULE-104 test area assigned | pass | o28-stage2-final-inventory.log |
| 1662 | feature RULE-104 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1663 | feature RULE-105 name present | pass | o28-stage2-final-inventory.log |
| 1664 | feature RULE-105 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1665 | feature RULE-105 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1666 | feature RULE-105 test area assigned | pass | o28-stage2-final-inventory.log |
| 1667 | feature RULE-105 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1668 | feature RULE-106 name present | pass | o28-stage2-final-inventory.log |
| 1669 | feature RULE-106 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1670 | feature RULE-106 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1671 | feature RULE-106 test area assigned | pass | o28-stage2-final-inventory.log |
| 1672 | feature RULE-106 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1673 | feature RULE-107 name present | pass | o28-stage2-final-inventory.log |
| 1674 | feature RULE-107 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1675 | feature RULE-107 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1676 | feature RULE-107 test area assigned | pass | o28-stage2-final-inventory.log |
| 1677 | feature RULE-107 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1678 | feature RULE-108 name present | pass | o28-stage2-final-inventory.log |
| 1679 | feature RULE-108 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1680 | feature RULE-108 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1681 | feature RULE-108 test area assigned | pass | o28-stage2-final-inventory.log |
| 1682 | feature RULE-108 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1683 | feature RULE-109 name present | pass | o28-stage2-final-inventory.log |
| 1684 | feature RULE-109 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1685 | feature RULE-109 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1686 | feature RULE-109 test area assigned | pass | o28-stage2-final-inventory.log |
| 1687 | feature RULE-109 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1688 | feature RULE-110 name present | pass | o28-stage2-final-inventory.log |
| 1689 | feature RULE-110 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1690 | feature RULE-110 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1691 | feature RULE-110 test area assigned | pass | o28-stage2-final-inventory.log |
| 1692 | feature RULE-110 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1693 | feature RULE-111 name present | pass | o28-stage2-final-inventory.log |
| 1694 | feature RULE-111 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1695 | feature RULE-111 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1696 | feature RULE-111 test area assigned | pass | o28-stage2-final-inventory.log |
| 1697 | feature RULE-111 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1698 | feature RULE-112 name present | pass | o28-stage2-final-inventory.log |
| 1699 | feature RULE-112 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1700 | feature RULE-112 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1701 | feature RULE-112 test area assigned | pass | o28-stage2-final-inventory.log |
| 1702 | feature RULE-112 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1703 | feature EVT-001 name present | pass | o28-stage2-final-inventory.log |
| 1704 | feature EVT-001 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1705 | feature EVT-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1706 | feature EVT-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 1707 | feature EVT-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1708 | feature EVT-002 name present | pass | o28-stage2-final-inventory.log |
| 1709 | feature EVT-002 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1710 | feature EVT-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1711 | feature EVT-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 1712 | feature EVT-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1713 | feature EVT-003 name present | pass | o28-stage2-final-inventory.log |
| 1714 | feature EVT-003 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1715 | feature EVT-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1716 | feature EVT-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 1717 | feature EVT-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1718 | feature EVT-004 name present | pass | o28-stage2-final-inventory.log |
| 1719 | feature EVT-004 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1720 | feature EVT-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1721 | feature EVT-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 1722 | feature EVT-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1723 | feature EVT-005 name present | pass | o28-stage2-final-inventory.log |
| 1724 | feature EVT-005 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1725 | feature EVT-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1726 | feature EVT-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 1727 | feature EVT-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1728 | feature EVT-006 name present | pass | o28-stage2-final-inventory.log |
| 1729 | feature EVT-006 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1730 | feature EVT-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1731 | feature EVT-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 1732 | feature EVT-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1733 | feature EVT-007 name present | pass | o28-stage2-final-inventory.log |
| 1734 | feature EVT-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1735 | feature EVT-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1736 | feature EVT-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 1737 | feature EVT-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1738 | feature EVT-008 name present | pass | o28-stage2-final-inventory.log |
| 1739 | feature EVT-008 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1740 | feature EVT-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1741 | feature EVT-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 1742 | feature EVT-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1743 | feature EVT-009 name present | pass | o28-stage2-final-inventory.log |
| 1744 | feature EVT-009 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1745 | feature EVT-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1746 | feature EVT-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 1747 | feature EVT-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1748 | feature EVT-010 name present | pass | o28-stage2-final-inventory.log |
| 1749 | feature EVT-010 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1750 | feature EVT-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1751 | feature EVT-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 1752 | feature EVT-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1753 | feature EVT-011 name present | pass | o28-stage2-final-inventory.log |
| 1754 | feature EVT-011 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1755 | feature EVT-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1756 | feature EVT-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 1757 | feature EVT-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1758 | feature EVT-012 name present | pass | o28-stage2-final-inventory.log |
| 1759 | feature EVT-012 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1760 | feature EVT-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1761 | feature EVT-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 1762 | feature EVT-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1763 | feature EVT-013 name present | pass | o28-stage2-final-inventory.log |
| 1764 | feature EVT-013 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1765 | feature EVT-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1766 | feature EVT-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 1767 | feature EVT-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1768 | feature EVT-014 name present | pass | o28-stage2-final-inventory.log |
| 1769 | feature EVT-014 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1770 | feature EVT-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1771 | feature EVT-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 1772 | feature EVT-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1773 | feature EVT-015 name present | pass | o28-stage2-final-inventory.log |
| 1774 | feature EVT-015 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1775 | feature EVT-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1776 | feature EVT-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 1777 | feature EVT-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1778 | feature EVT-016 name present | pass | o28-stage2-final-inventory.log |
| 1779 | feature EVT-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1780 | feature EVT-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1781 | feature EVT-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 1782 | feature EVT-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1783 | feature EVT-017 name present | pass | o28-stage2-final-inventory.log |
| 1784 | feature EVT-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1785 | feature EVT-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1786 | feature EVT-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 1787 | feature EVT-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1788 | feature EVT-018 name present | pass | o28-stage2-final-inventory.log |
| 1789 | feature EVT-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1790 | feature EVT-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1791 | feature EVT-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 1792 | feature EVT-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1793 | feature EVT-019 name present | pass | o28-stage2-final-inventory.log |
| 1794 | feature EVT-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1795 | feature EVT-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1796 | feature EVT-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 1797 | feature EVT-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1798 | feature EVT-020 name present | pass | o28-stage2-final-inventory.log |
| 1799 | feature EVT-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1800 | feature EVT-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1801 | feature EVT-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 1802 | feature EVT-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1803 | feature EVT-021 name present | pass | o28-stage2-final-inventory.log |
| 1804 | feature EVT-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1805 | feature EVT-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1806 | feature EVT-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 1807 | feature EVT-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1808 | feature EVT-022 name present | pass | o28-stage2-final-inventory.log |
| 1809 | feature EVT-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1810 | feature EVT-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1811 | feature EVT-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 1812 | feature EVT-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1813 | feature EVT-023 name present | pass | o28-stage2-final-inventory.log |
| 1814 | feature EVT-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1815 | feature EVT-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1816 | feature EVT-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 1817 | feature EVT-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1818 | feature EVT-024 name present | pass | o28-stage2-final-inventory.log |
| 1819 | feature EVT-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1820 | feature EVT-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1821 | feature EVT-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 1822 | feature EVT-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1823 | feature EVT-025 name present | pass | o28-stage2-final-inventory.log |
| 1824 | feature EVT-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1825 | feature EVT-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1826 | feature EVT-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 1827 | feature EVT-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1828 | feature EVT-026 name present | pass | o28-stage2-final-inventory.log |
| 1829 | feature EVT-026 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1830 | feature EVT-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1831 | feature EVT-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 1832 | feature EVT-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1833 | feature EVT-027 name present | pass | o28-stage2-final-inventory.log |
| 1834 | feature EVT-027 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1835 | feature EVT-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1836 | feature EVT-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 1837 | feature EVT-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1838 | feature EVT-028 name present | pass | o28-stage2-final-inventory.log |
| 1839 | feature EVT-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1840 | feature EVT-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1841 | feature EVT-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 1842 | feature EVT-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1843 | feature EVT-029 name present | pass | o28-stage2-final-inventory.log |
| 1844 | feature EVT-029 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1845 | feature EVT-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1846 | feature EVT-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 1847 | feature EVT-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1848 | feature EVT-030 name present | pass | o28-stage2-final-inventory.log |
| 1849 | feature EVT-030 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1850 | feature EVT-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1851 | feature EVT-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 1852 | feature EVT-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1853 | feature EVT-031 name present | pass | o28-stage2-final-inventory.log |
| 1854 | feature EVT-031 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1855 | feature EVT-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1856 | feature EVT-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 1857 | feature EVT-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1858 | feature EVT-032 name present | pass | o28-stage2-final-inventory.log |
| 1859 | feature EVT-032 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1860 | feature EVT-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1861 | feature EVT-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 1862 | feature EVT-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1863 | feature EVT-033 name present | pass | o28-stage2-final-inventory.log |
| 1864 | feature EVT-033 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1865 | feature EVT-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1866 | feature EVT-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 1867 | feature EVT-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1868 | feature EVT-034 name present | pass | o28-stage2-final-inventory.log |
| 1869 | feature EVT-034 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1870 | feature EVT-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1871 | feature EVT-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 1872 | feature EVT-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1873 | feature EVT-035 name present | pass | o28-stage2-final-inventory.log |
| 1874 | feature EVT-035 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1875 | feature EVT-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1876 | feature EVT-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 1877 | feature EVT-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1878 | feature EVT-036 name present | pass | o28-stage2-final-inventory.log |
| 1879 | feature EVT-036 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 1880 | feature EVT-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1881 | feature EVT-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 1882 | feature EVT-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1883 | feature EVT-037 name present | pass | o28-stage2-final-inventory.log |
| 1884 | feature EVT-037 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1885 | feature EVT-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1886 | feature EVT-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 1887 | feature EVT-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1888 | feature EVT-038 name present | pass | o28-stage2-final-inventory.log |
| 1889 | feature EVT-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1890 | feature EVT-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1891 | feature EVT-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 1892 | feature EVT-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1893 | feature EVT-039 name present | pass | o28-stage2-final-inventory.log |
| 1894 | feature EVT-039 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1895 | feature EVT-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1896 | feature EVT-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 1897 | feature EVT-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1898 | feature EVT-040 name present | pass | o28-stage2-final-inventory.log |
| 1899 | feature EVT-040 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1900 | feature EVT-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1901 | feature EVT-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 1902 | feature EVT-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1903 | feature EVT-041 name present | pass | o28-stage2-final-inventory.log |
| 1904 | feature EVT-041 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1905 | feature EVT-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1906 | feature EVT-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 1907 | feature EVT-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1908 | feature EVT-042 name present | pass | o28-stage2-final-inventory.log |
| 1909 | feature EVT-042 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1910 | feature EVT-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1911 | feature EVT-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 1912 | feature EVT-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1913 | feature EVT-043 name present | pass | o28-stage2-final-inventory.log |
| 1914 | feature EVT-043 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1915 | feature EVT-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1916 | feature EVT-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 1917 | feature EVT-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1918 | feature EVT-044 name present | pass | o28-stage2-final-inventory.log |
| 1919 | feature EVT-044 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1920 | feature EVT-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1921 | feature EVT-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 1922 | feature EVT-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1923 | feature EVT-045 name present | pass | o28-stage2-final-inventory.log |
| 1924 | feature EVT-045 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1925 | feature EVT-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1926 | feature EVT-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 1927 | feature EVT-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1928 | feature EVT-046 name present | pass | o28-stage2-final-inventory.log |
| 1929 | feature EVT-046 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1930 | feature EVT-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1931 | feature EVT-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 1932 | feature EVT-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1933 | feature EVT-047 name present | pass | o28-stage2-final-inventory.log |
| 1934 | feature EVT-047 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1935 | feature EVT-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1936 | feature EVT-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 1937 | feature EVT-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1938 | feature EVT-048 name present | pass | o28-stage2-final-inventory.log |
| 1939 | feature EVT-048 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1940 | feature EVT-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1941 | feature EVT-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 1942 | feature EVT-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1943 | feature EVT-049 name present | pass | o28-stage2-final-inventory.log |
| 1944 | feature EVT-049 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1945 | feature EVT-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1946 | feature EVT-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 1947 | feature EVT-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1948 | feature EVT-050 name present | pass | o28-stage2-final-inventory.log |
| 1949 | feature EVT-050 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1950 | feature EVT-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1951 | feature EVT-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 1952 | feature EVT-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1953 | feature EVT-051 name present | pass | o28-stage2-final-inventory.log |
| 1954 | feature EVT-051 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1955 | feature EVT-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1956 | feature EVT-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 1957 | feature EVT-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1958 | feature EVT-052 name present | pass | o28-stage2-final-inventory.log |
| 1959 | feature EVT-052 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1960 | feature EVT-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1961 | feature EVT-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 1962 | feature EVT-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1963 | feature EVT-053 name present | pass | o28-stage2-final-inventory.log |
| 1964 | feature EVT-053 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1965 | feature EVT-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1966 | feature EVT-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 1967 | feature EVT-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1968 | feature EVT-054 name present | pass | o28-stage2-final-inventory.log |
| 1969 | feature EVT-054 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1970 | feature EVT-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1971 | feature EVT-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 1972 | feature EVT-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1973 | feature EVT-055 name present | pass | o28-stage2-final-inventory.log |
| 1974 | feature EVT-055 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1975 | feature EVT-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1976 | feature EVT-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 1977 | feature EVT-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1978 | feature EVT-056 name present | pass | o28-stage2-final-inventory.log |
| 1979 | feature EVT-056 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1980 | feature EVT-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1981 | feature EVT-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 1982 | feature EVT-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1983 | feature EVT-057 name present | pass | o28-stage2-final-inventory.log |
| 1984 | feature EVT-057 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1985 | feature EVT-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1986 | feature EVT-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 1987 | feature EVT-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1988 | feature EVT-058 name present | pass | o28-stage2-final-inventory.log |
| 1989 | feature EVT-058 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 1990 | feature EVT-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1991 | feature EVT-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 1992 | feature EVT-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1993 | feature EVT-059 name present | pass | o28-stage2-final-inventory.log |
| 1994 | feature EVT-059 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 1995 | feature EVT-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 1996 | feature EVT-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 1997 | feature EVT-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 1998 | feature EVT-060 name present | pass | o28-stage2-final-inventory.log |
| 1999 | feature EVT-060 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2000 | feature EVT-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2001 | feature EVT-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 2002 | feature EVT-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2003 | feature EVT-061 name present | pass | o28-stage2-final-inventory.log |
| 2004 | feature EVT-061 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2005 | feature EVT-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2006 | feature EVT-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 2007 | feature EVT-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2008 | feature EVT-062 name present | pass | o28-stage2-final-inventory.log |
| 2009 | feature EVT-062 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2010 | feature EVT-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2011 | feature EVT-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 2012 | feature EVT-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2013 | feature EVT-063 name present | pass | o28-stage2-final-inventory.log |
| 2014 | feature EVT-063 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2015 | feature EVT-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2016 | feature EVT-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 2017 | feature EVT-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2018 | feature EVT-064 name present | pass | o28-stage2-final-inventory.log |
| 2019 | feature EVT-064 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2020 | feature EVT-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2021 | feature EVT-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 2022 | feature EVT-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2023 | feature EVT-065 name present | pass | o28-stage2-final-inventory.log |
| 2024 | feature EVT-065 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2025 | feature EVT-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2026 | feature EVT-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 2027 | feature EVT-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2028 | feature EVT-066 name present | pass | o28-stage2-final-inventory.log |
| 2029 | feature EVT-066 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2030 | feature EVT-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2031 | feature EVT-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 2032 | feature EVT-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2033 | feature EVT-067 name present | pass | o28-stage2-final-inventory.log |
| 2034 | feature EVT-067 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2035 | feature EVT-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2036 | feature EVT-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 2037 | feature EVT-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2038 | feature EVT-068 name present | pass | o28-stage2-final-inventory.log |
| 2039 | feature EVT-068 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2040 | feature EVT-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2041 | feature EVT-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 2042 | feature EVT-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2043 | feature EVT-069 name present | pass | o28-stage2-final-inventory.log |
| 2044 | feature EVT-069 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2045 | feature EVT-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2046 | feature EVT-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 2047 | feature EVT-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2048 | feature EVT-070 name present | pass | o28-stage2-final-inventory.log |
| 2049 | feature EVT-070 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2050 | feature EVT-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2051 | feature EVT-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 2052 | feature EVT-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2053 | feature EVT-071 name present | pass | o28-stage2-final-inventory.log |
| 2054 | feature EVT-071 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2055 | feature EVT-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2056 | feature EVT-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 2057 | feature EVT-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2058 | feature EVT-072 name present | pass | o28-stage2-final-inventory.log |
| 2059 | feature EVT-072 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2060 | feature EVT-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2061 | feature EVT-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 2062 | feature EVT-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2063 | feature EVT-073 name present | pass | o28-stage2-final-inventory.log |
| 2064 | feature EVT-073 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2065 | feature EVT-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2066 | feature EVT-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 2067 | feature EVT-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2068 | feature EVT-074 name present | pass | o28-stage2-final-inventory.log |
| 2069 | feature EVT-074 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2070 | feature EVT-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2071 | feature EVT-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 2072 | feature EVT-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2073 | feature EVT-075 name present | pass | o28-stage2-final-inventory.log |
| 2074 | feature EVT-075 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2075 | feature EVT-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2076 | feature EVT-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 2077 | feature EVT-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2078 | feature EVT-076 name present | pass | o28-stage2-final-inventory.log |
| 2079 | feature EVT-076 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2080 | feature EVT-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2081 | feature EVT-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 2082 | feature EVT-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2083 | feature EVT-077 name present | pass | o28-stage2-final-inventory.log |
| 2084 | feature EVT-077 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2085 | feature EVT-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2086 | feature EVT-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 2087 | feature EVT-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2088 | feature EVT-078 name present | pass | o28-stage2-final-inventory.log |
| 2089 | feature EVT-078 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2090 | feature EVT-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2091 | feature EVT-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 2092 | feature EVT-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2093 | feature EVT-079 name present | pass | o28-stage2-final-inventory.log |
| 2094 | feature EVT-079 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2095 | feature EVT-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2096 | feature EVT-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 2097 | feature EVT-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2098 | feature EVT-080 name present | pass | o28-stage2-final-inventory.log |
| 2099 | feature EVT-080 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2100 | feature EVT-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2101 | feature EVT-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 2102 | feature EVT-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2103 | feature EVT-081 name present | pass | o28-stage2-final-inventory.log |
| 2104 | feature EVT-081 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2105 | feature EVT-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2106 | feature EVT-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 2107 | feature EVT-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2108 | feature EVT-082 name present | pass | o28-stage2-final-inventory.log |
| 2109 | feature EVT-082 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2110 | feature EVT-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2111 | feature EVT-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 2112 | feature EVT-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2113 | feature EVT-083 name present | pass | o28-stage2-final-inventory.log |
| 2114 | feature EVT-083 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2115 | feature EVT-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2116 | feature EVT-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 2117 | feature EVT-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2118 | feature EVT-084 name present | pass | o28-stage2-final-inventory.log |
| 2119 | feature EVT-084 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2120 | feature EVT-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2121 | feature EVT-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 2122 | feature EVT-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2123 | feature EVT-085 name present | pass | o28-stage2-final-inventory.log |
| 2124 | feature EVT-085 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2125 | feature EVT-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2126 | feature EVT-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 2127 | feature EVT-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2128 | feature EVT-086 name present | pass | o28-stage2-final-inventory.log |
| 2129 | feature EVT-086 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2130 | feature EVT-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2131 | feature EVT-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 2132 | feature EVT-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2133 | feature EVT-087 name present | pass | o28-stage2-final-inventory.log |
| 2134 | feature EVT-087 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2135 | feature EVT-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2136 | feature EVT-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 2137 | feature EVT-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2138 | feature CLIENT-001 name present | pass | o28-stage2-final-inventory.log |
| 2139 | feature CLIENT-001 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2140 | feature CLIENT-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2141 | feature CLIENT-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 2142 | feature CLIENT-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2143 | feature CLIENT-002 name present | pass | o28-stage2-final-inventory.log |
| 2144 | feature CLIENT-002 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2145 | feature CLIENT-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2146 | feature CLIENT-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 2147 | feature CLIENT-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2148 | feature CLIENT-003 name present | pass | o28-stage2-final-inventory.log |
| 2149 | feature CLIENT-003 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2150 | feature CLIENT-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2151 | feature CLIENT-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 2152 | feature CLIENT-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2153 | feature CLIENT-004 name present | pass | o28-stage2-final-inventory.log |
| 2154 | feature CLIENT-004 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2155 | feature CLIENT-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2156 | feature CLIENT-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 2157 | feature CLIENT-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2158 | feature CLIENT-005 name present | pass | o28-stage2-final-inventory.log |
| 2159 | feature CLIENT-005 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2160 | feature CLIENT-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2161 | feature CLIENT-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 2162 | feature CLIENT-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2163 | feature CLIENT-006 name present | pass | o28-stage2-final-inventory.log |
| 2164 | feature CLIENT-006 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2165 | feature CLIENT-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2166 | feature CLIENT-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 2167 | feature CLIENT-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2168 | feature CLIENT-007 name present | pass | o28-stage2-final-inventory.log |
| 2169 | feature CLIENT-007 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2170 | feature CLIENT-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2171 | feature CLIENT-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 2172 | feature CLIENT-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2173 | feature CLIENT-008 name present | pass | o28-stage2-final-inventory.log |
| 2174 | feature CLIENT-008 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2175 | feature CLIENT-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2176 | feature CLIENT-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 2177 | feature CLIENT-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2178 | feature CLIENT-009 name present | pass | o28-stage2-final-inventory.log |
| 2179 | feature CLIENT-009 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2180 | feature CLIENT-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2181 | feature CLIENT-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 2182 | feature CLIENT-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2183 | feature CLIENT-010 name present | pass | o28-stage2-final-inventory.log |
| 2184 | feature CLIENT-010 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2185 | feature CLIENT-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2186 | feature CLIENT-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 2187 | feature CLIENT-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2188 | feature CLIENT-011 name present | pass | o28-stage2-final-inventory.log |
| 2189 | feature CLIENT-011 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2190 | feature CLIENT-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2191 | feature CLIENT-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 2192 | feature CLIENT-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2193 | feature CLIENT-012 name present | pass | o28-stage2-final-inventory.log |
| 2194 | feature CLIENT-012 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2195 | feature CLIENT-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2196 | feature CLIENT-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 2197 | feature CLIENT-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2198 | feature CLIENT-013 name present | pass | o28-stage2-final-inventory.log |
| 2199 | feature CLIENT-013 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2200 | feature CLIENT-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2201 | feature CLIENT-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 2202 | feature CLIENT-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2203 | feature CLIENT-014 name present | pass | o28-stage2-final-inventory.log |
| 2204 | feature CLIENT-014 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2205 | feature CLIENT-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2206 | feature CLIENT-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 2207 | feature CLIENT-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2208 | feature CLIENT-015 name present | pass | o28-stage2-final-inventory.log |
| 2209 | feature CLIENT-015 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2210 | feature CLIENT-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2211 | feature CLIENT-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 2212 | feature CLIENT-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2213 | feature CLIENT-016 name present | pass | o28-stage2-final-inventory.log |
| 2214 | feature CLIENT-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2215 | feature CLIENT-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2216 | feature CLIENT-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 2217 | feature CLIENT-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2218 | feature CLIENT-017 name present | pass | o28-stage2-final-inventory.log |
| 2219 | feature CLIENT-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2220 | feature CLIENT-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2221 | feature CLIENT-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 2222 | feature CLIENT-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2223 | feature CLIENT-018 name present | pass | o28-stage2-final-inventory.log |
| 2224 | feature CLIENT-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2225 | feature CLIENT-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2226 | feature CLIENT-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 2227 | feature CLIENT-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2228 | feature CLIENT-019 name present | pass | o28-stage2-final-inventory.log |
| 2229 | feature CLIENT-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2230 | feature CLIENT-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2231 | feature CLIENT-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 2232 | feature CLIENT-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2233 | feature CLIENT-020 name present | pass | o28-stage2-final-inventory.log |
| 2234 | feature CLIENT-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2235 | feature CLIENT-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2236 | feature CLIENT-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 2237 | feature CLIENT-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2238 | feature CLIENT-021 name present | pass | o28-stage2-final-inventory.log |
| 2239 | feature CLIENT-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2240 | feature CLIENT-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2241 | feature CLIENT-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 2242 | feature CLIENT-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2243 | feature CLIENT-022 name present | pass | o28-stage2-final-inventory.log |
| 2244 | feature CLIENT-022 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2245 | feature CLIENT-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2246 | feature CLIENT-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 2247 | feature CLIENT-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2248 | feature CLIENT-023 name present | pass | o28-stage2-final-inventory.log |
| 2249 | feature CLIENT-023 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2250 | feature CLIENT-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2251 | feature CLIENT-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 2252 | feature CLIENT-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2253 | feature CLIENT-024 name present | pass | o28-stage2-final-inventory.log |
| 2254 | feature CLIENT-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2255 | feature CLIENT-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2256 | feature CLIENT-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 2257 | feature CLIENT-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2258 | feature CLIENT-025 name present | pass | o28-stage2-final-inventory.log |
| 2259 | feature CLIENT-025 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2260 | feature CLIENT-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2261 | feature CLIENT-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 2262 | feature CLIENT-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2263 | feature CLIENT-026 name present | pass | o28-stage2-final-inventory.log |
| 2264 | feature CLIENT-026 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2265 | feature CLIENT-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2266 | feature CLIENT-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 2267 | feature CLIENT-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2268 | feature CLIENT-027 name present | pass | o28-stage2-final-inventory.log |
| 2269 | feature CLIENT-027 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2270 | feature CLIENT-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2271 | feature CLIENT-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 2272 | feature CLIENT-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2273 | feature CLIENT-028 name present | pass | o28-stage2-final-inventory.log |
| 2274 | feature CLIENT-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2275 | feature CLIENT-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2276 | feature CLIENT-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 2277 | feature CLIENT-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2278 | feature CLIENT-029 name present | pass | o28-stage2-final-inventory.log |
| 2279 | feature CLIENT-029 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2280 | feature CLIENT-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2281 | feature CLIENT-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 2282 | feature CLIENT-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2283 | feature CLIENT-030 name present | pass | o28-stage2-final-inventory.log |
| 2284 | feature CLIENT-030 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2285 | feature CLIENT-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2286 | feature CLIENT-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 2287 | feature CLIENT-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2288 | feature CLIENT-031 name present | pass | o28-stage2-final-inventory.log |
| 2289 | feature CLIENT-031 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2290 | feature CLIENT-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2291 | feature CLIENT-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 2292 | feature CLIENT-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2293 | feature CLIENT-032 name present | pass | o28-stage2-final-inventory.log |
| 2294 | feature CLIENT-032 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2295 | feature CLIENT-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2296 | feature CLIENT-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 2297 | feature CLIENT-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2298 | feature CLIENT-033 name present | pass | o28-stage2-final-inventory.log |
| 2299 | feature CLIENT-033 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2300 | feature CLIENT-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2301 | feature CLIENT-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 2302 | feature CLIENT-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2303 | feature CLIENT-034 name present | pass | o28-stage2-final-inventory.log |
| 2304 | feature CLIENT-034 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2305 | feature CLIENT-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2306 | feature CLIENT-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 2307 | feature CLIENT-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2308 | feature CLIENT-035 name present | pass | o28-stage2-final-inventory.log |
| 2309 | feature CLIENT-035 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2310 | feature CLIENT-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2311 | feature CLIENT-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 2312 | feature CLIENT-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2313 | feature CLIENT-036 name present | pass | o28-stage2-final-inventory.log |
| 2314 | feature CLIENT-036 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2315 | feature CLIENT-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2316 | feature CLIENT-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 2317 | feature CLIENT-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2318 | feature CLIENT-037 name present | pass | o28-stage2-final-inventory.log |
| 2319 | feature CLIENT-037 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2320 | feature CLIENT-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2321 | feature CLIENT-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 2322 | feature CLIENT-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2323 | feature CLIENT-038 name present | pass | o28-stage2-final-inventory.log |
| 2324 | feature CLIENT-038 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2325 | feature CLIENT-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2326 | feature CLIENT-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 2327 | feature CLIENT-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2328 | feature CLIENT-039 name present | pass | o28-stage2-final-inventory.log |
| 2329 | feature CLIENT-039 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2330 | feature CLIENT-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2331 | feature CLIENT-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 2332 | feature CLIENT-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2333 | feature CLIENT-040 name present | pass | o28-stage2-final-inventory.log |
| 2334 | feature CLIENT-040 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2335 | feature CLIENT-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2336 | feature CLIENT-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 2337 | feature CLIENT-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2338 | feature CLIENT-041 name present | pass | o28-stage2-final-inventory.log |
| 2339 | feature CLIENT-041 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2340 | feature CLIENT-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2341 | feature CLIENT-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 2342 | feature CLIENT-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2343 | feature CLIENT-042 name present | pass | o28-stage2-final-inventory.log |
| 2344 | feature CLIENT-042 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2345 | feature CLIENT-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2346 | feature CLIENT-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 2347 | feature CLIENT-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2348 | feature MEDIA-001 name present | pass | o28-stage2-final-inventory.log |
| 2349 | feature MEDIA-001 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2350 | feature MEDIA-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2351 | feature MEDIA-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 2352 | feature MEDIA-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2353 | feature MEDIA-002 name present | pass | o28-stage2-final-inventory.log |
| 2354 | feature MEDIA-002 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2355 | feature MEDIA-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2356 | feature MEDIA-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 2357 | feature MEDIA-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2358 | feature MEDIA-003 name present | pass | o28-stage2-final-inventory.log |
| 2359 | feature MEDIA-003 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2360 | feature MEDIA-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2361 | feature MEDIA-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 2362 | feature MEDIA-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2363 | feature MEDIA-004 name present | pass | o28-stage2-final-inventory.log |
| 2364 | feature MEDIA-004 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2365 | feature MEDIA-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2366 | feature MEDIA-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 2367 | feature MEDIA-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2368 | feature MEDIA-005 name present | pass | o28-stage2-final-inventory.log |
| 2369 | feature MEDIA-005 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2370 | feature MEDIA-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2371 | feature MEDIA-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 2372 | feature MEDIA-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2373 | feature MEDIA-006 name present | pass | o28-stage2-final-inventory.log |
| 2374 | feature MEDIA-006 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2375 | feature MEDIA-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2376 | feature MEDIA-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 2377 | feature MEDIA-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2378 | feature MEDIA-007 name present | pass | o28-stage2-final-inventory.log |
| 2379 | feature MEDIA-007 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2380 | feature MEDIA-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2381 | feature MEDIA-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 2382 | feature MEDIA-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2383 | feature MEDIA-008 name present | pass | o28-stage2-final-inventory.log |
| 2384 | feature MEDIA-008 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2385 | feature MEDIA-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2386 | feature MEDIA-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 2387 | feature MEDIA-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2388 | feature MEDIA-009 name present | pass | o28-stage2-final-inventory.log |
| 2389 | feature MEDIA-009 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2390 | feature MEDIA-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2391 | feature MEDIA-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 2392 | feature MEDIA-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2393 | feature MEDIA-010 name present | pass | o28-stage2-final-inventory.log |
| 2394 | feature MEDIA-010 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2395 | feature MEDIA-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2396 | feature MEDIA-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 2397 | feature MEDIA-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2398 | feature MEDIA-011 name present | pass | o28-stage2-final-inventory.log |
| 2399 | feature MEDIA-011 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2400 | feature MEDIA-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2401 | feature MEDIA-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 2402 | feature MEDIA-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2403 | feature MEDIA-012 name present | pass | o28-stage2-final-inventory.log |
| 2404 | feature MEDIA-012 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2405 | feature MEDIA-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2406 | feature MEDIA-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 2407 | feature MEDIA-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2408 | feature MEDIA-013 name present | pass | o28-stage2-final-inventory.log |
| 2409 | feature MEDIA-013 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2410 | feature MEDIA-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2411 | feature MEDIA-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 2412 | feature MEDIA-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2413 | feature MEDIA-014 name present | pass | o28-stage2-final-inventory.log |
| 2414 | feature MEDIA-014 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2415 | feature MEDIA-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2416 | feature MEDIA-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 2417 | feature MEDIA-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2418 | feature MEDIA-015 name present | pass | o28-stage2-final-inventory.log |
| 2419 | feature MEDIA-015 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2420 | feature MEDIA-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2421 | feature MEDIA-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 2422 | feature MEDIA-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2423 | feature MEDIA-016 name present | pass | o28-stage2-final-inventory.log |
| 2424 | feature MEDIA-016 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2425 | feature MEDIA-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2426 | feature MEDIA-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 2427 | feature MEDIA-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2428 | feature MEDIA-017 name present | pass | o28-stage2-final-inventory.log |
| 2429 | feature MEDIA-017 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 2430 | feature MEDIA-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2431 | feature MEDIA-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 2432 | feature MEDIA-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2433 | feature MEDIA-018 name present | pass | o28-stage2-final-inventory.log |
| 2434 | feature MEDIA-018 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2435 | feature MEDIA-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2436 | feature MEDIA-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 2437 | feature MEDIA-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2438 | feature MEDIA-019 name present | pass | o28-stage2-final-inventory.log |
| 2439 | feature MEDIA-019 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 2440 | feature MEDIA-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2441 | feature MEDIA-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 2442 | feature MEDIA-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2443 | feature MEDIA-020 name present | pass | o28-stage2-final-inventory.log |
| 2444 | feature MEDIA-020 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2445 | feature MEDIA-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2446 | feature MEDIA-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 2447 | feature MEDIA-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2448 | feature MEDIA-021 name present | pass | o28-stage2-final-inventory.log |
| 2449 | feature MEDIA-021 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2450 | feature MEDIA-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2451 | feature MEDIA-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 2452 | feature MEDIA-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2453 | feature MEDIA-022 name present | pass | o28-stage2-final-inventory.log |
| 2454 | feature MEDIA-022 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2455 | feature MEDIA-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2456 | feature MEDIA-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 2457 | feature MEDIA-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2458 | feature MEDIA-023 name present | pass | o28-stage2-final-inventory.log |
| 2459 | feature MEDIA-023 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2460 | feature MEDIA-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2461 | feature MEDIA-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 2462 | feature MEDIA-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2463 | feature MEDIA-024 name present | pass | o28-stage2-final-inventory.log |
| 2464 | feature MEDIA-024 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2465 | feature MEDIA-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2466 | feature MEDIA-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 2467 | feature MEDIA-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2468 | feature MEDIA-025 name present | pass | o28-stage2-final-inventory.log |
| 2469 | feature MEDIA-025 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2470 | feature MEDIA-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2471 | feature MEDIA-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 2472 | feature MEDIA-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2473 | feature MEDIA-026 name present | pass | o28-stage2-final-inventory.log |
| 2474 | feature MEDIA-026 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2475 | feature MEDIA-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2476 | feature MEDIA-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 2477 | feature MEDIA-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2478 | feature MEDIA-027 name present | pass | o28-stage2-final-inventory.log |
| 2479 | feature MEDIA-027 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2480 | feature MEDIA-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2481 | feature MEDIA-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 2482 | feature MEDIA-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2483 | feature LAB-001 name present | pass | o28-stage2-final-inventory.log |
| 2484 | feature LAB-001 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2485 | feature LAB-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2486 | feature LAB-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 2487 | feature LAB-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2488 | feature LAB-002 name present | pass | o28-stage2-final-inventory.log |
| 2489 | feature LAB-002 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2490 | feature LAB-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2491 | feature LAB-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 2492 | feature LAB-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2493 | feature LAB-003 name present | pass | o28-stage2-final-inventory.log |
| 2494 | feature LAB-003 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2495 | feature LAB-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2496 | feature LAB-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 2497 | feature LAB-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2498 | feature LAB-004 name present | pass | o28-stage2-final-inventory.log |
| 2499 | feature LAB-004 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2500 | feature LAB-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2501 | feature LAB-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 2502 | feature LAB-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2503 | feature LAB-005 name present | pass | o28-stage2-final-inventory.log |
| 2504 | feature LAB-005 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2505 | feature LAB-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2506 | feature LAB-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 2507 | feature LAB-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2508 | feature LAB-006 name present | pass | o28-stage2-final-inventory.log |
| 2509 | feature LAB-006 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2510 | feature LAB-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2511 | feature LAB-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 2512 | feature LAB-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2513 | feature LAB-007 name present | pass | o28-stage2-final-inventory.log |
| 2514 | feature LAB-007 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2515 | feature LAB-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2516 | feature LAB-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 2517 | feature LAB-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2518 | feature LAB-008 name present | pass | o28-stage2-final-inventory.log |
| 2519 | feature LAB-008 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2520 | feature LAB-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2521 | feature LAB-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 2522 | feature LAB-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2523 | feature LAB-009 name present | pass | o28-stage2-final-inventory.log |
| 2524 | feature LAB-009 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2525 | feature LAB-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2526 | feature LAB-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 2527 | feature LAB-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2528 | feature LAB-010 name present | pass | o28-stage2-final-inventory.log |
| 2529 | feature LAB-010 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2530 | feature LAB-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2531 | feature LAB-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 2532 | feature LAB-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2533 | feature LAB-011 name present | pass | o28-stage2-final-inventory.log |
| 2534 | feature LAB-011 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2535 | feature LAB-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2536 | feature LAB-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 2537 | feature LAB-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2538 | feature LAB-012 name present | pass | o28-stage2-final-inventory.log |
| 2539 | feature LAB-012 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2540 | feature LAB-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2541 | feature LAB-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 2542 | feature LAB-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2543 | feature LAB-013 name present | pass | o28-stage2-final-inventory.log |
| 2544 | feature LAB-013 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2545 | feature LAB-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2546 | feature LAB-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 2547 | feature LAB-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2548 | feature LAB-014 name present | pass | o28-stage2-final-inventory.log |
| 2549 | feature LAB-014 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2550 | feature LAB-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2551 | feature LAB-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 2552 | feature LAB-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2553 | feature LAB-015 name present | pass | o28-stage2-final-inventory.log |
| 2554 | feature LAB-015 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2555 | feature LAB-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2556 | feature LAB-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 2557 | feature LAB-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2558 | feature LAB-016 name present | pass | o28-stage2-final-inventory.log |
| 2559 | feature LAB-016 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2560 | feature LAB-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2561 | feature LAB-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 2562 | feature LAB-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2563 | feature LAB-017 name present | pass | o28-stage2-final-inventory.log |
| 2564 | feature LAB-017 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2565 | feature LAB-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2566 | feature LAB-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 2567 | feature LAB-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2568 | feature LAB-018 name present | pass | o28-stage2-final-inventory.log |
| 2569 | feature LAB-018 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2570 | feature LAB-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2571 | feature LAB-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 2572 | feature LAB-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2573 | feature LAB-019 name present | pass | o28-stage2-final-inventory.log |
| 2574 | feature LAB-019 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2575 | feature LAB-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2576 | feature LAB-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 2577 | feature LAB-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2578 | feature LAB-020 name present | pass | o28-stage2-final-inventory.log |
| 2579 | feature LAB-020 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2580 | feature LAB-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2581 | feature LAB-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 2582 | feature LAB-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2583 | feature LAB-021 name present | pass | o28-stage2-final-inventory.log |
| 2584 | feature LAB-021 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2585 | feature LAB-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2586 | feature LAB-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 2587 | feature LAB-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2588 | feature LAB-022 name present | pass | o28-stage2-final-inventory.log |
| 2589 | feature LAB-022 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2590 | feature LAB-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2591 | feature LAB-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 2592 | feature LAB-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2593 | feature LAB-023 name present | pass | o28-stage2-final-inventory.log |
| 2594 | feature LAB-023 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2595 | feature LAB-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2596 | feature LAB-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 2597 | feature LAB-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2598 | feature LAB-024 name present | pass | o28-stage2-final-inventory.log |
| 2599 | feature LAB-024 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2600 | feature LAB-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2601 | feature LAB-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 2602 | feature LAB-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2603 | feature LAB-025 name present | pass | o28-stage2-final-inventory.log |
| 2604 | feature LAB-025 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2605 | feature LAB-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2606 | feature LAB-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 2607 | feature LAB-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2608 | feature LAB-026 name present | pass | o28-stage2-final-inventory.log |
| 2609 | feature LAB-026 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2610 | feature LAB-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2611 | feature LAB-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 2612 | feature LAB-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2613 | feature LAB-027 name present | pass | o28-stage2-final-inventory.log |
| 2614 | feature LAB-027 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2615 | feature LAB-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2616 | feature LAB-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 2617 | feature LAB-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2618 | feature LAB-028 name present | pass | o28-stage2-final-inventory.log |
| 2619 | feature LAB-028 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2620 | feature LAB-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2621 | feature LAB-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 2622 | feature LAB-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2623 | feature LAB-029 name present | pass | o28-stage2-final-inventory.log |
| 2624 | feature LAB-029 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2625 | feature LAB-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2626 | feature LAB-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 2627 | feature LAB-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2628 | feature LAB-030 name present | pass | o28-stage2-final-inventory.log |
| 2629 | feature LAB-030 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2630 | feature LAB-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2631 | feature LAB-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 2632 | feature LAB-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2633 | feature LAB-031 name present | pass | o28-stage2-final-inventory.log |
| 2634 | feature LAB-031 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2635 | feature LAB-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2636 | feature LAB-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 2637 | feature LAB-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2638 | feature LAB-032 name present | pass | o28-stage2-final-inventory.log |
| 2639 | feature LAB-032 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2640 | feature LAB-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2641 | feature LAB-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 2642 | feature LAB-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2643 | feature LAB-033 name present | pass | o28-stage2-final-inventory.log |
| 2644 | feature LAB-033 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2645 | feature LAB-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2646 | feature LAB-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 2647 | feature LAB-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2648 | feature LAB-034 name present | pass | o28-stage2-final-inventory.log |
| 2649 | feature LAB-034 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2650 | feature LAB-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2651 | feature LAB-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 2652 | feature LAB-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2653 | feature LAB-035 name present | pass | o28-stage2-final-inventory.log |
| 2654 | feature LAB-035 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2655 | feature LAB-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2656 | feature LAB-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 2657 | feature LAB-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2658 | feature LAB-036 name present | pass | o28-stage2-final-inventory.log |
| 2659 | feature LAB-036 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2660 | feature LAB-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2661 | feature LAB-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 2662 | feature LAB-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2663 | feature LAB-037 name present | pass | o28-stage2-final-inventory.log |
| 2664 | feature LAB-037 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2665 | feature LAB-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2666 | feature LAB-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 2667 | feature LAB-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2668 | feature LAB-038 name present | pass | o28-stage2-final-inventory.log |
| 2669 | feature LAB-038 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2670 | feature LAB-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2671 | feature LAB-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 2672 | feature LAB-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2673 | feature LAB-039 name present | pass | o28-stage2-final-inventory.log |
| 2674 | feature LAB-039 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2675 | feature LAB-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2676 | feature LAB-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 2677 | feature LAB-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2678 | feature LAB-040 name present | pass | o28-stage2-final-inventory.log |
| 2679 | feature LAB-040 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2680 | feature LAB-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2681 | feature LAB-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 2682 | feature LAB-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2683 | feature LAB-041 name present | pass | o28-stage2-final-inventory.log |
| 2684 | feature LAB-041 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2685 | feature LAB-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2686 | feature LAB-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 2687 | feature LAB-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2688 | feature LAB-042 name present | pass | o28-stage2-final-inventory.log |
| 2689 | feature LAB-042 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2690 | feature LAB-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2691 | feature LAB-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 2692 | feature LAB-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2693 | feature LAB-043 name present | pass | o28-stage2-final-inventory.log |
| 2694 | feature LAB-043 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2695 | feature LAB-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2696 | feature LAB-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 2697 | feature LAB-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2698 | feature LAB-044 name present | pass | o28-stage2-final-inventory.log |
| 2699 | feature LAB-044 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2700 | feature LAB-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2701 | feature LAB-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 2702 | feature LAB-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2703 | feature LAB-045 name present | pass | o28-stage2-final-inventory.log |
| 2704 | feature LAB-045 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2705 | feature LAB-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2706 | feature LAB-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 2707 | feature LAB-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2708 | feature LAB-046 name present | pass | o28-stage2-final-inventory.log |
| 2709 | feature LAB-046 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2710 | feature LAB-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2711 | feature LAB-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 2712 | feature LAB-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2713 | feature LAB-047 name present | pass | o28-stage2-final-inventory.log |
| 2714 | feature LAB-047 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2715 | feature LAB-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2716 | feature LAB-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 2717 | feature LAB-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2718 | feature LAB-048 name present | pass | o28-stage2-final-inventory.log |
| 2719 | feature LAB-048 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2720 | feature LAB-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2721 | feature LAB-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 2722 | feature LAB-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2723 | feature LAB-049 name present | pass | o28-stage2-final-inventory.log |
| 2724 | feature LAB-049 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2725 | feature LAB-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2726 | feature LAB-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 2727 | feature LAB-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2728 | feature LAB-050 name present | pass | o28-stage2-final-inventory.log |
| 2729 | feature LAB-050 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2730 | feature LAB-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2731 | feature LAB-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 2732 | feature LAB-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2733 | feature LAB-051 name present | pass | o28-stage2-final-inventory.log |
| 2734 | feature LAB-051 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2735 | feature LAB-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2736 | feature LAB-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 2737 | feature LAB-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2738 | feature LAB-052 name present | pass | o28-stage2-final-inventory.log |
| 2739 | feature LAB-052 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2740 | feature LAB-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2741 | feature LAB-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 2742 | feature LAB-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2743 | feature LAB-053 name present | pass | o28-stage2-final-inventory.log |
| 2744 | feature LAB-053 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2745 | feature LAB-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2746 | feature LAB-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 2747 | feature LAB-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2748 | feature LAB-054 name present | pass | o28-stage2-final-inventory.log |
| 2749 | feature LAB-054 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2750 | feature LAB-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2751 | feature LAB-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 2752 | feature LAB-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2753 | feature LAB-055 name present | pass | o28-stage2-final-inventory.log |
| 2754 | feature LAB-055 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2755 | feature LAB-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2756 | feature LAB-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 2757 | feature LAB-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2758 | feature LAB-056 name present | pass | o28-stage2-final-inventory.log |
| 2759 | feature LAB-056 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2760 | feature LAB-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2761 | feature LAB-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 2762 | feature LAB-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2763 | feature LAB-057 name present | pass | o28-stage2-final-inventory.log |
| 2764 | feature LAB-057 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2765 | feature LAB-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2766 | feature LAB-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 2767 | feature LAB-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2768 | feature LAB-058 name present | pass | o28-stage2-final-inventory.log |
| 2769 | feature LAB-058 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2770 | feature LAB-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2771 | feature LAB-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 2772 | feature LAB-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2773 | feature LAB-059 name present | pass | o28-stage2-final-inventory.log |
| 2774 | feature LAB-059 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2775 | feature LAB-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2776 | feature LAB-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 2777 | feature LAB-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2778 | feature LAB-060 name present | pass | o28-stage2-final-inventory.log |
| 2779 | feature LAB-060 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2780 | feature LAB-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2781 | feature LAB-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 2782 | feature LAB-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2783 | feature LAB-061 name present | pass | o28-stage2-final-inventory.log |
| 2784 | feature LAB-061 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2785 | feature LAB-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2786 | feature LAB-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 2787 | feature LAB-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2788 | feature LAB-062 name present | pass | o28-stage2-final-inventory.log |
| 2789 | feature LAB-062 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2790 | feature LAB-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2791 | feature LAB-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 2792 | feature LAB-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2793 | feature LAB-063 name present | pass | o28-stage2-final-inventory.log |
| 2794 | feature LAB-063 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2795 | feature LAB-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2796 | feature LAB-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 2797 | feature LAB-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2798 | feature LAB-064 name present | pass | o28-stage2-final-inventory.log |
| 2799 | feature LAB-064 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2800 | feature LAB-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2801 | feature LAB-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 2802 | feature LAB-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2803 | feature LAB-065 name present | pass | o28-stage2-final-inventory.log |
| 2804 | feature LAB-065 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2805 | feature LAB-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2806 | feature LAB-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 2807 | feature LAB-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2808 | feature LAB-066 name present | pass | o28-stage2-final-inventory.log |
| 2809 | feature LAB-066 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2810 | feature LAB-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2811 | feature LAB-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 2812 | feature LAB-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2813 | feature LAB-067 name present | pass | o28-stage2-final-inventory.log |
| 2814 | feature LAB-067 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2815 | feature LAB-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2816 | feature LAB-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 2817 | feature LAB-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2818 | feature LAB-068 name present | pass | o28-stage2-final-inventory.log |
| 2819 | feature LAB-068 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2820 | feature LAB-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2821 | feature LAB-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 2822 | feature LAB-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2823 | feature LAB-069 name present | pass | o28-stage2-final-inventory.log |
| 2824 | feature LAB-069 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2825 | feature LAB-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2826 | feature LAB-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 2827 | feature LAB-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2828 | feature LAB-070 name present | pass | o28-stage2-final-inventory.log |
| 2829 | feature LAB-070 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2830 | feature LAB-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2831 | feature LAB-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 2832 | feature LAB-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2833 | feature LAB-071 name present | pass | o28-stage2-final-inventory.log |
| 2834 | feature LAB-071 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2835 | feature LAB-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2836 | feature LAB-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 2837 | feature LAB-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2838 | feature LAB-072 name present | pass | o28-stage2-final-inventory.log |
| 2839 | feature LAB-072 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2840 | feature LAB-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2841 | feature LAB-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 2842 | feature LAB-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2843 | feature LAB-073 name present | pass | o28-stage2-final-inventory.log |
| 2844 | feature LAB-073 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2845 | feature LAB-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2846 | feature LAB-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 2847 | feature LAB-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2848 | feature LAB-074 name present | pass | o28-stage2-final-inventory.log |
| 2849 | feature LAB-074 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2850 | feature LAB-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2851 | feature LAB-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 2852 | feature LAB-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2853 | feature LAB-075 name present | pass | o28-stage2-final-inventory.log |
| 2854 | feature LAB-075 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2855 | feature LAB-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2856 | feature LAB-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 2857 | feature LAB-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2858 | feature LAB-076 name present | pass | o28-stage2-final-inventory.log |
| 2859 | feature LAB-076 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2860 | feature LAB-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2861 | feature LAB-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 2862 | feature LAB-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2863 | feature LAB-077 name present | pass | o28-stage2-final-inventory.log |
| 2864 | feature LAB-077 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2865 | feature LAB-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2866 | feature LAB-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 2867 | feature LAB-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2868 | feature LAB-078 name present | pass | o28-stage2-final-inventory.log |
| 2869 | feature LAB-078 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2870 | feature LAB-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2871 | feature LAB-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 2872 | feature LAB-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2873 | feature LAB-079 name present | pass | o28-stage2-final-inventory.log |
| 2874 | feature LAB-079 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2875 | feature LAB-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2876 | feature LAB-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 2877 | feature LAB-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2878 | feature LAB-080 name present | pass | o28-stage2-final-inventory.log |
| 2879 | feature LAB-080 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2880 | feature LAB-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2881 | feature LAB-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 2882 | feature LAB-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2883 | feature LAB-081 name present | pass | o28-stage2-final-inventory.log |
| 2884 | feature LAB-081 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2885 | feature LAB-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2886 | feature LAB-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 2887 | feature LAB-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2888 | feature LAB-082 name present | pass | o28-stage2-final-inventory.log |
| 2889 | feature LAB-082 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2890 | feature LAB-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2891 | feature LAB-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 2892 | feature LAB-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2893 | feature LAB-083 name present | pass | o28-stage2-final-inventory.log |
| 2894 | feature LAB-083 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2895 | feature LAB-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2896 | feature LAB-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 2897 | feature LAB-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2898 | feature LAB-084 name present | pass | o28-stage2-final-inventory.log |
| 2899 | feature LAB-084 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2900 | feature LAB-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2901 | feature LAB-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 2902 | feature LAB-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2903 | feature LAB-085 name present | pass | o28-stage2-final-inventory.log |
| 2904 | feature LAB-085 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2905 | feature LAB-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2906 | feature LAB-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 2907 | feature LAB-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2908 | feature LAB-086 name present | pass | o28-stage2-final-inventory.log |
| 2909 | feature LAB-086 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2910 | feature LAB-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2911 | feature LAB-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 2912 | feature LAB-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2913 | feature LAB-087 name present | pass | o28-stage2-final-inventory.log |
| 2914 | feature LAB-087 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2915 | feature LAB-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2916 | feature LAB-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 2917 | feature LAB-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2918 | feature LAB-088 name present | pass | o28-stage2-final-inventory.log |
| 2919 | feature LAB-088 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2920 | feature LAB-088 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2921 | feature LAB-088 test area assigned | pass | o28-stage2-final-inventory.log |
| 2922 | feature LAB-088 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2923 | feature LAB-089 name present | pass | o28-stage2-final-inventory.log |
| 2924 | feature LAB-089 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2925 | feature LAB-089 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2926 | feature LAB-089 test area assigned | pass | o28-stage2-final-inventory.log |
| 2927 | feature LAB-089 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2928 | feature LAB-090 name present | pass | o28-stage2-final-inventory.log |
| 2929 | feature LAB-090 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2930 | feature LAB-090 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2931 | feature LAB-090 test area assigned | pass | o28-stage2-final-inventory.log |
| 2932 | feature LAB-090 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2933 | feature LAB-091 name present | pass | o28-stage2-final-inventory.log |
| 2934 | feature LAB-091 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2935 | feature LAB-091 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2936 | feature LAB-091 test area assigned | pass | o28-stage2-final-inventory.log |
| 2937 | feature LAB-091 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2938 | feature LAB-092 name present | pass | o28-stage2-final-inventory.log |
| 2939 | feature LAB-092 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2940 | feature LAB-092 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2941 | feature LAB-092 test area assigned | pass | o28-stage2-final-inventory.log |
| 2942 | feature LAB-092 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2943 | feature LAB-093 name present | pass | o28-stage2-final-inventory.log |
| 2944 | feature LAB-093 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2945 | feature LAB-093 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2946 | feature LAB-093 test area assigned | pass | o28-stage2-final-inventory.log |
| 2947 | feature LAB-093 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2948 | feature LAB-094 name present | pass | o28-stage2-final-inventory.log |
| 2949 | feature LAB-094 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2950 | feature LAB-094 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2951 | feature LAB-094 test area assigned | pass | o28-stage2-final-inventory.log |
| 2952 | feature LAB-094 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2953 | feature LAB-095 name present | pass | o28-stage2-final-inventory.log |
| 2954 | feature LAB-095 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2955 | feature LAB-095 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2956 | feature LAB-095 test area assigned | pass | o28-stage2-final-inventory.log |
| 2957 | feature LAB-095 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2958 | feature LAB-096 name present | pass | o28-stage2-final-inventory.log |
| 2959 | feature LAB-096 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2960 | feature LAB-096 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2961 | feature LAB-096 test area assigned | pass | o28-stage2-final-inventory.log |
| 2962 | feature LAB-096 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2963 | feature LAB-097 name present | pass | o28-stage2-final-inventory.log |
| 2964 | feature LAB-097 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2965 | feature LAB-097 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2966 | feature LAB-097 test area assigned | pass | o28-stage2-final-inventory.log |
| 2967 | feature LAB-097 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2968 | feature LAB-098 name present | pass | o28-stage2-final-inventory.log |
| 2969 | feature LAB-098 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2970 | feature LAB-098 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2971 | feature LAB-098 test area assigned | pass | o28-stage2-final-inventory.log |
| 2972 | feature LAB-098 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2973 | feature LAB-099 name present | pass | o28-stage2-final-inventory.log |
| 2974 | feature LAB-099 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2975 | feature LAB-099 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2976 | feature LAB-099 test area assigned | pass | o28-stage2-final-inventory.log |
| 2977 | feature LAB-099 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2978 | feature LAB-100 name present | pass | o28-stage2-final-inventory.log |
| 2979 | feature LAB-100 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2980 | feature LAB-100 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2981 | feature LAB-100 test area assigned | pass | o28-stage2-final-inventory.log |
| 2982 | feature LAB-100 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2983 | feature LAB-101 name present | pass | o28-stage2-final-inventory.log |
| 2984 | feature LAB-101 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2985 | feature LAB-101 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2986 | feature LAB-101 test area assigned | pass | o28-stage2-final-inventory.log |
| 2987 | feature LAB-101 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2988 | feature LAB-102 name present | pass | o28-stage2-final-inventory.log |
| 2989 | feature LAB-102 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2990 | feature LAB-102 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2991 | feature LAB-102 test area assigned | pass | o28-stage2-final-inventory.log |
| 2992 | feature LAB-102 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2993 | feature LAB-103 name present | pass | o28-stage2-final-inventory.log |
| 2994 | feature LAB-103 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 2995 | feature LAB-103 test need 필요 | pass | o28-stage2-final-inventory.log |
| 2996 | feature LAB-103 test area assigned | pass | o28-stage2-final-inventory.log |
| 2997 | feature LAB-103 pass criteria present | pass | o28-stage2-final-inventory.log |
| 2998 | feature LAB-104 name present | pass | o28-stage2-final-inventory.log |
| 2999 | feature LAB-104 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3000 | feature LAB-104 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3001 | feature LAB-104 test area assigned | pass | o28-stage2-final-inventory.log |
| 3002 | feature LAB-104 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3003 | feature LAB-105 name present | pass | o28-stage2-final-inventory.log |
| 3004 | feature LAB-105 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3005 | feature LAB-105 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3006 | feature LAB-105 test area assigned | pass | o28-stage2-final-inventory.log |
| 3007 | feature LAB-105 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3008 | feature LAB-106 name present | pass | o28-stage2-final-inventory.log |
| 3009 | feature LAB-106 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3010 | feature LAB-106 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3011 | feature LAB-106 test area assigned | pass | o28-stage2-final-inventory.log |
| 3012 | feature LAB-106 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3013 | feature LAB-107 name present | pass | o28-stage2-final-inventory.log |
| 3014 | feature LAB-107 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3015 | feature LAB-107 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3016 | feature LAB-107 test area assigned | pass | o28-stage2-final-inventory.log |
| 3017 | feature LAB-107 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3018 | feature LAB-108 name present | pass | o28-stage2-final-inventory.log |
| 3019 | feature LAB-108 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3020 | feature LAB-108 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3021 | feature LAB-108 test area assigned | pass | o28-stage2-final-inventory.log |
| 3022 | feature LAB-108 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3023 | feature LAB-109 name present | pass | o28-stage2-final-inventory.log |
| 3024 | feature LAB-109 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3025 | feature LAB-109 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3026 | feature LAB-109 test area assigned | pass | o28-stage2-final-inventory.log |
| 3027 | feature LAB-109 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3028 | feature LAB-110 name present | pass | o28-stage2-final-inventory.log |
| 3029 | feature LAB-110 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3030 | feature LAB-110 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3031 | feature LAB-110 test area assigned | pass | o28-stage2-final-inventory.log |
| 3032 | feature LAB-110 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3033 | feature LAB-111 name present | pass | o28-stage2-final-inventory.log |
| 3034 | feature LAB-111 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3035 | feature LAB-111 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3036 | feature LAB-111 test area assigned | pass | o28-stage2-final-inventory.log |
| 3037 | feature LAB-111 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3038 | feature LAB-112 name present | pass | o28-stage2-final-inventory.log |
| 3039 | feature LAB-112 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3040 | feature LAB-112 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3041 | feature LAB-112 test area assigned | pass | o28-stage2-final-inventory.log |
| 3042 | feature LAB-112 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3043 | feature LAB-113 name present | pass | o28-stage2-final-inventory.log |
| 3044 | feature LAB-113 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3045 | feature LAB-113 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3046 | feature LAB-113 test area assigned | pass | o28-stage2-final-inventory.log |
| 3047 | feature LAB-113 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3048 | feature LAB-114 name present | pass | o28-stage2-final-inventory.log |
| 3049 | feature LAB-114 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3050 | feature LAB-114 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3051 | feature LAB-114 test area assigned | pass | o28-stage2-final-inventory.log |
| 3052 | feature LAB-114 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3053 | feature LAB-115 name present | pass | o28-stage2-final-inventory.log |
| 3054 | feature LAB-115 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3055 | feature LAB-115 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3056 | feature LAB-115 test area assigned | pass | o28-stage2-final-inventory.log |
| 3057 | feature LAB-115 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3058 | feature LAB-116 name present | pass | o28-stage2-final-inventory.log |
| 3059 | feature LAB-116 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3060 | feature LAB-116 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3061 | feature LAB-116 test area assigned | pass | o28-stage2-final-inventory.log |
| 3062 | feature LAB-116 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3063 | feature LAB-117 name present | pass | o28-stage2-final-inventory.log |
| 3064 | feature LAB-117 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3065 | feature LAB-117 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3066 | feature LAB-117 test area assigned | pass | o28-stage2-final-inventory.log |
| 3067 | feature LAB-117 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3068 | feature LAB-118 name present | pass | o28-stage2-final-inventory.log |
| 3069 | feature LAB-118 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3070 | feature LAB-118 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3071 | feature LAB-118 test area assigned | pass | o28-stage2-final-inventory.log |
| 3072 | feature LAB-118 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3073 | feature LAB-119 name present | pass | o28-stage2-final-inventory.log |
| 3074 | feature LAB-119 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3075 | feature LAB-119 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3076 | feature LAB-119 test area assigned | pass | o28-stage2-final-inventory.log |
| 3077 | feature LAB-119 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3078 | feature LAB-120 name present | pass | o28-stage2-final-inventory.log |
| 3079 | feature LAB-120 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3080 | feature LAB-120 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3081 | feature LAB-120 test area assigned | pass | o28-stage2-final-inventory.log |
| 3082 | feature LAB-120 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3083 | feature LAB-121 name present | pass | o28-stage2-final-inventory.log |
| 3084 | feature LAB-121 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3085 | feature LAB-121 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3086 | feature LAB-121 test area assigned | pass | o28-stage2-final-inventory.log |
| 3087 | feature LAB-121 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3088 | feature LAB-122 name present | pass | o28-stage2-final-inventory.log |
| 3089 | feature LAB-122 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3090 | feature LAB-122 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3091 | feature LAB-122 test area assigned | pass | o28-stage2-final-inventory.log |
| 3092 | feature LAB-122 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3093 | feature LAB-123 name present | pass | o28-stage2-final-inventory.log |
| 3094 | feature LAB-123 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3095 | feature LAB-123 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3096 | feature LAB-123 test area assigned | pass | o28-stage2-final-inventory.log |
| 3097 | feature LAB-123 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3098 | feature LAB-124 name present | pass | o28-stage2-final-inventory.log |
| 3099 | feature LAB-124 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3100 | feature LAB-124 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3101 | feature LAB-124 test area assigned | pass | o28-stage2-final-inventory.log |
| 3102 | feature LAB-124 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3103 | feature LAB-125 name present | pass | o28-stage2-final-inventory.log |
| 3104 | feature LAB-125 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3105 | feature LAB-125 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3106 | feature LAB-125 test area assigned | pass | o28-stage2-final-inventory.log |
| 3107 | feature LAB-125 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3108 | feature LAB-126 name present | pass | o28-stage2-final-inventory.log |
| 3109 | feature LAB-126 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3110 | feature LAB-126 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3111 | feature LAB-126 test area assigned | pass | o28-stage2-final-inventory.log |
| 3112 | feature LAB-126 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3113 | feature SAFE-001 name present | pass | o28-stage2-final-inventory.log |
| 3114 | feature SAFE-001 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3115 | feature SAFE-001 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3116 | feature SAFE-001 test area assigned | pass | o28-stage2-final-inventory.log |
| 3117 | feature SAFE-001 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3118 | feature SAFE-002 name present | pass | o28-stage2-final-inventory.log |
| 3119 | feature SAFE-002 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3120 | feature SAFE-002 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3121 | feature SAFE-002 test area assigned | pass | o28-stage2-final-inventory.log |
| 3122 | feature SAFE-002 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3123 | feature SAFE-003 name present | pass | o28-stage2-final-inventory.log |
| 3124 | feature SAFE-003 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3125 | feature SAFE-003 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3126 | feature SAFE-003 test area assigned | pass | o28-stage2-final-inventory.log |
| 3127 | feature SAFE-003 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3128 | feature SAFE-004 name present | pass | o28-stage2-final-inventory.log |
| 3129 | feature SAFE-004 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3130 | feature SAFE-004 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3131 | feature SAFE-004 test area assigned | pass | o28-stage2-final-inventory.log |
| 3132 | feature SAFE-004 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3133 | feature SAFE-005 name present | pass | o28-stage2-final-inventory.log |
| 3134 | feature SAFE-005 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3135 | feature SAFE-005 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3136 | feature SAFE-005 test area assigned | pass | o28-stage2-final-inventory.log |
| 3137 | feature SAFE-005 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3138 | feature SAFE-006 name present | pass | o28-stage2-final-inventory.log |
| 3139 | feature SAFE-006 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3140 | feature SAFE-006 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3141 | feature SAFE-006 test area assigned | pass | o28-stage2-final-inventory.log |
| 3142 | feature SAFE-006 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3143 | feature SAFE-007 name present | pass | o28-stage2-final-inventory.log |
| 3144 | feature SAFE-007 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3145 | feature SAFE-007 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3146 | feature SAFE-007 test area assigned | pass | o28-stage2-final-inventory.log |
| 3147 | feature SAFE-007 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3148 | feature SAFE-008 name present | pass | o28-stage2-final-inventory.log |
| 3149 | feature SAFE-008 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3150 | feature SAFE-008 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3151 | feature SAFE-008 test area assigned | pass | o28-stage2-final-inventory.log |
| 3152 | feature SAFE-008 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3153 | feature SAFE-009 name present | pass | o28-stage2-final-inventory.log |
| 3154 | feature SAFE-009 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3155 | feature SAFE-009 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3156 | feature SAFE-009 test area assigned | pass | o28-stage2-final-inventory.log |
| 3157 | feature SAFE-009 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3158 | feature SAFE-010 name present | pass | o28-stage2-final-inventory.log |
| 3159 | feature SAFE-010 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3160 | feature SAFE-010 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3161 | feature SAFE-010 test area assigned | pass | o28-stage2-final-inventory.log |
| 3162 | feature SAFE-010 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3163 | feature SAFE-011 name present | pass | o28-stage2-final-inventory.log |
| 3164 | feature SAFE-011 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3165 | feature SAFE-011 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3166 | feature SAFE-011 test area assigned | pass | o28-stage2-final-inventory.log |
| 3167 | feature SAFE-011 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3168 | feature SAFE-012 name present | pass | o28-stage2-final-inventory.log |
| 3169 | feature SAFE-012 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3170 | feature SAFE-012 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3171 | feature SAFE-012 test area assigned | pass | o28-stage2-final-inventory.log |
| 3172 | feature SAFE-012 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3173 | feature SAFE-013 name present | pass | o28-stage2-final-inventory.log |
| 3174 | feature SAFE-013 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3175 | feature SAFE-013 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3176 | feature SAFE-013 test area assigned | pass | o28-stage2-final-inventory.log |
| 3177 | feature SAFE-013 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3178 | feature SAFE-014 name present | pass | o28-stage2-final-inventory.log |
| 3179 | feature SAFE-014 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3180 | feature SAFE-014 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3181 | feature SAFE-014 test area assigned | pass | o28-stage2-final-inventory.log |
| 3182 | feature SAFE-014 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3183 | feature SAFE-015 name present | pass | o28-stage2-final-inventory.log |
| 3184 | feature SAFE-015 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3185 | feature SAFE-015 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3186 | feature SAFE-015 test area assigned | pass | o28-stage2-final-inventory.log |
| 3187 | feature SAFE-015 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3188 | feature SAFE-016 name present | pass | o28-stage2-final-inventory.log |
| 3189 | feature SAFE-016 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 3190 | feature SAFE-016 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3191 | feature SAFE-016 test area assigned | pass | o28-stage2-final-inventory.log |
| 3192 | feature SAFE-016 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3193 | feature SAFE-017 name present | pass | o28-stage2-final-inventory.log |
| 3194 | feature SAFE-017 UI need 간접 | pass | o28-stage2-final-inventory.log |
| 3195 | feature SAFE-017 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3196 | feature SAFE-017 test area assigned | pass | o28-stage2-final-inventory.log |
| 3197 | feature SAFE-017 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3198 | feature SAFE-018 name present | pass | o28-stage2-final-inventory.log |
| 3199 | feature SAFE-018 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3200 | feature SAFE-018 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3201 | feature SAFE-018 test area assigned | pass | o28-stage2-final-inventory.log |
| 3202 | feature SAFE-018 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3203 | feature SAFE-019 name present | pass | o28-stage2-final-inventory.log |
| 3204 | feature SAFE-019 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3205 | feature SAFE-019 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3206 | feature SAFE-019 test area assigned | pass | o28-stage2-final-inventory.log |
| 3207 | feature SAFE-019 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3208 | feature SAFE-020 name present | pass | o28-stage2-final-inventory.log |
| 3209 | feature SAFE-020 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3210 | feature SAFE-020 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3211 | feature SAFE-020 test area assigned | pass | o28-stage2-final-inventory.log |
| 3212 | feature SAFE-020 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3213 | feature SAFE-021 name present | pass | o28-stage2-final-inventory.log |
| 3214 | feature SAFE-021 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3215 | feature SAFE-021 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3216 | feature SAFE-021 test area assigned | pass | o28-stage2-final-inventory.log |
| 3217 | feature SAFE-021 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3218 | feature SAFE-022 name present | pass | o28-stage2-final-inventory.log |
| 3219 | feature SAFE-022 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3220 | feature SAFE-022 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3221 | feature SAFE-022 test area assigned | pass | o28-stage2-final-inventory.log |
| 3222 | feature SAFE-022 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3223 | feature SAFE-023 name present | pass | o28-stage2-final-inventory.log |
| 3224 | feature SAFE-023 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3225 | feature SAFE-023 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3226 | feature SAFE-023 test area assigned | pass | o28-stage2-final-inventory.log |
| 3227 | feature SAFE-023 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3228 | feature SAFE-024 name present | pass | o28-stage2-final-inventory.log |
| 3229 | feature SAFE-024 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3230 | feature SAFE-024 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3231 | feature SAFE-024 test area assigned | pass | o28-stage2-final-inventory.log |
| 3232 | feature SAFE-024 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3233 | feature SAFE-025 name present | pass | o28-stage2-final-inventory.log |
| 3234 | feature SAFE-025 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3235 | feature SAFE-025 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3236 | feature SAFE-025 test area assigned | pass | o28-stage2-final-inventory.log |
| 3237 | feature SAFE-025 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3238 | feature SAFE-026 name present | pass | o28-stage2-final-inventory.log |
| 3239 | feature SAFE-026 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3240 | feature SAFE-026 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3241 | feature SAFE-026 test area assigned | pass | o28-stage2-final-inventory.log |
| 3242 | feature SAFE-026 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3243 | feature SAFE-027 name present | pass | o28-stage2-final-inventory.log |
| 3244 | feature SAFE-027 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3245 | feature SAFE-027 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3246 | feature SAFE-027 test area assigned | pass | o28-stage2-final-inventory.log |
| 3247 | feature SAFE-027 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3248 | feature SAFE-028 name present | pass | o28-stage2-final-inventory.log |
| 3249 | feature SAFE-028 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3250 | feature SAFE-028 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3251 | feature SAFE-028 test area assigned | pass | o28-stage2-final-inventory.log |
| 3252 | feature SAFE-028 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3253 | feature SAFE-029 name present | pass | o28-stage2-final-inventory.log |
| 3254 | feature SAFE-029 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3255 | feature SAFE-029 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3256 | feature SAFE-029 test area assigned | pass | o28-stage2-final-inventory.log |
| 3257 | feature SAFE-029 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3258 | feature SAFE-030 name present | pass | o28-stage2-final-inventory.log |
| 3259 | feature SAFE-030 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3260 | feature SAFE-030 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3261 | feature SAFE-030 test area assigned | pass | o28-stage2-final-inventory.log |
| 3262 | feature SAFE-030 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3263 | feature SAFE-031 name present | pass | o28-stage2-final-inventory.log |
| 3264 | feature SAFE-031 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3265 | feature SAFE-031 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3266 | feature SAFE-031 test area assigned | pass | o28-stage2-final-inventory.log |
| 3267 | feature SAFE-031 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3268 | feature SAFE-032 name present | pass | o28-stage2-final-inventory.log |
| 3269 | feature SAFE-032 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3270 | feature SAFE-032 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3271 | feature SAFE-032 test area assigned | pass | o28-stage2-final-inventory.log |
| 3272 | feature SAFE-032 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3273 | feature SAFE-033 name present | pass | o28-stage2-final-inventory.log |
| 3274 | feature SAFE-033 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3275 | feature SAFE-033 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3276 | feature SAFE-033 test area assigned | pass | o28-stage2-final-inventory.log |
| 3277 | feature SAFE-033 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3278 | feature SAFE-034 name present | pass | o28-stage2-final-inventory.log |
| 3279 | feature SAFE-034 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3280 | feature SAFE-034 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3281 | feature SAFE-034 test area assigned | pass | o28-stage2-final-inventory.log |
| 3282 | feature SAFE-034 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3283 | feature SAFE-035 name present | pass | o28-stage2-final-inventory.log |
| 3284 | feature SAFE-035 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3285 | feature SAFE-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3286 | feature SAFE-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 3287 | feature SAFE-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3288 | feature SAFE-036 name present | pass | o28-stage2-final-inventory.log |
| 3289 | feature SAFE-036 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3290 | feature SAFE-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3291 | feature SAFE-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 3292 | feature SAFE-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3293 | feature SAFE-037 name present | pass | o28-stage2-final-inventory.log |
| 3294 | feature SAFE-037 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3295 | feature SAFE-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3296 | feature SAFE-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 3297 | feature SAFE-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3298 | feature SAFE-038 name present | pass | o28-stage2-final-inventory.log |
| 3299 | feature SAFE-038 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3300 | feature SAFE-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3301 | feature SAFE-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 3302 | feature SAFE-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3303 | feature SAFE-039 name present | pass | o28-stage2-final-inventory.log |
| 3304 | feature SAFE-039 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3305 | feature SAFE-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3306 | feature SAFE-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 3307 | feature SAFE-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3308 | feature SAFE-040 name present | pass | o28-stage2-final-inventory.log |
| 3309 | feature SAFE-040 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3310 | feature SAFE-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3311 | feature SAFE-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 3312 | feature SAFE-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3313 | feature SAFE-041 name present | pass | o28-stage2-final-inventory.log |
| 3314 | feature SAFE-041 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3315 | feature SAFE-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3316 | feature SAFE-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 3317 | feature SAFE-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3318 | feature SAFE-042 name present | pass | o28-stage2-final-inventory.log |
| 3319 | feature SAFE-042 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3320 | feature SAFE-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3321 | feature SAFE-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 3322 | feature SAFE-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3323 | feature SAFE-043 name present | pass | o28-stage2-final-inventory.log |
| 3324 | feature SAFE-043 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3325 | feature SAFE-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3326 | feature SAFE-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 3327 | feature SAFE-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3328 | feature SAFE-044 name present | pass | o28-stage2-final-inventory.log |
| 3329 | feature SAFE-044 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3330 | feature SAFE-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3331 | feature SAFE-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 3332 | feature SAFE-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3333 | feature SAFE-045 name present | pass | o28-stage2-final-inventory.log |
| 3334 | feature SAFE-045 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3335 | feature SAFE-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3336 | feature SAFE-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 3337 | feature SAFE-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3338 | feature SAFE-046 name present | pass | o28-stage2-final-inventory.log |
| 3339 | feature SAFE-046 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3340 | feature SAFE-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3341 | feature SAFE-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 3342 | feature SAFE-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3343 | feature SAFE-047 name present | pass | o28-stage2-final-inventory.log |
| 3344 | feature SAFE-047 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3345 | feature SAFE-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3346 | feature SAFE-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 3347 | feature SAFE-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3348 | feature SAFE-048 name present | pass | o28-stage2-final-inventory.log |
| 3349 | feature SAFE-048 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3350 | feature SAFE-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3351 | feature SAFE-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 3352 | feature SAFE-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3353 | feature SAFE-049 name present | pass | o28-stage2-final-inventory.log |
| 3354 | feature SAFE-049 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3355 | feature SAFE-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3356 | feature SAFE-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 3357 | feature SAFE-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3358 | feature SAFE-050 name present | pass | o28-stage2-final-inventory.log |
| 3359 | feature SAFE-050 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3360 | feature SAFE-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3361 | feature SAFE-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 3362 | feature SAFE-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3363 | feature SAFE-051 name present | pass | o28-stage2-final-inventory.log |
| 3364 | feature SAFE-051 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3365 | feature SAFE-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3366 | feature SAFE-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 3367 | feature SAFE-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3368 | feature SAFE-052 name present | pass | o28-stage2-final-inventory.log |
| 3369 | feature SAFE-052 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3370 | feature SAFE-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3371 | feature SAFE-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 3372 | feature SAFE-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3373 | feature SAFE-053 name present | pass | o28-stage2-final-inventory.log |
| 3374 | feature SAFE-053 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3375 | feature SAFE-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3376 | feature SAFE-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 3377 | feature SAFE-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3378 | feature SAFE-054 name present | pass | o28-stage2-final-inventory.log |
| 3379 | feature SAFE-054 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3380 | feature SAFE-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3381 | feature SAFE-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 3382 | feature SAFE-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3383 | feature SAFE-055 name present | pass | o28-stage2-final-inventory.log |
| 3384 | feature SAFE-055 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3385 | feature SAFE-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3386 | feature SAFE-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 3387 | feature SAFE-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3388 | feature SAFE-056 name present | pass | o28-stage2-final-inventory.log |
| 3389 | feature SAFE-056 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3390 | feature SAFE-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3391 | feature SAFE-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 3392 | feature SAFE-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3393 | feature SAFE-057 name present | pass | o28-stage2-final-inventory.log |
| 3394 | feature SAFE-057 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3395 | feature SAFE-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3396 | feature SAFE-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 3397 | feature SAFE-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3398 | feature SAFE-058 name present | pass | o28-stage2-final-inventory.log |
| 3399 | feature SAFE-058 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3400 | feature SAFE-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3401 | feature SAFE-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 3402 | feature SAFE-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3403 | feature SAFE-059 name present | pass | o28-stage2-final-inventory.log |
| 3404 | feature SAFE-059 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3405 | feature SAFE-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3406 | feature SAFE-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 3407 | feature SAFE-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3408 | feature SAFE-060 name present | pass | o28-stage2-final-inventory.log |
| 3409 | feature SAFE-060 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3410 | feature SAFE-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3411 | feature SAFE-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 3412 | feature SAFE-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3413 | feature SAFE-061 name present | pass | o28-stage2-final-inventory.log |
| 3414 | feature SAFE-061 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3415 | feature SAFE-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3416 | feature SAFE-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 3417 | feature SAFE-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3418 | feature SAFE-062 name present | pass | o28-stage2-final-inventory.log |
| 3419 | feature SAFE-062 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3420 | feature SAFE-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3421 | feature SAFE-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 3422 | feature SAFE-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3423 | feature SAFE-063 name present | pass | o28-stage2-final-inventory.log |
| 3424 | feature SAFE-063 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3425 | feature SAFE-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3426 | feature SAFE-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 3427 | feature SAFE-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3428 | feature SAFE-064 name present | pass | o28-stage2-final-inventory.log |
| 3429 | feature SAFE-064 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3430 | feature SAFE-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3431 | feature SAFE-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 3432 | feature SAFE-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3433 | feature SAFE-065 name present | pass | o28-stage2-final-inventory.log |
| 3434 | feature SAFE-065 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3435 | feature SAFE-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3436 | feature SAFE-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 3437 | feature SAFE-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3438 | feature SAFE-066 name present | pass | o28-stage2-final-inventory.log |
| 3439 | feature SAFE-066 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3440 | feature SAFE-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3441 | feature SAFE-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 3442 | feature SAFE-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3443 | feature SAFE-067 name present | pass | o28-stage2-final-inventory.log |
| 3444 | feature SAFE-067 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3445 | feature SAFE-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3446 | feature SAFE-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 3447 | feature SAFE-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3448 | feature SAFE-068 name present | pass | o28-stage2-final-inventory.log |
| 3449 | feature SAFE-068 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3450 | feature SAFE-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3451 | feature SAFE-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 3452 | feature SAFE-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3453 | feature SAFE-069 name present | pass | o28-stage2-final-inventory.log |
| 3454 | feature SAFE-069 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3455 | feature SAFE-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3456 | feature SAFE-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 3457 | feature SAFE-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3458 | feature SAFE-070 name present | pass | o28-stage2-final-inventory.log |
| 3459 | feature SAFE-070 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3460 | feature SAFE-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3461 | feature SAFE-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 3462 | feature SAFE-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3463 | feature SAFE-071 name present | pass | o28-stage2-final-inventory.log |
| 3464 | feature SAFE-071 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3465 | feature SAFE-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3466 | feature SAFE-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 3467 | feature SAFE-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3468 | feature SAFE-072 name present | pass | o28-stage2-final-inventory.log |
| 3469 | feature SAFE-072 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3470 | feature SAFE-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3471 | feature SAFE-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 3472 | feature SAFE-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3473 | feature SAFE-073 name present | pass | o28-stage2-final-inventory.log |
| 3474 | feature SAFE-073 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3475 | feature SAFE-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3476 | feature SAFE-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 3477 | feature SAFE-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3478 | feature SAFE-074 name present | pass | o28-stage2-final-inventory.log |
| 3479 | feature SAFE-074 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3480 | feature SAFE-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3481 | feature SAFE-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 3482 | feature SAFE-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3483 | feature SAFE-075 name present | pass | o28-stage2-final-inventory.log |
| 3484 | feature SAFE-075 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3485 | feature SAFE-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3486 | feature SAFE-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 3487 | feature SAFE-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3488 | feature SAFE-076 name present | pass | o28-stage2-final-inventory.log |
| 3489 | feature SAFE-076 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3490 | feature SAFE-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3491 | feature SAFE-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 3492 | feature SAFE-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3493 | feature SAFE-077 name present | pass | o28-stage2-final-inventory.log |
| 3494 | feature SAFE-077 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3495 | feature SAFE-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3496 | feature SAFE-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 3497 | feature SAFE-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3498 | feature SAFE-078 name present | pass | o28-stage2-final-inventory.log |
| 3499 | feature SAFE-078 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3500 | feature SAFE-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3501 | feature SAFE-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 3502 | feature SAFE-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3503 | feature SAFE-079 name present | pass | o28-stage2-final-inventory.log |
| 3504 | feature SAFE-079 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3505 | feature SAFE-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3506 | feature SAFE-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 3507 | feature SAFE-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3508 | feature SAFE-080 name present | pass | o28-stage2-final-inventory.log |
| 3509 | feature SAFE-080 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3510 | feature SAFE-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3511 | feature SAFE-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 3512 | feature SAFE-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3513 | feature SAFE-081 name present | pass | o28-stage2-final-inventory.log |
| 3514 | feature SAFE-081 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3515 | feature SAFE-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3516 | feature SAFE-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 3517 | feature SAFE-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3518 | feature SAFE-082 name present | pass | o28-stage2-final-inventory.log |
| 3519 | feature SAFE-082 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3520 | feature SAFE-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3521 | feature SAFE-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 3522 | feature SAFE-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3523 | feature SAFE-083 name present | pass | o28-stage2-final-inventory.log |
| 3524 | feature SAFE-083 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3525 | feature SAFE-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3526 | feature SAFE-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 3527 | feature SAFE-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3528 | feature SAFE-084 name present | pass | o28-stage2-final-inventory.log |
| 3529 | feature SAFE-084 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3530 | feature SAFE-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3531 | feature SAFE-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 3532 | feature SAFE-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3533 | feature SAFE-085 name present | pass | o28-stage2-final-inventory.log |
| 3534 | feature SAFE-085 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3535 | feature SAFE-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3536 | feature SAFE-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 3537 | feature SAFE-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3538 | feature SAFE-086 name present | pass | o28-stage2-final-inventory.log |
| 3539 | feature SAFE-086 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3540 | feature SAFE-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3541 | feature SAFE-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 3542 | feature SAFE-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3543 | feature SAFE-087 name present | pass | o28-stage2-final-inventory.log |
| 3544 | feature SAFE-087 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3545 | feature SAFE-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3546 | feature SAFE-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 3547 | feature SAFE-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3548 | feature SAFE-088 name present | pass | o28-stage2-final-inventory.log |
| 3549 | feature SAFE-088 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3550 | feature SAFE-088 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3551 | feature SAFE-088 test area assigned | pass | o28-stage2-final-inventory.log |
| 3552 | feature SAFE-088 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3553 | feature SAFE-089 name present | pass | o28-stage2-final-inventory.log |
| 3554 | feature SAFE-089 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3555 | feature SAFE-089 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3556 | feature SAFE-089 test area assigned | pass | o28-stage2-final-inventory.log |
| 3557 | feature SAFE-089 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3558 | feature SAFE-090 name present | pass | o28-stage2-final-inventory.log |
| 3559 | feature SAFE-090 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3560 | feature SAFE-090 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3561 | feature SAFE-090 test area assigned | pass | o28-stage2-final-inventory.log |
| 3562 | feature SAFE-090 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3563 | feature SAFE-091 name present | pass | o28-stage2-final-inventory.log |
| 3564 | feature SAFE-091 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3565 | feature SAFE-091 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3566 | feature SAFE-091 test area assigned | pass | o28-stage2-final-inventory.log |
| 3567 | feature SAFE-091 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3568 | feature SAFE-092 name present | pass | o28-stage2-final-inventory.log |
| 3569 | feature SAFE-092 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3570 | feature SAFE-092 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3571 | feature SAFE-092 test area assigned | pass | o28-stage2-final-inventory.log |
| 3572 | feature SAFE-092 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3573 | feature SAFE-093 name present | pass | o28-stage2-final-inventory.log |
| 3574 | feature SAFE-093 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3575 | feature SAFE-093 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3576 | feature SAFE-093 test area assigned | pass | o28-stage2-final-inventory.log |
| 3577 | feature SAFE-093 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3578 | feature SAFE-094 name present | pass | o28-stage2-final-inventory.log |
| 3579 | feature SAFE-094 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3580 | feature SAFE-094 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3581 | feature SAFE-094 test area assigned | pass | o28-stage2-final-inventory.log |
| 3582 | feature SAFE-094 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3583 | feature SAFE-095 name present | pass | o28-stage2-final-inventory.log |
| 3584 | feature SAFE-095 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3585 | feature SAFE-095 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3586 | feature SAFE-095 test area assigned | pass | o28-stage2-final-inventory.log |
| 3587 | feature SAFE-095 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3588 | feature SAFE-096 name present | pass | o28-stage2-final-inventory.log |
| 3589 | feature SAFE-096 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3590 | feature SAFE-096 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3591 | feature SAFE-096 test area assigned | pass | o28-stage2-final-inventory.log |
| 3592 | feature SAFE-096 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3593 | feature SAFE-097 name present | pass | o28-stage2-final-inventory.log |
| 3594 | feature SAFE-097 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3595 | feature SAFE-097 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3596 | feature SAFE-097 test area assigned | pass | o28-stage2-final-inventory.log |
| 3597 | feature SAFE-097 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3598 | feature SAFE-098 name present | pass | o28-stage2-final-inventory.log |
| 3599 | feature SAFE-098 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3600 | feature SAFE-098 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3601 | feature SAFE-098 test area assigned | pass | o28-stage2-final-inventory.log |
| 3602 | feature SAFE-098 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3603 | feature SAFE-099 name present | pass | o28-stage2-final-inventory.log |
| 3604 | feature SAFE-099 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3605 | feature SAFE-099 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3606 | feature SAFE-099 test area assigned | pass | o28-stage2-final-inventory.log |
| 3607 | feature SAFE-099 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3608 | feature SAFE-100 name present | pass | o28-stage2-final-inventory.log |
| 3609 | feature SAFE-100 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3610 | feature SAFE-100 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3611 | feature SAFE-100 test area assigned | pass | o28-stage2-final-inventory.log |
| 3612 | feature SAFE-100 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3613 | feature SAFE-101 name present | pass | o28-stage2-final-inventory.log |
| 3614 | feature SAFE-101 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3615 | feature SAFE-101 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3616 | feature SAFE-101 test area assigned | pass | o28-stage2-final-inventory.log |
| 3617 | feature SAFE-101 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3618 | feature SAFE-102 name present | pass | o28-stage2-final-inventory.log |
| 3619 | feature SAFE-102 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3620 | feature SAFE-102 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3621 | feature SAFE-102 test area assigned | pass | o28-stage2-final-inventory.log |
| 3622 | feature SAFE-102 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3623 | feature SAFE-103 name present | pass | o28-stage2-final-inventory.log |
| 3624 | feature SAFE-103 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3625 | feature SAFE-103 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3626 | feature SAFE-103 test area assigned | pass | o28-stage2-final-inventory.log |
| 3627 | feature SAFE-103 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3628 | feature SAFE-104 name present | pass | o28-stage2-final-inventory.log |
| 3629 | feature SAFE-104 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3630 | feature SAFE-104 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3631 | feature SAFE-104 test area assigned | pass | o28-stage2-final-inventory.log |
| 3632 | feature SAFE-104 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3633 | feature SAFE-105 name present | pass | o28-stage2-final-inventory.log |
| 3634 | feature SAFE-105 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3635 | feature SAFE-105 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3636 | feature SAFE-105 test area assigned | pass | o28-stage2-final-inventory.log |
| 3637 | feature SAFE-105 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3638 | feature SAFE-106 name present | pass | o28-stage2-final-inventory.log |
| 3639 | feature SAFE-106 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3640 | feature SAFE-106 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3641 | feature SAFE-106 test area assigned | pass | o28-stage2-final-inventory.log |
| 3642 | feature SAFE-106 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3643 | feature SAFE-107 name present | pass | o28-stage2-final-inventory.log |
| 3644 | feature SAFE-107 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3645 | feature SAFE-107 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3646 | feature SAFE-107 test area assigned | pass | o28-stage2-final-inventory.log |
| 3647 | feature SAFE-107 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3648 | feature SAFE-108 name present | pass | o28-stage2-final-inventory.log |
| 3649 | feature SAFE-108 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3650 | feature SAFE-108 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3651 | feature SAFE-108 test area assigned | pass | o28-stage2-final-inventory.log |
| 3652 | feature SAFE-108 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3653 | feature SAFE-109 name present | pass | o28-stage2-final-inventory.log |
| 3654 | feature SAFE-109 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3655 | feature SAFE-109 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3656 | feature SAFE-109 test area assigned | pass | o28-stage2-final-inventory.log |
| 3657 | feature SAFE-109 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3658 | feature SAFE-110 name present | pass | o28-stage2-final-inventory.log |
| 3659 | feature SAFE-110 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3660 | feature SAFE-110 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3661 | feature SAFE-110 test area assigned | pass | o28-stage2-final-inventory.log |
| 3662 | feature SAFE-110 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3663 | feature SAFE-111 name present | pass | o28-stage2-final-inventory.log |
| 3664 | feature SAFE-111 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3665 | feature SAFE-111 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3666 | feature SAFE-111 test area assigned | pass | o28-stage2-final-inventory.log |
| 3667 | feature SAFE-111 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3668 | feature SAFE-112 name present | pass | o28-stage2-final-inventory.log |
| 3669 | feature SAFE-112 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3670 | feature SAFE-112 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3671 | feature SAFE-112 test area assigned | pass | o28-stage2-final-inventory.log |
| 3672 | feature SAFE-112 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3673 | feature SAFE-113 name present | pass | o28-stage2-final-inventory.log |
| 3674 | feature SAFE-113 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3675 | feature SAFE-113 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3676 | feature SAFE-113 test area assigned | pass | o28-stage2-final-inventory.log |
| 3677 | feature SAFE-113 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3678 | feature SAFE-114 name present | pass | o28-stage2-final-inventory.log |
| 3679 | feature SAFE-114 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3680 | feature SAFE-114 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3681 | feature SAFE-114 test area assigned | pass | o28-stage2-final-inventory.log |
| 3682 | feature SAFE-114 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3683 | feature SAFE-115 name present | pass | o28-stage2-final-inventory.log |
| 3684 | feature SAFE-115 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3685 | feature SAFE-115 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3686 | feature SAFE-115 test area assigned | pass | o28-stage2-final-inventory.log |
| 3687 | feature SAFE-115 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3688 | feature SAFE-116 name present | pass | o28-stage2-final-inventory.log |
| 3689 | feature SAFE-116 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3690 | feature SAFE-116 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3691 | feature SAFE-116 test area assigned | pass | o28-stage2-final-inventory.log |
| 3692 | feature SAFE-116 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3693 | feature SAFE-117 name present | pass | o28-stage2-final-inventory.log |
| 3694 | feature SAFE-117 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3695 | feature SAFE-117 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3696 | feature SAFE-117 test area assigned | pass | o28-stage2-final-inventory.log |
| 3697 | feature SAFE-117 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3698 | feature SAFE-118 name present | pass | o28-stage2-final-inventory.log |
| 3699 | feature SAFE-118 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3700 | feature SAFE-118 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3701 | feature SAFE-118 test area assigned | pass | o28-stage2-final-inventory.log |
| 3702 | feature SAFE-118 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3703 | feature SAFE-119 name present | pass | o28-stage2-final-inventory.log |
| 3704 | feature SAFE-119 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3705 | feature SAFE-119 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3706 | feature SAFE-119 test area assigned | pass | o28-stage2-final-inventory.log |
| 3707 | feature SAFE-119 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3708 | feature SAFE-120 name present | pass | o28-stage2-final-inventory.log |
| 3709 | feature SAFE-120 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3710 | feature SAFE-120 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3711 | feature SAFE-120 test area assigned | pass | o28-stage2-final-inventory.log |
| 3712 | feature SAFE-120 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3713 | feature SAFE-121 name present | pass | o28-stage2-final-inventory.log |
| 3714 | feature SAFE-121 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3715 | feature SAFE-121 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3716 | feature SAFE-121 test area assigned | pass | o28-stage2-final-inventory.log |
| 3717 | feature SAFE-121 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3718 | feature SAFE-122 name present | pass | o28-stage2-final-inventory.log |
| 3719 | feature SAFE-122 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3720 | feature SAFE-122 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3721 | feature SAFE-122 test area assigned | pass | o28-stage2-final-inventory.log |
| 3722 | feature SAFE-122 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3723 | feature SAFE-123 name present | pass | o28-stage2-final-inventory.log |
| 3724 | feature SAFE-123 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3725 | feature SAFE-123 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3726 | feature SAFE-123 test area assigned | pass | o28-stage2-final-inventory.log |
| 3727 | feature SAFE-123 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3728 | feature SAFE-124 name present | pass | o28-stage2-final-inventory.log |
| 3729 | feature SAFE-124 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3730 | feature SAFE-124 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3731 | feature SAFE-124 test area assigned | pass | o28-stage2-final-inventory.log |
| 3732 | feature SAFE-124 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3733 | feature SAFE-125 name present | pass | o28-stage2-final-inventory.log |
| 3734 | feature SAFE-125 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3735 | feature SAFE-125 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3736 | feature SAFE-125 test area assigned | pass | o28-stage2-final-inventory.log |
| 3737 | feature SAFE-125 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3738 | feature SAFE-126 name present | pass | o28-stage2-final-inventory.log |
| 3739 | feature SAFE-126 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3740 | feature SAFE-126 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3741 | feature SAFE-126 test area assigned | pass | o28-stage2-final-inventory.log |
| 3742 | feature SAFE-126 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3743 | feature SAFE-127 name present | pass | o28-stage2-final-inventory.log |
| 3744 | feature SAFE-127 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3745 | feature SAFE-127 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3746 | feature SAFE-127 test area assigned | pass | o28-stage2-final-inventory.log |
| 3747 | feature SAFE-127 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3748 | feature SAFE-128 name present | pass | o28-stage2-final-inventory.log |
| 3749 | feature SAFE-128 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3750 | feature SAFE-128 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3751 | feature SAFE-128 test area assigned | pass | o28-stage2-final-inventory.log |
| 3752 | feature SAFE-128 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3753 | feature SAFE-129 name present | pass | o28-stage2-final-inventory.log |
| 3754 | feature SAFE-129 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3755 | feature SAFE-129 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3756 | feature SAFE-129 test area assigned | pass | o28-stage2-final-inventory.log |
| 3757 | feature SAFE-129 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3758 | feature SAFE-130 name present | pass | o28-stage2-final-inventory.log |
| 3759 | feature SAFE-130 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3760 | feature SAFE-130 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3761 | feature SAFE-130 test area assigned | pass | o28-stage2-final-inventory.log |
| 3762 | feature SAFE-130 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3763 | feature SAFE-131 name present | pass | o28-stage2-final-inventory.log |
| 3764 | feature SAFE-131 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3765 | feature SAFE-131 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3766 | feature SAFE-131 test area assigned | pass | o28-stage2-final-inventory.log |
| 3767 | feature SAFE-131 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3768 | feature SAFE-132 name present | pass | o28-stage2-final-inventory.log |
| 3769 | feature SAFE-132 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3770 | feature SAFE-132 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3771 | feature SAFE-132 test area assigned | pass | o28-stage2-final-inventory.log |
| 3772 | feature SAFE-132 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3773 | feature SAFE-133 name present | pass | o28-stage2-final-inventory.log |
| 3774 | feature SAFE-133 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3775 | feature SAFE-133 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3776 | feature SAFE-133 test area assigned | pass | o28-stage2-final-inventory.log |
| 3777 | feature SAFE-133 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3778 | feature SAFE-134 name present | pass | o28-stage2-final-inventory.log |
| 3779 | feature SAFE-134 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3780 | feature SAFE-134 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3781 | feature SAFE-134 test area assigned | pass | o28-stage2-final-inventory.log |
| 3782 | feature SAFE-134 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3783 | feature SAFE-135 name present | pass | o28-stage2-final-inventory.log |
| 3784 | feature SAFE-135 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3785 | feature SAFE-135 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3786 | feature SAFE-135 test area assigned | pass | o28-stage2-final-inventory.log |
| 3787 | feature SAFE-135 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3788 | feature SAFE-136 name present | pass | o28-stage2-final-inventory.log |
| 3789 | feature SAFE-136 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3790 | feature SAFE-136 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3791 | feature SAFE-136 test area assigned | pass | o28-stage2-final-inventory.log |
| 3792 | feature SAFE-136 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3793 | feature SAFE-137 name present | pass | o28-stage2-final-inventory.log |
| 3794 | feature SAFE-137 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3795 | feature SAFE-137 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3796 | feature SAFE-137 test area assigned | pass | o28-stage2-final-inventory.log |
| 3797 | feature SAFE-137 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3798 | feature SAFE-138 name present | pass | o28-stage2-final-inventory.log |
| 3799 | feature SAFE-138 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3800 | feature SAFE-138 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3801 | feature SAFE-138 test area assigned | pass | o28-stage2-final-inventory.log |
| 3802 | feature SAFE-138 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3803 | feature SAFE-139 name present | pass | o28-stage2-final-inventory.log |
| 3804 | feature SAFE-139 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3805 | feature SAFE-139 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3806 | feature SAFE-139 test area assigned | pass | o28-stage2-final-inventory.log |
| 3807 | feature SAFE-139 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3808 | feature SAFE-140 name present | pass | o28-stage2-final-inventory.log |
| 3809 | feature SAFE-140 UI need 필요 | pass | o28-stage2-final-inventory.log |
| 3810 | feature SAFE-140 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3811 | feature SAFE-140 test area assigned | pass | o28-stage2-final-inventory.log |
| 3812 | feature SAFE-140 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3813 | feature SAFE-141 name present | pass | o28-stage2-final-inventory.log |
| 3814 | feature SAFE-141 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3815 | feature SAFE-141 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3816 | feature SAFE-141 test area assigned | pass | o28-stage2-final-inventory.log |
| 3817 | feature SAFE-141 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3818 | feature SAFE-142 name present | pass | o28-stage2-final-inventory.log |
| 3819 | feature SAFE-142 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3820 | feature SAFE-142 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3821 | feature SAFE-142 test area assigned | pass | o28-stage2-final-inventory.log |
| 3822 | feature SAFE-142 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3823 | feature SAFE-143 name present | pass | o28-stage2-final-inventory.log |
| 3824 | feature SAFE-143 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3825 | feature SAFE-143 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3826 | feature SAFE-143 test area assigned | pass | o28-stage2-final-inventory.log |
| 3827 | feature SAFE-143 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3828 | feature SAFE-144 name present | pass | o28-stage2-final-inventory.log |
| 3829 | feature SAFE-144 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3830 | feature SAFE-144 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3831 | feature SAFE-144 test area assigned | pass | o28-stage2-final-inventory.log |
| 3832 | feature SAFE-144 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3833 | feature SAFE-145 name present | pass | o28-stage2-final-inventory.log |
| 3834 | feature SAFE-145 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3835 | feature SAFE-145 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3836 | feature SAFE-145 test area assigned | pass | o28-stage2-final-inventory.log |
| 3837 | feature SAFE-145 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3838 | feature SAFE-146 name present | pass | o28-stage2-final-inventory.log |
| 3839 | feature SAFE-146 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3840 | feature SAFE-146 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3841 | feature SAFE-146 test area assigned | pass | o28-stage2-final-inventory.log |
| 3842 | feature SAFE-146 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3843 | feature SAFE-147 name present | pass | o28-stage2-final-inventory.log |
| 3844 | feature SAFE-147 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3845 | feature SAFE-147 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3846 | feature SAFE-147 test area assigned | pass | o28-stage2-final-inventory.log |
| 3847 | feature SAFE-147 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3848 | feature SAFE-148 name present | pass | o28-stage2-final-inventory.log |
| 3849 | feature SAFE-148 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3850 | feature SAFE-148 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3851 | feature SAFE-148 test area assigned | pass | o28-stage2-final-inventory.log |
| 3852 | feature SAFE-148 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3853 | feature SAFE-149 name present | pass | o28-stage2-final-inventory.log |
| 3854 | feature SAFE-149 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3855 | feature SAFE-149 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3856 | feature SAFE-149 test area assigned | pass | o28-stage2-final-inventory.log |
| 3857 | feature SAFE-149 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3858 | feature SAFE-150 name present | pass | o28-stage2-final-inventory.log |
| 3859 | feature SAFE-150 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3860 | feature SAFE-150 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3861 | feature SAFE-150 test area assigned | pass | o28-stage2-final-inventory.log |
| 3862 | feature SAFE-150 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3863 | feature SAFE-151 name present | pass | o28-stage2-final-inventory.log |
| 3864 | feature SAFE-151 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3865 | feature SAFE-151 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3866 | feature SAFE-151 test area assigned | pass | o28-stage2-final-inventory.log |
| 3867 | feature SAFE-151 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3868 | feature SAFE-152 name present | pass | o28-stage2-final-inventory.log |
| 3869 | feature SAFE-152 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3870 | feature SAFE-152 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3871 | feature SAFE-152 test area assigned | pass | o28-stage2-final-inventory.log |
| 3872 | feature SAFE-152 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3873 | feature SAFE-153 name present | pass | o28-stage2-final-inventory.log |
| 3874 | feature SAFE-153 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3875 | feature SAFE-153 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3876 | feature SAFE-153 test area assigned | pass | o28-stage2-final-inventory.log |
| 3877 | feature SAFE-153 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3878 | feature SAFE-154 name present | pass | o28-stage2-final-inventory.log |
| 3879 | feature SAFE-154 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3880 | feature SAFE-154 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3881 | feature SAFE-154 test area assigned | pass | o28-stage2-final-inventory.log |
| 3882 | feature SAFE-154 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3883 | feature SAFE-155 name present | pass | o28-stage2-final-inventory.log |
| 3884 | feature SAFE-155 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3885 | feature SAFE-155 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3886 | feature SAFE-155 test area assigned | pass | o28-stage2-final-inventory.log |
| 3887 | feature SAFE-155 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3888 | feature SAFE-156 name present | pass | o28-stage2-final-inventory.log |
| 3889 | feature SAFE-156 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3890 | feature SAFE-156 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3891 | feature SAFE-156 test area assigned | pass | o28-stage2-final-inventory.log |
| 3892 | feature SAFE-156 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3893 | feature SAFE-157 name present | pass | o28-stage2-final-inventory.log |
| 3894 | feature SAFE-157 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3895 | feature SAFE-157 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3896 | feature SAFE-157 test area assigned | pass | o28-stage2-final-inventory.log |
| 3897 | feature SAFE-157 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3898 | feature SAFE-158 name present | pass | o28-stage2-final-inventory.log |
| 3899 | feature SAFE-158 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3900 | feature SAFE-158 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3901 | feature SAFE-158 test area assigned | pass | o28-stage2-final-inventory.log |
| 3902 | feature SAFE-158 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3903 | feature SAFE-159 name present | pass | o28-stage2-final-inventory.log |
| 3904 | feature SAFE-159 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3905 | feature SAFE-159 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3906 | feature SAFE-159 test area assigned | pass | o28-stage2-final-inventory.log |
| 3907 | feature SAFE-159 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3908 | feature SAFE-160 name present | pass | o28-stage2-final-inventory.log |
| 3909 | feature SAFE-160 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3910 | feature SAFE-160 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3911 | feature SAFE-160 test area assigned | pass | o28-stage2-final-inventory.log |
| 3912 | feature SAFE-160 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3913 | feature SAFE-161 name present | pass | o28-stage2-final-inventory.log |
| 3914 | feature SAFE-161 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3915 | feature SAFE-161 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3916 | feature SAFE-161 test area assigned | pass | o28-stage2-final-inventory.log |
| 3917 | feature SAFE-161 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3918 | feature SAFE-162 name present | pass | o28-stage2-final-inventory.log |
| 3919 | feature SAFE-162 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3920 | feature SAFE-162 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3921 | feature SAFE-162 test area assigned | pass | o28-stage2-final-inventory.log |
| 3922 | feature SAFE-162 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3923 | feature SAFE-163 name present | pass | o28-stage2-final-inventory.log |
| 3924 | feature SAFE-163 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3925 | feature SAFE-163 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3926 | feature SAFE-163 test area assigned | pass | o28-stage2-final-inventory.log |
| 3927 | feature SAFE-163 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3928 | feature SAFE-164 name present | pass | o28-stage2-final-inventory.log |
| 3929 | feature SAFE-164 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3930 | feature SAFE-164 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3931 | feature SAFE-164 test area assigned | pass | o28-stage2-final-inventory.log |
| 3932 | feature SAFE-164 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3933 | feature SAFE-165 name present | pass | o28-stage2-final-inventory.log |
| 3934 | feature SAFE-165 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3935 | feature SAFE-165 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3936 | feature SAFE-165 test area assigned | pass | o28-stage2-final-inventory.log |
| 3937 | feature SAFE-165 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3938 | feature SAFE-166 name present | pass | o28-stage2-final-inventory.log |
| 3939 | feature SAFE-166 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3940 | feature SAFE-166 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3941 | feature SAFE-166 test area assigned | pass | o28-stage2-final-inventory.log |
| 3942 | feature SAFE-166 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3943 | feature SAFE-167 name present | pass | o28-stage2-final-inventory.log |
| 3944 | feature SAFE-167 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3945 | feature SAFE-167 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3946 | feature SAFE-167 test area assigned | pass | o28-stage2-final-inventory.log |
| 3947 | feature SAFE-167 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3948 | feature SAFE-168 name present | pass | o28-stage2-final-inventory.log |
| 3949 | feature SAFE-168 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3950 | feature SAFE-168 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3951 | feature SAFE-168 test area assigned | pass | o28-stage2-final-inventory.log |
| 3952 | feature SAFE-168 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3953 | feature SAFE-169 name present | pass | o28-stage2-final-inventory.log |
| 3954 | feature SAFE-169 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3955 | feature SAFE-169 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3956 | feature SAFE-169 test area assigned | pass | o28-stage2-final-inventory.log |
| 3957 | feature SAFE-169 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3958 | feature SAFE-170 name present | pass | o28-stage2-final-inventory.log |
| 3959 | feature SAFE-170 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3960 | feature SAFE-170 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3961 | feature SAFE-170 test area assigned | pass | o28-stage2-final-inventory.log |
| 3962 | feature SAFE-170 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3963 | feature SAFE-171 name present | pass | o28-stage2-final-inventory.log |
| 3964 | feature SAFE-171 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3965 | feature SAFE-171 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3966 | feature SAFE-171 test area assigned | pass | o28-stage2-final-inventory.log |
| 3967 | feature SAFE-171 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3968 | feature SAFE-172 name present | pass | o28-stage2-final-inventory.log |
| 3969 | feature SAFE-172 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3970 | feature SAFE-172 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3971 | feature SAFE-172 test area assigned | pass | o28-stage2-final-inventory.log |
| 3972 | feature SAFE-172 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3973 | feature SAFE-173 name present | pass | o28-stage2-final-inventory.log |
| 3974 | feature SAFE-173 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3975 | feature SAFE-173 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3976 | feature SAFE-173 test area assigned | pass | o28-stage2-final-inventory.log |
| 3977 | feature SAFE-173 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3978 | feature SAFE-174 name present | pass | o28-stage2-final-inventory.log |
| 3979 | feature SAFE-174 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3980 | feature SAFE-174 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3981 | feature SAFE-174 test area assigned | pass | o28-stage2-final-inventory.log |
| 3982 | feature SAFE-174 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3983 | feature SAFE-175 name present | pass | o28-stage2-final-inventory.log |
| 3984 | feature SAFE-175 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3985 | feature SAFE-175 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3986 | feature SAFE-175 test area assigned | pass | o28-stage2-final-inventory.log |
| 3987 | feature SAFE-175 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3988 | feature SAFE-176 name present | pass | o28-stage2-final-inventory.log |
| 3989 | feature SAFE-176 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3990 | feature SAFE-176 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3991 | feature SAFE-176 test area assigned | pass | o28-stage2-final-inventory.log |
| 3992 | feature SAFE-176 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3993 | feature SAFE-177 name present | pass | o28-stage2-final-inventory.log |
| 3994 | feature SAFE-177 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 3995 | feature SAFE-177 test need 필요 | pass | o28-stage2-final-inventory.log |
| 3996 | feature SAFE-177 test area assigned | pass | o28-stage2-final-inventory.log |
| 3997 | feature SAFE-177 pass criteria present | pass | o28-stage2-final-inventory.log |
| 3998 | feature SAFE-178 name present | pass | o28-stage2-final-inventory.log |
| 3999 | feature SAFE-178 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4000 | feature SAFE-178 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4001 | feature SAFE-178 test area assigned | pass | o28-stage2-final-inventory.log |
| 4002 | feature SAFE-178 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4003 | feature SAFE-179 name present | pass | o28-stage2-final-inventory.log |
| 4004 | feature SAFE-179 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4005 | feature SAFE-179 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4006 | feature SAFE-179 test area assigned | pass | o28-stage2-final-inventory.log |
| 4007 | feature SAFE-179 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4008 | feature SAFE-180 name present | pass | o28-stage2-final-inventory.log |
| 4009 | feature SAFE-180 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4010 | feature SAFE-180 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4011 | feature SAFE-180 test area assigned | pass | o28-stage2-final-inventory.log |
| 4012 | feature SAFE-180 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4013 | feature SAFE-181 name present | pass | o28-stage2-final-inventory.log |
| 4014 | feature SAFE-181 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4015 | feature SAFE-181 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4016 | feature SAFE-181 test area assigned | pass | o28-stage2-final-inventory.log |
| 4017 | feature SAFE-181 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4018 | feature SAFE-182 name present | pass | o28-stage2-final-inventory.log |
| 4019 | feature SAFE-182 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4020 | feature SAFE-182 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4021 | feature SAFE-182 test area assigned | pass | o28-stage2-final-inventory.log |
| 4022 | feature SAFE-182 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4023 | feature SAFE-183 name present | pass | o28-stage2-final-inventory.log |
| 4024 | feature SAFE-183 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4025 | feature SAFE-183 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4026 | feature SAFE-183 test area assigned | pass | o28-stage2-final-inventory.log |
| 4027 | feature SAFE-183 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4028 | feature SAFE-184 name present | pass | o28-stage2-final-inventory.log |
| 4029 | feature SAFE-184 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4030 | feature SAFE-184 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4031 | feature SAFE-184 test area assigned | pass | o28-stage2-final-inventory.log |
| 4032 | feature SAFE-184 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4033 | feature SAFE-185 name present | pass | o28-stage2-final-inventory.log |
| 4034 | feature SAFE-185 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4035 | feature SAFE-185 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4036 | feature SAFE-185 test area assigned | pass | o28-stage2-final-inventory.log |
| 4037 | feature SAFE-185 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4038 | feature SAFE-186 name present | pass | o28-stage2-final-inventory.log |
| 4039 | feature SAFE-186 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4040 | feature SAFE-186 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4041 | feature SAFE-186 test area assigned | pass | o28-stage2-final-inventory.log |
| 4042 | feature SAFE-186 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4043 | feature SAFE-187 name present | pass | o28-stage2-final-inventory.log |
| 4044 | feature SAFE-187 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4045 | feature SAFE-187 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4046 | feature SAFE-187 test area assigned | pass | o28-stage2-final-inventory.log |
| 4047 | feature SAFE-187 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4048 | feature SAFE-188 name present | pass | o28-stage2-final-inventory.log |
| 4049 | feature SAFE-188 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4050 | feature SAFE-188 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4051 | feature SAFE-188 test area assigned | pass | o28-stage2-final-inventory.log |
| 4052 | feature SAFE-188 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4053 | feature SAFE-189 name present | pass | o28-stage2-final-inventory.log |
| 4054 | feature SAFE-189 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4055 | feature SAFE-189 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4056 | feature SAFE-189 test area assigned | pass | o28-stage2-final-inventory.log |
| 4057 | feature SAFE-189 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4058 | feature SAFE-190 name present | pass | o28-stage2-final-inventory.log |
| 4059 | feature SAFE-190 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4060 | feature SAFE-190 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4061 | feature SAFE-190 test area assigned | pass | o28-stage2-final-inventory.log |
| 4062 | feature SAFE-190 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4063 | feature SAFE-191 name present | pass | o28-stage2-final-inventory.log |
| 4064 | feature SAFE-191 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4065 | feature SAFE-191 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4066 | feature SAFE-191 test area assigned | pass | o28-stage2-final-inventory.log |
| 4067 | feature SAFE-191 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4068 | feature SAFE-192 name present | pass | o28-stage2-final-inventory.log |
| 4069 | feature SAFE-192 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4070 | feature SAFE-192 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4071 | feature SAFE-192 test area assigned | pass | o28-stage2-final-inventory.log |
| 4072 | feature SAFE-192 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4073 | feature SAFE-193 name present | pass | o28-stage2-final-inventory.log |
| 4074 | feature SAFE-193 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4075 | feature SAFE-193 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4076 | feature SAFE-193 test area assigned | pass | o28-stage2-final-inventory.log |
| 4077 | feature SAFE-193 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4078 | feature SAFE-194 name present | pass | o28-stage2-final-inventory.log |
| 4079 | feature SAFE-194 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4080 | feature SAFE-194 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4081 | feature SAFE-194 test area assigned | pass | o28-stage2-final-inventory.log |
| 4082 | feature SAFE-194 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4083 | feature SAFE-195 name present | pass | o28-stage2-final-inventory.log |
| 4084 | feature SAFE-195 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4085 | feature SAFE-195 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4086 | feature SAFE-195 test area assigned | pass | o28-stage2-final-inventory.log |
| 4087 | feature SAFE-195 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4088 | feature SAFE-196 name present | pass | o28-stage2-final-inventory.log |
| 4089 | feature SAFE-196 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4090 | feature SAFE-196 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4091 | feature SAFE-196 test area assigned | pass | o28-stage2-final-inventory.log |
| 4092 | feature SAFE-196 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4093 | feature SAFE-197 name present | pass | o28-stage2-final-inventory.log |
| 4094 | feature SAFE-197 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4095 | feature SAFE-197 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4096 | feature SAFE-197 test area assigned | pass | o28-stage2-final-inventory.log |
| 4097 | feature SAFE-197 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4098 | feature SAFE-198 name present | pass | o28-stage2-final-inventory.log |
| 4099 | feature SAFE-198 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4100 | feature SAFE-198 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4101 | feature SAFE-198 test area assigned | pass | o28-stage2-final-inventory.log |
| 4102 | feature SAFE-198 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4103 | feature SAFE-199 name present | pass | o28-stage2-final-inventory.log |
| 4104 | feature SAFE-199 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4105 | feature SAFE-199 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4106 | feature SAFE-199 test area assigned | pass | o28-stage2-final-inventory.log |
| 4107 | feature SAFE-199 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4108 | feature SAFE-200 name present | pass | o28-stage2-final-inventory.log |
| 4109 | feature SAFE-200 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4110 | feature SAFE-200 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4111 | feature SAFE-200 test area assigned | pass | o28-stage2-final-inventory.log |
| 4112 | feature SAFE-200 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4113 | feature SAFE-201 name present | pass | o28-stage2-final-inventory.log |
| 4114 | feature SAFE-201 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4115 | feature SAFE-201 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4116 | feature SAFE-201 test area assigned | pass | o28-stage2-final-inventory.log |
| 4117 | feature SAFE-201 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4118 | feature SAFE-202 name present | pass | o28-stage2-final-inventory.log |
| 4119 | feature SAFE-202 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4120 | feature SAFE-202 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4121 | feature SAFE-202 test area assigned | pass | o28-stage2-final-inventory.log |
| 4122 | feature SAFE-202 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4123 | feature SAFE-203 name present | pass | o28-stage2-final-inventory.log |
| 4124 | feature SAFE-203 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4125 | feature SAFE-203 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4126 | feature SAFE-203 test area assigned | pass | o28-stage2-final-inventory.log |
| 4127 | feature SAFE-203 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4128 | feature SAFE-204 name present | pass | o28-stage2-final-inventory.log |
| 4129 | feature SAFE-204 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4130 | feature SAFE-204 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4131 | feature SAFE-204 test area assigned | pass | o28-stage2-final-inventory.log |
| 4132 | feature SAFE-204 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4133 | feature SAFE-205 name present | pass | o28-stage2-final-inventory.log |
| 4134 | feature SAFE-205 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4135 | feature SAFE-205 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4136 | feature SAFE-205 test area assigned | pass | o28-stage2-final-inventory.log |
| 4137 | feature SAFE-205 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4138 | feature SAFE-206 name present | pass | o28-stage2-final-inventory.log |
| 4139 | feature SAFE-206 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4140 | feature SAFE-206 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4141 | feature SAFE-206 test area assigned | pass | o28-stage2-final-inventory.log |
| 4142 | feature SAFE-206 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4143 | feature SAFE-207 name present | pass | o28-stage2-final-inventory.log |
| 4144 | feature SAFE-207 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4145 | feature SAFE-207 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4146 | feature SAFE-207 test area assigned | pass | o28-stage2-final-inventory.log |
| 4147 | feature SAFE-207 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4148 | feature SAFE-208 name present | pass | o28-stage2-final-inventory.log |
| 4149 | feature SAFE-208 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4150 | feature SAFE-208 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4151 | feature SAFE-208 test area assigned | pass | o28-stage2-final-inventory.log |
| 4152 | feature SAFE-208 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4153 | feature SAFE-209 name present | pass | o28-stage2-final-inventory.log |
| 4154 | feature SAFE-209 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4155 | feature SAFE-209 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4156 | feature SAFE-209 test area assigned | pass | o28-stage2-final-inventory.log |
| 4157 | feature SAFE-209 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4158 | feature SAFE-210 name present | pass | o28-stage2-final-inventory.log |
| 4159 | feature SAFE-210 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4160 | feature SAFE-210 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4161 | feature SAFE-210 test area assigned | pass | o28-stage2-final-inventory.log |
| 4162 | feature SAFE-210 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4163 | feature SAFE-211 name present | pass | o28-stage2-final-inventory.log |
| 4164 | feature SAFE-211 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4165 | feature SAFE-211 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4166 | feature SAFE-211 test area assigned | pass | o28-stage2-final-inventory.log |
| 4167 | feature SAFE-211 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4168 | feature SAFE-212 name present | pass | o28-stage2-final-inventory.log |
| 4169 | feature SAFE-212 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4170 | feature SAFE-212 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4171 | feature SAFE-212 test area assigned | pass | o28-stage2-final-inventory.log |
| 4172 | feature SAFE-212 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4173 | feature SAFE-213 name present | pass | o28-stage2-final-inventory.log |
| 4174 | feature SAFE-213 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4175 | feature SAFE-213 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4176 | feature SAFE-213 test area assigned | pass | o28-stage2-final-inventory.log |
| 4177 | feature SAFE-213 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4178 | feature SAFE-214 name present | pass | o28-stage2-final-inventory.log |
| 4179 | feature SAFE-214 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4180 | feature SAFE-214 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4181 | feature SAFE-214 test area assigned | pass | o28-stage2-final-inventory.log |
| 4182 | feature SAFE-214 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4183 | feature SAFE-215 name present | pass | o28-stage2-final-inventory.log |
| 4184 | feature SAFE-215 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4185 | feature SAFE-215 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4186 | feature SAFE-215 test area assigned | pass | o28-stage2-final-inventory.log |
| 4187 | feature SAFE-215 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4188 | feature SAFE-216 name present | pass | o28-stage2-final-inventory.log |
| 4189 | feature SAFE-216 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4190 | feature SAFE-216 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4191 | feature SAFE-216 test area assigned | pass | o28-stage2-final-inventory.log |
| 4192 | feature SAFE-216 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4193 | feature SAFE-217 name present | pass | o28-stage2-final-inventory.log |
| 4194 | feature SAFE-217 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4195 | feature SAFE-217 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4196 | feature SAFE-217 test area assigned | pass | o28-stage2-final-inventory.log |
| 4197 | feature SAFE-217 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4198 | feature OPS-035 name present | pass | o28-stage2-final-inventory.log |
| 4199 | feature OPS-035 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4200 | feature OPS-035 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4201 | feature OPS-035 test area assigned | pass | o28-stage2-final-inventory.log |
| 4202 | feature OPS-035 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4203 | feature OPS-036 name present | pass | o28-stage2-final-inventory.log |
| 4204 | feature OPS-036 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4205 | feature OPS-036 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4206 | feature OPS-036 test area assigned | pass | o28-stage2-final-inventory.log |
| 4207 | feature OPS-036 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4208 | feature OPS-037 name present | pass | o28-stage2-final-inventory.log |
| 4209 | feature OPS-037 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4210 | feature OPS-037 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4211 | feature OPS-037 test area assigned | pass | o28-stage2-final-inventory.log |
| 4212 | feature OPS-037 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4213 | feature OPS-038 name present | pass | o28-stage2-final-inventory.log |
| 4214 | feature OPS-038 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4215 | feature OPS-038 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4216 | feature OPS-038 test area assigned | pass | o28-stage2-final-inventory.log |
| 4217 | feature OPS-038 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4218 | feature OPS-039 name present | pass | o28-stage2-final-inventory.log |
| 4219 | feature OPS-039 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4220 | feature OPS-039 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4221 | feature OPS-039 test area assigned | pass | o28-stage2-final-inventory.log |
| 4222 | feature OPS-039 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4223 | feature OPS-040 name present | pass | o28-stage2-final-inventory.log |
| 4224 | feature OPS-040 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4225 | feature OPS-040 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4226 | feature OPS-040 test area assigned | pass | o28-stage2-final-inventory.log |
| 4227 | feature OPS-040 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4228 | feature OPS-041 name present | pass | o28-stage2-final-inventory.log |
| 4229 | feature OPS-041 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4230 | feature OPS-041 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4231 | feature OPS-041 test area assigned | pass | o28-stage2-final-inventory.log |
| 4232 | feature OPS-041 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4233 | feature OPS-042 name present | pass | o28-stage2-final-inventory.log |
| 4234 | feature OPS-042 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4235 | feature OPS-042 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4236 | feature OPS-042 test area assigned | pass | o28-stage2-final-inventory.log |
| 4237 | feature OPS-042 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4238 | feature OPS-043 name present | pass | o28-stage2-final-inventory.log |
| 4239 | feature OPS-043 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4240 | feature OPS-043 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4241 | feature OPS-043 test area assigned | pass | o28-stage2-final-inventory.log |
| 4242 | feature OPS-043 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4243 | feature OPS-044 name present | pass | o28-stage2-final-inventory.log |
| 4244 | feature OPS-044 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4245 | feature OPS-044 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4246 | feature OPS-044 test area assigned | pass | o28-stage2-final-inventory.log |
| 4247 | feature OPS-044 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4248 | feature OPS-045 name present | pass | o28-stage2-final-inventory.log |
| 4249 | feature OPS-045 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4250 | feature OPS-045 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4251 | feature OPS-045 test area assigned | pass | o28-stage2-final-inventory.log |
| 4252 | feature OPS-045 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4253 | feature OPS-046 name present | pass | o28-stage2-final-inventory.log |
| 4254 | feature OPS-046 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4255 | feature OPS-046 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4256 | feature OPS-046 test area assigned | pass | o28-stage2-final-inventory.log |
| 4257 | feature OPS-046 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4258 | feature OPS-047 name present | pass | o28-stage2-final-inventory.log |
| 4259 | feature OPS-047 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4260 | feature OPS-047 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4261 | feature OPS-047 test area assigned | pass | o28-stage2-final-inventory.log |
| 4262 | feature OPS-047 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4263 | feature OPS-048 name present | pass | o28-stage2-final-inventory.log |
| 4264 | feature OPS-048 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4265 | feature OPS-048 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4266 | feature OPS-048 test area assigned | pass | o28-stage2-final-inventory.log |
| 4267 | feature OPS-048 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4268 | feature OPS-049 name present | pass | o28-stage2-final-inventory.log |
| 4269 | feature OPS-049 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4270 | feature OPS-049 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4271 | feature OPS-049 test area assigned | pass | o28-stage2-final-inventory.log |
| 4272 | feature OPS-049 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4273 | feature OPS-050 name present | pass | o28-stage2-final-inventory.log |
| 4274 | feature OPS-050 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4275 | feature OPS-050 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4276 | feature OPS-050 test area assigned | pass | o28-stage2-final-inventory.log |
| 4277 | feature OPS-050 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4278 | feature OPS-051 name present | pass | o28-stage2-final-inventory.log |
| 4279 | feature OPS-051 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4280 | feature OPS-051 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4281 | feature OPS-051 test area assigned | pass | o28-stage2-final-inventory.log |
| 4282 | feature OPS-051 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4283 | feature OPS-052 name present | pass | o28-stage2-final-inventory.log |
| 4284 | feature OPS-052 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4285 | feature OPS-052 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4286 | feature OPS-052 test area assigned | pass | o28-stage2-final-inventory.log |
| 4287 | feature OPS-052 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4288 | feature OPS-053 name present | pass | o28-stage2-final-inventory.log |
| 4289 | feature OPS-053 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4290 | feature OPS-053 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4291 | feature OPS-053 test area assigned | pass | o28-stage2-final-inventory.log |
| 4292 | feature OPS-053 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4293 | feature OPS-054 name present | pass | o28-stage2-final-inventory.log |
| 4294 | feature OPS-054 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4295 | feature OPS-054 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4296 | feature OPS-054 test area assigned | pass | o28-stage2-final-inventory.log |
| 4297 | feature OPS-054 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4298 | feature OPS-055 name present | pass | o28-stage2-final-inventory.log |
| 4299 | feature OPS-055 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4300 | feature OPS-055 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4301 | feature OPS-055 test area assigned | pass | o28-stage2-final-inventory.log |
| 4302 | feature OPS-055 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4303 | feature OPS-056 name present | pass | o28-stage2-final-inventory.log |
| 4304 | feature OPS-056 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4305 | feature OPS-056 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4306 | feature OPS-056 test area assigned | pass | o28-stage2-final-inventory.log |
| 4307 | feature OPS-056 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4308 | feature OPS-057 name present | pass | o28-stage2-final-inventory.log |
| 4309 | feature OPS-057 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4310 | feature OPS-057 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4311 | feature OPS-057 test area assigned | pass | o28-stage2-final-inventory.log |
| 4312 | feature OPS-057 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4313 | feature OPS-058 name present | pass | o28-stage2-final-inventory.log |
| 4314 | feature OPS-058 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4315 | feature OPS-058 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4316 | feature OPS-058 test area assigned | pass | o28-stage2-final-inventory.log |
| 4317 | feature OPS-058 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4318 | feature OPS-059 name present | pass | o28-stage2-final-inventory.log |
| 4319 | feature OPS-059 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4320 | feature OPS-059 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4321 | feature OPS-059 test area assigned | pass | o28-stage2-final-inventory.log |
| 4322 | feature OPS-059 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4323 | feature OPS-060 name present | pass | o28-stage2-final-inventory.log |
| 4324 | feature OPS-060 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4325 | feature OPS-060 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4326 | feature OPS-060 test area assigned | pass | o28-stage2-final-inventory.log |
| 4327 | feature OPS-060 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4328 | feature OPS-061 name present | pass | o28-stage2-final-inventory.log |
| 4329 | feature OPS-061 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4330 | feature OPS-061 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4331 | feature OPS-061 test area assigned | pass | o28-stage2-final-inventory.log |
| 4332 | feature OPS-061 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4333 | feature OPS-062 name present | pass | o28-stage2-final-inventory.log |
| 4334 | feature OPS-062 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4335 | feature OPS-062 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4336 | feature OPS-062 test area assigned | pass | o28-stage2-final-inventory.log |
| 4337 | feature OPS-062 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4338 | feature OPS-063 name present | pass | o28-stage2-final-inventory.log |
| 4339 | feature OPS-063 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4340 | feature OPS-063 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4341 | feature OPS-063 test area assigned | pass | o28-stage2-final-inventory.log |
| 4342 | feature OPS-063 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4343 | feature OPS-064 name present | pass | o28-stage2-final-inventory.log |
| 4344 | feature OPS-064 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4345 | feature OPS-064 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4346 | feature OPS-064 test area assigned | pass | o28-stage2-final-inventory.log |
| 4347 | feature OPS-064 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4348 | feature OPS-065 name present | pass | o28-stage2-final-inventory.log |
| 4349 | feature OPS-065 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4350 | feature OPS-065 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4351 | feature OPS-065 test area assigned | pass | o28-stage2-final-inventory.log |
| 4352 | feature OPS-065 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4353 | feature OPS-066 name present | pass | o28-stage2-final-inventory.log |
| 4354 | feature OPS-066 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4355 | feature OPS-066 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4356 | feature OPS-066 test area assigned | pass | o28-stage2-final-inventory.log |
| 4357 | feature OPS-066 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4358 | feature OPS-067 name present | pass | o28-stage2-final-inventory.log |
| 4359 | feature OPS-067 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4360 | feature OPS-067 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4361 | feature OPS-067 test area assigned | pass | o28-stage2-final-inventory.log |
| 4362 | feature OPS-067 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4363 | feature OPS-068 name present | pass | o28-stage2-final-inventory.log |
| 4364 | feature OPS-068 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4365 | feature OPS-068 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4366 | feature OPS-068 test area assigned | pass | o28-stage2-final-inventory.log |
| 4367 | feature OPS-068 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4368 | feature OPS-069 name present | pass | o28-stage2-final-inventory.log |
| 4369 | feature OPS-069 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4370 | feature OPS-069 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4371 | feature OPS-069 test area assigned | pass | o28-stage2-final-inventory.log |
| 4372 | feature OPS-069 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4373 | feature OPS-070 name present | pass | o28-stage2-final-inventory.log |
| 4374 | feature OPS-070 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4375 | feature OPS-070 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4376 | feature OPS-070 test area assigned | pass | o28-stage2-final-inventory.log |
| 4377 | feature OPS-070 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4378 | feature OPS-071 name present | pass | o28-stage2-final-inventory.log |
| 4379 | feature OPS-071 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4380 | feature OPS-071 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4381 | feature OPS-071 test area assigned | pass | o28-stage2-final-inventory.log |
| 4382 | feature OPS-071 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4383 | feature OPS-072 name present | pass | o28-stage2-final-inventory.log |
| 4384 | feature OPS-072 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4385 | feature OPS-072 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4386 | feature OPS-072 test area assigned | pass | o28-stage2-final-inventory.log |
| 4387 | feature OPS-072 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4388 | feature OPS-073 name present | pass | o28-stage2-final-inventory.log |
| 4389 | feature OPS-073 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4390 | feature OPS-073 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4391 | feature OPS-073 test area assigned | pass | o28-stage2-final-inventory.log |
| 4392 | feature OPS-073 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4393 | feature OPS-074 name present | pass | o28-stage2-final-inventory.log |
| 4394 | feature OPS-074 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4395 | feature OPS-074 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4396 | feature OPS-074 test area assigned | pass | o28-stage2-final-inventory.log |
| 4397 | feature OPS-074 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4398 | feature OPS-075 name present | pass | o28-stage2-final-inventory.log |
| 4399 | feature OPS-075 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4400 | feature OPS-075 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4401 | feature OPS-075 test area assigned | pass | o28-stage2-final-inventory.log |
| 4402 | feature OPS-075 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4403 | feature OPS-076 name present | pass | o28-stage2-final-inventory.log |
| 4404 | feature OPS-076 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4405 | feature OPS-076 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4406 | feature OPS-076 test area assigned | pass | o28-stage2-final-inventory.log |
| 4407 | feature OPS-076 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4408 | feature OPS-077 name present | pass | o28-stage2-final-inventory.log |
| 4409 | feature OPS-077 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4410 | feature OPS-077 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4411 | feature OPS-077 test area assigned | pass | o28-stage2-final-inventory.log |
| 4412 | feature OPS-077 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4413 | feature OPS-078 name present | pass | o28-stage2-final-inventory.log |
| 4414 | feature OPS-078 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4415 | feature OPS-078 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4416 | feature OPS-078 test area assigned | pass | o28-stage2-final-inventory.log |
| 4417 | feature OPS-078 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4418 | feature OPS-079 name present | pass | o28-stage2-final-inventory.log |
| 4419 | feature OPS-079 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4420 | feature OPS-079 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4421 | feature OPS-079 test area assigned | pass | o28-stage2-final-inventory.log |
| 4422 | feature OPS-079 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4423 | feature OPS-080 name present | pass | o28-stage2-final-inventory.log |
| 4424 | feature OPS-080 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4425 | feature OPS-080 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4426 | feature OPS-080 test area assigned | pass | o28-stage2-final-inventory.log |
| 4427 | feature OPS-080 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4428 | feature OPS-081 name present | pass | o28-stage2-final-inventory.log |
| 4429 | feature OPS-081 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4430 | feature OPS-081 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4431 | feature OPS-081 test area assigned | pass | o28-stage2-final-inventory.log |
| 4432 | feature OPS-081 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4433 | feature OPS-082 name present | pass | o28-stage2-final-inventory.log |
| 4434 | feature OPS-082 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4435 | feature OPS-082 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4436 | feature OPS-082 test area assigned | pass | o28-stage2-final-inventory.log |
| 4437 | feature OPS-082 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4438 | feature OPS-083 name present | pass | o28-stage2-final-inventory.log |
| 4439 | feature OPS-083 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4440 | feature OPS-083 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4441 | feature OPS-083 test area assigned | pass | o28-stage2-final-inventory.log |
| 4442 | feature OPS-083 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4443 | feature OPS-084 name present | pass | o28-stage2-final-inventory.log |
| 4444 | feature OPS-084 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4445 | feature OPS-084 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4446 | feature OPS-084 test area assigned | pass | o28-stage2-final-inventory.log |
| 4447 | feature OPS-084 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4448 | feature OPS-085 name present | pass | o28-stage2-final-inventory.log |
| 4449 | feature OPS-085 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4450 | feature OPS-085 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4451 | feature OPS-085 test area assigned | pass | o28-stage2-final-inventory.log |
| 4452 | feature OPS-085 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4453 | feature OPS-086 name present | pass | o28-stage2-final-inventory.log |
| 4454 | feature OPS-086 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4455 | feature OPS-086 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4456 | feature OPS-086 test area assigned | pass | o28-stage2-final-inventory.log |
| 4457 | feature OPS-086 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4458 | feature OPS-087 name present | pass | o28-stage2-final-inventory.log |
| 4459 | feature OPS-087 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4460 | feature OPS-087 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4461 | feature OPS-087 test area assigned | pass | o28-stage2-final-inventory.log |
| 4462 | feature OPS-087 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4463 | feature OPS-088 name present | pass | o28-stage2-final-inventory.log |
| 4464 | feature OPS-088 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4465 | feature OPS-088 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4466 | feature OPS-088 test area assigned | pass | o28-stage2-final-inventory.log |
| 4467 | feature OPS-088 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4468 | feature OPS-089 name present | pass | o28-stage2-final-inventory.log |
| 4469 | feature OPS-089 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4470 | feature OPS-089 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4471 | feature OPS-089 test area assigned | pass | o28-stage2-final-inventory.log |
| 4472 | feature OPS-089 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4473 | feature OPS-090 name present | pass | o28-stage2-final-inventory.log |
| 4474 | feature OPS-090 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4475 | feature OPS-090 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4476 | feature OPS-090 test area assigned | pass | o28-stage2-final-inventory.log |
| 4477 | feature OPS-090 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4478 | feature OPS-091 name present | pass | o28-stage2-final-inventory.log |
| 4479 | feature OPS-091 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4480 | feature OPS-091 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4481 | feature OPS-091 test area assigned | pass | o28-stage2-final-inventory.log |
| 4482 | feature OPS-091 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4483 | feature OPS-092 name present | pass | o28-stage2-final-inventory.log |
| 4484 | feature OPS-092 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4485 | feature OPS-092 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4486 | feature OPS-092 test area assigned | pass | o28-stage2-final-inventory.log |
| 4487 | feature OPS-092 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4488 | feature OPS-093 name present | pass | o28-stage2-final-inventory.log |
| 4489 | feature OPS-093 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4490 | feature OPS-093 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4491 | feature OPS-093 test area assigned | pass | o28-stage2-final-inventory.log |
| 4492 | feature OPS-093 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4493 | feature OPS-094 name present | pass | o28-stage2-final-inventory.log |
| 4494 | feature OPS-094 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4495 | feature OPS-094 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4496 | feature OPS-094 test area assigned | pass | o28-stage2-final-inventory.log |
| 4497 | feature OPS-094 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4498 | feature OPS-095 name present | pass | o28-stage2-final-inventory.log |
| 4499 | feature OPS-095 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4500 | feature OPS-095 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4501 | feature OPS-095 test area assigned | pass | o28-stage2-final-inventory.log |
| 4502 | feature OPS-095 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4503 | feature OPS-096 name present | pass | o28-stage2-final-inventory.log |
| 4504 | feature OPS-096 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4505 | feature OPS-096 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4506 | feature OPS-096 test area assigned | pass | o28-stage2-final-inventory.log |
| 4507 | feature OPS-096 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4508 | feature OPS-097 name present | pass | o28-stage2-final-inventory.log |
| 4509 | feature OPS-097 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4510 | feature OPS-097 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4511 | feature OPS-097 test area assigned | pass | o28-stage2-final-inventory.log |
| 4512 | feature OPS-097 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4513 | feature OPS-098 name present | pass | o28-stage2-final-inventory.log |
| 4514 | feature OPS-098 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4515 | feature OPS-098 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4516 | feature OPS-098 test area assigned | pass | o28-stage2-final-inventory.log |
| 4517 | feature OPS-098 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4518 | feature OPS-099 name present | pass | o28-stage2-final-inventory.log |
| 4519 | feature OPS-099 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4520 | feature OPS-099 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4521 | feature OPS-099 test area assigned | pass | o28-stage2-final-inventory.log |
| 4522 | feature OPS-099 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4523 | feature OPS-100 name present | pass | o28-stage2-final-inventory.log |
| 4524 | feature OPS-100 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4525 | feature OPS-100 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4526 | feature OPS-100 test area assigned | pass | o28-stage2-final-inventory.log |
| 4527 | feature OPS-100 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4528 | feature OPS-101 name present | pass | o28-stage2-final-inventory.log |
| 4529 | feature OPS-101 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4530 | feature OPS-101 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4531 | feature OPS-101 test area assigned | pass | o28-stage2-final-inventory.log |
| 4532 | feature OPS-101 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4533 | feature OPS-102 name present | pass | o28-stage2-final-inventory.log |
| 4534 | feature OPS-102 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4535 | feature OPS-102 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4536 | feature OPS-102 test area assigned | pass | o28-stage2-final-inventory.log |
| 4537 | feature OPS-102 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4538 | feature OPS-103 name present | pass | o28-stage2-final-inventory.log |
| 4539 | feature OPS-103 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4540 | feature OPS-103 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4541 | feature OPS-103 test area assigned | pass | o28-stage2-final-inventory.log |
| 4542 | feature OPS-103 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4543 | feature OPS-104 name present | pass | o28-stage2-final-inventory.log |
| 4544 | feature OPS-104 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4545 | feature OPS-104 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4546 | feature OPS-104 test area assigned | pass | o28-stage2-final-inventory.log |
| 4547 | feature OPS-104 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4548 | feature OPS-105 name present | pass | o28-stage2-final-inventory.log |
| 4549 | feature OPS-105 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4550 | feature OPS-105 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4551 | feature OPS-105 test area assigned | pass | o28-stage2-final-inventory.log |
| 4552 | feature OPS-105 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4553 | feature OPS-106 name present | pass | o28-stage2-final-inventory.log |
| 4554 | feature OPS-106 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4555 | feature OPS-106 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4556 | feature OPS-106 test area assigned | pass | o28-stage2-final-inventory.log |
| 4557 | feature OPS-106 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4558 | feature OPS-107 name present | pass | o28-stage2-final-inventory.log |
| 4559 | feature OPS-107 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4560 | feature OPS-107 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4561 | feature OPS-107 test area assigned | pass | o28-stage2-final-inventory.log |
| 4562 | feature OPS-107 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4563 | feature OPS-108 name present | pass | o28-stage2-final-inventory.log |
| 4564 | feature OPS-108 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4565 | feature OPS-108 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4566 | feature OPS-108 test area assigned | pass | o28-stage2-final-inventory.log |
| 4567 | feature OPS-108 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4568 | feature OPS-109 name present | pass | o28-stage2-final-inventory.log |
| 4569 | feature OPS-109 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4570 | feature OPS-109 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4571 | feature OPS-109 test area assigned | pass | o28-stage2-final-inventory.log |
| 4572 | feature OPS-109 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4573 | feature OPS-110 name present | pass | o28-stage2-final-inventory.log |
| 4574 | feature OPS-110 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4575 | feature OPS-110 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4576 | feature OPS-110 test area assigned | pass | o28-stage2-final-inventory.log |
| 4577 | feature OPS-110 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4578 | feature OPS-111 name present | pass | o28-stage2-final-inventory.log |
| 4579 | feature OPS-111 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4580 | feature OPS-111 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4581 | feature OPS-111 test area assigned | pass | o28-stage2-final-inventory.log |
| 4582 | feature OPS-111 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4583 | feature OPS-112 name present | pass | o28-stage2-final-inventory.log |
| 4584 | feature OPS-112 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4585 | feature OPS-112 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4586 | feature OPS-112 test area assigned | pass | o28-stage2-final-inventory.log |
| 4587 | feature OPS-112 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4588 | feature OPS-113 name present | pass | o28-stage2-final-inventory.log |
| 4589 | feature OPS-113 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4590 | feature OPS-113 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4591 | feature OPS-113 test area assigned | pass | o28-stage2-final-inventory.log |
| 4592 | feature OPS-113 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4593 | feature OPS-114 name present | pass | o28-stage2-final-inventory.log |
| 4594 | feature OPS-114 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4595 | feature OPS-114 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4596 | feature OPS-114 test area assigned | pass | o28-stage2-final-inventory.log |
| 4597 | feature OPS-114 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4598 | feature OPS-115 name present | pass | o28-stage2-final-inventory.log |
| 4599 | feature OPS-115 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4600 | feature OPS-115 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4601 | feature OPS-115 test area assigned | pass | o28-stage2-final-inventory.log |
| 4602 | feature OPS-115 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4603 | feature OPS-116 name present | pass | o28-stage2-final-inventory.log |
| 4604 | feature OPS-116 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4605 | feature OPS-116 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4606 | feature OPS-116 test area assigned | pass | o28-stage2-final-inventory.log |
| 4607 | feature OPS-116 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4608 | feature OPS-117 name present | pass | o28-stage2-final-inventory.log |
| 4609 | feature OPS-117 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4610 | feature OPS-117 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4611 | feature OPS-117 test area assigned | pass | o28-stage2-final-inventory.log |
| 4612 | feature OPS-117 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4613 | feature OPS-118 name present | pass | o28-stage2-final-inventory.log |
| 4614 | feature OPS-118 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4615 | feature OPS-118 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4616 | feature OPS-118 test area assigned | pass | o28-stage2-final-inventory.log |
| 4617 | feature OPS-118 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4618 | feature OPS-119 name present | pass | o28-stage2-final-inventory.log |
| 4619 | feature OPS-119 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4620 | feature OPS-119 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4621 | feature OPS-119 test area assigned | pass | o28-stage2-final-inventory.log |
| 4622 | feature OPS-119 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4623 | feature OPS-120 name present | pass | o28-stage2-final-inventory.log |
| 4624 | feature OPS-120 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4625 | feature OPS-120 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4626 | feature OPS-120 test area assigned | pass | o28-stage2-final-inventory.log |
| 4627 | feature OPS-120 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4628 | feature OPS-121 name present | pass | o28-stage2-final-inventory.log |
| 4629 | feature OPS-121 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4630 | feature OPS-121 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4631 | feature OPS-121 test area assigned | pass | o28-stage2-final-inventory.log |
| 4632 | feature OPS-121 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4633 | feature OPS-122 name present | pass | o28-stage2-final-inventory.log |
| 4634 | feature OPS-122 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4635 | feature OPS-122 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4636 | feature OPS-122 test area assigned | pass | o28-stage2-final-inventory.log |
| 4637 | feature OPS-122 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4638 | feature OPS-123 name present | pass | o28-stage2-final-inventory.log |
| 4639 | feature OPS-123 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4640 | feature OPS-123 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4641 | feature OPS-123 test area assigned | pass | o28-stage2-final-inventory.log |
| 4642 | feature OPS-123 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4643 | feature OPS-124 name present | pass | o28-stage2-final-inventory.log |
| 4644 | feature OPS-124 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4645 | feature OPS-124 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4646 | feature OPS-124 test area assigned | pass | o28-stage2-final-inventory.log |
| 4647 | feature OPS-124 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4648 | feature OPS-125 name present | pass | o28-stage2-final-inventory.log |
| 4649 | feature OPS-125 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4650 | feature OPS-125 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4651 | feature OPS-125 test area assigned | pass | o28-stage2-final-inventory.log |
| 4652 | feature OPS-125 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4653 | feature OPS-126 name present | pass | o28-stage2-final-inventory.log |
| 4654 | feature OPS-126 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4655 | feature OPS-126 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4656 | feature OPS-126 test area assigned | pass | o28-stage2-final-inventory.log |
| 4657 | feature OPS-126 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4658 | feature OPS-127 name present | pass | o28-stage2-final-inventory.log |
| 4659 | feature OPS-127 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4660 | feature OPS-127 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4661 | feature OPS-127 test area assigned | pass | o28-stage2-final-inventory.log |
| 4662 | feature OPS-127 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4663 | feature OPS-128 name present | pass | o28-stage2-final-inventory.log |
| 4664 | feature OPS-128 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4665 | feature OPS-128 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4666 | feature OPS-128 test area assigned | pass | o28-stage2-final-inventory.log |
| 4667 | feature OPS-128 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4668 | feature OPS-129 name present | pass | o28-stage2-final-inventory.log |
| 4669 | feature OPS-129 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4670 | feature OPS-129 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4671 | feature OPS-129 test area assigned | pass | o28-stage2-final-inventory.log |
| 4672 | feature OPS-129 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4673 | feature OPS-130 name present | pass | o28-stage2-final-inventory.log |
| 4674 | feature OPS-130 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4675 | feature OPS-130 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4676 | feature OPS-130 test area assigned | pass | o28-stage2-final-inventory.log |
| 4677 | feature OPS-130 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4678 | feature OPS-131 name present | pass | o28-stage2-final-inventory.log |
| 4679 | feature OPS-131 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4680 | feature OPS-131 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4681 | feature OPS-131 test area assigned | pass | o28-stage2-final-inventory.log |
| 4682 | feature OPS-131 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4683 | feature OPS-132 name present | pass | o28-stage2-final-inventory.log |
| 4684 | feature OPS-132 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4685 | feature OPS-132 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4686 | feature OPS-132 test area assigned | pass | o28-stage2-final-inventory.log |
| 4687 | feature OPS-132 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4688 | feature OPS-133 name present | pass | o28-stage2-final-inventory.log |
| 4689 | feature OPS-133 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4690 | feature OPS-133 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4691 | feature OPS-133 test area assigned | pass | o28-stage2-final-inventory.log |
| 4692 | feature OPS-133 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4693 | feature OPS-134 name present | pass | o28-stage2-final-inventory.log |
| 4694 | feature OPS-134 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4695 | feature OPS-134 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4696 | feature OPS-134 test area assigned | pass | o28-stage2-final-inventory.log |
| 4697 | feature OPS-134 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4698 | feature OPS-135 name present | pass | o28-stage2-final-inventory.log |
| 4699 | feature OPS-135 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4700 | feature OPS-135 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4701 | feature OPS-135 test area assigned | pass | o28-stage2-final-inventory.log |
| 4702 | feature OPS-135 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4703 | feature OPS-136 name present | pass | o28-stage2-final-inventory.log |
| 4704 | feature OPS-136 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4705 | feature OPS-136 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4706 | feature OPS-136 test area assigned | pass | o28-stage2-final-inventory.log |
| 4707 | feature OPS-136 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4708 | feature OPS-137 name present | pass | o28-stage2-final-inventory.log |
| 4709 | feature OPS-137 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4710 | feature OPS-137 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4711 | feature OPS-137 test area assigned | pass | o28-stage2-final-inventory.log |
| 4712 | feature OPS-137 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4713 | feature OPS-138 name present | pass | o28-stage2-final-inventory.log |
| 4714 | feature OPS-138 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4715 | feature OPS-138 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4716 | feature OPS-138 test area assigned | pass | o28-stage2-final-inventory.log |
| 4717 | feature OPS-138 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4718 | feature OPS-139 name present | pass | o28-stage2-final-inventory.log |
| 4719 | feature OPS-139 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4720 | feature OPS-139 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4721 | feature OPS-139 test area assigned | pass | o28-stage2-final-inventory.log |
| 4722 | feature OPS-139 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4723 | feature OPS-140 name present | pass | o28-stage2-final-inventory.log |
| 4724 | feature OPS-140 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4725 | feature OPS-140 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4726 | feature OPS-140 test area assigned | pass | o28-stage2-final-inventory.log |
| 4727 | feature OPS-140 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4728 | feature OPS-141 name present | pass | o28-stage2-final-inventory.log |
| 4729 | feature OPS-141 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4730 | feature OPS-141 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4731 | feature OPS-141 test area assigned | pass | o28-stage2-final-inventory.log |
| 4732 | feature OPS-141 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4733 | feature OPS-142 name present | pass | o28-stage2-final-inventory.log |
| 4734 | feature OPS-142 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4735 | feature OPS-142 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4736 | feature OPS-142 test area assigned | pass | o28-stage2-final-inventory.log |
| 4737 | feature OPS-142 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4738 | feature OPS-143 name present | pass | o28-stage2-final-inventory.log |
| 4739 | feature OPS-143 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4740 | feature OPS-143 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4741 | feature OPS-143 test area assigned | pass | o28-stage2-final-inventory.log |
| 4742 | feature OPS-143 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4743 | feature OPS-144 name present | pass | o28-stage2-final-inventory.log |
| 4744 | feature OPS-144 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4745 | feature OPS-144 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4746 | feature OPS-144 test area assigned | pass | o28-stage2-final-inventory.log |
| 4747 | feature OPS-144 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4748 | feature OPS-145 name present | pass | o28-stage2-final-inventory.log |
| 4749 | feature OPS-145 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4750 | feature OPS-145 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4751 | feature OPS-145 test area assigned | pass | o28-stage2-final-inventory.log |
| 4752 | feature OPS-145 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4753 | feature OPS-146 name present | pass | o28-stage2-final-inventory.log |
| 4754 | feature OPS-146 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4755 | feature OPS-146 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4756 | feature OPS-146 test area assigned | pass | o28-stage2-final-inventory.log |
| 4757 | feature OPS-146 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4758 | feature OPS-147 name present | pass | o28-stage2-final-inventory.log |
| 4759 | feature OPS-147 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4760 | feature OPS-147 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4761 | feature OPS-147 test area assigned | pass | o28-stage2-final-inventory.log |
| 4762 | feature OPS-147 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4763 | feature OPS-148 name present | pass | o28-stage2-final-inventory.log |
| 4764 | feature OPS-148 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4765 | feature OPS-148 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4766 | feature OPS-148 test area assigned | pass | o28-stage2-final-inventory.log |
| 4767 | feature OPS-148 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4768 | feature OPS-149 name present | pass | o28-stage2-final-inventory.log |
| 4769 | feature OPS-149 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4770 | feature OPS-149 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4771 | feature OPS-149 test area assigned | pass | o28-stage2-final-inventory.log |
| 4772 | feature OPS-149 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4773 | feature OPS-150 name present | pass | o28-stage2-final-inventory.log |
| 4774 | feature OPS-150 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4775 | feature OPS-150 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4776 | feature OPS-150 test area assigned | pass | o28-stage2-final-inventory.log |
| 4777 | feature OPS-150 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4778 | feature OPS-151 name present | pass | o28-stage2-final-inventory.log |
| 4779 | feature OPS-151 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4780 | feature OPS-151 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4781 | feature OPS-151 test area assigned | pass | o28-stage2-final-inventory.log |
| 4782 | feature OPS-151 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4783 | feature OPS-152 name present | pass | o28-stage2-final-inventory.log |
| 4784 | feature OPS-152 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4785 | feature OPS-152 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4786 | feature OPS-152 test area assigned | pass | o28-stage2-final-inventory.log |
| 4787 | feature OPS-152 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4788 | feature OPS-153 name present | pass | o28-stage2-final-inventory.log |
| 4789 | feature OPS-153 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4790 | feature OPS-153 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4791 | feature OPS-153 test area assigned | pass | o28-stage2-final-inventory.log |
| 4792 | feature OPS-153 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4793 | feature OPS-154 name present | pass | o28-stage2-final-inventory.log |
| 4794 | feature OPS-154 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4795 | feature OPS-154 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4796 | feature OPS-154 test area assigned | pass | o28-stage2-final-inventory.log |
| 4797 | feature OPS-154 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4798 | feature OPS-155 name present | pass | o28-stage2-final-inventory.log |
| 4799 | feature OPS-155 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4800 | feature OPS-155 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4801 | feature OPS-155 test area assigned | pass | o28-stage2-final-inventory.log |
| 4802 | feature OPS-155 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4803 | feature OPS-156 name present | pass | o28-stage2-final-inventory.log |
| 4804 | feature OPS-156 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4805 | feature OPS-156 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4806 | feature OPS-156 test area assigned | pass | o28-stage2-final-inventory.log |
| 4807 | feature OPS-156 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4808 | feature OPS-157 name present | pass | o28-stage2-final-inventory.log |
| 4809 | feature OPS-157 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4810 | feature OPS-157 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4811 | feature OPS-157 test area assigned | pass | o28-stage2-final-inventory.log |
| 4812 | feature OPS-157 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4813 | feature OPS-158 name present | pass | o28-stage2-final-inventory.log |
| 4814 | feature OPS-158 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4815 | feature OPS-158 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4816 | feature OPS-158 test area assigned | pass | o28-stage2-final-inventory.log |
| 4817 | feature OPS-158 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4818 | feature OPS-159 name present | pass | o28-stage2-final-inventory.log |
| 4819 | feature OPS-159 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4820 | feature OPS-159 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4821 | feature OPS-159 test area assigned | pass | o28-stage2-final-inventory.log |
| 4822 | feature OPS-159 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4823 | feature OPS-160 name present | pass | o28-stage2-final-inventory.log |
| 4824 | feature OPS-160 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4825 | feature OPS-160 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4826 | feature OPS-160 test area assigned | pass | o28-stage2-final-inventory.log |
| 4827 | feature OPS-160 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4828 | feature OPS-161 name present | pass | o28-stage2-final-inventory.log |
| 4829 | feature OPS-161 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4830 | feature OPS-161 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4831 | feature OPS-161 test area assigned | pass | o28-stage2-final-inventory.log |
| 4832 | feature OPS-161 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4833 | feature OPS-162 name present | pass | o28-stage2-final-inventory.log |
| 4834 | feature OPS-162 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4835 | feature OPS-162 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4836 | feature OPS-162 test area assigned | pass | o28-stage2-final-inventory.log |
| 4837 | feature OPS-162 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4838 | feature OPS-163 name present | pass | o28-stage2-final-inventory.log |
| 4839 | feature OPS-163 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4840 | feature OPS-163 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4841 | feature OPS-163 test area assigned | pass | o28-stage2-final-inventory.log |
| 4842 | feature OPS-163 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4843 | feature OPS-164 name present | pass | o28-stage2-final-inventory.log |
| 4844 | feature OPS-164 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4845 | feature OPS-164 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4846 | feature OPS-164 test area assigned | pass | o28-stage2-final-inventory.log |
| 4847 | feature OPS-164 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4848 | feature OPS-165 name present | pass | o28-stage2-final-inventory.log |
| 4849 | feature OPS-165 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4850 | feature OPS-165 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4851 | feature OPS-165 test area assigned | pass | o28-stage2-final-inventory.log |
| 4852 | feature OPS-165 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4853 | feature OPS-166 name present | pass | o28-stage2-final-inventory.log |
| 4854 | feature OPS-166 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4855 | feature OPS-166 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4856 | feature OPS-166 test area assigned | pass | o28-stage2-final-inventory.log |
| 4857 | feature OPS-166 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4858 | feature OPS-167 name present | pass | o28-stage2-final-inventory.log |
| 4859 | feature OPS-167 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4860 | feature OPS-167 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4861 | feature OPS-167 test area assigned | pass | o28-stage2-final-inventory.log |
| 4862 | feature OPS-167 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4863 | feature OPS-168 name present | pass | o28-stage2-final-inventory.log |
| 4864 | feature OPS-168 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4865 | feature OPS-168 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4866 | feature OPS-168 test area assigned | pass | o28-stage2-final-inventory.log |
| 4867 | feature OPS-168 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4868 | feature OPS-169 name present | pass | o28-stage2-final-inventory.log |
| 4869 | feature OPS-169 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4870 | feature OPS-169 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4871 | feature OPS-169 test area assigned | pass | o28-stage2-final-inventory.log |
| 4872 | feature OPS-169 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4873 | feature OPS-170 name present | pass | o28-stage2-final-inventory.log |
| 4874 | feature OPS-170 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4875 | feature OPS-170 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4876 | feature OPS-170 test area assigned | pass | o28-stage2-final-inventory.log |
| 4877 | feature OPS-170 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4878 | feature OPS-171 name present | pass | o28-stage2-final-inventory.log |
| 4879 | feature OPS-171 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4880 | feature OPS-171 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4881 | feature OPS-171 test area assigned | pass | o28-stage2-final-inventory.log |
| 4882 | feature OPS-171 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4883 | feature OPS-172 name present | pass | o28-stage2-final-inventory.log |
| 4884 | feature OPS-172 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4885 | feature OPS-172 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4886 | feature OPS-172 test area assigned | pass | o28-stage2-final-inventory.log |
| 4887 | feature OPS-172 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4888 | feature OPS-173 name present | pass | o28-stage2-final-inventory.log |
| 4889 | feature OPS-173 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4890 | feature OPS-173 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4891 | feature OPS-173 test area assigned | pass | o28-stage2-final-inventory.log |
| 4892 | feature OPS-173 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4893 | feature OPS-174 name present | pass | o28-stage2-final-inventory.log |
| 4894 | feature OPS-174 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4895 | feature OPS-174 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4896 | feature OPS-174 test area assigned | pass | o28-stage2-final-inventory.log |
| 4897 | feature OPS-174 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4898 | feature OPS-175 name present | pass | o28-stage2-final-inventory.log |
| 4899 | feature OPS-175 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4900 | feature OPS-175 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4901 | feature OPS-175 test area assigned | pass | o28-stage2-final-inventory.log |
| 4902 | feature OPS-175 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4903 | feature OPS-176 name present | pass | o28-stage2-final-inventory.log |
| 4904 | feature OPS-176 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4905 | feature OPS-176 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4906 | feature OPS-176 test area assigned | pass | o28-stage2-final-inventory.log |
| 4907 | feature OPS-176 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4908 | feature OPS-177 name present | pass | o28-stage2-final-inventory.log |
| 4909 | feature OPS-177 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4910 | feature OPS-177 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4911 | feature OPS-177 test area assigned | pass | o28-stage2-final-inventory.log |
| 4912 | feature OPS-177 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4913 | feature OPS-178 name present | pass | o28-stage2-final-inventory.log |
| 4914 | feature OPS-178 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4915 | feature OPS-178 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4916 | feature OPS-178 test area assigned | pass | o28-stage2-final-inventory.log |
| 4917 | feature OPS-178 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4918 | feature OPS-179 name present | pass | o28-stage2-final-inventory.log |
| 4919 | feature OPS-179 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4920 | feature OPS-179 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4921 | feature OPS-179 test area assigned | pass | o28-stage2-final-inventory.log |
| 4922 | feature OPS-179 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4923 | feature OPS-180 name present | pass | o28-stage2-final-inventory.log |
| 4924 | feature OPS-180 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4925 | feature OPS-180 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4926 | feature OPS-180 test area assigned | pass | o28-stage2-final-inventory.log |
| 4927 | feature OPS-180 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4928 | feature OPS-181 name present | pass | o28-stage2-final-inventory.log |
| 4929 | feature OPS-181 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4930 | feature OPS-181 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4931 | feature OPS-181 test area assigned | pass | o28-stage2-final-inventory.log |
| 4932 | feature OPS-181 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4933 | feature OPS-182 name present | pass | o28-stage2-final-inventory.log |
| 4934 | feature OPS-182 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4935 | feature OPS-182 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4936 | feature OPS-182 test area assigned | pass | o28-stage2-final-inventory.log |
| 4937 | feature OPS-182 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4938 | feature OPS-183 name present | pass | o28-stage2-final-inventory.log |
| 4939 | feature OPS-183 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4940 | feature OPS-183 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4941 | feature OPS-183 test area assigned | pass | o28-stage2-final-inventory.log |
| 4942 | feature OPS-183 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4943 | feature OPS-184 name present | pass | o28-stage2-final-inventory.log |
| 4944 | feature OPS-184 UI need 비대상 | pass | o28-stage2-final-inventory.log |
| 4945 | feature OPS-184 test need 필요 | pass | o28-stage2-final-inventory.log |
| 4946 | feature OPS-184 test area assigned | pass | o28-stage2-final-inventory.log |
| 4947 | feature OPS-184 pass criteria present | pass | o28-stage2-final-inventory.log |
| 4948 | feature rows have required matrix columns | pass | o28-stage2-final-inventory.log |
| 4949 | inventory rejects separate test-area labels | pass | o28-stage2-final-inventory.log |
| 4950 | coverage wording separates mapping from execution | pass | o28-stage2-final-inventory.log |
| 4951 | current feature expansion rows exist | pass | o28-stage2-final-inventory.log |
| 4952 | manual UI docs reference inventory | pass | o28-stage2-final-inventory.log |
| 4953 | manual checklist references seed fixture | pass | o28-stage2-final-inventory.log |
| 4954 | manual result template references seed fixture | pass | o28-stage2-final-inventory.log |
| 4955 | VA seed inventory commands select the latest published baseline explicitly | pass | o28-stage2-final-inventory.log |
| 4956 | AGENTS requires individual future feature test rows | pass | o28-stage2-final-inventory.log |
| 4957 | manual UI seed account role admin | pass | o28-stage2-final-inventory.log |
| 4958 | manual UI seed account role operator | pass | o28-stage2-final-inventory.log |
| 4959 | manual UI seed account role viewer | pass | o28-stage2-final-inventory.log |
| 4960 | manual UI seed account role integrator | pass | o28-stage2-final-inventory.log |
| 4961 | manual UI seed profile 9101 numeric id | pass | o28-stage2-final-inventory.log |
| 4962 | manual UI seed profile 9101 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4963 | manual UI seed profile 9102 numeric id | pass | o28-stage2-final-inventory.log |
| 4964 | manual UI seed profile 9102 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4965 | manual UI seed profile 9103 numeric id | pass | o28-stage2-final-inventory.log |
| 4966 | manual UI seed profile 9103 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4967 | manual UI seed profile 9104 numeric id | pass | o28-stage2-final-inventory.log |
| 4968 | manual UI seed profile 9104 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4969 | manual UI seed profile 9105 numeric id | pass | o28-stage2-final-inventory.log |
| 4970 | manual UI seed profile 9105 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4971 | manual UI seed profile 9106 numeric id | pass | o28-stage2-final-inventory.log |
| 4972 | manual UI seed profile 9106 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4973 | manual UI seed profile 9107 numeric id | pass | o28-stage2-final-inventory.log |
| 4974 | manual UI seed profile 9107 tracking classes present | pass | o28-stage2-final-inventory.log |
| 4975 | manual UI seed event type presence | pass | o28-stage2-final-inventory.log |
| 4976 | manual UI seed event type enter | pass | o28-stage2-final-inventory.log |
| 4977 | manual UI seed event type exit | pass | o28-stage2-final-inventory.log |
| 4978 | manual UI seed event type line-crossing | pass | o28-stage2-final-inventory.log |
| 4979 | manual UI seed event type intrusion-dwell | pass | o28-stage2-final-inventory.log |
| 4980 | manual UI seed event type re-entry | pass | o28-stage2-final-inventory.log |
| 4981 | manual UI seed event type wrong-direction | pass | o28-stage2-final-inventory.log |
| 4982 | manual UI seed event type intrusion-after-line-crossing | pass | o28-stage2-final-inventory.log |
| 4983 | manual UI seed event type loitering | pass | o28-stage2-final-inventory.log |
| 4984 | manual UI seed event type zone-occupancy | pass | o28-stage2-final-inventory.log |
| 4985 | manual UI seed event template 9201 numeric id | pass | o28-stage2-final-inventory.log |
| 4986 | manual UI seed event template 9201 event type presence | pass | o28-stage2-final-inventory.log |
| 4987 | manual UI seed event template 9201 profile reference | pass | o28-stage2-final-inventory.log |
| 4988 | manual UI seed event template 9202 numeric id | pass | o28-stage2-final-inventory.log |
| 4989 | manual UI seed event template 9202 event type enter | pass | o28-stage2-final-inventory.log |
| 4990 | manual UI seed event template 9202 profile reference | pass | o28-stage2-final-inventory.log |
| 4991 | manual UI seed event template 9203 numeric id | pass | o28-stage2-final-inventory.log |
| 4992 | manual UI seed event template 9203 event type exit | pass | o28-stage2-final-inventory.log |
| 4993 | manual UI seed event template 9203 profile reference | pass | o28-stage2-final-inventory.log |
| 4994 | manual UI seed event template 9204 numeric id | pass | o28-stage2-final-inventory.log |
| 4995 | manual UI seed event template 9204 event type line-crossing | pass | o28-stage2-final-inventory.log |
| 4996 | manual UI seed event template 9204 profile reference | pass | o28-stage2-final-inventory.log |
| 4997 | manual UI seed event template 9205 numeric id | pass | o28-stage2-final-inventory.log |
| 4998 | manual UI seed event template 9205 event type line-crossing | pass | o28-stage2-final-inventory.log |
| 4999 | manual UI seed event template 9205 profile reference | pass | o28-stage2-final-inventory.log |
| 5000 | manual UI seed event template 9206 numeric id | pass | o28-stage2-final-inventory.log |
| 5001 | manual UI seed event template 9206 event type line-crossing | pass | o28-stage2-final-inventory.log |
| 5002 | manual UI seed event template 9206 profile reference | pass | o28-stage2-final-inventory.log |
| 5003 | manual UI seed event template 9207 numeric id | pass | o28-stage2-final-inventory.log |
| 5004 | manual UI seed event template 9207 event type intrusion-dwell | pass | o28-stage2-final-inventory.log |
| 5005 | manual UI seed event template 9207 profile reference | pass | o28-stage2-final-inventory.log |
| 5006 | manual UI seed event template 9208 numeric id | pass | o28-stage2-final-inventory.log |
| 5007 | manual UI seed event template 9208 event type re-entry | pass | o28-stage2-final-inventory.log |
| 5008 | manual UI seed event template 9208 profile reference | pass | o28-stage2-final-inventory.log |
| 5009 | manual UI seed event template 9209 numeric id | pass | o28-stage2-final-inventory.log |
| 5010 | manual UI seed event template 9209 event type wrong-direction | pass | o28-stage2-final-inventory.log |
| 5011 | manual UI seed event template 9209 profile reference | pass | o28-stage2-final-inventory.log |
| 5012 | manual UI seed event template 9210 numeric id | pass | o28-stage2-final-inventory.log |
| 5013 | manual UI seed event template 9210 event type intrusion-after-line-crossing | pass | o28-stage2-final-inventory.log |
| 5014 | manual UI seed event template 9210 profile reference | pass | o28-stage2-final-inventory.log |
| 5015 | manual UI seed event template 9211 numeric id | pass | o28-stage2-final-inventory.log |
| 5016 | manual UI seed event template 9211 event type loitering | pass | o28-stage2-final-inventory.log |
| 5017 | manual UI seed event template 9211 profile reference | pass | o28-stage2-final-inventory.log |
| 5018 | manual UI seed event template 9212 numeric id | pass | o28-stage2-final-inventory.log |
| 5019 | manual UI seed event template 9212 event type zone-occupancy | pass | o28-stage2-final-inventory.log |
| 5020 | manual UI seed event template 9212 profile reference | pass | o28-stage2-final-inventory.log |
| 5021 | manual UI seed line direction any | pass | o28-stage2-final-inventory.log |
| 5022 | manual UI seed line direction forward | pass | o28-stage2-final-inventory.log |
| 5023 | manual UI seed line direction reverse | pass | o28-stage2-final-inventory.log |
| 5024 | manual UI seed scenario preset default | pass | o28-stage2-final-inventory.log |
| 5025 | manual UI seed scenario preset road | pass | o28-stage2-final-inventory.log |
| 5026 | manual UI seed scenario preset retail | pass | o28-stage2-final-inventory.log |
| 5027 | manual UI seed scenario preset park | pass | o28-stage2-final-inventory.log |
| 5028 | manual UI seed scenario preset indoor | pass | o28-stage2-final-inventory.log |
| 5029 | manual UI seed scenario preset lobby | pass | o28-stage2-final-inventory.log |
| 5030 | manual UI seed scenario preset platform | pass | o28-stage2-final-inventory.log |
| 5031 | manual UI seed scenario preset entrance | pass | o28-stage2-final-inventory.log |
| 5032 | manual UI seed scenario preset doorway | pass | o28-stage2-final-inventory.log |
| 5033 | manual UI seed scenario preset parking | pass | o28-stage2-final-inventory.log |
| 5034 | manual UI seed scenario preset elevator | pass | o28-stage2-final-inventory.log |
| 5035 | manual UI seed scenario preset custom | pass | o28-stage2-final-inventory.log |
| 5036 | manual UI seed vaRule 9301 numeric id | pass | o28-stage2-final-inventory.log |
| 5037 | manual UI seed vaRule 9301 profile reference | pass | o28-stage2-final-inventory.log |
| 5038 | manual UI seed vaRule 9301 event template reference | pass | o28-stage2-final-inventory.log |
| 5039 | manual UI seed vaRule 9302 numeric id | pass | o28-stage2-final-inventory.log |
| 5040 | manual UI seed vaRule 9302 profile reference | pass | o28-stage2-final-inventory.log |
| 5041 | manual UI seed vaRule 9302 event template reference | pass | o28-stage2-final-inventory.log |
| 5042 | manual UI seed vaRule 9303 numeric id | pass | o28-stage2-final-inventory.log |
| 5043 | manual UI seed vaRule 9303 profile reference | pass | o28-stage2-final-inventory.log |
| 5044 | manual UI seed vaRule 9303 event template reference | pass | o28-stage2-final-inventory.log |
| 5045 | manual UI seed vaRule 9304 numeric id | pass | o28-stage2-final-inventory.log |
| 5046 | manual UI seed vaRule 9304 profile reference | pass | o28-stage2-final-inventory.log |
| 5047 | manual UI seed vaRule 9304 event template reference | pass | o28-stage2-final-inventory.log |
| 5048 | manual UI seed vaRule 9305 numeric id | pass | o28-stage2-final-inventory.log |
| 5049 | manual UI seed vaRule 9305 profile reference | pass | o28-stage2-final-inventory.log |
| 5050 | manual UI seed vaRule 9305 event template reference | pass | o28-stage2-final-inventory.log |
| 5051 | manual UI seed vaRule 9306 numeric id | pass | o28-stage2-final-inventory.log |
| 5052 | manual UI seed vaRule 9306 profile reference | pass | o28-stage2-final-inventory.log |
| 5053 | manual UI seed vaRule 9306 event template reference | pass | o28-stage2-final-inventory.log |
| 5054 | manual UI seed vaRule 9307 numeric id | pass | o28-stage2-final-inventory.log |
| 5055 | manual UI seed vaRule 9307 profile reference | pass | o28-stage2-final-inventory.log |
| 5056 | manual UI seed vaRule 9307 event template reference | pass | o28-stage2-final-inventory.log |
| 5057 | manual UI seed vaRule 9308 numeric id | pass | o28-stage2-final-inventory.log |
| 5058 | manual UI seed vaRule 9308 profile reference | pass | o28-stage2-final-inventory.log |
| 5059 | manual UI seed vaRule 9308 event template reference | pass | o28-stage2-final-inventory.log |
| 5060 | manual UI seed vaRule 9309 numeric id | pass | o28-stage2-final-inventory.log |
| 5061 | manual UI seed vaRule 9309 profile reference | pass | o28-stage2-final-inventory.log |
| 5062 | manual UI seed vaRule 9309 event template reference | pass | o28-stage2-final-inventory.log |
| 5063 | manual UI seed vaRule 9310 numeric id | pass | o28-stage2-final-inventory.log |
| 5064 | manual UI seed vaRule 9310 profile reference | pass | o28-stage2-final-inventory.log |
| 5065 | manual UI seed vaRule 9310 event template reference | pass | o28-stage2-final-inventory.log |
| 5066 | manual UI seed vaRule 9311 numeric id | pass | o28-stage2-final-inventory.log |
| 5067 | manual UI seed vaRule 9311 profile reference | pass | o28-stage2-final-inventory.log |
| 5068 | manual UI seed vaRule 9311 event template reference | pass | o28-stage2-final-inventory.log |
| 5069 | manual UI seed vaRule 9312 numeric id | pass | o28-stage2-final-inventory.log |
| 5070 | manual UI seed vaRule 9312 profile reference | pass | o28-stage2-final-inventory.log |
| 5071 | manual UI seed vaRule 9312 event template reference | pass | o28-stage2-final-inventory.log |
| 5072 | manual UI seed tracker Re-ID pair none/off | pass | o28-stage2-final-inventory.log |
| 5073 | manual UI seed tracker Re-ID pair lite/off | pass | o28-stage2-final-inventory.log |
| 5074 | manual UI seed tracker Re-ID pair kalman-lite/off | pass | o28-stage2-final-inventory.log |
| 5075 | manual UI seed tracker Re-ID pair bytetrack/off | pass | o28-stage2-final-inventory.log |
| 5076 | manual UI seed tracker Re-ID pair lite/assist | pass | o28-stage2-final-inventory.log |
| 5077 | manual UI seed tracker Re-ID pair kalman-lite/assist | pass | o28-stage2-final-inventory.log |
| 5078 | manual UI seed tracker Re-ID pair bytetrack/assist | pass | o28-stage2-final-inventory.log |
| 5079 | manual UI seed invalid policy tracker none Re-ID assist | pass | o28-stage2-final-inventory.log |
| 5080 | manual UI seed final state minimum vaRules | pass | o28-stage2-final-inventory.log |
| 5081 | manual UI VA seed matrix covers required current release cases | pass | o28-stage2-final-inventory.log |
## o28-stage2-final-links.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
## o28-stage2-final-syntax.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | node --check scripts/internal/recording_accumulation_run.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 2 | node --check scripts/internal/recording_archive_diagnostic_profile.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 3 | node --check scripts/internal/recording_archive_diagnostic_profile.test.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 4 | node --check scripts/internal/recording_current_longrun_diagnostics.test.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 5 | node --check scripts/internal/recording_current_observer.test.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 6 | node --check scripts/internal/recording_failure_capture.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 7 | bash -n scripts/internal/verify_recording_accumulation_probe.sh exit 0 | pass | o28-stage2-final-syntax.log |
| 8 | node --check scripts/internal/verify_recording_current_longrun.mjs exit 0 | pass | o28-stage2-final-syntax.log |
| 9 | bash -n scripts/internal/verify_recording_current_observer.sh exit 0 | pass | o28-stage2-final-syntax.log |
## o28-stage2-group-escalated-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP17-H11 자식만 남긴 종료를 정상 완료로 오인하지 않음 (158.407125ms) | pass | o28-stage2-group-escalated-20260924.log |
## o28-stage2-longrun-final-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.704541ms) | pass | o28-stage2-longrun-final-20260924.log |
| 2 | LP26-O09-A02 identity·clock·pid 불일치 (0.072375ms) | pass | o28-stage2-longrun-final-20260924.log |
| 3 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.057292ms) | pass | o28-stage2-longrun-final-20260924.log |
| 4 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.304958ms) | pass | o28-stage2-longrun-final-20260924.log |
| 5 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.068875ms) | pass | o28-stage2-longrun-final-20260924.log |
| 6 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.391375ms) | pass | o28-stage2-longrun-final-20260924.log |
| 7 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.159333ms) | pass | o28-stage2-longrun-final-20260924.log |
| 8 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.094541ms) | pass | o28-stage2-longrun-final-20260924.log |
| 9 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.071459ms) | pass | o28-stage2-longrun-final-20260924.log |
| 10 | O28-R04 accumulation runner와 EXIT는 receipt 누락·실패를 삭제하지 않는다 (0.118708ms) | pass | o28-stage2-longrun-final-20260924.log |
## o28-stage2-observer-redgreen1-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | S11-O27-01 retired resource mode rejects before setup | pass | o28-stage2-observer-redgreen1-20260924.log |
| 2 | LP26-O02 final stopped tail must be complete and fully drained | pass | o28-stage2-observer-redgreen1-20260924.log |
| 3 | LP26-O05 initial plus added channels exact disabled on restart | pass | o28-stage2-observer-redgreen1-20260924.log |
| 4 | LP26-O01 actual managed writer fixture | pass | o28-stage2-observer-redgreen1-20260924.log |
| 5 | LP26-O08 physical archive fixture and logical native rows | pass | o28-stage2-observer-redgreen1-20260924.log |
| 6 | LP26-O08 bounded normalization retains count and order under accumulated physical input | pass | o28-stage2-observer-redgreen1-20260924.log |
| 7 | LP26-O08 later invalid row rejects the whole batch result | pass | o28-stage2-observer-redgreen1-20260924.log |
| 8 | LP26-O01 native exact row count and two channel segments | pass | o28-stage2-observer-redgreen1-20260924.log |
| 9 | LP26-O01 compact excludes binding samples source URL and payload | pass | o28-stage2-observer-redgreen1-20260924.log |
| 10 | LP26-O02 actual store read preserves original bytes | pass | o28-stage2-observer-redgreen1-20260924.log |
| 11 | LP26-O05 actual deleted and survivor Catalog recovery twice | pass | o28-stage2-observer-redgreen1-20260924.log |
| 12 | O28-D03 small native snapshot exposes external and internal phases without changing JSON | pass | o28-stage2-observer-redgreen1-20260924.log |
| 13 | O28-R04 actual native two verified copies preserve equal receipts before cleanup | pass | o28-stage2-observer-redgreen1-20260924.log |
| 14 | O28-R03 actual native failure preserves receipt and roots until verified cleanup | pass | o28-stage2-observer-redgreen1-20260924.log |
| 15 | LP26-O01 known envelope segment_finalized | pass | o28-stage2-observer-redgreen1-20260924.log |
| 16 | LP26-O01 known envelope event_link_created | pass | o28-stage2-observer-redgreen1-20260924.log |
| 17 | LP26-O01 known envelope observation_put | pass | o28-stage2-observer-redgreen1-20260924.log |
| 18 | LP26-O01 known envelope observation_v2_put | pass | o28-stage2-observer-redgreen1-20260924.log |
| 19 | LP26-O01 known envelope deletion_requested | pass | o28-stage2-observer-redgreen1-20260924.log |
| 20 | LP26-O01 known envelope deletion_completed | pass | o28-stage2-observer-redgreen1-20260924.log |
| 21 | LP26-O01 known envelope corruption_detected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 22 | LP26-O01 known envelope consumer_reference_put | pass | o28-stage2-observer-redgreen1-20260924.log |
| 23 | LP26-O01 known envelope derived_reference_accepted | pass | o28-stage2-observer-redgreen1-20260924.log |
| 24 | LP26-O01 known envelope referenced_observation_put | pass | o28-stage2-observer-redgreen1-20260924.log |
| 25 | LP26-O01 known envelope derived_job_intent | pass | o28-stage2-observer-redgreen1-20260924.log |
| 26 | LP26-O01 known envelope derived_job_files | pass | o28-stage2-observer-redgreen1-20260924.log |
| 27 | LP26-O01 known envelope derived_job_ready | pass | o28-stage2-observer-redgreen1-20260924.log |
| 28 | LP26-O01 known envelope derived_job_committed | pass | o28-stage2-observer-redgreen1-20260924.log |
| 29 | LP26-O01 known envelope derived_job_complete | pass | o28-stage2-observer-redgreen1-20260924.log |
| 30 | LP26-O01 known envelope derived_job_failed | pass | o28-stage2-observer-redgreen1-20260924.log |
| 31 | LP26-O01 reject unknown | pass | o28-stage2-observer-redgreen1-20260924.log |
| 32 | LP26-O01 reject duplicate-key | pass | o28-stage2-observer-redgreen1-20260924.log |
| 33 | LP26-O01 reject invalid-json | pass | o28-stage2-observer-redgreen1-20260924.log |
| 34 | LP26-O01 reject unsafe-id | pass | o28-stage2-observer-redgreen1-20260924.log |
| 35 | LP26-O01 reject bad-segment | pass | o28-stage2-observer-redgreen1-20260924.log |
| 36 | LP26-O01 reject bad-state | pass | o28-stage2-observer-redgreen1-20260924.log |
| 37 | LP26-O01 reject bad-deleted | pass | o28-stage2-observer-redgreen1-20260924.log |
| 38 | LP26-O02 partial line not consumed | pass | o28-stage2-observer-redgreen1-20260924.log |
| 39 | LP26-O02 partial append consumed once | pass | o28-stage2-observer-redgreen1-20260924.log |
| 40 | LP26-O02 exact checkpoint receipt prefix and suffix | pass | o28-stage2-observer-redgreen1-20260924.log |
| 41 | LP26-O02 checkpoint changed refused | pass | o28-stage2-observer-redgreen1-20260924.log |
| 42 | LP26-O02 checkpoint missing refused | pass | o28-stage2-observer-redgreen1-20260924.log |
| 43 | LP26-O02 truncation latched | pass | o28-stage2-observer-redgreen1-20260924.log |
| 44 | LP26-O02 duplicate mutation rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 45 | LP26-O02 symlink rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 46 | LP26-O02 observer and progress share one total identity budget | pass | o28-stage2-observer-redgreen1-20260924.log |
| 47 | LP26-O02 total byte cap and invalid cap cannot be increased | pass | o28-stage2-observer-redgreen1-20260924.log |
| 48 | LP26-O03 actual native order advances independent of UTC | pass | o28-stage2-observer-redgreen1-20260924.log |
| 49 | LP26-O03 huge order unknown UTC new epoch PTS reset accepted | pass | o28-stage2-observer-redgreen1-20260924.log |
| 50 | LP26-O03 duplicate segment rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 51 | LP26-O03 persistent order regression rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 52 | LP26-O03 completion without pending rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 53 | LP26-O03 pending completed physical target once | pass | o28-stage2-observer-redgreen1-20260924.log |
| 54 | LP26-O03 changed tombstone rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 55 | LP26-O04 stall clock and shortened finish rejected | pass | o28-stage2-observer-redgreen1-20260924.log |
| 56 | LP26-O04 exactly120 argument only | pass | o28-stage2-observer-redgreen1-20260924.log |
| 57 | LP26-O04 monotonic sample independent wallclock | pass | o28-stage2-observer-redgreen1-20260924.log |
| 58 | LP26-O04 pause time cannot satisfy 120 minutes | pass | o28-stage2-observer-redgreen1-20260924.log |
| 59 | LP26-O04 current resources use monotonic not wallclock | pass | o28-stage2-observer-redgreen1-20260924.log |
| 60 | LP26-O04 literal delta gap and insufficient warmup statistics | pass | o28-stage2-observer-redgreen1-20260924.log |
| 61 | LP26-O04 invalid resource rss | pass | o28-stage2-observer-redgreen1-20260924.log |
| 62 | LP26-O04 invalid resource fd | pass | o28-stage2-observer-redgreen1-20260924.log |
| 63 | LP26-O04 invalid resource pid | pass | o28-stage2-observer-redgreen1-20260924.log |
| 64 | LP26-O04 invalid resource identity | pass | o28-stage2-observer-redgreen1-20260924.log |
| 65 | LP26-O04 invalid resource counter | pass | o28-stage2-observer-redgreen1-20260924.log |
| 66 | LP26-O04 invalid resource clock | pass | o28-stage2-observer-redgreen1-20260924.log |
| 67 | LP26-O05 current public dispatch avoids legacy longrun prelude | pass | o28-stage2-observer-redgreen1-20260924.log |
## o28-stage2-profile-red1-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.70375ms) | pass | o28-stage2-profile-red1-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.145875ms) | pass | o28-stage2-profile-red1-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (8.653583ms) | pass | o28-stage2-profile-red1-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.28025ms) | pass | o28-stage2-profile-red1-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.158ms) | pass | o28-stage2-profile-red1-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (25.207875ms) | pass | o28-stage2-profile-red1-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (7.73125ms) | pass | o28-stage2-profile-red1-20260924.log |
| 8 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.080875ms) | pass | o28-stage2-profile-red1-20260924.log |
| 9 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.850708ms) | pass | o28-stage2-profile-red1-20260924.log |
| 10 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.630917ms) | pass | o28-stage2-profile-red1-20260924.log |
| 11 | LP23-DH05 changed original or unconfirmed child blocks cleanup (0.825209ms) | pass | o28-stage2-profile-red1-20260924.log |
| 12 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (610.488209ms) | pass | o28-stage2-profile-red1-20260924.log |
## o28-stage2-pure-green3-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.778125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.141667ms) | pass | o28-stage2-pure-green3-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (14.696542ms) | pass | o28-stage2-pure-green3-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.298666ms) | pass | o28-stage2-pure-green3-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.159959ms) | pass | o28-stage2-pure-green3-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (51.245666ms) | pass | o28-stage2-pure-green3-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (16.466875ms) | pass | o28-stage2-pure-green3-20260924.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (22.035917ms) | pass | o28-stage2-pure-green3-20260924.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (8.872542ms) | pass | o28-stage2-pure-green3-20260924.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (35.245ms) | pass | o28-stage2-pure-green3-20260924.log |
| 11 | O28-R04 accumulation receipt도 case·manifest·group 종료를 결속 (21.769333ms) | pass | o28-stage2-pure-green3-20260924.log |
| 12 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (18.261125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 13 | LP23-DH05 changed original or unconfirmed child blocks cleanup (8.401084ms) | pass | o28-stage2-pure-green3-20260924.log |
| 14 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (322.754083ms) | pass | o28-stage2-pure-green3-20260924.log |
| 15 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.868834ms) | pass | o28-stage2-pure-green3-20260924.log |
| 16 | LP26-O09-A02 identity·clock·pid 불일치 (0.085125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 17 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.289792ms) | pass | o28-stage2-pure-green3-20260924.log |
| 18 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.256292ms) | pass | o28-stage2-pure-green3-20260924.log |
| 19 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.066958ms) | pass | o28-stage2-pure-green3-20260924.log |
| 20 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.229208ms) | pass | o28-stage2-pure-green3-20260924.log |
| 21 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (0.138875ms) | pass | o28-stage2-pure-green3-20260924.log |
| 22 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.092708ms) | pass | o28-stage2-pure-green3-20260924.log |
| 23 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.071291ms) | pass | o28-stage2-pure-green3-20260924.log |
| 24 | O28-R04 accumulation runner와 EXIT는 receipt 누락·실패를 삭제하지 않는다 (0.117959ms) | pass | o28-stage2-pure-green3-20260924.log |
| 25 | LP12-F04 input framing 고정 오류만 안전 집계 (0.739083ms) | pass | o28-stage2-pure-green3-20260924.log |
| 26 | LP12-C07 exact phase/code와 unknown 고정 조합만 수집 (0.116041ms) | pass | o28-stage2-pure-green3-20260924.log |
| 27 | LP12-D06 writer fixed 사유만 집계하고 원문을 보존하지 않음 (0.316458ms) | pass | o28-stage2-pure-green3-20260924.log |
| 28 | LP08-B01 완료 작업 안전 증거 선보존 (14.639792ms) | pass | o28-stage2-pure-green3-20260924.log |
| 29 | LP08-B02 field 증거 실패 시 정리 차단 (0.514125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 30 | LP08-B02 enum 증거 실패 시 정리 차단 (0.280208ms) | pass | o28-stage2-pure-green3-20260924.log |
| 31 | LP08-B02 range 증거 실패 시 정리 차단 (0.246208ms) | pass | o28-stage2-pure-green3-20260924.log |
| 32 | LP08-B02 throw 증거 실패 시 정리 차단 (0.244833ms) | pass | o28-stage2-pure-green3-20260924.log |
| 33 | LP08-B02 timeout 증거 실패 시 정리 차단 (0.226167ms) | pass | o28-stage2-pure-green3-20260924.log |
| 34 | LP08-B02 existing 증거 실패 시 정리 차단 (5.167708ms) | pass | o28-stage2-pure-green3-20260924.log |
| 35 | LP08-B02 symlink 증거 실패 시 정리 차단 (15.631417ms) | pass | o28-stage2-pure-green3-20260924.log |
| 36 | LP12-D02 missing binding valid (34.25275ms) | pass | o28-stage2-pure-green3-20260924.log |
| 37 | LP12-D02 missing binding binding-valid (8.7105ms) | pass | o28-stage2-pure-green3-20260924.log |
| 38 | LP12-D02 missing binding proof-present (11.209625ms) | pass | o28-stage2-pure-green3-20260924.log |
| 39 | LP12-D02 missing binding binding-hash (14.024666ms) | pass | o28-stage2-pure-green3-20260924.log |
| 40 | LP12-D02 missing binding matches (8.991583ms) | pass | o28-stage2-pure-green3-20260924.log |
| 41 | LP12-D04 cap-exceeded count 미확인 보존 (34.961417ms) | pass | o28-stage2-pure-green3-20260924.log |
| 42 | LP12-D04 unavailable count 미확인 보존 (30.980583ms) | pass | o28-stage2-pure-green3-20260924.log |
| 43 | LP12-D05 catalog schema raw 변조 거부 (9.015792ms) | pass | o28-stage2-pure-green3-20260924.log |
| 44 | LP12-D05 catalog schema profile 변조 거부 (8.902917ms) | pass | o28-stage2-pure-green3-20260924.log |
| 45 | LP12-D05 catalog schema scope 변조 거부 (6.849125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 46 | LP12-D05 catalog schema id 변조 거부 (9.1815ms) | pass | o28-stage2-pure-green3-20260924.log |
| 47 | LP12-D05 catalog schema validity 변조 거부 (9.258625ms) | pass | o28-stage2-pure-green3-20260924.log |
| 48 | LP12-D05 catalog schema lifecycle 변조 거부 (7.646916ms) | pass | o28-stage2-pure-green3-20260924.log |
| 49 | LP12-D05 catalog schema count 변조 거부 (7.782375ms) | pass | o28-stage2-pure-green3-20260924.log |
| 50 | LP12-D05 catalog schema cap 변조 거부 (7.940958ms) | pass | o28-stage2-pure-green3-20260924.log |
| 51 | LP12-D05 catalog schema truncated 변조 거부 (7.012667ms) | pass | o28-stage2-pure-green3-20260924.log |
| 52 | LP12-D06 newline 없는 fixed prefix tail은 known 인정 금지 (0.097083ms) | pass | o28-stage2-pure-green3-20260924.log |
| 53 | LP12-D06 line/count cap 및 다음 정상행 복구 (1.42625ms) | pass | o28-stage2-pure-green3-20260924.log |
| 54 | LP13-P04 expected reference missing 거부 (0.349792ms) | pass | o28-stage2-pure-green3-20260924.log |
| 55 | LP13-P04 expected reference mismatch 거부 (0.250084ms) | pass | o28-stage2-pure-green3-20260924.log |
| 56 | LP13-P04 expected reference invalid 거부 (0.214625ms) | pass | o28-stage2-pure-green3-20260924.log |
| 57 | LP13-P01 generic absent HTTP 실패 증거 보존 (8.660541ms) | pass | o28-stage2-pure-green3-20260924.log |
| 58 | LP13-P01 generic intent HTTP 실패 증거 보존 (7.8835ms) | pass | o28-stage2-pure-green3-20260924.log |
| 59 | LP13-P01 generic ready HTTP 실패 증거 보존 (7.982ms) | pass | o28-stage2-pure-green3-20260924.log |
| 60 | LP13-P01 generic committed HTTP 실패 증거 보존 (8.03375ms) | pass | o28-stage2-pure-green3-20260924.log |
| 61 | LP13-P01 generic complete HTTP 실패 증거 보존 (7.905584ms) | pass | o28-stage2-pure-green3-20260924.log |
| 62 | LP13-P01 generic failed HTTP 실패 증거 보존 (6.973166ms) | pass | o28-stage2-pure-green3-20260924.log |
| 63 | LP13-P01 generic field 실패 시 cleanup 차단 (0.329125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 64 | LP13-P01 generic state 실패 시 cleanup 차단 (0.2145ms) | pass | o28-stage2-pure-green3-20260924.log |
| 65 | LP13-P01 generic count 실패 시 cleanup 차단 (0.204791ms) | pass | o28-stage2-pure-green3-20260924.log |
| 66 | LP13-P01 generic hash 실패 시 cleanup 차단 (0.195666ms) | pass | o28-stage2-pure-green3-20260924.log |
| 67 | LP13-P01 generic absent 실패 시 cleanup 차단 (0.193709ms) | pass | o28-stage2-pure-green3-20260924.log |
| 68 | LP13-P01 generic throw 실패 시 cleanup 차단 (0.180333ms) | pass | o28-stage2-pure-green3-20260924.log |
| 69 | LP13-P01 generic timeout 실패 시 cleanup 차단 (0.168959ms) | pass | o28-stage2-pure-green3-20260924.log |
| 70 | LP13-P01 generic persist 실패 시 cleanup 차단 (4.544458ms) | pass | o28-stage2-pure-green3-20260924.log |
| 71 | LP06-B01 진단 파일을 재현 전에 보존 (24.202959ms) | pass | o28-stage2-pure-green3-20260924.log |
| 72 | LP26-O18 사후 failed는 기본 코드만 보존하고 원문·재현 없이 정리 가능 (7.690083ms) | pass | o28-stage2-pure-green3-20260924.log |
| 73 | LP26-O18 사후 실패 미등록 코드·저장 충돌은 정리 거부 (5.205167ms) | pass | o28-stage2-pure-green3-20260924.log |
| 74 | LP06-B02 실제 자식 exit 뒤 최초 증거 유지 (41.892709ms) | pass | o28-stage2-pure-green3-20260924.log |
| 75 | LP06-B02 실제 자식 timeout 뒤 최초 증거 유지 (76.968292ms) | pass | o28-stage2-pure-green3-20260924.log |
| 76 | LP06-B03 진단 throw 시 재현·정리 거부 (0.327ms) | pass | o28-stage2-pure-green3-20260924.log |
| 77 | LP06-B03 진단 unsafe 시 재현·정리 거부 (0.21225ms) | pass | o28-stage2-pure-green3-20260924.log |
| 78 | LP06-B04 최초 보존 실패 시 재현 금지 (4.427958ms) | pass | o28-stage2-pure-green3-20260924.log |
| 79 | LP06-B04 후속 보존 실패 시 최초 파일 유지 (21.214375ms) | pass | o28-stage2-pure-green3-20260924.log |
| 80 | LP06-B05 진단 미보존 root 정리 금지·소유권 불일치 거부 (0.748209ms) | pass | o28-stage2-pure-green3-20260924.log |
| 81 | LP06-B06 symlink 증거 덮어쓰기 거부 (5.165125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 82 | LP06-B06 성공 결과 분리 보존·미등록 필드 거부 (22.982541ms) | pass | o28-stage2-pure-green3-20260924.log |
| 83 | LP06-B07 상세 수집 throw 시 기본 진단 유지·재현 금지 (8.016041ms) | pass | o28-stage2-pure-green3-20260924.log |
| 84 | LP06-B07 상세 수집 timeout 시 기본 진단 유지·재현 금지 (59.835541ms) | pass | o28-stage2-pure-green3-20260924.log |
| 85 | LP06-B07 상세 수집 identity 시 기본 진단 유지·재현 금지 (5.943125ms) | pass | o28-stage2-pure-green3-20260924.log |
| 86 | LP06-B07 상세 수집 persist 시 기본 진단 유지·재현 금지 (12.143917ms) | pass | o28-stage2-pure-green3-20260924.log |
| 87 | LP06-B08 기본 자식은 plugin 환경 준비 실패와 독립 (27.503916ms) | pass | o28-stage2-pure-green3-20260924.log |
| 88 | LP06-B09 만료 시 자식 미기동·남은 시간만 대기 (103.552583ms) | pass | o28-stage2-pure-green3-20260924.log |
## o28-stage2-pure-redgreen2-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| 1 | LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.70125ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 2 | LP23-DH02 timeout preserves last open phase without synthetic completion (0.185ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 3 | LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (20.345375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 4 | O28-D01 child termination classes and bounded metadata remain distinct (0.260791ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 5 | O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.159792ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 6 | O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (44.647084ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 7 | O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (17.043833ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 8 | O28-R02 loss row는 고정형만 receipt에 보존 (13.755292ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 9 | O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (6.881166ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 10 | O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (34.763959ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 11 | O28-R04 accumulation receipt도 case·manifest·group 종료를 결속 (21.409041ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 12 | LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (20.989708ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 13 | LP23-DH05 changed original or unconfirmed child blocks cleanup (8.918583ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 14 | LP23-DH06 exact instrumentation drift and trace bounds fail closed (354.35025ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 15 | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 (0.879166ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 16 | LP26-O09-A02 identity·clock·pid 불일치 (0.094042ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 17 | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 (1.287166ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 18 | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 (0.242375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 19 | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 (0.067042ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 20 | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 (0.217125ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 21 | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 (2.108792ms) | fail | o28-stage2-pure-redgreen2-20260924.log |
| 22 | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 (0.222ms) | fail | o28-stage2-pure-redgreen2-20260924.log |
| 23 | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 (0.10125ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 24 | O28-R04 accumulation runner와 EXIT는 receipt 누락·실패를 삭제하지 않는다 (0.1425ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 25 | LP12-F04 input framing 고정 오류만 안전 집계 (0.727542ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 26 | LP12-C07 exact phase/code와 unknown 고정 조합만 수집 (0.09075ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 27 | LP12-D06 writer fixed 사유만 집계하고 원문을 보존하지 않음 (0.295375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 28 | LP08-B01 완료 작업 안전 증거 선보존 (20.062958ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 29 | LP08-B02 field 증거 실패 시 정리 차단 (0.4675ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 30 | LP08-B02 enum 증거 실패 시 정리 차단 (0.282583ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 31 | LP08-B02 range 증거 실패 시 정리 차단 (0.248333ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 32 | LP08-B02 throw 증거 실패 시 정리 차단 (0.224291ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 33 | LP08-B02 timeout 증거 실패 시 정리 차단 (0.238542ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 34 | LP08-B02 existing 증거 실패 시 정리 차단 (3.484583ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 35 | LP08-B02 symlink 증거 실패 시 정리 차단 (12.876291ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 36 | LP12-D02 missing binding valid (32.146791ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 37 | LP12-D02 missing binding binding-valid (12.751208ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 38 | LP12-D02 missing binding proof-present (9.921375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 39 | LP12-D02 missing binding binding-hash (10.221041ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 40 | LP12-D02 missing binding matches (6.86225ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 41 | LP12-D04 cap-exceeded count 미확인 보존 (31.937875ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 42 | LP12-D04 unavailable count 미확인 보존 (33.037292ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 43 | LP12-D05 catalog schema raw 변조 거부 (10.151541ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 44 | LP12-D05 catalog schema profile 변조 거부 (8.711584ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 45 | LP12-D05 catalog schema scope 변조 거부 (8.082792ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 46 | LP12-D05 catalog schema id 변조 거부 (7.842625ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 47 | LP12-D05 catalog schema validity 변조 거부 (7.216583ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 48 | LP12-D05 catalog schema lifecycle 변조 거부 (5.6805ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 49 | LP12-D05 catalog schema count 변조 거부 (6.99175ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 50 | LP12-D05 catalog schema cap 변조 거부 (8.918167ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 51 | LP12-D05 catalog schema truncated 변조 거부 (7.980583ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 52 | LP12-D06 newline 없는 fixed prefix tail은 known 인정 금지 (0.092458ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 53 | LP12-D06 line/count cap 및 다음 정상행 복구 (1.33325ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 54 | LP13-P04 expected reference missing 거부 (0.3245ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 55 | LP13-P04 expected reference mismatch 거부 (0.245667ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 56 | LP13-P04 expected reference invalid 거부 (0.206708ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 57 | LP13-P01 generic absent HTTP 실패 증거 보존 (6.761625ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 58 | LP13-P01 generic intent HTTP 실패 증거 보존 (8.007584ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 59 | LP13-P01 generic ready HTTP 실패 증거 보존 (7.937416ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 60 | LP13-P01 generic committed HTTP 실패 증거 보존 (6.9605ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 61 | LP13-P01 generic complete HTTP 실패 증거 보존 (6.972084ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 62 | LP13-P01 generic failed HTTP 실패 증거 보존 (8.0935ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 63 | LP13-P01 generic field 실패 시 cleanup 차단 (0.535333ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 64 | LP13-P01 generic state 실패 시 cleanup 차단 (0.317166ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 65 | LP13-P01 generic count 실패 시 cleanup 차단 (0.221375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 66 | LP13-P01 generic hash 실패 시 cleanup 차단 (0.187417ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 67 | LP13-P01 generic absent 실패 시 cleanup 차단 (0.184875ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 68 | LP13-P01 generic throw 실패 시 cleanup 차단 (0.1755ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 69 | LP13-P01 generic timeout 실패 시 cleanup 차단 (0.169375ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 70 | LP13-P01 generic persist 실패 시 cleanup 차단 (5.209541ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 71 | LP06-B01 진단 파일을 재현 전에 보존 (24.011416ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 72 | LP26-O18 사후 failed는 기본 코드만 보존하고 원문·재현 없이 정리 가능 (7.8065ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 73 | LP26-O18 사후 실패 미등록 코드·저장 충돌은 정리 거부 (3.194333ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 74 | LP06-B02 실제 자식 exit 뒤 최초 증거 유지 (39.874958ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 75 | LP06-B02 실제 자식 timeout 뒤 최초 증거 유지 (75.035792ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 76 | LP06-B03 진단 throw 시 재현·정리 거부 (0.73675ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 77 | LP06-B03 진단 unsafe 시 재현·정리 거부 (0.261208ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 78 | LP06-B04 최초 보존 실패 시 재현 금지 (5.031333ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 79 | LP06-B04 후속 보존 실패 시 최초 파일 유지 (20.439541ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 80 | LP06-B05 진단 미보존 root 정리 금지·소유권 불일치 거부 (0.853125ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 81 | LP06-B06 symlink 증거 덮어쓰기 거부 (4.891084ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 82 | LP06-B06 성공 결과 분리 보존·미등록 필드 거부 (24.872875ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 83 | LP06-B07 상세 수집 throw 시 기본 진단 유지·재현 금지 (8.673333ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 84 | LP06-B07 상세 수집 timeout 시 기본 진단 유지·재현 금지 (62.0615ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 85 | LP06-B07 상세 수집 identity 시 기본 진단 유지·재현 금지 (8.036458ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 86 | LP06-B07 상세 수집 persist 시 기본 진단 유지·재현 금지 (11.405291ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 87 | LP06-B08 기본 자식은 plugin 환경 준비 실패와 독립 (28.27825ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
| 88 | LP06-B09 만료 시 자식 미기동·남은 시간만 대기 (103.158041ms) | pass | o28-stage2-pure-redgreen2-20260924.log |
## o28-stage2-static-final-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
## o28-stage2-static-green1-20260924.log

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |

개별 assertion 없는 원출력. 성공으로 변환하지 않음.
