# O28 3번 원출력 개별 결과

독자: 검증 담당자. lifecycle: 해당 실행의 보존 기록. 중앙 기록을 보조하며 전체 실행 판정은 o28-results.md를 따른다. 빈 판정은 실행 관측값이고 PASS/FAIL 결과가 아니다. 최초 실패를 보존한다.

제목 | 테스트내용 | pass/fail | 비고
--- | --- | --- | ---
FC01 exact insertion checks count=110 | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[bounded-exit] | o28-stage3-accumulation-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage3-accumulation-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage3-accumulation-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
LP26-O10-D01 records8192 admitted | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-D01 records8193 rejected | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-D01 charge64MiB admitted | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-D01 charge64MiBplus1 rejected | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--bounds","selectedCase":null,"status":0,"signal":null,"stop":null,"elapsedMs":486,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":1,"stageLimitMs":null,"technicalCapMs":15000,"diskBytes":13242632,"parentRssBytes":70647808} (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--generate","selectedCase":null,"status":0,"signal":null,"stop":null,"elapsedMs":7138,"groupClosed":true,"peakObservedRssBytes":43810816,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":111236591,"parentRssBytes":72712192} (관측값; 단독 PASS 아님)
LP26-O10-B 16 initial exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":16,"phase":"initial","elapsedMs":464.3944169999995,"polls":1,"fresh":64,"rotations":0,"before":{"diskBytes":111236591,"parentRssBytes":72744960},"after":{"diskBytes":111236591,"parentRssBytes":73596928},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-B exact timeline count and deleted rows | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--catalog","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":210,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":111324043,"parentRssBytes":73842688} (관측값; 단독 PASS 아님)
LP26-O10-B 16 rotated exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":16,"phase":"rotated","elapsedMs":135.9309170000015,"polls":1,"fresh":0,"rotations":1,"before":{"diskBytes":111324043,"parentRssBytes":73891840},"after":{"diskBytes":111324043,"parentRssBytes":73924608},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-B 1020 initial exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":1020,"phase":"initial","elapsedMs":5513.221416999999,"polls":1,"fresh":4080,"rotations":0,"before":{"diskBytes":111324043,"parentRssBytes":73924608},"after":{"diskBytes":111324043,"parentRssBytes":140197888},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-B exact timeline count and deleted rows | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--catalog","selectedCase":"1020","status":0,"signal":null,"stop":null,"elapsedMs":11382,"groupClosed":true,"peakObservedRssBytes":200638464,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":104460971,"parentRssBytes":136298496} (관측값; 단독 PASS 아님)
LP26-O10-B 1020 rotated exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":1020,"phase":"rotated","elapsedMs":5355.611041,"polls":1,"fresh":0,"rotations":1,"before":{"diskBytes":104460971,"parentRssBytes":136298496},"after":{"diskBytes":104460971,"parentRssBytes":162234368},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-B 2048 initial exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":2048,"phase":"initial","elapsedMs":11033.999790999998,"polls":2,"fresh":8192,"rotations":0,"before":{"diskBytes":104460971,"parentRssBytes":162234368},"after":{"diskBytes":104460971,"parentRssBytes":200884224},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-B exact timeline count and deleted rows | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--catalog","selectedCase":"2048","status":0,"signal":null,"stop":null,"elapsedMs":22950,"groupClosed":true,"peakObservedRssBytes":371867648,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":90476469,"parentRssBytes":233570304} (관측값; 단독 PASS 아님)
LP26-O10-B 2048 rotated exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":2048,"phase":"rotated","elapsedMs":10813.029374999998,"polls":1,"fresh":0,"rotations":1,"before":{"diskBytes":90476469,"parentRssBytes":234225664},"after":{"diskBytes":90476469,"parentRssBytes":312360960},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-B 2049 initial exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":2049,"phase":"initial","elapsedMs":11014.094291999994,"polls":2,"fresh":8196,"rotations":0,"before":{"diskBytes":90476469,"parentRssBytes":313016320},"after":{"diskBytes":90476469,"parentRssBytes":336330752},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-B exact timeline count and deleted rows | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-A manual full checkpoint and same-lock timeline measurement | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--catalog","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":33161,"groupClosed":true,"peakObservedRssBytes":371359744,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":76484355,"parentRssBytes":326139904} (관측값; 단독 PASS 아님)
LP26-O10-B 2049 rotated exact-count-prefix | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-accumulation-run1-20260924.log |  | [probe-drain] {"sources":2049,"phase":"rotated","elapsedMs":10807.789334000001,"polls":1,"fresh":0,"rotations":1,"before":{"diskBytes":76484355,"parentRssBytes":326139904},"after":{"diskBytes":76484355,"parentRssBytes":372441088},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O14-A public PutObservationV2 automatic CheckpointDue path classified | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-A public observation recovery exact IDs and zero corruption | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--automatic","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":28100,"groupClosed":true,"peakObservedRssBytes":327499776,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":30000,"diskBytes":79346752,"parentRssBytes":326336512} (관측값; 단독 PASS 아님)
lp10-public-full-seed FE02 writer start | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
lp10-public-full-seed FE04 bound finalized mutation segment0 | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-D public normal lifecycle automatic full fallback classified | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--automatic-full","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":22503,"groupClosed":true,"peakObservedRssBytes":415907840,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":30000,"diskBytes":80804369,"parentRssBytes":326336512} (관측값; 단독 PASS 아님)
LP26-O14-E public normal lifecycle recovery IDs observations and zero corruption | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-accumulation-run1-20260924.log |  | [probe-process] {"mode":"--automatic-full-reopen","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":14563,"groupClosed":true,"peakObservedRssBytes":338329600,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":30000,"diskBytes":80816657,"parentRssBytes":326352896} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage3-accumulation-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10 receipt-preservation | o28-stage3-accumulation-run1-20260924.log | fail | 원출력 개별 결과
[probe-reader-cleanup] | o28-stage3-accumulation-run1-20260924.log |  | [probe-reader-cleanup] {"readers":4,"closed":true,"groupsClosed":true,"receiptPreserved":false,"elapsedMs":195775.411666,"diskBytes":80816657,"parentRssBytes":326467584} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage3-accumulation-run1-20260924.log |  | [cleanup] {"preserved":true,"reason":"failed-run"} (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[bounded-exit] | o28-stage3-case16-receipt-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage3-case16-receipt-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage3-case16-receipt-run1-20260924.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-process] {"mode":"--generate","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":1903,"groupClosed":true,"peakObservedRssBytes":29573120,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":15300824,"parentRssBytes":71958528} (관측값; 단독 PASS 아님)
LP26-O10-B 16 initial exact-count-prefix | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-drain] {"sources":16,"phase":"initial","elapsedMs":436.94495800000004,"polls":1,"fresh":64,"rotations":0,"before":{"diskBytes":15300824,"parentRssBytes":72155136},"after":{"diskBytes":15300824,"parentRssBytes":73154560},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
LP26-O14-B exact timeline count and deleted rows | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[probe-process] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-process] {"mode":"--catalog","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":208,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15388271,"parentRssBytes":73334784} (관측값; 단독 PASS 아님)
LP26-O10-B 16 rotated exact-count-prefix | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[probe-drain] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-drain] {"sources":16,"phase":"rotated","elapsedMs":132.89766699999973,"polls":1,"fresh":0,"rotations":1,"before":{"diskBytes":15388271,"parentRssBytes":73400320},"after":{"diskBytes":15388271,"parentRssBytes":73433088},"nativeTimeoutMs":3000,"observationLimitMs":15000,"performancePass":false} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage3-case16-receipt-run1-20260924.log | pass | 원출력 개별 결과
[probe-receipt] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-receipt] {"preserved":true,"bytes":2440,"sha256":"08c14fb06216618d9c94c2faec261b109e1e3bfa5606a980849f23624dd07e98","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage3-case16-receipt-run1-20260924.log |  | [probe-reader-cleanup] {"readers":1,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":2793.6919169999996,"diskBytes":15388335,"parentRssBytes":73744384} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage3-case16-receipt-run1-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.dsznZZ","bytes":15388335,"absent":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.464125ms) | o28-stage3-final-static-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.781209ms) | o28-stage3-final-static-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.125584ms) | o28-stage3-final-static-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.046042ms) | o28-stage3-final-static-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.2725ms) | o28-stage3-final-static-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.873625ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.956791ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.131ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.053917ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.543834ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.770667ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.160667ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.351334ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.327833ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.156333ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (26.035542ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.91175ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.908125ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.464375ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (18.042833ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.322417ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (7.857ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.338375ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.726375ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.603792ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.451833ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.90125ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (300.854041ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (144.346084ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (2.584959ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.081ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (37.878334ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (42.900167ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (40.386459ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (43.988167ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (45.228042ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (44.1335ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (5.597916ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (16.051833ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (46.433334ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (65.881ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (292.059875ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (2.07875ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (24.414167ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (11.376417ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.0695ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.029333ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.021458ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.021084ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.018042ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.015416ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (64.678084ms) | o28-stage3-focused-final-20260924.log | pass | 실제 Node 개별 결과
[cleanup] | o28-stage3-focused-final-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-MMkTe1","bytes":528047,"removed":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.544167ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.835083ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.137542ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.053541ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.306042ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.759083ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.145458ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.985208ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.329ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.405291ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (26.646167ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (7.711541ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.013417ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.154792ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.428ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.735625ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (9.59475ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.86125ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.929ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.232959ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (1.118125ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (300.371583ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (132.2955ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (2.5525ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.083167ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (38.720875ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (41.659791ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (41.68675ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (44.108291ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (37.365375ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (44.864584ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (6.33325ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (12.975875ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (47.075708ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (70.274291ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (291.80475ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (2.10025ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (24.98375ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (11.548208ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.09275ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.031375ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.023416ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.025666ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.020666ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.018625ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (63.497583ms) | o28-stage3-focused-green1-20260924.log | pass | 실제 Node 개별 결과
[cleanup] | o28-stage3-focused-green1-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-shHHOT","bytes":528047,"removed":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.89325ms) | o28-stage3-focused-red1-20260924.log | fail | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (2.671042ms) | o28-stage3-focused-red1-20260924.log | fail | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.54925ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.086542ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.30425ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.779666ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.148208ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (11.614792ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.39975ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.175958ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (27.369667ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.529083ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.966333ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.093333ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.542375ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (2.432541ms) | o28-stage3-focused-red1-20260924.log | fail | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (10.121416ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (4.065625ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.776292ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.129083ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.907166ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (526.970083ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (275.33425ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (5.685667ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.213875ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (45.806334ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (37.2965ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (45.139416ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (45.296042ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (42.905167ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (46.292917ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (5.322792ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (15.146208ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (36.158375ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (70.751083ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (299.90625ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (2.6855ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (25.158125ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (12.515959ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.094375ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.033208ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.025125ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.023208ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.020417ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.018334ms) | o28-stage3-focused-red1-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (35.984541ms) | o28-stage3-focused-red1-20260924.log | fail | 실제 Node 개별 결과
[cleanup] | o28-stage3-focused-red1-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-kLma39","bytes":527657,"removed":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.900708ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (1.304125ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.19525ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.059ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.323916ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.749042ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.133667ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (12.011333ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.409791ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.205417ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (24.885083ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (9.86675ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.764875ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.188708ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.291917ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.461042ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (8.909875ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.423459ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (1.15375ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.47575ms) | o28-stage3-receipt-focused-green1-20260924.log | fail | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.455333ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.795875ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (488.190583ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (333.838625ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (6.984084ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.234292ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (45.914584ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (43.4225ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (44.611ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (44.932792ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (39.847625ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (41.772541ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (5.583667ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (18.054167ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (46.429084ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (71.075209ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (288.195375ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (2.765541ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (24.396167ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (11.561833ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.104208ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.033709ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.024833ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.025167ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.040792ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.01875ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (64.972166ms) | o28-stage3-receipt-focused-green1-20260924.log | pass | 실제 Node 개별 결과
[cleanup] | o28-stage3-receipt-focused-green1-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-6OfQTk","bytes":528047,"removed":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.681333ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (1.099167ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.16825ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.059542ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.312833ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.729875ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.141084ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (10.901709ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.532416ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.198042ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (24.733708ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (7.75325ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (9.030625ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.579833ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (17.9785ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.4415ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (9.821666ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.9275ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.901333ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.230917ms) | o28-stage3-receipt-focused-green2-20260924.log | fail | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.183084ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (1.001375ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (301.433416ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (83.521167ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (1.756166ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.078125ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (40.169042ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (42.262958ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (42.478459ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (35.712667ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (43.498ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (43.310917ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (5.208292ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (15.698833ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (45.262458ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (65.153208ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (288.682292ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (2.40125ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (24.166709ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (12.496041ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.0845ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.031042ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.023042ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.021333ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.018667ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.016375ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (63.668542ms) | o28-stage3-receipt-focused-green2-20260924.log | pass | 실제 Node 개별 결과
[cleanup] | o28-stage3-receipt-focused-green2-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-odVcR3","bytes":528047,"removed":true} (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.498083ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.779542ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.121167ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.049916ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.285458ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.867125ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.14675ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (8.985333ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.291917ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.172458ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (24.907208ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (7.765375ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.9255ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.175375ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (17.468791ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.43725ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (10.079375ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.755542ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.706875ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.09025ms) | o28-stage3-receipt-focused-green3-20260924.log | fail | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.578ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.789417ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (292.891583ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C01 slow-only 초기20000행 생략·마지막64·33KiB 상한 (129.638625ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP26-O09-C03 slow flag만으로 trace 활성화 금지 (2.723833ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 collector 존재 (0.088792ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid null 무출력 (33.123209ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "" 무출력 (41.467709ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "0" 무출력 (41.841875ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "true" 무출력 (44.2645ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "01" 무출력 (44.842792ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T01 disabled/invalid "1 " 무출력 (36.634209ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 fast aggregate count/sum/max 정확 (5.588208ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 부분증거 parent/target 실패와 phase누락 미완료 (13.3035ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T02 실제 동일 mutex 경합·다른 mutex·unlock 후 sink (37.831375ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 600 poll·15fastlocks/poll·5400worker 합성 예산 (69.885334ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 1800 poll·15fastlocks/poll·5400worker 합성 예산 (290.152042ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 tls-cap 손실 명시 (1.997292ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T03 cap 손실 명시 (23.82475ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 split·safe부분보존·순번누락 (11.860541ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 enum 거부 (0.095709ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 numeric 거부 (0.030625ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 time 거부 (0.022417ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 count 거부 (0.022167ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 linecap 거부 (0.032667ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T04 incomplete 거부 (0.016833ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
LP13-T05 cost instrumentation 신규wrapper 단일치환·trace중복거부 (64.088959ms) | o28-stage3-receipt-focused-green3-20260924.log | pass | 실제 Node 개별 결과
[cleanup] | o28-stage3-receipt-focused-green3-20260924.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-latency-MSWO5l","bytes":528047,"removed":true} (관측값; 단독 PASS 아님)
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.69725ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.142083ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (10.891833ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.2655ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.154042ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (25.176333ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (9.763958ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.125209ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.199292ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (16.196833ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.263625ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (8.850791ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.408125ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.691709ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.297292ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.68125ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.898417ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (259.716833ms) | o28-stage3-receipt-helper-green4-20260924.log | pass | 실제 Node 개별 결과
