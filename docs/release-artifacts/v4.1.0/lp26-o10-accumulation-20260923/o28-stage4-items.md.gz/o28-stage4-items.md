# O28 4번 개별 결과

독자: 검증 담당자. lifecycle: 해당 실행 증거 보존. 중앙 결과를 보조하며 전체 판정과 최초 실패는 o28-results.md를 따른다. 빈 판정은 관측값이다.

제목 | 테스트내용 | pass/fail | 비고
--- | --- | --- | ---
FC01 exact insertion checks count=110 | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case1020-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case1020-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case1020-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case1020-run1.log |  | [probe-process] {"mode":"--generate","selectedCase":"1020","status":0,"signal":null,"stop":null,"elapsedMs":2415,"groupClosed":true,"peakObservedRssBytes":43761664,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":34299040,"parentRssBytes":71876608} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-open","elapsedUs":5937419,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"pre-checkpoint","sources":1020,"currentRssBytes":136593408,"peakRssBytes":136593408} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"journal","values":[4080,0,0,0,1269528,1460640,196608,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-timeline","elapsedUs":3904,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-held","owner":"snapshot","values":[0,0,0,0,0,0,0,0,1020,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-acquire","elapsedUs":44523,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"handles-held","sources":1020,"currentRssBytes":137216000,"peakRssBytes":137216000} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"journal","values":[4080,0,0,0,1269528,1460640,196608,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-released","owner":"snapshot","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"handles-released","sources":1020,"currentRssBytes":137216000,"peakRssBytes":137216000} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"journal","values":[4080,0,0,0,1269528,1460640,196608,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-release","elapsedUs":22985,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"requery-released","sources":1020,"currentRssBytes":137216000,"peakRssBytes":137216000} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"journal","values":[4080,0,0,0,1269528,1460640,196608,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-checkpoint","elapsedUs":3521655,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"post-checkpoint","sources":1020,"currentRssBytes":200720384,"peakRssBytes":200720384} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"journal","values":[4080,0,0,0,1269528,1460640,195840,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"shadow","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"prefix","values":[4080,0,0,0,0,0,293760,0,0,0,0,0,0,0,19167033,0,0,0,0,0,4080,19167033,4080,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-lifecycle] | o28-stage4-case1020-run1.log |  | [ownership-lifecycle] {"testIds":["O28-M01","O28-M02"],"sources":1020,"readers":8,"samplesPerBinding":60,"mediaFiles":0,"sameObject":0,"requeryAddressMatches":0,"heldDistinctObjects":16,"expiredWeak":16,"requeryDistinctAddresses":8,"bindingSha256":"8a1c09a57b714ecb01ccdc3c71220bb7d01dcf4dbdc4d5fffa402e45d27f7b7a","serializedEqual":true,"deleted":true,"snapshotReleased":true,"handlesReleased":true,"wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
O28-M01/M02 bounded reader ownership lifecycle | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case1020-run1.log |  | [probe-process] {"mode":"--ownership","selectedCase":"1020","status":0,"signal":null,"stop":null,"elapsedMs":9583,"groupClosed":true,"peakObservedRssBytes":200720384,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":27431534,"parentRssBytes":73646080} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case1020-run1.log |  | [probe-wall] {"stage":"ownership-reopen","elapsedUs":6639993,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"memory","stage":"fresh-reopen","sources":1020,"currentRssBytes":173359104,"peakRssBytes":173359104} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"journal","values":[4080,0,0,0,1269528,1460640,196608,0,0,0,0,0,0,0,19167033,0,0,0,0,0,0,0,0,0,4080,0,0,0,0,0,848640]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"live","values":[4080,0,0,2040,920775,1224000,342720,0,2040,1020,1020,0,0,0,35805099,0,0,61200,0,0,4080,35805099,4080,0,0,0,1020,0,0,244800,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case1020-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-reopen] | o28-stage4-case1020-run1.log |  | [ownership-reopen] {"sources":1020,"readers":8,"samplesPerBinding":60,"bindingSha256":"8a1c09a57b714ecb01ccdc3c71220bb7d01dcf4dbdc4d5fffa402e45d27f7b7a","serializedEqual":true,"deleted":true} (관측값; 단독 PASS 아님)
[probe-process] | o28-stage4-case1020-run1.log |  | [probe-process] {"mode":"--ownership-reopen","selectedCase":"1020","status":0,"signal":null,"stop":null,"elapsedMs":6686,"groupClosed":true,"peakObservedRssBytes":173277184,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":27431534,"parentRssBytes":73809920} (관측값; 단독 PASS 아님)
[ownership-summary] | o28-stage4-case1020-run1.log |  | [ownership-summary] {"sources":1020,"ownerRows":26,"readers":8,"bindingSha256":"8a1c09a57b714ecb01ccdc3c71220bb7d01dcf4dbdc4d5fffa402e45d27f7b7a","wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage4-case1020-run1.log | pass | 실제 개별 결과
[probe-receipt] | o28-stage4-case1020-run1.log |  | [probe-receipt] {"preserved":true,"bytes":2831,"sha256":"1ee980350c65f8e9dc6f0d0d133b7468206d8d573cf33425573e586aa0ed5630","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-case1020-run1.log |  | [probe-reader-cleanup] {"readers":0,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":18923.892958,"diskBytes":27431598,"parentRssBytes":74399744} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case1020-run1.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.d6kSJk","bytes":27431598,"absent":true} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case1020-run1.log |  | [exit] code=0 elapsed_seconds=28 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-case16-run1.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case16-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run1.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run1.log |  | [bounded-exit] code=1 signal=none timeout=false (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case16-run1.log |  | [cleanup] {"preserved":true,"reason":"failed-run"} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case16-run1.log |  | [exit] code=1 elapsed_seconds=7 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-case16-run2.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-case16-run2.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-case16-run2.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-case16-run2.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case16-run2.log |  | [probe-process] {"mode":"--generate","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":1565,"groupClosed":true,"peakObservedRssBytes":38109184,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":15484378,"parentRssBytes":72155136} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-open","elapsedUs":72491,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"pre-checkpoint","sources":16,"currentRssBytes":31637504,"peakRssBytes":31637504} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-timeline","elapsedUs":134,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-held","owner":"snapshot","values":[0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-acquire","elapsedUs":43895,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"handles-held","sources":16,"currentRssBytes":31834112,"peakRssBytes":31834112} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-released","owner":"snapshot","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"handles-released","sources":16,"currentRssBytes":31834112,"peakRssBytes":31834112} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-release","elapsedUs":21831,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"requery-released","sources":16,"currentRssBytes":31834112,"peakRssBytes":31834112} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-checkpoint","elapsedUs":58383,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"post-checkpoint","sources":16,"currentRssBytes":33030144,"peakRssBytes":33030144} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"shadow","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"prefix","values":[64,0,0,0,0,0,4608,0,0,0,0,0,0,0,300163,0,0,0,0,0,64,300163,64,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-lifecycle] | o28-stage4-case16-run2.log |  | [ownership-lifecycle] {"testIds":["O28-M01","O28-M02"],"sources":16,"readers":8,"samplesPerBinding":60,"mediaFiles":0,"sameObject":0,"requeryAddressMatches":0,"heldDistinctObjects":16,"expiredWeak":16,"requeryDistinctAddresses":8,"bindingSha256":"5c6739c1a79c19e1cdb2bcbc40d7b08e8acfcf1261bf678411387fd6c8827f06","serializedEqual":true,"deleted":true,"snapshotReleased":true,"handlesReleased":true,"wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
O28-M01/M02 bounded reader ownership lifecycle | o28-stage4-case16-run2.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case16-run2.log |  | [probe-process] {"mode":"--ownership","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":239,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15571788,"parentRssBytes":72482816} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run2.log |  | [probe-wall] {"stage":"ownership-reopen","elapsedUs":138985,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"memory","stage":"fresh-reopen","sources":16,"currentRssBytes":32260096,"peakRssBytes":32260096} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run2.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-reopen] | o28-stage4-case16-run2.log |  | [ownership-reopen] {"sources":16,"readers":8,"samplesPerBinding":60,"bindingSha256":"5c6739c1a79c19e1cdb2bcbc40d7b08e8acfcf1261bf678411387fd6c8827f06","serializedEqual":true,"deleted":true} (관측값; 단독 PASS 아님)
[probe-process] | o28-stage4-case16-run2.log |  | [probe-process] {"mode":"--ownership-reopen","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":180,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15571788,"parentRssBytes":72515584} (관측값; 단독 PASS 아님)
LP26-O10 unknown | o28-stage4-case16-run2.log | fail | 실제 개별 결과
[probe-receipt] | o28-stage4-case16-run2.log |  | [probe-receipt] {"preserved":true,"bytes":2820,"sha256":"659bc51c41a19fadd58c6823a5b0b92f95cefffda7b5dbbd64ff5ae333701d61","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-case16-run2.log |  | [probe-reader-cleanup] {"readers":0,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":2005.333542,"diskBytes":15571852,"parentRssBytes":73105408} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case16-run2.log |  | [cleanup] {"preserved":true,"reason":"failed-run"} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case16-run2.log |  | [exit] code=1 elapsed_seconds=11 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-case16-run3.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run3.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run3.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case16-run3.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-case16-run3.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-case16-run3.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-case16-run3.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case16-run3.log |  | [probe-process] {"mode":"--generate","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":1325,"groupClosed":true,"peakObservedRssBytes":36536320,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":15484378,"parentRssBytes":71958528} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-open","elapsedUs":73190,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"pre-checkpoint","sources":16,"currentRssBytes":31588352,"peakRssBytes":31588352} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-timeline","elapsedUs":143,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-held","owner":"snapshot","values":[0,0,0,0,0,0,0,0,16,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-acquire","elapsedUs":43981,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"handles-held","sources":16,"currentRssBytes":31817728,"peakRssBytes":31817728} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-released","owner":"snapshot","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"handles-released","sources":16,"currentRssBytes":31817728,"peakRssBytes":31817728} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-release","elapsedUs":21778,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"requery-released","sources":16,"currentRssBytes":31817728,"peakRssBytes":31817728} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-checkpoint","elapsedUs":57525,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"post-checkpoint","sources":16,"currentRssBytes":32964608,"peakRssBytes":32964608} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"shadow","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"prefix","values":[64,0,0,0,0,0,4608,0,0,0,0,0,0,0,300163,0,0,0,0,0,64,300163,64,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-lifecycle] | o28-stage4-case16-run3.log |  | [ownership-lifecycle] {"testIds":["O28-M01","O28-M02"],"sources":16,"readers":8,"samplesPerBinding":60,"mediaFiles":0,"sameObject":0,"requeryAddressMatches":0,"heldDistinctObjects":16,"expiredWeak":16,"requeryDistinctAddresses":8,"bindingSha256":"d82d3aec00283e3fdee018e80aa04b476a7162c6abd694d6932ca47c644fb3f2","serializedEqual":true,"deleted":true,"snapshotReleased":true,"handlesReleased":true,"wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
O28-M01/M02 bounded reader ownership lifecycle | o28-stage4-case16-run3.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case16-run3.log |  | [probe-process] {"mode":"--ownership","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":239,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15571773,"parentRssBytes":72384512} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case16-run3.log |  | [probe-wall] {"stage":"ownership-reopen","elapsedUs":140490,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"memory","stage":"fresh-reopen","sources":16,"currentRssBytes":32325632,"peakRssBytes":32325632} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"journal","values":[64,0,0,0,19536,22912,3072,0,0,0,0,0,0,0,300163,0,0,0,0,0,0,0,0,0,64,0,0,0,0,0,13312]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"live","values":[64,0,0,32,14089,19200,5376,0,32,16,16,0,0,0,561105,0,0,960,0,0,64,561105,64,0,0,0,16,0,0,3840,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case16-run3.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-reopen] | o28-stage4-case16-run3.log |  | [ownership-reopen] {"sources":16,"readers":8,"samplesPerBinding":60,"bindingSha256":"d82d3aec00283e3fdee018e80aa04b476a7162c6abd694d6932ca47c644fb3f2","serializedEqual":true,"deleted":true} (관측값; 단독 PASS 아님)
[probe-process] | o28-stage4-case16-run3.log |  | [probe-process] {"mode":"--ownership-reopen","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":182,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15571773,"parentRssBytes":72450048} (관측값; 단독 PASS 아님)
[ownership-summary] | o28-stage4-case16-run3.log |  | [ownership-summary] {"sources":16,"ownerRows":26,"readers":8,"bindingSha256":"d82d3aec00283e3fdee018e80aa04b476a7162c6abd694d6932ca47c644fb3f2","wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage4-case16-run3.log | pass | 실제 개별 결과
[probe-receipt] | o28-stage4-case16-run3.log |  | [probe-receipt] {"preserved":true,"bytes":2815,"sha256":"d0c80ea902866bc613f217d31c03e4b03cd25589a58f74d974f43f347d1b9e20","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-case16-run3.log |  | [probe-reader-cleanup] {"readers":0,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":2174.145916,"diskBytes":15571837,"parentRssBytes":72990720} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case16-run3.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.P7l0cw","bytes":15571837,"absent":true} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case16-run3.log |  | [exit] code=0 elapsed_seconds=12 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2048-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2048-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2048-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case2048-run1.log |  | [probe-process] {"mode":"--generate","selectedCase":"2048","status":0,"signal":null,"stop":null,"elapsedMs":3593,"groupClosed":true,"peakObservedRssBytes":43859968,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":53586376,"parentRssBytes":72220672} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-open","elapsedUs":12061016,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"pre-checkpoint","sources":2048,"currentRssBytes":242712576,"peakRssBytes":242712576} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-timeline","elapsedUs":7944,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-held","owner":"snapshot","values":[0,0,0,0,0,0,0,0,2048,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-acquire","elapsedUs":44192,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"handles-held","sources":2048,"currentRssBytes":245104640,"peakRssBytes":245104640} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-released","owner":"snapshot","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"handles-released","sources":2048,"currentRssBytes":245104640,"peakRssBytes":245104640} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-release","elapsedUs":23003,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"requery-released","sources":2048,"currentRssBytes":245121024,"peakRssBytes":245121024} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-checkpoint","elapsedUs":7134193,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"post-checkpoint","sources":2048,"currentRssBytes":371097600,"peakRssBytes":371097600} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"shadow","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"prefix","values":[8192,0,0,0,0,0,589824,0,0,0,0,0,0,0,38507825,0,0,0,0,0,8192,38507825,8192,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-lifecycle] | o28-stage4-case2048-run1.log |  | [ownership-lifecycle] {"testIds":["O28-M01","O28-M02"],"sources":2048,"readers":8,"samplesPerBinding":60,"mediaFiles":0,"sameObject":0,"requeryAddressMatches":0,"heldDistinctObjects":16,"expiredWeak":16,"requeryDistinctAddresses":8,"bindingSha256":"37dbfabf582df58093f9a324b707f353d80d80f79db60a4778a5e7c7b53bfafe","serializedEqual":true,"deleted":true,"snapshotReleased":true,"handlesReleased":true,"wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
O28-M01/M02 bounded reader ownership lifecycle | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case2048-run1.log |  | [probe-process] {"mode":"--ownership","selectedCase":"2048","status":0,"signal":null,"stop":null,"elapsedMs":19335,"groupClosed":true,"peakObservedRssBytes":371097600,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":39597862,"parentRssBytes":74104832} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2048-run1.log |  | [probe-wall] {"stage":"ownership-reopen","elapsedUs":13353199,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"memory","stage":"fresh-reopen","sources":2048,"currentRssBytes":316424192,"peakRssBytes":316424192} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"journal","values":[8192,0,0,0,2566864,2932736,393216,0,0,0,0,0,0,0,38507825,0,0,0,0,0,0,0,0,0,8192,0,0,0,0,0,1703936]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"live","values":[8192,0,0,4096,1865507,2457600,688128,0,4096,2048,2048,0,0,0,71916683,0,0,122880,0,0,8192,71916683,8192,0,0,0,2048,0,0,491520,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2048-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-reopen] | o28-stage4-case2048-run1.log |  | [ownership-reopen] {"sources":2048,"readers":8,"samplesPerBinding":60,"bindingSha256":"37dbfabf582df58093f9a324b707f353d80d80f79db60a4778a5e7c7b53bfafe","serializedEqual":true,"deleted":true} (관측값; 단독 PASS 아님)
[probe-process] | o28-stage4-case2048-run1.log |  | [probe-process] {"mode":"--ownership-reopen","selectedCase":"2048","status":0,"signal":null,"stop":null,"elapsedMs":13404,"groupClosed":true,"peakObservedRssBytes":316424192,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":39597862,"parentRssBytes":74137600} (관측값; 단독 PASS 아님)
[ownership-summary] | o28-stage4-case2048-run1.log |  | [ownership-summary] {"sources":2048,"ownerRows":26,"readers":8,"bindingSha256":"37dbfabf582df58093f9a324b707f353d80d80f79db60a4778a5e7c7b53bfafe","wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage4-case2048-run1.log | pass | 실제 개별 결과
[probe-receipt] | o28-stage4-case2048-run1.log |  | [probe-receipt] {"preserved":true,"bytes":2834,"sha256":"c29067cbf47cf17c72fa94af95ee657488b9525d5a2ad4cd27027d3a23f89ef6","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-case2048-run1.log |  | [probe-reader-cleanup] {"readers":0,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":36689.478583000004,"diskBytes":39597926,"parentRssBytes":74530816} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case2048-run1.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.Pb7oMU","bytes":39597926,"absent":true} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case2048-run1.log |  | [exit] code=0 elapsed_seconds=46 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.h","originalSha256":"49250e6ff55304e97bd0d27c275da08b1d8f7c378a80357d891ec0fde383bc78","instrumentedSha256":"0456cc7e71948099fa2e8cb1da98d32653c477f681bdb1836d27896d39367337"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.h","originalSha256":"31ae6242254278b294284d0cd8e66b6f103890b0e729e1776a98b268360ed63c","instrumentedSha256":"27a3503cc19779cc924ae7f21a160ce885d7da981555ed27f7ff5a93b67be4b6"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"instrument","file":"recording_catalog.cpp","originalSha256":"de9cad6b8ac20ee940511824f9730c4fcb81c09515e18363f70a974286d6a612","instrumentedSha256":"eec53eb2826a45e8c76120f3faa2cbdecffbaff2718f4b515ca668ab54fb950a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"instrument","file":"recording_journal.cpp","originalSha256":"ff9a0f46233ce42a859332e5388742a3775252cc400afa16afe77c1b9d2f4114","instrumentedSha256":"69dd8246d7833b37661c991d1871a5f791700944bafc41464ca63ac44a2c6b1a"} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"instrumentSummary","exactEdits":7,"cacheChange":"retention-and-reuse-only"} (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2049-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2049-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-case2049-run1.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case2049-run1.log |  | [probe-process] {"mode":"--generate","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":3612,"groupClosed":true,"peakObservedRssBytes":43859968,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":53605138,"parentRssBytes":71991296} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-open","elapsedUs":12538320,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"pre-checkpoint","sources":2049,"currentRssBytes":243056640,"peakRssBytes":243056640} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"journal","values":[8196,0,0,0,2568126,2934168,786432,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"pre-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-timeline","elapsedUs":9107,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-held","owner":"snapshot","values":[0,0,0,0,0,0,0,0,2049,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-acquire","elapsedUs":44026,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"handles-held","sources":2049,"currentRssBytes":246153216,"peakRssBytes":246153216} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"journal","values":[8196,0,0,0,2568126,2934168,786432,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-held","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"snapshot-released","owner":"snapshot","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"handles-released","sources":2049,"currentRssBytes":246153216,"peakRssBytes":246153216} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"journal","values":[8196,0,0,0,2568126,2934168,786432,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"handles-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-release","elapsedUs":23460,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"requery-released","sources":2049,"currentRssBytes":246153216,"peakRssBytes":246153216} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"journal","values":[8196,0,0,0,2568126,2934168,786432,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"requery-released","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-checkpoint","elapsedUs":6579727,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"post-checkpoint","sources":2049,"currentRssBytes":368885760,"peakRssBytes":368885760} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"journal","values":[8196,0,0,0,2568126,2934168,393408,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"post-checkpoint","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-lifecycle] | o28-stage4-case2049-run1.log |  | [ownership-lifecycle] {"testIds":["O28-M01","O28-M02"],"sources":2049,"readers":8,"samplesPerBinding":60,"mediaFiles":0,"sameObject":0,"requeryAddressMatches":0,"heldDistinctObjects":16,"expiredWeak":16,"requeryDistinctAddresses":8,"bindingSha256":"094ef11c898b15e090a8295f4d77f226fdba8b00000eea49326eee67ba334763","serializedEqual":true,"deleted":true,"snapshotReleased":true,"handlesReleased":true,"wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
O28-M01/M02 bounded reader ownership lifecycle | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-case2049-run1.log |  | [probe-process] {"mode":"--ownership","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":19255,"groupClosed":true,"peakObservedRssBytes":368885760,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":39612899,"parentRssBytes":73498624} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-case2049-run1.log |  | [probe-wall] {"stage":"ownership-reopen","elapsedUs":13391023,"ok":true} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"memory","stage":"fresh-reopen","sources":2049,"currentRssBytes":316948480,"peakRssBytes":316948480} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"journal","values":[8196,0,0,0,2568126,2934168,786432,0,0,0,0,0,0,0,38526639,0,0,0,0,0,0,0,0,0,8196,0,0,0,0,0,1704768]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"live","values":[8196,0,0,4098,1866426,2458800,688464,0,4098,2049,2049,0,0,0,71951811,0,0,122940,0,0,8196,71951811,8196,0,0,0,2049,0,0,491760,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"shadow","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[lp17] | o28-stage4-case2049-run1.log |  | [lp17] {"kind":"owner-packed","version":1,"stage":"fresh-reopen","owner":"prefix","values":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]} (관측값; 단독 PASS 아님)
[ownership-reopen] | o28-stage4-case2049-run1.log |  | [ownership-reopen] {"sources":2049,"readers":8,"samplesPerBinding":60,"bindingSha256":"094ef11c898b15e090a8295f4d77f226fdba8b00000eea49326eee67ba334763","serializedEqual":true,"deleted":true} (관측값; 단독 PASS 아님)
[probe-process] | o28-stage4-case2049-run1.log |  | [probe-process] {"mode":"--ownership-reopen","selectedCase":"2049","status":0,"signal":null,"stop":null,"elapsedMs":13441,"groupClosed":true,"peakObservedRssBytes":316915712,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":39612899,"parentRssBytes":73564160} (관측값; 단독 PASS 아님)
[ownership-summary] | o28-stage4-case2049-run1.log |  | [ownership-summary] {"sources":2049,"ownerRows":26,"readers":8,"bindingSha256":"094ef11c898b15e090a8295f4d77f226fdba8b00000eea49326eee67ba334763","wholeHeapAttributed":false,"rssLeakProven":false} (관측값; 단독 PASS 아님)
LP26-O10-E01 malformed mutation rejected | o28-stage4-case2049-run1.log | pass | 실제 개별 결과
[probe-receipt] | o28-stage4-case2049-run1.log |  | [probe-receipt] {"preserved":true,"bytes":2834,"sha256":"fba25491ae3794019bb77229f72bbde790485f05e080bfe2aeec10c8226964bd","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-case2049-run1.log |  | [probe-reader-cleanup] {"readers":0,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":36699.105666,"diskBytes":39612963,"parentRssBytes":74153984} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-case2049-run1.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.dTl83e","bytes":39612963,"absent":true} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-case2049-run1.log |  | [exit] code=0 elapsed_seconds=46 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
LP20-C04 임시 파일 삭제 경쟁은 동일 root의 전체 관측으로 재확인 (1.284459ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP20-C04 반복 관측 실패·권한 실패·root 교체는 계속 거부 (0.587666ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP19-H01 계측 손실 없는 왕복 (1.026625ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP19-H02 잘못된 축약 표현 거부 (0.274209ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H01 기존 RSS 실패와 유효 진단 분리 (0.107083ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H02 관측 누락·손상·역행·잘못된 owner 거부 (0.163167ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H03 완료 summary 누락·중복·다른 작업·실패 거부 (0.093541ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H04 process group 단위와 외부·zombie 제외 (0.304042ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H05 실행 안전 상한·기능 실패·정리 실패 분리 (0.2315ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H06 실제 소유 자식 exit0/7와 그룹 종료 확인 (65.699ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H07 실제 timeout 자식 종료와 뒤 단계 차단 (118.612667ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H08 출력 초과 종료와 보존량 상한 (34.470792ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H09 정리 소유권·symlink target 보존 (0.868459ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H10 입력 manifest 변조와 symlink 거부 (0.888875ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
LP17-H11 자식만 남긴 종료를 정상 완료로 오인하지 않음 (151.209709ms) | o28-stage4-comparison-green1.log | pass | 실제 Node 결과
FC01 exact insertion checks count=110 | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[bounded-exit] | o28-stage4-cost-case16-regression-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-cost-case16-regression-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
[bounded-exit] | o28-stage4-cost-case16-regression-run2.log |  | [bounded-exit] code=0 signal=none timeout=false (관측값; 단독 PASS 아님)
seed FE02 writer start | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
seed FE04 bound finalized mutation segment0 | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
LP26-O10-A02 typed segment binding tombstone serialization and seed file verification | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-cost-case16-regression-run2.log |  | [probe-process] {"mode":"--generate","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":1586,"groupClosed":true,"peakObservedRssBytes":31768576,"metricsUnavailable":0,"stageLimitMs":null,"technicalCapMs":60000,"diskBytes":15300824,"parentRssBytes":72171520} (관측값; 단독 PASS 아님)
LP26-O10-B 16 initial exact-count-prefix | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-wall] | o28-stage4-cost-case16-regression-run2.log |  | [probe-wall] {"stage":"recovery","elapsedUs":73334,"ok":true} (관측값; 단독 PASS 아님)
LP26-O10-A02 strict Open exact4N and deletedN zero recovery errors | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-wall] | o28-stage4-cost-case16-regression-run2.log |  | [probe-wall] {"stage":"timeline-projection","elapsedUs":161,"ok":true} (관측값; 단독 PASS 아님)
LP26-O14-B exact timeline count and deleted rows | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-wall] | o28-stage4-cost-case16-regression-run2.log |  | [probe-wall] {"stage":"cold-binding","elapsedUs":4903,"ok":true} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-cost-case16-regression-run2.log |  | [probe-wall] {"stage":"checkpoint-cold","elapsedUs":57181,"ok":true} (관측값; 단독 PASS 아님)
[probe-wall] | o28-stage4-cost-case16-regression-run2.log |  | [probe-wall] {"stage":"checkpoint-repeat","elapsedUs":29445,"ok":true} (관측값; 단독 PASS 아님)
LP26-O10-C02 cache prefix or full fallback exact oracle | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-process] | o28-stage4-cost-case16-regression-run2.log |  | [probe-process] {"mode":"--catalog","selectedCase":"16","status":0,"signal":null,"stop":null,"elapsedMs":207,"groupClosed":true,"peakObservedRssBytes":null,"metricsUnavailable":0,"stageLimitMs":15000,"technicalCapMs":65000,"diskBytes":15388262,"parentRssBytes":73121792} (관측값; 단독 PASS 아님)
LP26-O10-B 16 rotated exact-count-prefix | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
LP26-O10-E01 malformed mutation rejected | o28-stage4-cost-case16-regression-run2.log | pass | 실제 개별 결과
[probe-receipt] | o28-stage4-cost-case16-regression-run2.log |  | [probe-receipt] {"preserved":true,"bytes":2679,"sha256":"1b01c7663cb16edd3568d5ad933c19ded7c6eb954f876baf20d220b6f4c1e593","rawPathsPublished":false} (관측값; 단독 PASS 아님)
[probe-reader-cleanup] | o28-stage4-cost-case16-regression-run2.log |  | [probe-reader-cleanup] {"readers":1,"closed":true,"groupsClosed":true,"receiptPreserved":true,"elapsedMs":2287.35925,"diskBytes":15388326,"parentRssBytes":73547776} (관측값; 단독 PASS 아님)
[cleanup] | o28-stage4-cost-case16-regression-run2.log |  | [cleanup] {"root":"/private/var/folders/k0/qhmr6zdx11q0_41wfx4dsd200000gn/T/media-server-catalog-cost.NRQdMv","bytes":15388326,"absent":true} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-cost-case16-regression-run2.log |  | [exit] code=0 elapsed_seconds=11 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
FC01 exact insertion checks count=110 | o28-stage4-cost-case16-regression.log | pass | 실제 개별 결과
[cleanup] | o28-stage4-cost-case16-regression.log |  | [cleanup] {"preserved":true,"reason":"evidence-missing"} (관측값; 단독 PASS 아님)
[exit] | o28-stage4-cost-case16-regression.log |  | [exit] code=2 elapsed_seconds=1 source=bash-SECONDS token_usage=unavailable (관측값; 단독 PASS 아님)
LP26-O10-A01 4N 독립 규모와 최대 bound (0.542208ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.407125ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.476125ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.082833ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.322666ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.091125ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.243416ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (1.109208ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.728542ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.142666ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (11.050959ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.275209ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.147875ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (25.841792ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.777666ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R02 loss row는 고정형만 receipt에 보존 (9.28275ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.219625ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (15.043542ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.676042ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (9.88675ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.106333ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.64775ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-M01 ownership receipt는 성공 전체·generate 실패 prefix·default null command를 구분 (23.896ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.936917ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (5.525334ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (1.39875ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (518.53375ms) | o28-stage4-final-focused.log | pass | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.511709ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.681166ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.158584ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.056541ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.289417ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.089208ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.236417ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (0.47075ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.701041ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.13425ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (10.305ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.252958ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.151167ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (24.580334ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (9.712958ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R02 loss row는 고정형만 receipt에 보존 (7.057917ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.201334ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (18.329458ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (9.606917ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (9.788959ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (2.833125ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.614917ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-M01 ownership receipt는 고정 mode와 실제 command 결속만 허용 (9.71575ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.523666ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (7.110917ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.877875ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (527.27025ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP20-C04 임시 파일 삭제 경쟁은 동일 root의 전체 관측으로 재확인 (1.287667ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP20-C04 반복 관측 실패·권한 실패·root 교체는 계속 거부 (0.6445ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP19-H01 계측 손실 없는 왕복 (1.128083ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP19-H02 잘못된 축약 표현 거부 (0.28875ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H01 기존 RSS 실패와 유효 진단 분리 (0.160083ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H02 관측 누락·손상·역행·잘못된 owner 거부 (0.444791ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H03 완료 summary 누락·중복·다른 작업·실패 거부 (0.174958ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H04 process group 단위와 외부·zombie 제외 (0.238583ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H05 실행 안전 상한·기능 실패·정리 실패 분리 (0.194792ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H06 실제 소유 자식 exit0/7와 그룹 종료 확인 (23.816875ms) | o28-stage4-focused-green1.log | fail | 실제 Node 결과
LP17-H07 실제 timeout 자식 종료와 뒤 단계 차단 (109.16275ms) | o28-stage4-focused-green1.log | fail | 실제 Node 결과
LP17-H08 출력 초과 종료와 보존량 상한 (22.177ms) | o28-stage4-focused-green1.log | fail | 실제 Node 결과
LP17-H09 정리 소유권·symlink target 보존 (0.941125ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H10 입력 manifest 변조와 symlink 거부 (0.950875ms) | o28-stage4-focused-green1.log | pass | 실제 Node 결과
LP17-H11 자식만 남긴 종료를 정상 완료로 오인하지 않음 (23.802583ms) | o28-stage4-focused-green1.log | fail | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.533209ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.340166ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.437208ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.083125ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.305208ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.085292ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.214041ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (0.462667ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.668375ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.132791ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (12.724209ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.310334ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.273792ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (25.799875ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (7.939541ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R02 loss row는 고정형만 receipt에 보존 (8.702167ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.06675ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (17.541083ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.520792ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (6.851959ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.00125ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.626083ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-M01 ownership receipt는 고정 mode와 실제 command 결속만 허용 (8.27325ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.703917ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.789ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.863ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (264.724542ms) | o28-stage4-focused-green2.log | pass | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.52625ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.693ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.11625ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.048583ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.28475ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.077ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.203834ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (0.597083ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH01 phase nesting and completed diagnostic remain distinct from app PASS (0.696584ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH02 timeout preserves last open phase without synthetic completion (0.133083ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH03 partial malformed unknown and secret-bearing trace rows reject (9.727875ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-D01 child termination classes and bounded metadata remain distinct (0.284375ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-D02 missing partial malformed loss and incomplete traces never synthesize completion (0.170917ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R01 known failure와 timeout receipt를 원문 없이 immutable 선보존 (27.312875ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R02 partial trace는 검증된 prefix/open phase만 receipt에 보존 (8.559667ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R02 loss row는 고정형만 receipt에 보존 (7.853917ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R03 source manifest symlink와 receipt schema 변조를 fail closed (1.195375ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R04 동일 입력 receipt 재실행 동등성과 cleanup proof 네 조건 (15.950083ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R04 accumulation receipt는 최초 실패·미종료 group·고정 진단을 결속 (8.844875ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R04 parent drain 실패는 성공 child와 별도로 receipt에 보존 (8.071542ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R04 실제 synthetic child group의 열린 상태와 종료를 구분 (3.049167ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-R04 source manifest는 실행 전 snapshot과 동일 길이 사후 변조를 구분 (0.584167ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-M01 ownership receipt는 고정 mode와 실제 command 결속만 허용 (8.329292ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
O28-C04 accumulation store receipt는 case 저장소만 결속하고 root 도구 symlink는 제외 (2.695542ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH04 owned nofollow copy preserves every byte and rejects foreign scope (6.943542ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH05 changed original or unconfirmed child blocks cleanup (0.940292ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP23-DH06 exact instrumentation drift and trace bounds fail closed (337.900875ms) | o28-stage4-focused-green4.log | pass | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.538208ms) | o28-stage4-focused-red1.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.998125ms) | o28-stage4-focused-red1.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.123125ms) | o28-stage4-focused-red1.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.049292ms) | o28-stage4-focused-red1.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.281417ms) | o28-stage4-focused-red1.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.3275ms) | o28-stage4-focused-red1.log | fail | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (1.771458ms) | o28-stage4-focused-red1.log | fail | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.513125ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.41925ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.453917ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.066583ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.298667ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.079584ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.217458ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (0.472125ms) | o28-stage4-plan-green3.log | pass | 실제 Node 결과
LP26-O10-A01 4N 독립 규모와 최대 bound (0.540625ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
O28-C01 2048 CLI·receipt 허용과 unknown case 거부가 정적으로 연결 (0.423333ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
LP26-O10-B01 정확한 네 type·count·partial/backlog oracle (0.528458ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
LP26-O10-B02 회전 후 fresh0·rotations1이상 oracle (0.051959ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
LP26-O10-F01 복구·checkpoint별15초 독립 경계와 정확한 순서 (0.293375ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
O28-M01 ownership 수명 단계는 별도 allowlist와 동일 15초 경계를 쓴다 (0.089917ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
O28-M01/M02 ownership CLI·collector·receipt 연결은 최대8 reader와 내용 oracle을 고정한다 (0.210125ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
O28-M02 31열 owner와 fresh-process fingerprint collector가 손실·불일치를 거부한다 (0.61675ms) | o28-stage4-wrapper-focused-green.log | pass | 실제 Node 결과
