# B13 인증 진단 개별 실행 결과

독자: v4.1.0 검증 담당자. 수명: 실행 이력 보존. 정책은 AGENTS.md, 중앙 색인은 release-test-records.md다.
red-wrapper는 개별 출력만 보존하며 exit 미확인으로 suite 완료 증거가 아니다. inventory의 내부 5,081행과 최상위 18검사를 구분한다.

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| red-wrapper AUTH-P06 whoami HTTP 상태와 setup JSON 조합을 함께 판정 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P10 임시 비밀번호 변경 실패는 고정 check와 정규화한 HTTP 상태를 진단 | 격리 auth 자체검사; exit 미확인 | fail | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P11 임시 비밀번호 변경 진단은 비정상값을 숨기고 대상 비교에만 출력 | 격리 auth 자체검사; exit 미확인 | fail | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P03 json_quote 비밀은 Node argv에 나타나지 않는다 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P01 실행별 5개 CSPRNG 정책·중복 및 재사용 없음 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P02 xtrace/allexport·inherited 값이 helper 자식에 전달되지 않음 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P03 curl config 내용 보존·argv/환경에는 비밀 없음 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P03 curl 실패는 비밀 원문 없이 HTTP 상태와 전송 종류만 분류 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P03 URL newline·외부주소·옵션주입 거부와 config escaping | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P04 stdin JSON quote escaping·빈값·개행 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P04 Python heredoc sys.argv 의미 보존·OS argv 비노출 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P05 소유 root0700/file0600·불일치 보존·정상 정리 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P06 자식 환경의 상속 credential/provider/proxy 제거 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P07 기존 세 mode만 dispatch하며 알 수 없는 mode는 root 전에 거부 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P08 S06 env 부재에도 기존 child 순서·메모리 auth 모드 선택 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P09 inventory는 새 bootstrap 허용·구형 operator-env 강제 거부 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P05 실제 cleanup 성공·oracle 실패·중단·종료 실패 전파 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P05 실제 stop_server는 비정상 exit·HTTP/RTSP 점유를 거부 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P06 실제 start_server double은 소유 경로·off·비상속 환경을 받는다 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red-wrapper AUTH-P06 setup true 지연·false 실제 config 검사·잘못된 상태 거부 | 격리 auth 자체검사; exit 미확인 | pass | 래퍼 exit 유실; 완료 증거 아님 |
| red AUTH-P06 whoami HTTP 상태와 setup JSON 조합을 함께 판정 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P10 임시 비밀번호 변경 실패는 고정 check와 정규화한 HTTP 상태를 진단 | 격리 auth 자체검사; exit 1 | fail | 신규 진단만 예상 RED |
| red AUTH-P11 임시 비밀번호 변경 진단은 비정상값을 숨기고 대상 비교에만 출력 | 격리 auth 자체검사; exit 1 | fail | 신규 진단만 예상 RED |
| red AUTH-P03 json_quote 비밀은 Node argv에 나타나지 않는다 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P01 실행별 5개 CSPRNG 정책·중복 및 재사용 없음 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P02 xtrace/allexport·inherited 값이 helper 자식에 전달되지 않음 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P03 curl config 내용 보존·argv/환경에는 비밀 없음 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P03 curl 실패는 비밀 원문 없이 HTTP 상태와 전송 종류만 분류 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P03 URL newline·외부주소·옵션주입 거부와 config escaping | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P04 stdin JSON quote escaping·빈값·개행 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P04 Python heredoc sys.argv 의미 보존·OS argv 비노출 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P05 소유 root0700/file0600·불일치 보존·정상 정리 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P06 자식 환경의 상속 credential/provider/proxy 제거 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P07 기존 세 mode만 dispatch하며 알 수 없는 mode는 root 전에 거부 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P08 S06 env 부재에도 기존 child 순서·메모리 auth 모드 선택 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P09 inventory는 새 bootstrap 허용·구형 operator-env 강제 거부 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P05 실제 cleanup 성공·oracle 실패·중단·종료 실패 전파 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P05 실제 stop_server는 비정상 exit·HTTP/RTSP 점유를 거부 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P06 실제 start_server double은 소유 경로·off·비상속 환경을 받는다 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| red AUTH-P06 setup true 지연·false 실제 config 검사·잘못된 상태 거부 | 격리 auth 자체검사; exit 1 | pass | 신규 진단만 예상 RED |
| green AUTH-P06 whoami HTTP 상태와 setup JSON 조합을 함께 판정 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P10 임시 비밀번호 변경 실패는 고정 check와 정규화한 HTTP 상태를 진단 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P11 임시 비밀번호 변경 진단은 비정상값을 숨기고 대상 비교에만 출력 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P03 json_quote 비밀은 Node argv에 나타나지 않는다 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P01 실행별 5개 CSPRNG 정책·중복 및 재사용 없음 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P02 xtrace/allexport·inherited 값이 helper 자식에 전달되지 않음 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P03 curl config 내용 보존·argv/환경에는 비밀 없음 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P03 curl 실패는 비밀 원문 없이 HTTP 상태와 전송 종류만 분류 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P03 URL newline·외부주소·옵션주입 거부와 config escaping | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P04 stdin JSON quote escaping·빈값·개행 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P04 Python heredoc sys.argv 의미 보존·OS argv 비노출 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P05 소유 root0700/file0600·불일치 보존·정상 정리 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P06 자식 환경의 상속 credential/provider/proxy 제거 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P07 기존 세 mode만 dispatch하며 알 수 없는 mode는 root 전에 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P08 S06 env 부재에도 기존 child 순서·메모리 auth 모드 선택 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P09 inventory는 새 bootstrap 허용·구형 operator-env 강제 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P05 실제 cleanup 성공·oracle 실패·중단·종료 실패 전파 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P05 실제 stop_server는 비정상 exit·HTTP/RTSP 점유를 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P06 실제 start_server double은 소유 경로·off·비상속 환경을 받는다 | 격리 auth 자체검사; exit 0 | pass |  |
| green AUTH-P06 setup true 지연·false 실제 config 검사·잘못된 상태 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P06 whoami HTTP 상태와 setup JSON 조합을 함께 판정 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P10 임시 비밀번호 변경 실패는 고정 check와 정규화한 HTTP 상태를 진단 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P11 임시 비밀번호 변경 진단은 비정상값을 숨기고 대상 비교에만 출력 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P03 json_quote 비밀은 Node argv에 나타나지 않는다 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P01 실행별 5개 CSPRNG 정책·중복 및 재사용 없음 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P02 xtrace/allexport·inherited 값이 helper 자식에 전달되지 않음 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P03 curl config 내용 보존·argv/환경에는 비밀 없음 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P03 curl 실패는 비밀 원문 없이 HTTP 상태와 전송 종류만 분류 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P03 URL newline·외부주소·옵션주입 거부와 config escaping | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P04 stdin JSON quote escaping·빈값·개행 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P04 Python heredoc sys.argv 의미 보존·OS argv 비노출 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P05 소유 root0700/file0600·불일치 보존·정상 정리 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P06 자식 환경의 상속 credential/provider/proxy 제거 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P07 기존 세 mode만 dispatch하며 알 수 없는 mode는 root 전에 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P08 S06 env 부재에도 기존 child 순서·메모리 auth 모드 선택 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P09 inventory는 새 bootstrap 허용·구형 operator-env 강제 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P05 실제 cleanup 성공·oracle 실패·중단·종료 실패 전파 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P05 실제 stop_server는 비정상 exit·HTTP/RTSP 점유를 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P06 실제 start_server double은 소유 경로·off·비상속 환경을 받는다 | 격리 auth 자체검사; exit 0 | pass |  |
| green-final AUTH-P06 setup true 지연·false 실제 config 검사·잘못된 상태 거부 | 격리 auth 자체검사; exit 0 | pass |  |
| inventory 1 S05 개별 동작 등록 exact 연결 (실행 증거 아님) | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2 public docs index excludes internal feature inventory | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3 feature inventory pins current release scope | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4 required sections exist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5 historical V280 source-of-truth keeps the 2.x runway boundary explicit | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 6 historical V290 source-of-truth keeps source, published, and roadmap distinct | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 7 inventory summary count 전체 기능 항목 986 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 8 inventory summary count UI 직접 필요 400 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 9 inventory summary count UI 간접 필요 36 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 10 inventory summary count UI 비대상 550 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 11 inventory summary count 테스트 필요 986 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 12 inventory summary count 안정화 대상 976 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 13 inventory summary count UI 풀테스트 대상 424 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 14 inventory summary count 30분 soak 대상 50 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 15 inventory summary count 120분 대상 7 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 16 summary counts match current feature IDs | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 17 implementation evidence manifest matches all feature rows | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 18 feature UI-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 19 feature UI-001 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 20 feature UI-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 21 feature UI-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 22 feature UI-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 23 feature UI-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 24 feature UI-002 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 25 feature UI-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 26 feature UI-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 27 feature UI-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 28 feature UI-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 29 feature UI-003 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 30 feature UI-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 31 feature UI-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 32 feature UI-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 33 feature UI-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 34 feature UI-004 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 35 feature UI-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 36 feature UI-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 37 feature UI-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 38 feature UI-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 39 feature UI-005 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 40 feature UI-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 41 feature UI-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 42 feature UI-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 43 feature UI-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 44 feature UI-006 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 45 feature UI-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 46 feature UI-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 47 feature UI-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 48 feature UI-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 49 feature UI-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 50 feature UI-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 51 feature UI-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 52 feature UI-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 53 feature UI-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 54 feature UI-008 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 55 feature UI-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 56 feature UI-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 57 feature UI-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 58 feature UI-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 59 feature UI-009 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 60 feature UI-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 61 feature UI-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 62 feature UI-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 63 feature UI-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 64 feature UI-010 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 65 feature UI-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 66 feature UI-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 67 feature UI-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 68 feature UI-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 69 feature UI-011 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 70 feature UI-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 71 feature UI-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 72 feature UI-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 73 feature UI-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 74 feature UI-012 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 75 feature UI-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 76 feature UI-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 77 feature UI-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 78 feature UI-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 79 feature UI-013 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 80 feature UI-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 81 feature UI-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 82 feature UI-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 83 feature UI-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 84 feature UI-014 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 85 feature UI-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 86 feature UI-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 87 feature UI-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 88 feature UI-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 89 feature UI-015 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 90 feature UI-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 91 feature UI-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 92 feature UI-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 93 feature UI-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 94 feature UI-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 95 feature UI-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 96 feature UI-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 97 feature UI-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 98 feature UI-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 99 feature UI-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 100 feature UI-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 101 feature UI-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 102 feature UI-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 103 feature UI-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 104 feature UI-018 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 105 feature UI-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 106 feature UI-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 107 feature UI-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 108 feature UI-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 109 feature UI-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 110 feature UI-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 111 feature UI-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 112 feature UI-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 113 feature UI-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 114 feature UI-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 115 feature UI-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 116 feature UI-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 117 feature UI-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 118 feature UI-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 119 feature UI-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 120 feature UI-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 121 feature UI-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 122 feature UI-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 123 feature UI-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 124 feature UI-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 125 feature UI-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 126 feature UI-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 127 feature UI-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 128 feature UI-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 129 feature UI-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 130 feature UI-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 131 feature UI-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 132 feature UI-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 133 feature UI-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 134 feature UI-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 135 feature UI-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 136 feature UI-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 137 feature UI-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 138 feature UI-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 139 feature UI-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 140 feature UI-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 141 feature UI-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 142 feature UI-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 143 feature UI-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 144 feature UI-026 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 145 feature UI-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 146 feature UI-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 147 feature UI-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 148 feature UI-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 149 feature UI-027 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 150 feature UI-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 151 feature UI-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 152 feature UI-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 153 feature UI-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 154 feature UI-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 155 feature UI-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 156 feature UI-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 157 feature UI-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 158 feature UI-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 159 feature UI-029 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 160 feature UI-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 161 feature UI-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 162 feature UI-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 163 feature UI-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 164 feature UI-030 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 165 feature UI-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 166 feature UI-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 167 feature UI-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 168 feature UI-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 169 feature UI-031 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 170 feature UI-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 171 feature UI-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 172 feature UI-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 173 feature UI-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 174 feature UI-032 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 175 feature UI-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 176 feature UI-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 177 feature UI-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 178 feature UI-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 179 feature UI-033 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 180 feature UI-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 181 feature UI-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 182 feature UI-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 183 feature UI-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 184 feature UI-034 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 185 feature UI-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 186 feature UI-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 187 feature UI-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 188 feature UI-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 189 feature UI-035 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 190 feature UI-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 191 feature UI-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 192 feature UI-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 193 feature UI-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 194 feature UI-036 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 195 feature UI-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 196 feature UI-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 197 feature UI-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 198 feature UI-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 199 feature UI-037 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 200 feature UI-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 201 feature UI-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 202 feature UI-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 203 feature UI-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 204 feature UI-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 205 feature UI-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 206 feature UI-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 207 feature UI-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 208 feature UI-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 209 feature UI-039 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 210 feature UI-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 211 feature UI-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 212 feature UI-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 213 feature UI-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 214 feature UI-040 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 215 feature UI-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 216 feature UI-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 217 feature UI-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 218 feature UI-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 219 feature UI-041 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 220 feature UI-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 221 feature UI-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 222 feature UI-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 223 feature UI-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 224 feature UI-042 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 225 feature UI-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 226 feature UI-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 227 feature UI-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 228 feature UI-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 229 feature UI-043 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 230 feature UI-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 231 feature UI-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 232 feature UI-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 233 feature UI-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 234 feature UI-044 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 235 feature UI-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 236 feature UI-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 237 feature UI-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 238 feature UI-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 239 feature UI-045 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 240 feature UI-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 241 feature UI-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 242 feature UI-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 243 feature UI-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 244 feature UI-046 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 245 feature UI-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 246 feature UI-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 247 feature UI-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 248 feature UI-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 249 feature UI-047 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 250 feature UI-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 251 feature UI-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 252 feature UI-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 253 feature UI-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 254 feature UI-048 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 255 feature UI-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 256 feature UI-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 257 feature UI-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 258 feature UI-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 259 feature UI-049 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 260 feature UI-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 261 feature UI-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 262 feature UI-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 263 feature UI-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 264 feature UI-050 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 265 feature UI-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 266 feature UI-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 267 feature UI-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 268 feature UI-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 269 feature UI-051 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 270 feature UI-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 271 feature UI-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 272 feature UI-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 273 feature UI-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 274 feature UI-052 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 275 feature UI-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 276 feature UI-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 277 feature UI-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 278 feature UI-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 279 feature UI-053 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 280 feature UI-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 281 feature UI-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 282 feature UI-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 283 feature UI-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 284 feature UI-054 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 285 feature UI-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 286 feature UI-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 287 feature UI-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 288 feature UI-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 289 feature UI-055 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 290 feature UI-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 291 feature UI-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 292 feature UI-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 293 feature UI-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 294 feature UI-056 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 295 feature UI-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 296 feature UI-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 297 feature UI-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 298 feature UI-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 299 feature UI-057 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 300 feature UI-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 301 feature UI-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 302 feature UI-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 303 feature UI-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 304 feature UI-058 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 305 feature UI-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 306 feature UI-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 307 feature UI-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 308 feature UI-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 309 feature UI-059 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 310 feature UI-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 311 feature UI-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 312 feature UI-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 313 feature UI-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 314 feature UI-060 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 315 feature UI-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 316 feature UI-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 317 feature UI-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 318 feature UI-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 319 feature UI-061 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 320 feature UI-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 321 feature UI-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 322 feature UI-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 323 feature UI-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 324 feature UI-062 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 325 feature UI-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 326 feature UI-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 327 feature UI-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 328 feature UI-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 329 feature UI-063 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 330 feature UI-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 331 feature UI-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 332 feature UI-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 333 feature UI-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 334 feature UI-064 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 335 feature UI-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 336 feature UI-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 337 feature UI-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 338 feature UI-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 339 feature UI-065 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 340 feature UI-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 341 feature UI-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 342 feature UI-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 343 feature UI-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 344 feature UI-066 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 345 feature UI-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 346 feature UI-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 347 feature UI-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 348 feature UI-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 349 feature UI-067 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 350 feature UI-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 351 feature UI-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 352 feature UI-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 353 feature UI-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 354 feature UI-068 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 355 feature UI-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 356 feature UI-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 357 feature UI-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 358 feature UI-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 359 feature UI-069 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 360 feature UI-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 361 feature UI-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 362 feature UI-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 363 feature UI-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 364 feature UI-070 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 365 feature UI-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 366 feature UI-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 367 feature UI-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 368 feature UI-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 369 feature UI-071 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 370 feature UI-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 371 feature UI-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 372 feature UI-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 373 feature UI-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 374 feature UI-072 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 375 feature UI-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 376 feature UI-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 377 feature UI-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 378 feature UI-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 379 feature UI-073 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 380 feature UI-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 381 feature UI-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 382 feature UI-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 383 feature UI-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 384 feature UI-074 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 385 feature UI-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 386 feature UI-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 387 feature UI-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 388 feature UI-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 389 feature UI-075 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 390 feature UI-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 391 feature UI-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 392 feature UI-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 393 feature UI-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 394 feature UI-076 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 395 feature UI-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 396 feature UI-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 397 feature UI-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 398 feature UI-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 399 feature UI-077 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 400 feature UI-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 401 feature UI-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 402 feature UI-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 403 feature UI-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 404 feature UI-078 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 405 feature UI-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 406 feature UI-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 407 feature UI-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 408 feature UI-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 409 feature UI-079 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 410 feature UI-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 411 feature UI-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 412 feature UI-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 413 feature UI-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 414 feature UI-080 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 415 feature UI-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 416 feature UI-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 417 feature UI-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 418 feature UI-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 419 feature UI-081 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 420 feature UI-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 421 feature UI-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 422 feature UI-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 423 feature UI-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 424 feature UI-082 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 425 feature UI-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 426 feature UI-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 427 feature UI-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 428 feature UI-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 429 feature UI-083 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 430 feature UI-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 431 feature UI-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 432 feature UI-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 433 feature UI-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 434 feature UI-084 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 435 feature UI-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 436 feature UI-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 437 feature UI-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 438 feature UI-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 439 feature UI-085 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 440 feature UI-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 441 feature UI-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 442 feature UI-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 443 feature UI-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 444 feature UI-086 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 445 feature UI-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 446 feature UI-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 447 feature UI-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 448 feature UI-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 449 feature UI-087 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 450 feature UI-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 451 feature UI-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 452 feature UI-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 453 feature UI-088 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 454 feature UI-088 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 455 feature UI-088 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 456 feature UI-088 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 457 feature UI-088 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 458 feature UI-089 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 459 feature UI-089 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 460 feature UI-089 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 461 feature UI-089 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 462 feature UI-089 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 463 feature UI-090 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 464 feature UI-090 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 465 feature UI-090 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 466 feature UI-090 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 467 feature UI-090 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 468 feature UI-091 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 469 feature UI-091 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 470 feature UI-091 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 471 feature UI-091 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 472 feature UI-091 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 473 feature UI-092 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 474 feature UI-092 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 475 feature UI-092 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 476 feature UI-092 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 477 feature UI-092 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 478 feature UI-093 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 479 feature UI-093 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 480 feature UI-093 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 481 feature UI-093 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 482 feature UI-093 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 483 feature UI-094 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 484 feature UI-094 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 485 feature UI-094 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 486 feature UI-094 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 487 feature UI-094 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 488 feature UI-095 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 489 feature UI-095 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 490 feature UI-095 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 491 feature UI-095 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 492 feature UI-095 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 493 feature UI-096 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 494 feature UI-096 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 495 feature UI-096 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 496 feature UI-096 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 497 feature UI-096 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 498 feature UI-097 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 499 feature UI-097 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 500 feature UI-097 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 501 feature UI-097 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 502 feature UI-097 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 503 feature UI-098 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 504 feature UI-098 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 505 feature UI-098 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 506 feature UI-098 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 507 feature UI-098 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 508 feature UI-099 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 509 feature UI-099 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 510 feature UI-099 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 511 feature UI-099 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 512 feature UI-099 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 513 feature UI-100 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 514 feature UI-100 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 515 feature UI-100 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 516 feature UI-100 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 517 feature UI-100 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 518 feature UI-101 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 519 feature UI-101 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 520 feature UI-101 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 521 feature UI-101 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 522 feature UI-101 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 523 feature UI-102 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 524 feature UI-102 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 525 feature UI-102 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 526 feature UI-102 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 527 feature UI-102 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 528 feature UI-103 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 529 feature UI-103 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 530 feature UI-103 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 531 feature UI-103 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 532 feature UI-103 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 533 feature UI-104 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 534 feature UI-104 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 535 feature UI-104 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 536 feature UI-104 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 537 feature UI-104 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 538 feature UI-105 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 539 feature UI-105 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 540 feature UI-105 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 541 feature UI-105 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 542 feature UI-105 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 543 feature UI-106 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 544 feature UI-106 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 545 feature UI-106 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 546 feature UI-106 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 547 feature UI-106 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 548 feature UI-107 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 549 feature UI-107 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 550 feature UI-107 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 551 feature UI-107 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 552 feature UI-107 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 553 feature UI-108 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 554 feature UI-108 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 555 feature UI-108 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 556 feature UI-108 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 557 feature UI-108 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 558 feature UI-109 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 559 feature UI-109 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 560 feature UI-109 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 561 feature UI-109 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 562 feature UI-109 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 563 feature UI-110 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 564 feature UI-110 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 565 feature UI-110 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 566 feature UI-110 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 567 feature UI-110 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 568 feature UI-111 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 569 feature UI-111 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 570 feature UI-111 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 571 feature UI-111 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 572 feature UI-111 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 573 feature UI-112 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 574 feature UI-112 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 575 feature UI-112 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 576 feature UI-112 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 577 feature UI-112 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 578 feature UI-113 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 579 feature UI-113 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 580 feature UI-113 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 581 feature UI-113 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 582 feature UI-113 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 583 feature UI-114 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 584 feature UI-114 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 585 feature UI-114 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 586 feature UI-114 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 587 feature UI-114 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 588 feature UI-115 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 589 feature UI-115 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 590 feature UI-115 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 591 feature UI-115 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 592 feature UI-115 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 593 feature AUTH-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 594 feature AUTH-001 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 595 feature AUTH-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 596 feature AUTH-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 597 feature AUTH-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 598 feature AUTH-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 599 feature AUTH-002 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 600 feature AUTH-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 601 feature AUTH-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 602 feature AUTH-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 603 feature AUTH-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 604 feature AUTH-003 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 605 feature AUTH-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 606 feature AUTH-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 607 feature AUTH-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 608 feature AUTH-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 609 feature AUTH-004 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 610 feature AUTH-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 611 feature AUTH-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 612 feature AUTH-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 613 feature AUTH-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 614 feature AUTH-005 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 615 feature AUTH-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 616 feature AUTH-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 617 feature AUTH-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 618 feature AUTH-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 619 feature AUTH-006 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 620 feature AUTH-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 621 feature AUTH-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 622 feature AUTH-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 623 feature AUTH-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 624 feature AUTH-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 625 feature AUTH-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 626 feature AUTH-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 627 feature AUTH-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 628 feature AUTH-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 629 feature AUTH-008 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 630 feature AUTH-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 631 feature AUTH-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 632 feature AUTH-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 633 feature AUTH-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 634 feature AUTH-009 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 635 feature AUTH-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 636 feature AUTH-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 637 feature AUTH-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 638 feature AUTH-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 639 feature AUTH-010 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 640 feature AUTH-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 641 feature AUTH-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 642 feature AUTH-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 643 feature AUTH-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 644 feature AUTH-011 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 645 feature AUTH-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 646 feature AUTH-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 647 feature AUTH-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 648 feature AUTH-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 649 feature AUTH-012 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 650 feature AUTH-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 651 feature AUTH-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 652 feature AUTH-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 653 feature AUTH-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 654 feature AUTH-013 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 655 feature AUTH-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 656 feature AUTH-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 657 feature AUTH-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 658 feature AUTH-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 659 feature AUTH-014 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 660 feature AUTH-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 661 feature AUTH-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 662 feature AUTH-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 663 feature AUTH-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 664 feature AUTH-015 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 665 feature AUTH-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 666 feature AUTH-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 667 feature AUTH-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 668 feature AUTH-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 669 feature AUTH-016 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 670 feature AUTH-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 671 feature AUTH-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 672 feature AUTH-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 673 feature AUTH-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 674 feature AUTH-017 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 675 feature AUTH-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 676 feature AUTH-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 677 feature AUTH-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 678 feature AUTH-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 679 feature AUTH-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 680 feature AUTH-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 681 feature AUTH-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 682 feature AUTH-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 683 feature AUTH-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 684 feature AUTH-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 685 feature AUTH-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 686 feature AUTH-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 687 feature AUTH-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 688 feature AUTH-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 689 feature AUTH-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 690 feature AUTH-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 691 feature AUTH-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 692 feature AUTH-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 693 feature AUTH-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 694 feature AUTH-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 695 feature AUTH-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 696 feature AUTH-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 697 feature AUTH-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 698 feature AUTH-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 699 feature AUTH-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 700 feature AUTH-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 701 feature AUTH-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 702 feature AUTH-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 703 feature AUTH-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 704 feature AUTH-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 705 feature AUTH-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 706 feature AUTH-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 707 feature AUTH-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 708 feature AUTH-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 709 feature AUTH-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 710 feature AUTH-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 711 feature AUTH-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 712 feature AUTH-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 713 feature AUTH-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 714 feature AUTH-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 715 feature AUTH-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 716 feature AUTH-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 717 feature AUTH-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 718 feature AUTH-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 719 feature AUTH-026 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 720 feature AUTH-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 721 feature AUTH-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 722 feature AUTH-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 723 feature AUTH-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 724 feature AUTH-027 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 725 feature AUTH-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 726 feature AUTH-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 727 feature AUTH-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 728 feature AUTH-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 729 feature AUTH-028 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 730 feature AUTH-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 731 feature AUTH-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 732 feature AUTH-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 733 feature AUTH-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 734 feature AUTH-029 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 735 feature AUTH-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 736 feature AUTH-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 737 feature AUTH-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 738 feature AUTH-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 739 feature AUTH-030 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 740 feature AUTH-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 741 feature AUTH-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 742 feature AUTH-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 743 feature AUTH-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 744 feature AUTH-031 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 745 feature AUTH-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 746 feature AUTH-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 747 feature AUTH-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 748 feature AUTH-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 749 feature AUTH-032 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 750 feature AUTH-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 751 feature AUTH-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 752 feature AUTH-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 753 feature AUTH-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 754 feature AUTH-033 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 755 feature AUTH-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 756 feature AUTH-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 757 feature AUTH-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 758 feature AUTH-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 759 feature AUTH-034 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 760 feature AUTH-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 761 feature AUTH-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 762 feature AUTH-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 763 feature AUTH-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 764 feature AUTH-035 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 765 feature AUTH-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 766 feature AUTH-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 767 feature AUTH-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 768 feature AUTH-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 769 feature AUTH-036 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 770 feature AUTH-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 771 feature AUTH-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 772 feature AUTH-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 773 feature AUTH-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 774 feature AUTH-037 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 775 feature AUTH-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 776 feature AUTH-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 777 feature AUTH-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 778 feature AUTH-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 779 feature AUTH-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 780 feature AUTH-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 781 feature AUTH-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 782 feature AUTH-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 783 feature AUTH-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 784 feature AUTH-039 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 785 feature AUTH-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 786 feature AUTH-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 787 feature AUTH-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 788 feature AUTH-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 789 feature AUTH-040 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 790 feature AUTH-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 791 feature AUTH-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 792 feature AUTH-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 793 feature AUTH-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 794 feature AUTH-041 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 795 feature AUTH-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 796 feature AUTH-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 797 feature AUTH-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 798 feature AUTH-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 799 feature AUTH-042 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 800 feature AUTH-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 801 feature AUTH-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 802 feature AUTH-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 803 feature SRC-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 804 feature SRC-001 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 805 feature SRC-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 806 feature SRC-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 807 feature SRC-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 808 feature SRC-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 809 feature SRC-002 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 810 feature SRC-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 811 feature SRC-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 812 feature SRC-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 813 feature SRC-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 814 feature SRC-003 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 815 feature SRC-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 816 feature SRC-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 817 feature SRC-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 818 feature SRC-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 819 feature SRC-004 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 820 feature SRC-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 821 feature SRC-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 822 feature SRC-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 823 feature SRC-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 824 feature SRC-005 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 825 feature SRC-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 826 feature SRC-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 827 feature SRC-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 828 feature SRC-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 829 feature SRC-006 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 830 feature SRC-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 831 feature SRC-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 832 feature SRC-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 833 feature SRC-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 834 feature SRC-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 835 feature SRC-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 836 feature SRC-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 837 feature SRC-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 838 feature SRC-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 839 feature SRC-008 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 840 feature SRC-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 841 feature SRC-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 842 feature SRC-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 843 feature SRC-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 844 feature SRC-009 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 845 feature SRC-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 846 feature SRC-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 847 feature SRC-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 848 feature SRC-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 849 feature SRC-010 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 850 feature SRC-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 851 feature SRC-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 852 feature SRC-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 853 feature SRC-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 854 feature SRC-011 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 855 feature SRC-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 856 feature SRC-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 857 feature SRC-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 858 feature SRC-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 859 feature SRC-012 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 860 feature SRC-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 861 feature SRC-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 862 feature SRC-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 863 feature SRC-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 864 feature SRC-013 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 865 feature SRC-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 866 feature SRC-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 867 feature SRC-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 868 feature SRC-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 869 feature SRC-014 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 870 feature SRC-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 871 feature SRC-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 872 feature SRC-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 873 feature SRC-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 874 feature SRC-015 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 875 feature SRC-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 876 feature SRC-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 877 feature SRC-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 878 feature SRC-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 879 feature SRC-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 880 feature SRC-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 881 feature SRC-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 882 feature SRC-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 883 feature SRC-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 884 feature SRC-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 885 feature SRC-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 886 feature SRC-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 887 feature SRC-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 888 feature SRC-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 889 feature SRC-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 890 feature SRC-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 891 feature SRC-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 892 feature SRC-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 893 feature SRC-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 894 feature SRC-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 895 feature SRC-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 896 feature SRC-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 897 feature SRC-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 898 feature SRC-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 899 feature SRC-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 900 feature SRC-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 901 feature SRC-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 902 feature SRC-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 903 feature SRC-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 904 feature SRC-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 905 feature SRC-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 906 feature SRC-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 907 feature SRC-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 908 feature SRC-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 909 feature SRC-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 910 feature SRC-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 911 feature SRC-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 912 feature SRC-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 913 feature SRC-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 914 feature SRC-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 915 feature SRC-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 916 feature SRC-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 917 feature SRC-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 918 feature SRC-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 919 feature SRC-024 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 920 feature SRC-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 921 feature SRC-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 922 feature SRC-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 923 feature SRC-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 924 feature SRC-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 925 feature SRC-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 926 feature SRC-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 927 feature SRC-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 928 feature SRC-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 929 feature SRC-026 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 930 feature SRC-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 931 feature SRC-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 932 feature SRC-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 933 feature SRC-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 934 feature SRC-027 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 935 feature SRC-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 936 feature SRC-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 937 feature SRC-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 938 feature SRC-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 939 feature SRC-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 940 feature SRC-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 941 feature SRC-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 942 feature SRC-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 943 feature SRC-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 944 feature SRC-029 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 945 feature SRC-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 946 feature SRC-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 947 feature SRC-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 948 feature SRC-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 949 feature SRC-030 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 950 feature SRC-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 951 feature SRC-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 952 feature SRC-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 953 feature SRC-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 954 feature SRC-031 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 955 feature SRC-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 956 feature SRC-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 957 feature SRC-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 958 feature SRC-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 959 feature SRC-032 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 960 feature SRC-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 961 feature SRC-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 962 feature SRC-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 963 feature SRC-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 964 feature SRC-033 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 965 feature SRC-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 966 feature SRC-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 967 feature SRC-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 968 feature SRC-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 969 feature SRC-034 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 970 feature SRC-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 971 feature SRC-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 972 feature SRC-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 973 feature SRC-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 974 feature SRC-035 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 975 feature SRC-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 976 feature SRC-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 977 feature SRC-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 978 feature SRC-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 979 feature SRC-036 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 980 feature SRC-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 981 feature SRC-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 982 feature SRC-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 983 feature SRC-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 984 feature SRC-037 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 985 feature SRC-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 986 feature SRC-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 987 feature SRC-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 988 feature SRC-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 989 feature SRC-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 990 feature SRC-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 991 feature SRC-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 992 feature SRC-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 993 feature SRC-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 994 feature SRC-039 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 995 feature SRC-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 996 feature SRC-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 997 feature SRC-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 998 feature SRC-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 999 feature SRC-040 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1000 feature SRC-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1001 feature SRC-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1002 feature SRC-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1003 feature SRC-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1004 feature SRC-041 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1005 feature SRC-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1006 feature SRC-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1007 feature SRC-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1008 feature SRC-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1009 feature SRC-042 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1010 feature SRC-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1011 feature SRC-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1012 feature SRC-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1013 feature SRC-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1014 feature SRC-043 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1015 feature SRC-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1016 feature SRC-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1017 feature SRC-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1018 feature SRC-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1019 feature SRC-044 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1020 feature SRC-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1021 feature SRC-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1022 feature SRC-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1023 feature SRC-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1024 feature SRC-045 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1025 feature SRC-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1026 feature SRC-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1027 feature SRC-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1028 feature SRC-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1029 feature SRC-046 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1030 feature SRC-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1031 feature SRC-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1032 feature SRC-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1033 feature SRC-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1034 feature SRC-047 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1035 feature SRC-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1036 feature SRC-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1037 feature SRC-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1038 feature SRC-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1039 feature SRC-048 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1040 feature SRC-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1041 feature SRC-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1042 feature SRC-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1043 feature SRC-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1044 feature SRC-049 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1045 feature SRC-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1046 feature SRC-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1047 feature SRC-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1048 feature SRC-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1049 feature SRC-050 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1050 feature SRC-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1051 feature SRC-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1052 feature SRC-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1053 feature SRC-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1054 feature SRC-051 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1055 feature SRC-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1056 feature SRC-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1057 feature SRC-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1058 feature SRC-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1059 feature SRC-052 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1060 feature SRC-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1061 feature SRC-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1062 feature SRC-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1063 feature SRC-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1064 feature SRC-053 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1065 feature SRC-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1066 feature SRC-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1067 feature SRC-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1068 feature SRC-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1069 feature SRC-054 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1070 feature SRC-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1071 feature SRC-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1072 feature SRC-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1073 feature SRC-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1074 feature SRC-055 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1075 feature SRC-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1076 feature SRC-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1077 feature SRC-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1078 feature SRC-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1079 feature SRC-056 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1080 feature SRC-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1081 feature SRC-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1082 feature SRC-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1083 feature SRC-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1084 feature SRC-057 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1085 feature SRC-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1086 feature SRC-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1087 feature SRC-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1088 feature SRC-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1089 feature SRC-058 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1090 feature SRC-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1091 feature SRC-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1092 feature SRC-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1093 feature SRC-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1094 feature SRC-059 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1095 feature SRC-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1096 feature SRC-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1097 feature SRC-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1098 feature SRC-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1099 feature SRC-060 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1100 feature SRC-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1101 feature SRC-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1102 feature SRC-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1103 feature SRC-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1104 feature SRC-061 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1105 feature SRC-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1106 feature SRC-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1107 feature SRC-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1108 feature SRC-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1109 feature SRC-062 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1110 feature SRC-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1111 feature SRC-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1112 feature SRC-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1113 feature SRC-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1114 feature SRC-063 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1115 feature SRC-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1116 feature SRC-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1117 feature SRC-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1118 feature SRC-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1119 feature SRC-064 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1120 feature SRC-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1121 feature SRC-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1122 feature SRC-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1123 feature SRC-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1124 feature SRC-065 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1125 feature SRC-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1126 feature SRC-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1127 feature SRC-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1128 feature SRC-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1129 feature SRC-066 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1130 feature SRC-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1131 feature SRC-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1132 feature SRC-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1133 feature SRC-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1134 feature SRC-067 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1135 feature SRC-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1136 feature SRC-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1137 feature SRC-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1138 feature SRC-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1139 feature SRC-068 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1140 feature SRC-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1141 feature SRC-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1142 feature SRC-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1143 feature RULE-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1144 feature RULE-001 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1145 feature RULE-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1146 feature RULE-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1147 feature RULE-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1148 feature RULE-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1149 feature RULE-002 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1150 feature RULE-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1151 feature RULE-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1152 feature RULE-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1153 feature RULE-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1154 feature RULE-003 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1155 feature RULE-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1156 feature RULE-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1157 feature RULE-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1158 feature RULE-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1159 feature RULE-004 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1160 feature RULE-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1161 feature RULE-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1162 feature RULE-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1163 feature RULE-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1164 feature RULE-005 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1165 feature RULE-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1166 feature RULE-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1167 feature RULE-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1168 feature RULE-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1169 feature RULE-006 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1170 feature RULE-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1171 feature RULE-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1172 feature RULE-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1173 feature RULE-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1174 feature RULE-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1175 feature RULE-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1176 feature RULE-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1177 feature RULE-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1178 feature RULE-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1179 feature RULE-008 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1180 feature RULE-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1181 feature RULE-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1182 feature RULE-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1183 feature RULE-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1184 feature RULE-009 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1185 feature RULE-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1186 feature RULE-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1187 feature RULE-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1188 feature RULE-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1189 feature RULE-010 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1190 feature RULE-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1191 feature RULE-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1192 feature RULE-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1193 feature RULE-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1194 feature RULE-011 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1195 feature RULE-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1196 feature RULE-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1197 feature RULE-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1198 feature RULE-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1199 feature RULE-012 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1200 feature RULE-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1201 feature RULE-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1202 feature RULE-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1203 feature RULE-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1204 feature RULE-013 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1205 feature RULE-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1206 feature RULE-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1207 feature RULE-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1208 feature RULE-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1209 feature RULE-014 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1210 feature RULE-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1211 feature RULE-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1212 feature RULE-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1213 feature RULE-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1214 feature RULE-015 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1215 feature RULE-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1216 feature RULE-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1217 feature RULE-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1218 feature RULE-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1219 feature RULE-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1220 feature RULE-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1221 feature RULE-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1222 feature RULE-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1223 feature RULE-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1224 feature RULE-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1225 feature RULE-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1226 feature RULE-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1227 feature RULE-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1228 feature RULE-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1229 feature RULE-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1230 feature RULE-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1231 feature RULE-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1232 feature RULE-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1233 feature RULE-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1234 feature RULE-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1235 feature RULE-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1236 feature RULE-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1237 feature RULE-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1238 feature RULE-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1239 feature RULE-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1240 feature RULE-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1241 feature RULE-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1242 feature RULE-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1243 feature RULE-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1244 feature RULE-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1245 feature RULE-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1246 feature RULE-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1247 feature RULE-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1248 feature RULE-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1249 feature RULE-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1250 feature RULE-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1251 feature RULE-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1252 feature RULE-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1253 feature RULE-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1254 feature RULE-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1255 feature RULE-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1256 feature RULE-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1257 feature RULE-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1258 feature RULE-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1259 feature RULE-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1260 feature RULE-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1261 feature RULE-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1262 feature RULE-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1263 feature RULE-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1264 feature RULE-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1265 feature RULE-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1266 feature RULE-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1267 feature RULE-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1268 feature RULE-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1269 feature RULE-026 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1270 feature RULE-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1271 feature RULE-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1272 feature RULE-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1273 feature RULE-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1274 feature RULE-027 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1275 feature RULE-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1276 feature RULE-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1277 feature RULE-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1278 feature RULE-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1279 feature RULE-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1280 feature RULE-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1281 feature RULE-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1282 feature RULE-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1283 feature RULE-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1284 feature RULE-029 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1285 feature RULE-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1286 feature RULE-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1287 feature RULE-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1288 feature RULE-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1289 feature RULE-030 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1290 feature RULE-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1291 feature RULE-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1292 feature RULE-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1293 feature RULE-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1294 feature RULE-031 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1295 feature RULE-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1296 feature RULE-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1297 feature RULE-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1298 feature RULE-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1299 feature RULE-032 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1300 feature RULE-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1301 feature RULE-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1302 feature RULE-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1303 feature RULE-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1304 feature RULE-033 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1305 feature RULE-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1306 feature RULE-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1307 feature RULE-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1308 feature RULE-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1309 feature RULE-034 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1310 feature RULE-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1311 feature RULE-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1312 feature RULE-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1313 feature RULE-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1314 feature RULE-035 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1315 feature RULE-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1316 feature RULE-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1317 feature RULE-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1318 feature RULE-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1319 feature RULE-036 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1320 feature RULE-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1321 feature RULE-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1322 feature RULE-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1323 feature RULE-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1324 feature RULE-037 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1325 feature RULE-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1326 feature RULE-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1327 feature RULE-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1328 feature RULE-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1329 feature RULE-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1330 feature RULE-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1331 feature RULE-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1332 feature RULE-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1333 feature RULE-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1334 feature RULE-039 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1335 feature RULE-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1336 feature RULE-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1337 feature RULE-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1338 feature RULE-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1339 feature RULE-040 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1340 feature RULE-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1341 feature RULE-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1342 feature RULE-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1343 feature RULE-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1344 feature RULE-041 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1345 feature RULE-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1346 feature RULE-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1347 feature RULE-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1348 feature RULE-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1349 feature RULE-042 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1350 feature RULE-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1351 feature RULE-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1352 feature RULE-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1353 feature RULE-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1354 feature RULE-043 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1355 feature RULE-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1356 feature RULE-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1357 feature RULE-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1358 feature RULE-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1359 feature RULE-044 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1360 feature RULE-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1361 feature RULE-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1362 feature RULE-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1363 feature RULE-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1364 feature RULE-045 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1365 feature RULE-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1366 feature RULE-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1367 feature RULE-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1368 feature RULE-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1369 feature RULE-046 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1370 feature RULE-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1371 feature RULE-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1372 feature RULE-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1373 feature RULE-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1374 feature RULE-047 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1375 feature RULE-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1376 feature RULE-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1377 feature RULE-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1378 feature RULE-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1379 feature RULE-048 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1380 feature RULE-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1381 feature RULE-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1382 feature RULE-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1383 feature RULE-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1384 feature RULE-049 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1385 feature RULE-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1386 feature RULE-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1387 feature RULE-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1388 feature RULE-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1389 feature RULE-050 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1390 feature RULE-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1391 feature RULE-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1392 feature RULE-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1393 feature RULE-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1394 feature RULE-051 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1395 feature RULE-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1396 feature RULE-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1397 feature RULE-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1398 feature RULE-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1399 feature RULE-052 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1400 feature RULE-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1401 feature RULE-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1402 feature RULE-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1403 feature RULE-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1404 feature RULE-053 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1405 feature RULE-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1406 feature RULE-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1407 feature RULE-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1408 feature RULE-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1409 feature RULE-054 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1410 feature RULE-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1411 feature RULE-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1412 feature RULE-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1413 feature RULE-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1414 feature RULE-055 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1415 feature RULE-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1416 feature RULE-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1417 feature RULE-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1418 feature RULE-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1419 feature RULE-056 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1420 feature RULE-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1421 feature RULE-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1422 feature RULE-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1423 feature RULE-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1424 feature RULE-057 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1425 feature RULE-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1426 feature RULE-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1427 feature RULE-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1428 feature RULE-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1429 feature RULE-058 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1430 feature RULE-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1431 feature RULE-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1432 feature RULE-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1433 feature RULE-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1434 feature RULE-059 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1435 feature RULE-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1436 feature RULE-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1437 feature RULE-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1438 feature RULE-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1439 feature RULE-060 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1440 feature RULE-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1441 feature RULE-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1442 feature RULE-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1443 feature RULE-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1444 feature RULE-061 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1445 feature RULE-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1446 feature RULE-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1447 feature RULE-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1448 feature RULE-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1449 feature RULE-062 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1450 feature RULE-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1451 feature RULE-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1452 feature RULE-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1453 feature RULE-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1454 feature RULE-063 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1455 feature RULE-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1456 feature RULE-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1457 feature RULE-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1458 feature RULE-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1459 feature RULE-064 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1460 feature RULE-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1461 feature RULE-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1462 feature RULE-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1463 feature RULE-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1464 feature RULE-065 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1465 feature RULE-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1466 feature RULE-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1467 feature RULE-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1468 feature RULE-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1469 feature RULE-066 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1470 feature RULE-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1471 feature RULE-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1472 feature RULE-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1473 feature RULE-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1474 feature RULE-067 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1475 feature RULE-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1476 feature RULE-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1477 feature RULE-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1478 feature RULE-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1479 feature RULE-068 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1480 feature RULE-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1481 feature RULE-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1482 feature RULE-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1483 feature RULE-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1484 feature RULE-069 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1485 feature RULE-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1486 feature RULE-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1487 feature RULE-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1488 feature RULE-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1489 feature RULE-070 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1490 feature RULE-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1491 feature RULE-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1492 feature RULE-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1493 feature RULE-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1494 feature RULE-071 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1495 feature RULE-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1496 feature RULE-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1497 feature RULE-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1498 feature RULE-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1499 feature RULE-072 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1500 feature RULE-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1501 feature RULE-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1502 feature RULE-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1503 feature RULE-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1504 feature RULE-073 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1505 feature RULE-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1506 feature RULE-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1507 feature RULE-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1508 feature RULE-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1509 feature RULE-074 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1510 feature RULE-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1511 feature RULE-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1512 feature RULE-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1513 feature RULE-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1514 feature RULE-075 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1515 feature RULE-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1516 feature RULE-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1517 feature RULE-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1518 feature RULE-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1519 feature RULE-076 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1520 feature RULE-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1521 feature RULE-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1522 feature RULE-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1523 feature RULE-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1524 feature RULE-077 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1525 feature RULE-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1526 feature RULE-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1527 feature RULE-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1528 feature RULE-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1529 feature RULE-078 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1530 feature RULE-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1531 feature RULE-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1532 feature RULE-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1533 feature RULE-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1534 feature RULE-079 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1535 feature RULE-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1536 feature RULE-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1537 feature RULE-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1538 feature RULE-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1539 feature RULE-080 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1540 feature RULE-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1541 feature RULE-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1542 feature RULE-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1543 feature RULE-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1544 feature RULE-081 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1545 feature RULE-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1546 feature RULE-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1547 feature RULE-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1548 feature RULE-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1549 feature RULE-082 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1550 feature RULE-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1551 feature RULE-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1552 feature RULE-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1553 feature RULE-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1554 feature RULE-083 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1555 feature RULE-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1556 feature RULE-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1557 feature RULE-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1558 feature RULE-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1559 feature RULE-084 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1560 feature RULE-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1561 feature RULE-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1562 feature RULE-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1563 feature RULE-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1564 feature RULE-085 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1565 feature RULE-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1566 feature RULE-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1567 feature RULE-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1568 feature RULE-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1569 feature RULE-086 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1570 feature RULE-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1571 feature RULE-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1572 feature RULE-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1573 feature RULE-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1574 feature RULE-087 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1575 feature RULE-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1576 feature RULE-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1577 feature RULE-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1578 feature RULE-088 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1579 feature RULE-088 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1580 feature RULE-088 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1581 feature RULE-088 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1582 feature RULE-088 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1583 feature RULE-089 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1584 feature RULE-089 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1585 feature RULE-089 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1586 feature RULE-089 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1587 feature RULE-089 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1588 feature RULE-090 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1589 feature RULE-090 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1590 feature RULE-090 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1591 feature RULE-090 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1592 feature RULE-090 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1593 feature RULE-091 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1594 feature RULE-091 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1595 feature RULE-091 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1596 feature RULE-091 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1597 feature RULE-091 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1598 feature RULE-092 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1599 feature RULE-092 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1600 feature RULE-092 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1601 feature RULE-092 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1602 feature RULE-092 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1603 feature RULE-093 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1604 feature RULE-093 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1605 feature RULE-093 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1606 feature RULE-093 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1607 feature RULE-093 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1608 feature RULE-094 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1609 feature RULE-094 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1610 feature RULE-094 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1611 feature RULE-094 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1612 feature RULE-094 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1613 feature RULE-095 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1614 feature RULE-095 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1615 feature RULE-095 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1616 feature RULE-095 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1617 feature RULE-095 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1618 feature RULE-096 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1619 feature RULE-096 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1620 feature RULE-096 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1621 feature RULE-096 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1622 feature RULE-096 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1623 feature RULE-097 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1624 feature RULE-097 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1625 feature RULE-097 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1626 feature RULE-097 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1627 feature RULE-097 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1628 feature RULE-098 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1629 feature RULE-098 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1630 feature RULE-098 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1631 feature RULE-098 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1632 feature RULE-098 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1633 feature RULE-099 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1634 feature RULE-099 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1635 feature RULE-099 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1636 feature RULE-099 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1637 feature RULE-099 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1638 feature RULE-100 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1639 feature RULE-100 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1640 feature RULE-100 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1641 feature RULE-100 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1642 feature RULE-100 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1643 feature RULE-101 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1644 feature RULE-101 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1645 feature RULE-101 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1646 feature RULE-101 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1647 feature RULE-101 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1648 feature RULE-102 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1649 feature RULE-102 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1650 feature RULE-102 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1651 feature RULE-102 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1652 feature RULE-102 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1653 feature RULE-103 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1654 feature RULE-103 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1655 feature RULE-103 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1656 feature RULE-103 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1657 feature RULE-103 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1658 feature RULE-104 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1659 feature RULE-104 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1660 feature RULE-104 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1661 feature RULE-104 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1662 feature RULE-104 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1663 feature RULE-105 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1664 feature RULE-105 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1665 feature RULE-105 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1666 feature RULE-105 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1667 feature RULE-105 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1668 feature RULE-106 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1669 feature RULE-106 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1670 feature RULE-106 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1671 feature RULE-106 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1672 feature RULE-106 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1673 feature RULE-107 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1674 feature RULE-107 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1675 feature RULE-107 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1676 feature RULE-107 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1677 feature RULE-107 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1678 feature RULE-108 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1679 feature RULE-108 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1680 feature RULE-108 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1681 feature RULE-108 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1682 feature RULE-108 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1683 feature RULE-109 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1684 feature RULE-109 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1685 feature RULE-109 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1686 feature RULE-109 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1687 feature RULE-109 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1688 feature RULE-110 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1689 feature RULE-110 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1690 feature RULE-110 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1691 feature RULE-110 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1692 feature RULE-110 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1693 feature RULE-111 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1694 feature RULE-111 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1695 feature RULE-111 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1696 feature RULE-111 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1697 feature RULE-111 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1698 feature RULE-112 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1699 feature RULE-112 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1700 feature RULE-112 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1701 feature RULE-112 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1702 feature RULE-112 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1703 feature EVT-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1704 feature EVT-001 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1705 feature EVT-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1706 feature EVT-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1707 feature EVT-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1708 feature EVT-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1709 feature EVT-002 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1710 feature EVT-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1711 feature EVT-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1712 feature EVT-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1713 feature EVT-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1714 feature EVT-003 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1715 feature EVT-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1716 feature EVT-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1717 feature EVT-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1718 feature EVT-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1719 feature EVT-004 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1720 feature EVT-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1721 feature EVT-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1722 feature EVT-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1723 feature EVT-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1724 feature EVT-005 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1725 feature EVT-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1726 feature EVT-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1727 feature EVT-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1728 feature EVT-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1729 feature EVT-006 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1730 feature EVT-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1731 feature EVT-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1732 feature EVT-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1733 feature EVT-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1734 feature EVT-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1735 feature EVT-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1736 feature EVT-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1737 feature EVT-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1738 feature EVT-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1739 feature EVT-008 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1740 feature EVT-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1741 feature EVT-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1742 feature EVT-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1743 feature EVT-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1744 feature EVT-009 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1745 feature EVT-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1746 feature EVT-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1747 feature EVT-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1748 feature EVT-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1749 feature EVT-010 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1750 feature EVT-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1751 feature EVT-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1752 feature EVT-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1753 feature EVT-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1754 feature EVT-011 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1755 feature EVT-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1756 feature EVT-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1757 feature EVT-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1758 feature EVT-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1759 feature EVT-012 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1760 feature EVT-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1761 feature EVT-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1762 feature EVT-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1763 feature EVT-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1764 feature EVT-013 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1765 feature EVT-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1766 feature EVT-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1767 feature EVT-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1768 feature EVT-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1769 feature EVT-014 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1770 feature EVT-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1771 feature EVT-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1772 feature EVT-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1773 feature EVT-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1774 feature EVT-015 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1775 feature EVT-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1776 feature EVT-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1777 feature EVT-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1778 feature EVT-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1779 feature EVT-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1780 feature EVT-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1781 feature EVT-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1782 feature EVT-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1783 feature EVT-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1784 feature EVT-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1785 feature EVT-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1786 feature EVT-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1787 feature EVT-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1788 feature EVT-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1789 feature EVT-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1790 feature EVT-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1791 feature EVT-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1792 feature EVT-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1793 feature EVT-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1794 feature EVT-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1795 feature EVT-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1796 feature EVT-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1797 feature EVT-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1798 feature EVT-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1799 feature EVT-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1800 feature EVT-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1801 feature EVT-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1802 feature EVT-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1803 feature EVT-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1804 feature EVT-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1805 feature EVT-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1806 feature EVT-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1807 feature EVT-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1808 feature EVT-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1809 feature EVT-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1810 feature EVT-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1811 feature EVT-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1812 feature EVT-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1813 feature EVT-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1814 feature EVT-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1815 feature EVT-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1816 feature EVT-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1817 feature EVT-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1818 feature EVT-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1819 feature EVT-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1820 feature EVT-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1821 feature EVT-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1822 feature EVT-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1823 feature EVT-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1824 feature EVT-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1825 feature EVT-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1826 feature EVT-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1827 feature EVT-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1828 feature EVT-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1829 feature EVT-026 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1830 feature EVT-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1831 feature EVT-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1832 feature EVT-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1833 feature EVT-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1834 feature EVT-027 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1835 feature EVT-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1836 feature EVT-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1837 feature EVT-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1838 feature EVT-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1839 feature EVT-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1840 feature EVT-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1841 feature EVT-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1842 feature EVT-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1843 feature EVT-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1844 feature EVT-029 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1845 feature EVT-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1846 feature EVT-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1847 feature EVT-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1848 feature EVT-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1849 feature EVT-030 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1850 feature EVT-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1851 feature EVT-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1852 feature EVT-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1853 feature EVT-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1854 feature EVT-031 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1855 feature EVT-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1856 feature EVT-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1857 feature EVT-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1858 feature EVT-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1859 feature EVT-032 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1860 feature EVT-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1861 feature EVT-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1862 feature EVT-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1863 feature EVT-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1864 feature EVT-033 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1865 feature EVT-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1866 feature EVT-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1867 feature EVT-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1868 feature EVT-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1869 feature EVT-034 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1870 feature EVT-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1871 feature EVT-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1872 feature EVT-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1873 feature EVT-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1874 feature EVT-035 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1875 feature EVT-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1876 feature EVT-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1877 feature EVT-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1878 feature EVT-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1879 feature EVT-036 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1880 feature EVT-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1881 feature EVT-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1882 feature EVT-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1883 feature EVT-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1884 feature EVT-037 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1885 feature EVT-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1886 feature EVT-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1887 feature EVT-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1888 feature EVT-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1889 feature EVT-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1890 feature EVT-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1891 feature EVT-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1892 feature EVT-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1893 feature EVT-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1894 feature EVT-039 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1895 feature EVT-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1896 feature EVT-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1897 feature EVT-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1898 feature EVT-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1899 feature EVT-040 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1900 feature EVT-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1901 feature EVT-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1902 feature EVT-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1903 feature EVT-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1904 feature EVT-041 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1905 feature EVT-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1906 feature EVT-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1907 feature EVT-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1908 feature EVT-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1909 feature EVT-042 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1910 feature EVT-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1911 feature EVT-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1912 feature EVT-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1913 feature EVT-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1914 feature EVT-043 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1915 feature EVT-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1916 feature EVT-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1917 feature EVT-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1918 feature EVT-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1919 feature EVT-044 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1920 feature EVT-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1921 feature EVT-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1922 feature EVT-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1923 feature EVT-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1924 feature EVT-045 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1925 feature EVT-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1926 feature EVT-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1927 feature EVT-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1928 feature EVT-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1929 feature EVT-046 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1930 feature EVT-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1931 feature EVT-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1932 feature EVT-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1933 feature EVT-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1934 feature EVT-047 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1935 feature EVT-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1936 feature EVT-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1937 feature EVT-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1938 feature EVT-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1939 feature EVT-048 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1940 feature EVT-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1941 feature EVT-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1942 feature EVT-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1943 feature EVT-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1944 feature EVT-049 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1945 feature EVT-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1946 feature EVT-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1947 feature EVT-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1948 feature EVT-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1949 feature EVT-050 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1950 feature EVT-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1951 feature EVT-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1952 feature EVT-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1953 feature EVT-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1954 feature EVT-051 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1955 feature EVT-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1956 feature EVT-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1957 feature EVT-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1958 feature EVT-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1959 feature EVT-052 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1960 feature EVT-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1961 feature EVT-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1962 feature EVT-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1963 feature EVT-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1964 feature EVT-053 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1965 feature EVT-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1966 feature EVT-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1967 feature EVT-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1968 feature EVT-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1969 feature EVT-054 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1970 feature EVT-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1971 feature EVT-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1972 feature EVT-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1973 feature EVT-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1974 feature EVT-055 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1975 feature EVT-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1976 feature EVT-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1977 feature EVT-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1978 feature EVT-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1979 feature EVT-056 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1980 feature EVT-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1981 feature EVT-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1982 feature EVT-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1983 feature EVT-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1984 feature EVT-057 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1985 feature EVT-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1986 feature EVT-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1987 feature EVT-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1988 feature EVT-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1989 feature EVT-058 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1990 feature EVT-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1991 feature EVT-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1992 feature EVT-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1993 feature EVT-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1994 feature EVT-059 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1995 feature EVT-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1996 feature EVT-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1997 feature EVT-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1998 feature EVT-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 1999 feature EVT-060 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2000 feature EVT-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2001 feature EVT-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2002 feature EVT-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2003 feature EVT-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2004 feature EVT-061 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2005 feature EVT-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2006 feature EVT-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2007 feature EVT-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2008 feature EVT-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2009 feature EVT-062 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2010 feature EVT-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2011 feature EVT-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2012 feature EVT-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2013 feature EVT-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2014 feature EVT-063 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2015 feature EVT-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2016 feature EVT-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2017 feature EVT-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2018 feature EVT-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2019 feature EVT-064 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2020 feature EVT-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2021 feature EVT-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2022 feature EVT-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2023 feature EVT-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2024 feature EVT-065 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2025 feature EVT-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2026 feature EVT-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2027 feature EVT-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2028 feature EVT-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2029 feature EVT-066 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2030 feature EVT-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2031 feature EVT-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2032 feature EVT-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2033 feature EVT-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2034 feature EVT-067 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2035 feature EVT-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2036 feature EVT-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2037 feature EVT-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2038 feature EVT-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2039 feature EVT-068 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2040 feature EVT-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2041 feature EVT-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2042 feature EVT-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2043 feature EVT-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2044 feature EVT-069 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2045 feature EVT-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2046 feature EVT-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2047 feature EVT-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2048 feature EVT-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2049 feature EVT-070 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2050 feature EVT-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2051 feature EVT-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2052 feature EVT-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2053 feature EVT-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2054 feature EVT-071 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2055 feature EVT-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2056 feature EVT-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2057 feature EVT-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2058 feature EVT-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2059 feature EVT-072 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2060 feature EVT-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2061 feature EVT-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2062 feature EVT-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2063 feature EVT-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2064 feature EVT-073 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2065 feature EVT-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2066 feature EVT-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2067 feature EVT-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2068 feature EVT-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2069 feature EVT-074 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2070 feature EVT-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2071 feature EVT-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2072 feature EVT-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2073 feature EVT-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2074 feature EVT-075 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2075 feature EVT-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2076 feature EVT-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2077 feature EVT-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2078 feature EVT-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2079 feature EVT-076 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2080 feature EVT-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2081 feature EVT-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2082 feature EVT-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2083 feature EVT-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2084 feature EVT-077 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2085 feature EVT-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2086 feature EVT-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2087 feature EVT-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2088 feature EVT-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2089 feature EVT-078 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2090 feature EVT-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2091 feature EVT-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2092 feature EVT-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2093 feature EVT-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2094 feature EVT-079 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2095 feature EVT-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2096 feature EVT-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2097 feature EVT-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2098 feature EVT-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2099 feature EVT-080 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2100 feature EVT-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2101 feature EVT-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2102 feature EVT-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2103 feature EVT-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2104 feature EVT-081 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2105 feature EVT-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2106 feature EVT-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2107 feature EVT-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2108 feature EVT-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2109 feature EVT-082 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2110 feature EVT-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2111 feature EVT-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2112 feature EVT-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2113 feature EVT-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2114 feature EVT-083 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2115 feature EVT-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2116 feature EVT-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2117 feature EVT-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2118 feature EVT-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2119 feature EVT-084 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2120 feature EVT-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2121 feature EVT-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2122 feature EVT-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2123 feature EVT-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2124 feature EVT-085 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2125 feature EVT-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2126 feature EVT-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2127 feature EVT-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2128 feature EVT-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2129 feature EVT-086 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2130 feature EVT-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2131 feature EVT-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2132 feature EVT-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2133 feature EVT-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2134 feature EVT-087 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2135 feature EVT-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2136 feature EVT-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2137 feature EVT-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2138 feature CLIENT-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2139 feature CLIENT-001 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2140 feature CLIENT-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2141 feature CLIENT-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2142 feature CLIENT-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2143 feature CLIENT-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2144 feature CLIENT-002 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2145 feature CLIENT-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2146 feature CLIENT-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2147 feature CLIENT-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2148 feature CLIENT-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2149 feature CLIENT-003 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2150 feature CLIENT-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2151 feature CLIENT-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2152 feature CLIENT-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2153 feature CLIENT-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2154 feature CLIENT-004 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2155 feature CLIENT-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2156 feature CLIENT-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2157 feature CLIENT-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2158 feature CLIENT-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2159 feature CLIENT-005 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2160 feature CLIENT-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2161 feature CLIENT-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2162 feature CLIENT-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2163 feature CLIENT-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2164 feature CLIENT-006 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2165 feature CLIENT-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2166 feature CLIENT-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2167 feature CLIENT-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2168 feature CLIENT-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2169 feature CLIENT-007 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2170 feature CLIENT-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2171 feature CLIENT-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2172 feature CLIENT-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2173 feature CLIENT-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2174 feature CLIENT-008 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2175 feature CLIENT-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2176 feature CLIENT-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2177 feature CLIENT-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2178 feature CLIENT-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2179 feature CLIENT-009 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2180 feature CLIENT-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2181 feature CLIENT-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2182 feature CLIENT-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2183 feature CLIENT-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2184 feature CLIENT-010 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2185 feature CLIENT-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2186 feature CLIENT-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2187 feature CLIENT-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2188 feature CLIENT-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2189 feature CLIENT-011 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2190 feature CLIENT-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2191 feature CLIENT-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2192 feature CLIENT-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2193 feature CLIENT-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2194 feature CLIENT-012 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2195 feature CLIENT-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2196 feature CLIENT-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2197 feature CLIENT-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2198 feature CLIENT-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2199 feature CLIENT-013 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2200 feature CLIENT-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2201 feature CLIENT-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2202 feature CLIENT-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2203 feature CLIENT-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2204 feature CLIENT-014 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2205 feature CLIENT-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2206 feature CLIENT-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2207 feature CLIENT-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2208 feature CLIENT-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2209 feature CLIENT-015 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2210 feature CLIENT-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2211 feature CLIENT-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2212 feature CLIENT-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2213 feature CLIENT-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2214 feature CLIENT-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2215 feature CLIENT-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2216 feature CLIENT-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2217 feature CLIENT-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2218 feature CLIENT-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2219 feature CLIENT-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2220 feature CLIENT-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2221 feature CLIENT-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2222 feature CLIENT-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2223 feature CLIENT-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2224 feature CLIENT-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2225 feature CLIENT-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2226 feature CLIENT-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2227 feature CLIENT-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2228 feature CLIENT-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2229 feature CLIENT-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2230 feature CLIENT-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2231 feature CLIENT-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2232 feature CLIENT-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2233 feature CLIENT-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2234 feature CLIENT-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2235 feature CLIENT-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2236 feature CLIENT-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2237 feature CLIENT-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2238 feature CLIENT-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2239 feature CLIENT-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2240 feature CLIENT-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2241 feature CLIENT-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2242 feature CLIENT-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2243 feature CLIENT-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2244 feature CLIENT-022 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2245 feature CLIENT-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2246 feature CLIENT-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2247 feature CLIENT-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2248 feature CLIENT-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2249 feature CLIENT-023 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2250 feature CLIENT-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2251 feature CLIENT-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2252 feature CLIENT-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2253 feature CLIENT-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2254 feature CLIENT-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2255 feature CLIENT-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2256 feature CLIENT-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2257 feature CLIENT-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2258 feature CLIENT-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2259 feature CLIENT-025 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2260 feature CLIENT-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2261 feature CLIENT-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2262 feature CLIENT-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2263 feature CLIENT-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2264 feature CLIENT-026 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2265 feature CLIENT-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2266 feature CLIENT-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2267 feature CLIENT-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2268 feature CLIENT-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2269 feature CLIENT-027 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2270 feature CLIENT-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2271 feature CLIENT-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2272 feature CLIENT-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2273 feature CLIENT-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2274 feature CLIENT-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2275 feature CLIENT-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2276 feature CLIENT-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2277 feature CLIENT-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2278 feature CLIENT-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2279 feature CLIENT-029 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2280 feature CLIENT-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2281 feature CLIENT-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2282 feature CLIENT-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2283 feature CLIENT-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2284 feature CLIENT-030 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2285 feature CLIENT-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2286 feature CLIENT-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2287 feature CLIENT-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2288 feature CLIENT-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2289 feature CLIENT-031 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2290 feature CLIENT-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2291 feature CLIENT-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2292 feature CLIENT-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2293 feature CLIENT-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2294 feature CLIENT-032 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2295 feature CLIENT-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2296 feature CLIENT-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2297 feature CLIENT-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2298 feature CLIENT-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2299 feature CLIENT-033 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2300 feature CLIENT-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2301 feature CLIENT-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2302 feature CLIENT-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2303 feature CLIENT-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2304 feature CLIENT-034 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2305 feature CLIENT-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2306 feature CLIENT-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2307 feature CLIENT-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2308 feature CLIENT-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2309 feature CLIENT-035 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2310 feature CLIENT-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2311 feature CLIENT-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2312 feature CLIENT-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2313 feature CLIENT-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2314 feature CLIENT-036 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2315 feature CLIENT-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2316 feature CLIENT-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2317 feature CLIENT-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2318 feature CLIENT-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2319 feature CLIENT-037 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2320 feature CLIENT-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2321 feature CLIENT-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2322 feature CLIENT-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2323 feature CLIENT-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2324 feature CLIENT-038 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2325 feature CLIENT-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2326 feature CLIENT-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2327 feature CLIENT-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2328 feature CLIENT-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2329 feature CLIENT-039 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2330 feature CLIENT-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2331 feature CLIENT-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2332 feature CLIENT-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2333 feature CLIENT-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2334 feature CLIENT-040 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2335 feature CLIENT-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2336 feature CLIENT-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2337 feature CLIENT-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2338 feature CLIENT-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2339 feature CLIENT-041 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2340 feature CLIENT-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2341 feature CLIENT-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2342 feature CLIENT-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2343 feature CLIENT-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2344 feature CLIENT-042 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2345 feature CLIENT-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2346 feature CLIENT-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2347 feature CLIENT-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2348 feature MEDIA-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2349 feature MEDIA-001 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2350 feature MEDIA-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2351 feature MEDIA-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2352 feature MEDIA-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2353 feature MEDIA-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2354 feature MEDIA-002 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2355 feature MEDIA-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2356 feature MEDIA-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2357 feature MEDIA-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2358 feature MEDIA-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2359 feature MEDIA-003 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2360 feature MEDIA-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2361 feature MEDIA-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2362 feature MEDIA-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2363 feature MEDIA-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2364 feature MEDIA-004 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2365 feature MEDIA-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2366 feature MEDIA-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2367 feature MEDIA-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2368 feature MEDIA-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2369 feature MEDIA-005 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2370 feature MEDIA-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2371 feature MEDIA-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2372 feature MEDIA-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2373 feature MEDIA-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2374 feature MEDIA-006 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2375 feature MEDIA-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2376 feature MEDIA-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2377 feature MEDIA-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2378 feature MEDIA-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2379 feature MEDIA-007 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2380 feature MEDIA-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2381 feature MEDIA-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2382 feature MEDIA-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2383 feature MEDIA-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2384 feature MEDIA-008 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2385 feature MEDIA-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2386 feature MEDIA-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2387 feature MEDIA-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2388 feature MEDIA-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2389 feature MEDIA-009 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2390 feature MEDIA-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2391 feature MEDIA-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2392 feature MEDIA-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2393 feature MEDIA-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2394 feature MEDIA-010 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2395 feature MEDIA-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2396 feature MEDIA-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2397 feature MEDIA-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2398 feature MEDIA-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2399 feature MEDIA-011 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2400 feature MEDIA-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2401 feature MEDIA-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2402 feature MEDIA-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2403 feature MEDIA-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2404 feature MEDIA-012 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2405 feature MEDIA-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2406 feature MEDIA-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2407 feature MEDIA-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2408 feature MEDIA-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2409 feature MEDIA-013 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2410 feature MEDIA-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2411 feature MEDIA-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2412 feature MEDIA-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2413 feature MEDIA-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2414 feature MEDIA-014 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2415 feature MEDIA-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2416 feature MEDIA-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2417 feature MEDIA-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2418 feature MEDIA-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2419 feature MEDIA-015 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2420 feature MEDIA-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2421 feature MEDIA-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2422 feature MEDIA-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2423 feature MEDIA-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2424 feature MEDIA-016 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2425 feature MEDIA-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2426 feature MEDIA-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2427 feature MEDIA-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2428 feature MEDIA-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2429 feature MEDIA-017 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2430 feature MEDIA-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2431 feature MEDIA-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2432 feature MEDIA-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2433 feature MEDIA-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2434 feature MEDIA-018 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2435 feature MEDIA-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2436 feature MEDIA-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2437 feature MEDIA-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2438 feature MEDIA-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2439 feature MEDIA-019 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2440 feature MEDIA-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2441 feature MEDIA-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2442 feature MEDIA-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2443 feature MEDIA-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2444 feature MEDIA-020 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2445 feature MEDIA-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2446 feature MEDIA-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2447 feature MEDIA-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2448 feature MEDIA-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2449 feature MEDIA-021 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2450 feature MEDIA-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2451 feature MEDIA-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2452 feature MEDIA-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2453 feature MEDIA-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2454 feature MEDIA-022 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2455 feature MEDIA-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2456 feature MEDIA-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2457 feature MEDIA-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2458 feature MEDIA-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2459 feature MEDIA-023 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2460 feature MEDIA-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2461 feature MEDIA-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2462 feature MEDIA-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2463 feature MEDIA-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2464 feature MEDIA-024 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2465 feature MEDIA-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2466 feature MEDIA-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2467 feature MEDIA-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2468 feature MEDIA-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2469 feature MEDIA-025 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2470 feature MEDIA-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2471 feature MEDIA-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2472 feature MEDIA-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2473 feature MEDIA-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2474 feature MEDIA-026 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2475 feature MEDIA-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2476 feature MEDIA-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2477 feature MEDIA-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2478 feature MEDIA-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2479 feature MEDIA-027 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2480 feature MEDIA-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2481 feature MEDIA-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2482 feature MEDIA-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2483 feature LAB-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2484 feature LAB-001 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2485 feature LAB-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2486 feature LAB-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2487 feature LAB-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2488 feature LAB-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2489 feature LAB-002 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2490 feature LAB-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2491 feature LAB-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2492 feature LAB-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2493 feature LAB-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2494 feature LAB-003 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2495 feature LAB-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2496 feature LAB-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2497 feature LAB-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2498 feature LAB-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2499 feature LAB-004 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2500 feature LAB-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2501 feature LAB-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2502 feature LAB-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2503 feature LAB-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2504 feature LAB-005 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2505 feature LAB-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2506 feature LAB-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2507 feature LAB-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2508 feature LAB-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2509 feature LAB-006 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2510 feature LAB-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2511 feature LAB-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2512 feature LAB-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2513 feature LAB-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2514 feature LAB-007 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2515 feature LAB-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2516 feature LAB-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2517 feature LAB-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2518 feature LAB-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2519 feature LAB-008 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2520 feature LAB-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2521 feature LAB-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2522 feature LAB-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2523 feature LAB-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2524 feature LAB-009 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2525 feature LAB-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2526 feature LAB-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2527 feature LAB-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2528 feature LAB-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2529 feature LAB-010 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2530 feature LAB-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2531 feature LAB-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2532 feature LAB-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2533 feature LAB-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2534 feature LAB-011 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2535 feature LAB-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2536 feature LAB-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2537 feature LAB-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2538 feature LAB-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2539 feature LAB-012 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2540 feature LAB-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2541 feature LAB-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2542 feature LAB-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2543 feature LAB-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2544 feature LAB-013 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2545 feature LAB-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2546 feature LAB-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2547 feature LAB-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2548 feature LAB-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2549 feature LAB-014 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2550 feature LAB-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2551 feature LAB-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2552 feature LAB-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2553 feature LAB-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2554 feature LAB-015 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2555 feature LAB-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2556 feature LAB-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2557 feature LAB-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2558 feature LAB-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2559 feature LAB-016 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2560 feature LAB-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2561 feature LAB-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2562 feature LAB-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2563 feature LAB-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2564 feature LAB-017 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2565 feature LAB-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2566 feature LAB-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2567 feature LAB-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2568 feature LAB-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2569 feature LAB-018 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2570 feature LAB-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2571 feature LAB-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2572 feature LAB-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2573 feature LAB-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2574 feature LAB-019 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2575 feature LAB-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2576 feature LAB-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2577 feature LAB-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2578 feature LAB-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2579 feature LAB-020 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2580 feature LAB-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2581 feature LAB-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2582 feature LAB-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2583 feature LAB-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2584 feature LAB-021 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2585 feature LAB-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2586 feature LAB-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2587 feature LAB-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2588 feature LAB-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2589 feature LAB-022 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2590 feature LAB-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2591 feature LAB-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2592 feature LAB-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2593 feature LAB-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2594 feature LAB-023 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2595 feature LAB-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2596 feature LAB-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2597 feature LAB-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2598 feature LAB-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2599 feature LAB-024 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2600 feature LAB-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2601 feature LAB-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2602 feature LAB-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2603 feature LAB-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2604 feature LAB-025 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2605 feature LAB-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2606 feature LAB-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2607 feature LAB-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2608 feature LAB-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2609 feature LAB-026 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2610 feature LAB-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2611 feature LAB-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2612 feature LAB-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2613 feature LAB-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2614 feature LAB-027 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2615 feature LAB-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2616 feature LAB-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2617 feature LAB-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2618 feature LAB-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2619 feature LAB-028 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2620 feature LAB-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2621 feature LAB-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2622 feature LAB-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2623 feature LAB-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2624 feature LAB-029 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2625 feature LAB-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2626 feature LAB-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2627 feature LAB-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2628 feature LAB-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2629 feature LAB-030 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2630 feature LAB-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2631 feature LAB-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2632 feature LAB-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2633 feature LAB-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2634 feature LAB-031 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2635 feature LAB-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2636 feature LAB-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2637 feature LAB-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2638 feature LAB-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2639 feature LAB-032 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2640 feature LAB-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2641 feature LAB-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2642 feature LAB-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2643 feature LAB-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2644 feature LAB-033 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2645 feature LAB-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2646 feature LAB-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2647 feature LAB-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2648 feature LAB-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2649 feature LAB-034 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2650 feature LAB-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2651 feature LAB-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2652 feature LAB-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2653 feature LAB-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2654 feature LAB-035 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2655 feature LAB-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2656 feature LAB-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2657 feature LAB-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2658 feature LAB-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2659 feature LAB-036 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2660 feature LAB-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2661 feature LAB-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2662 feature LAB-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2663 feature LAB-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2664 feature LAB-037 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2665 feature LAB-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2666 feature LAB-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2667 feature LAB-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2668 feature LAB-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2669 feature LAB-038 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2670 feature LAB-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2671 feature LAB-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2672 feature LAB-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2673 feature LAB-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2674 feature LAB-039 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2675 feature LAB-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2676 feature LAB-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2677 feature LAB-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2678 feature LAB-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2679 feature LAB-040 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2680 feature LAB-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2681 feature LAB-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2682 feature LAB-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2683 feature LAB-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2684 feature LAB-041 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2685 feature LAB-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2686 feature LAB-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2687 feature LAB-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2688 feature LAB-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2689 feature LAB-042 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2690 feature LAB-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2691 feature LAB-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2692 feature LAB-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2693 feature LAB-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2694 feature LAB-043 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2695 feature LAB-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2696 feature LAB-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2697 feature LAB-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2698 feature LAB-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2699 feature LAB-044 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2700 feature LAB-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2701 feature LAB-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2702 feature LAB-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2703 feature LAB-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2704 feature LAB-045 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2705 feature LAB-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2706 feature LAB-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2707 feature LAB-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2708 feature LAB-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2709 feature LAB-046 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2710 feature LAB-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2711 feature LAB-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2712 feature LAB-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2713 feature LAB-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2714 feature LAB-047 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2715 feature LAB-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2716 feature LAB-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2717 feature LAB-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2718 feature LAB-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2719 feature LAB-048 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2720 feature LAB-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2721 feature LAB-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2722 feature LAB-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2723 feature LAB-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2724 feature LAB-049 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2725 feature LAB-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2726 feature LAB-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2727 feature LAB-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2728 feature LAB-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2729 feature LAB-050 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2730 feature LAB-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2731 feature LAB-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2732 feature LAB-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2733 feature LAB-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2734 feature LAB-051 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2735 feature LAB-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2736 feature LAB-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2737 feature LAB-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2738 feature LAB-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2739 feature LAB-052 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2740 feature LAB-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2741 feature LAB-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2742 feature LAB-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2743 feature LAB-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2744 feature LAB-053 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2745 feature LAB-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2746 feature LAB-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2747 feature LAB-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2748 feature LAB-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2749 feature LAB-054 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2750 feature LAB-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2751 feature LAB-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2752 feature LAB-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2753 feature LAB-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2754 feature LAB-055 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2755 feature LAB-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2756 feature LAB-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2757 feature LAB-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2758 feature LAB-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2759 feature LAB-056 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2760 feature LAB-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2761 feature LAB-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2762 feature LAB-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2763 feature LAB-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2764 feature LAB-057 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2765 feature LAB-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2766 feature LAB-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2767 feature LAB-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2768 feature LAB-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2769 feature LAB-058 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2770 feature LAB-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2771 feature LAB-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2772 feature LAB-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2773 feature LAB-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2774 feature LAB-059 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2775 feature LAB-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2776 feature LAB-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2777 feature LAB-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2778 feature LAB-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2779 feature LAB-060 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2780 feature LAB-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2781 feature LAB-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2782 feature LAB-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2783 feature LAB-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2784 feature LAB-061 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2785 feature LAB-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2786 feature LAB-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2787 feature LAB-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2788 feature LAB-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2789 feature LAB-062 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2790 feature LAB-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2791 feature LAB-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2792 feature LAB-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2793 feature LAB-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2794 feature LAB-063 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2795 feature LAB-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2796 feature LAB-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2797 feature LAB-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2798 feature LAB-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2799 feature LAB-064 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2800 feature LAB-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2801 feature LAB-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2802 feature LAB-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2803 feature LAB-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2804 feature LAB-065 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2805 feature LAB-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2806 feature LAB-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2807 feature LAB-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2808 feature LAB-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2809 feature LAB-066 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2810 feature LAB-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2811 feature LAB-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2812 feature LAB-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2813 feature LAB-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2814 feature LAB-067 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2815 feature LAB-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2816 feature LAB-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2817 feature LAB-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2818 feature LAB-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2819 feature LAB-068 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2820 feature LAB-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2821 feature LAB-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2822 feature LAB-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2823 feature LAB-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2824 feature LAB-069 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2825 feature LAB-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2826 feature LAB-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2827 feature LAB-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2828 feature LAB-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2829 feature LAB-070 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2830 feature LAB-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2831 feature LAB-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2832 feature LAB-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2833 feature LAB-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2834 feature LAB-071 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2835 feature LAB-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2836 feature LAB-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2837 feature LAB-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2838 feature LAB-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2839 feature LAB-072 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2840 feature LAB-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2841 feature LAB-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2842 feature LAB-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2843 feature LAB-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2844 feature LAB-073 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2845 feature LAB-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2846 feature LAB-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2847 feature LAB-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2848 feature LAB-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2849 feature LAB-074 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2850 feature LAB-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2851 feature LAB-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2852 feature LAB-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2853 feature LAB-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2854 feature LAB-075 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2855 feature LAB-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2856 feature LAB-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2857 feature LAB-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2858 feature LAB-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2859 feature LAB-076 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2860 feature LAB-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2861 feature LAB-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2862 feature LAB-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2863 feature LAB-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2864 feature LAB-077 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2865 feature LAB-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2866 feature LAB-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2867 feature LAB-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2868 feature LAB-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2869 feature LAB-078 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2870 feature LAB-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2871 feature LAB-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2872 feature LAB-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2873 feature LAB-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2874 feature LAB-079 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2875 feature LAB-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2876 feature LAB-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2877 feature LAB-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2878 feature LAB-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2879 feature LAB-080 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2880 feature LAB-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2881 feature LAB-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2882 feature LAB-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2883 feature LAB-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2884 feature LAB-081 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2885 feature LAB-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2886 feature LAB-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2887 feature LAB-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2888 feature LAB-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2889 feature LAB-082 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2890 feature LAB-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2891 feature LAB-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2892 feature LAB-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2893 feature LAB-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2894 feature LAB-083 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2895 feature LAB-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2896 feature LAB-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2897 feature LAB-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2898 feature LAB-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2899 feature LAB-084 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2900 feature LAB-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2901 feature LAB-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2902 feature LAB-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2903 feature LAB-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2904 feature LAB-085 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2905 feature LAB-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2906 feature LAB-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2907 feature LAB-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2908 feature LAB-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2909 feature LAB-086 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2910 feature LAB-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2911 feature LAB-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2912 feature LAB-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2913 feature LAB-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2914 feature LAB-087 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2915 feature LAB-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2916 feature LAB-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2917 feature LAB-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2918 feature LAB-088 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2919 feature LAB-088 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2920 feature LAB-088 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2921 feature LAB-088 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2922 feature LAB-088 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2923 feature LAB-089 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2924 feature LAB-089 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2925 feature LAB-089 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2926 feature LAB-089 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2927 feature LAB-089 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2928 feature LAB-090 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2929 feature LAB-090 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2930 feature LAB-090 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2931 feature LAB-090 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2932 feature LAB-090 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2933 feature LAB-091 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2934 feature LAB-091 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2935 feature LAB-091 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2936 feature LAB-091 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2937 feature LAB-091 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2938 feature LAB-092 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2939 feature LAB-092 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2940 feature LAB-092 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2941 feature LAB-092 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2942 feature LAB-092 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2943 feature LAB-093 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2944 feature LAB-093 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2945 feature LAB-093 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2946 feature LAB-093 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2947 feature LAB-093 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2948 feature LAB-094 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2949 feature LAB-094 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2950 feature LAB-094 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2951 feature LAB-094 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2952 feature LAB-094 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2953 feature LAB-095 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2954 feature LAB-095 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2955 feature LAB-095 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2956 feature LAB-095 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2957 feature LAB-095 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2958 feature LAB-096 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2959 feature LAB-096 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2960 feature LAB-096 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2961 feature LAB-096 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2962 feature LAB-096 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2963 feature LAB-097 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2964 feature LAB-097 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2965 feature LAB-097 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2966 feature LAB-097 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2967 feature LAB-097 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2968 feature LAB-098 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2969 feature LAB-098 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2970 feature LAB-098 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2971 feature LAB-098 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2972 feature LAB-098 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2973 feature LAB-099 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2974 feature LAB-099 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2975 feature LAB-099 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2976 feature LAB-099 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2977 feature LAB-099 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2978 feature LAB-100 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2979 feature LAB-100 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2980 feature LAB-100 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2981 feature LAB-100 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2982 feature LAB-100 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2983 feature LAB-101 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2984 feature LAB-101 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2985 feature LAB-101 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2986 feature LAB-101 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2987 feature LAB-101 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2988 feature LAB-102 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2989 feature LAB-102 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2990 feature LAB-102 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2991 feature LAB-102 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2992 feature LAB-102 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2993 feature LAB-103 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2994 feature LAB-103 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2995 feature LAB-103 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2996 feature LAB-103 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2997 feature LAB-103 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2998 feature LAB-104 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 2999 feature LAB-104 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3000 feature LAB-104 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3001 feature LAB-104 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3002 feature LAB-104 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3003 feature LAB-105 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3004 feature LAB-105 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3005 feature LAB-105 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3006 feature LAB-105 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3007 feature LAB-105 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3008 feature LAB-106 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3009 feature LAB-106 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3010 feature LAB-106 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3011 feature LAB-106 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3012 feature LAB-106 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3013 feature LAB-107 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3014 feature LAB-107 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3015 feature LAB-107 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3016 feature LAB-107 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3017 feature LAB-107 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3018 feature LAB-108 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3019 feature LAB-108 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3020 feature LAB-108 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3021 feature LAB-108 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3022 feature LAB-108 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3023 feature LAB-109 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3024 feature LAB-109 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3025 feature LAB-109 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3026 feature LAB-109 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3027 feature LAB-109 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3028 feature LAB-110 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3029 feature LAB-110 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3030 feature LAB-110 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3031 feature LAB-110 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3032 feature LAB-110 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3033 feature LAB-111 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3034 feature LAB-111 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3035 feature LAB-111 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3036 feature LAB-111 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3037 feature LAB-111 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3038 feature LAB-112 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3039 feature LAB-112 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3040 feature LAB-112 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3041 feature LAB-112 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3042 feature LAB-112 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3043 feature LAB-113 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3044 feature LAB-113 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3045 feature LAB-113 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3046 feature LAB-113 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3047 feature LAB-113 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3048 feature LAB-114 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3049 feature LAB-114 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3050 feature LAB-114 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3051 feature LAB-114 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3052 feature LAB-114 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3053 feature LAB-115 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3054 feature LAB-115 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3055 feature LAB-115 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3056 feature LAB-115 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3057 feature LAB-115 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3058 feature LAB-116 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3059 feature LAB-116 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3060 feature LAB-116 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3061 feature LAB-116 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3062 feature LAB-116 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3063 feature LAB-117 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3064 feature LAB-117 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3065 feature LAB-117 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3066 feature LAB-117 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3067 feature LAB-117 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3068 feature LAB-118 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3069 feature LAB-118 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3070 feature LAB-118 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3071 feature LAB-118 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3072 feature LAB-118 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3073 feature LAB-119 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3074 feature LAB-119 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3075 feature LAB-119 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3076 feature LAB-119 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3077 feature LAB-119 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3078 feature LAB-120 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3079 feature LAB-120 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3080 feature LAB-120 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3081 feature LAB-120 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3082 feature LAB-120 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3083 feature LAB-121 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3084 feature LAB-121 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3085 feature LAB-121 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3086 feature LAB-121 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3087 feature LAB-121 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3088 feature LAB-122 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3089 feature LAB-122 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3090 feature LAB-122 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3091 feature LAB-122 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3092 feature LAB-122 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3093 feature LAB-123 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3094 feature LAB-123 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3095 feature LAB-123 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3096 feature LAB-123 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3097 feature LAB-123 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3098 feature LAB-124 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3099 feature LAB-124 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3100 feature LAB-124 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3101 feature LAB-124 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3102 feature LAB-124 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3103 feature LAB-125 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3104 feature LAB-125 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3105 feature LAB-125 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3106 feature LAB-125 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3107 feature LAB-125 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3108 feature LAB-126 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3109 feature LAB-126 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3110 feature LAB-126 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3111 feature LAB-126 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3112 feature LAB-126 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3113 feature SAFE-001 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3114 feature SAFE-001 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3115 feature SAFE-001 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3116 feature SAFE-001 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3117 feature SAFE-001 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3118 feature SAFE-002 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3119 feature SAFE-002 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3120 feature SAFE-002 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3121 feature SAFE-002 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3122 feature SAFE-002 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3123 feature SAFE-003 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3124 feature SAFE-003 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3125 feature SAFE-003 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3126 feature SAFE-003 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3127 feature SAFE-003 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3128 feature SAFE-004 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3129 feature SAFE-004 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3130 feature SAFE-004 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3131 feature SAFE-004 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3132 feature SAFE-004 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3133 feature SAFE-005 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3134 feature SAFE-005 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3135 feature SAFE-005 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3136 feature SAFE-005 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3137 feature SAFE-005 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3138 feature SAFE-006 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3139 feature SAFE-006 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3140 feature SAFE-006 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3141 feature SAFE-006 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3142 feature SAFE-006 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3143 feature SAFE-007 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3144 feature SAFE-007 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3145 feature SAFE-007 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3146 feature SAFE-007 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3147 feature SAFE-007 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3148 feature SAFE-008 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3149 feature SAFE-008 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3150 feature SAFE-008 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3151 feature SAFE-008 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3152 feature SAFE-008 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3153 feature SAFE-009 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3154 feature SAFE-009 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3155 feature SAFE-009 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3156 feature SAFE-009 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3157 feature SAFE-009 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3158 feature SAFE-010 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3159 feature SAFE-010 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3160 feature SAFE-010 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3161 feature SAFE-010 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3162 feature SAFE-010 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3163 feature SAFE-011 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3164 feature SAFE-011 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3165 feature SAFE-011 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3166 feature SAFE-011 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3167 feature SAFE-011 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3168 feature SAFE-012 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3169 feature SAFE-012 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3170 feature SAFE-012 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3171 feature SAFE-012 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3172 feature SAFE-012 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3173 feature SAFE-013 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3174 feature SAFE-013 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3175 feature SAFE-013 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3176 feature SAFE-013 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3177 feature SAFE-013 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3178 feature SAFE-014 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3179 feature SAFE-014 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3180 feature SAFE-014 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3181 feature SAFE-014 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3182 feature SAFE-014 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3183 feature SAFE-015 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3184 feature SAFE-015 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3185 feature SAFE-015 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3186 feature SAFE-015 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3187 feature SAFE-015 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3188 feature SAFE-016 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3189 feature SAFE-016 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3190 feature SAFE-016 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3191 feature SAFE-016 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3192 feature SAFE-016 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3193 feature SAFE-017 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3194 feature SAFE-017 UI need 간접 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3195 feature SAFE-017 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3196 feature SAFE-017 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3197 feature SAFE-017 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3198 feature SAFE-018 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3199 feature SAFE-018 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3200 feature SAFE-018 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3201 feature SAFE-018 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3202 feature SAFE-018 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3203 feature SAFE-019 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3204 feature SAFE-019 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3205 feature SAFE-019 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3206 feature SAFE-019 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3207 feature SAFE-019 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3208 feature SAFE-020 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3209 feature SAFE-020 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3210 feature SAFE-020 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3211 feature SAFE-020 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3212 feature SAFE-020 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3213 feature SAFE-021 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3214 feature SAFE-021 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3215 feature SAFE-021 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3216 feature SAFE-021 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3217 feature SAFE-021 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3218 feature SAFE-022 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3219 feature SAFE-022 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3220 feature SAFE-022 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3221 feature SAFE-022 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3222 feature SAFE-022 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3223 feature SAFE-023 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3224 feature SAFE-023 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3225 feature SAFE-023 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3226 feature SAFE-023 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3227 feature SAFE-023 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3228 feature SAFE-024 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3229 feature SAFE-024 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3230 feature SAFE-024 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3231 feature SAFE-024 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3232 feature SAFE-024 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3233 feature SAFE-025 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3234 feature SAFE-025 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3235 feature SAFE-025 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3236 feature SAFE-025 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3237 feature SAFE-025 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3238 feature SAFE-026 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3239 feature SAFE-026 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3240 feature SAFE-026 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3241 feature SAFE-026 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3242 feature SAFE-026 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3243 feature SAFE-027 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3244 feature SAFE-027 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3245 feature SAFE-027 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3246 feature SAFE-027 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3247 feature SAFE-027 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3248 feature SAFE-028 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3249 feature SAFE-028 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3250 feature SAFE-028 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3251 feature SAFE-028 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3252 feature SAFE-028 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3253 feature SAFE-029 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3254 feature SAFE-029 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3255 feature SAFE-029 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3256 feature SAFE-029 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3257 feature SAFE-029 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3258 feature SAFE-030 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3259 feature SAFE-030 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3260 feature SAFE-030 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3261 feature SAFE-030 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3262 feature SAFE-030 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3263 feature SAFE-031 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3264 feature SAFE-031 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3265 feature SAFE-031 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3266 feature SAFE-031 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3267 feature SAFE-031 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3268 feature SAFE-032 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3269 feature SAFE-032 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3270 feature SAFE-032 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3271 feature SAFE-032 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3272 feature SAFE-032 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3273 feature SAFE-033 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3274 feature SAFE-033 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3275 feature SAFE-033 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3276 feature SAFE-033 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3277 feature SAFE-033 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3278 feature SAFE-034 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3279 feature SAFE-034 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3280 feature SAFE-034 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3281 feature SAFE-034 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3282 feature SAFE-034 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3283 feature SAFE-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3284 feature SAFE-035 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3285 feature SAFE-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3286 feature SAFE-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3287 feature SAFE-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3288 feature SAFE-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3289 feature SAFE-036 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3290 feature SAFE-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3291 feature SAFE-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3292 feature SAFE-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3293 feature SAFE-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3294 feature SAFE-037 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3295 feature SAFE-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3296 feature SAFE-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3297 feature SAFE-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3298 feature SAFE-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3299 feature SAFE-038 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3300 feature SAFE-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3301 feature SAFE-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3302 feature SAFE-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3303 feature SAFE-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3304 feature SAFE-039 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3305 feature SAFE-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3306 feature SAFE-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3307 feature SAFE-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3308 feature SAFE-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3309 feature SAFE-040 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3310 feature SAFE-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3311 feature SAFE-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3312 feature SAFE-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3313 feature SAFE-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3314 feature SAFE-041 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3315 feature SAFE-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3316 feature SAFE-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3317 feature SAFE-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3318 feature SAFE-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3319 feature SAFE-042 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3320 feature SAFE-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3321 feature SAFE-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3322 feature SAFE-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3323 feature SAFE-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3324 feature SAFE-043 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3325 feature SAFE-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3326 feature SAFE-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3327 feature SAFE-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3328 feature SAFE-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3329 feature SAFE-044 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3330 feature SAFE-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3331 feature SAFE-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3332 feature SAFE-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3333 feature SAFE-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3334 feature SAFE-045 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3335 feature SAFE-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3336 feature SAFE-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3337 feature SAFE-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3338 feature SAFE-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3339 feature SAFE-046 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3340 feature SAFE-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3341 feature SAFE-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3342 feature SAFE-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3343 feature SAFE-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3344 feature SAFE-047 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3345 feature SAFE-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3346 feature SAFE-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3347 feature SAFE-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3348 feature SAFE-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3349 feature SAFE-048 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3350 feature SAFE-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3351 feature SAFE-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3352 feature SAFE-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3353 feature SAFE-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3354 feature SAFE-049 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3355 feature SAFE-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3356 feature SAFE-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3357 feature SAFE-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3358 feature SAFE-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3359 feature SAFE-050 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3360 feature SAFE-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3361 feature SAFE-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3362 feature SAFE-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3363 feature SAFE-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3364 feature SAFE-051 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3365 feature SAFE-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3366 feature SAFE-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3367 feature SAFE-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3368 feature SAFE-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3369 feature SAFE-052 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3370 feature SAFE-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3371 feature SAFE-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3372 feature SAFE-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3373 feature SAFE-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3374 feature SAFE-053 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3375 feature SAFE-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3376 feature SAFE-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3377 feature SAFE-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3378 feature SAFE-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3379 feature SAFE-054 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3380 feature SAFE-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3381 feature SAFE-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3382 feature SAFE-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3383 feature SAFE-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3384 feature SAFE-055 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3385 feature SAFE-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3386 feature SAFE-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3387 feature SAFE-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3388 feature SAFE-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3389 feature SAFE-056 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3390 feature SAFE-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3391 feature SAFE-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3392 feature SAFE-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3393 feature SAFE-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3394 feature SAFE-057 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3395 feature SAFE-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3396 feature SAFE-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3397 feature SAFE-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3398 feature SAFE-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3399 feature SAFE-058 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3400 feature SAFE-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3401 feature SAFE-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3402 feature SAFE-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3403 feature SAFE-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3404 feature SAFE-059 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3405 feature SAFE-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3406 feature SAFE-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3407 feature SAFE-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3408 feature SAFE-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3409 feature SAFE-060 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3410 feature SAFE-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3411 feature SAFE-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3412 feature SAFE-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3413 feature SAFE-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3414 feature SAFE-061 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3415 feature SAFE-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3416 feature SAFE-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3417 feature SAFE-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3418 feature SAFE-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3419 feature SAFE-062 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3420 feature SAFE-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3421 feature SAFE-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3422 feature SAFE-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3423 feature SAFE-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3424 feature SAFE-063 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3425 feature SAFE-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3426 feature SAFE-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3427 feature SAFE-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3428 feature SAFE-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3429 feature SAFE-064 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3430 feature SAFE-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3431 feature SAFE-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3432 feature SAFE-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3433 feature SAFE-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3434 feature SAFE-065 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3435 feature SAFE-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3436 feature SAFE-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3437 feature SAFE-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3438 feature SAFE-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3439 feature SAFE-066 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3440 feature SAFE-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3441 feature SAFE-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3442 feature SAFE-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3443 feature SAFE-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3444 feature SAFE-067 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3445 feature SAFE-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3446 feature SAFE-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3447 feature SAFE-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3448 feature SAFE-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3449 feature SAFE-068 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3450 feature SAFE-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3451 feature SAFE-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3452 feature SAFE-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3453 feature SAFE-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3454 feature SAFE-069 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3455 feature SAFE-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3456 feature SAFE-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3457 feature SAFE-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3458 feature SAFE-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3459 feature SAFE-070 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3460 feature SAFE-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3461 feature SAFE-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3462 feature SAFE-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3463 feature SAFE-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3464 feature SAFE-071 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3465 feature SAFE-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3466 feature SAFE-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3467 feature SAFE-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3468 feature SAFE-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3469 feature SAFE-072 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3470 feature SAFE-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3471 feature SAFE-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3472 feature SAFE-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3473 feature SAFE-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3474 feature SAFE-073 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3475 feature SAFE-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3476 feature SAFE-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3477 feature SAFE-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3478 feature SAFE-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3479 feature SAFE-074 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3480 feature SAFE-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3481 feature SAFE-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3482 feature SAFE-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3483 feature SAFE-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3484 feature SAFE-075 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3485 feature SAFE-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3486 feature SAFE-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3487 feature SAFE-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3488 feature SAFE-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3489 feature SAFE-076 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3490 feature SAFE-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3491 feature SAFE-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3492 feature SAFE-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3493 feature SAFE-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3494 feature SAFE-077 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3495 feature SAFE-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3496 feature SAFE-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3497 feature SAFE-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3498 feature SAFE-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3499 feature SAFE-078 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3500 feature SAFE-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3501 feature SAFE-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3502 feature SAFE-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3503 feature SAFE-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3504 feature SAFE-079 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3505 feature SAFE-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3506 feature SAFE-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3507 feature SAFE-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3508 feature SAFE-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3509 feature SAFE-080 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3510 feature SAFE-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3511 feature SAFE-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3512 feature SAFE-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3513 feature SAFE-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3514 feature SAFE-081 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3515 feature SAFE-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3516 feature SAFE-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3517 feature SAFE-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3518 feature SAFE-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3519 feature SAFE-082 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3520 feature SAFE-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3521 feature SAFE-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3522 feature SAFE-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3523 feature SAFE-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3524 feature SAFE-083 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3525 feature SAFE-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3526 feature SAFE-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3527 feature SAFE-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3528 feature SAFE-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3529 feature SAFE-084 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3530 feature SAFE-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3531 feature SAFE-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3532 feature SAFE-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3533 feature SAFE-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3534 feature SAFE-085 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3535 feature SAFE-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3536 feature SAFE-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3537 feature SAFE-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3538 feature SAFE-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3539 feature SAFE-086 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3540 feature SAFE-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3541 feature SAFE-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3542 feature SAFE-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3543 feature SAFE-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3544 feature SAFE-087 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3545 feature SAFE-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3546 feature SAFE-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3547 feature SAFE-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3548 feature SAFE-088 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3549 feature SAFE-088 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3550 feature SAFE-088 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3551 feature SAFE-088 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3552 feature SAFE-088 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3553 feature SAFE-089 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3554 feature SAFE-089 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3555 feature SAFE-089 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3556 feature SAFE-089 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3557 feature SAFE-089 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3558 feature SAFE-090 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3559 feature SAFE-090 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3560 feature SAFE-090 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3561 feature SAFE-090 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3562 feature SAFE-090 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3563 feature SAFE-091 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3564 feature SAFE-091 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3565 feature SAFE-091 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3566 feature SAFE-091 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3567 feature SAFE-091 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3568 feature SAFE-092 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3569 feature SAFE-092 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3570 feature SAFE-092 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3571 feature SAFE-092 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3572 feature SAFE-092 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3573 feature SAFE-093 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3574 feature SAFE-093 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3575 feature SAFE-093 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3576 feature SAFE-093 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3577 feature SAFE-093 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3578 feature SAFE-094 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3579 feature SAFE-094 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3580 feature SAFE-094 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3581 feature SAFE-094 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3582 feature SAFE-094 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3583 feature SAFE-095 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3584 feature SAFE-095 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3585 feature SAFE-095 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3586 feature SAFE-095 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3587 feature SAFE-095 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3588 feature SAFE-096 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3589 feature SAFE-096 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3590 feature SAFE-096 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3591 feature SAFE-096 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3592 feature SAFE-096 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3593 feature SAFE-097 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3594 feature SAFE-097 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3595 feature SAFE-097 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3596 feature SAFE-097 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3597 feature SAFE-097 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3598 feature SAFE-098 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3599 feature SAFE-098 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3600 feature SAFE-098 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3601 feature SAFE-098 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3602 feature SAFE-098 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3603 feature SAFE-099 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3604 feature SAFE-099 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3605 feature SAFE-099 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3606 feature SAFE-099 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3607 feature SAFE-099 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3608 feature SAFE-100 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3609 feature SAFE-100 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3610 feature SAFE-100 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3611 feature SAFE-100 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3612 feature SAFE-100 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3613 feature SAFE-101 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3614 feature SAFE-101 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3615 feature SAFE-101 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3616 feature SAFE-101 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3617 feature SAFE-101 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3618 feature SAFE-102 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3619 feature SAFE-102 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3620 feature SAFE-102 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3621 feature SAFE-102 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3622 feature SAFE-102 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3623 feature SAFE-103 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3624 feature SAFE-103 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3625 feature SAFE-103 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3626 feature SAFE-103 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3627 feature SAFE-103 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3628 feature SAFE-104 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3629 feature SAFE-104 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3630 feature SAFE-104 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3631 feature SAFE-104 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3632 feature SAFE-104 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3633 feature SAFE-105 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3634 feature SAFE-105 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3635 feature SAFE-105 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3636 feature SAFE-105 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3637 feature SAFE-105 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3638 feature SAFE-106 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3639 feature SAFE-106 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3640 feature SAFE-106 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3641 feature SAFE-106 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3642 feature SAFE-106 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3643 feature SAFE-107 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3644 feature SAFE-107 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3645 feature SAFE-107 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3646 feature SAFE-107 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3647 feature SAFE-107 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3648 feature SAFE-108 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3649 feature SAFE-108 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3650 feature SAFE-108 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3651 feature SAFE-108 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3652 feature SAFE-108 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3653 feature SAFE-109 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3654 feature SAFE-109 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3655 feature SAFE-109 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3656 feature SAFE-109 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3657 feature SAFE-109 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3658 feature SAFE-110 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3659 feature SAFE-110 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3660 feature SAFE-110 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3661 feature SAFE-110 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3662 feature SAFE-110 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3663 feature SAFE-111 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3664 feature SAFE-111 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3665 feature SAFE-111 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3666 feature SAFE-111 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3667 feature SAFE-111 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3668 feature SAFE-112 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3669 feature SAFE-112 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3670 feature SAFE-112 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3671 feature SAFE-112 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3672 feature SAFE-112 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3673 feature SAFE-113 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3674 feature SAFE-113 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3675 feature SAFE-113 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3676 feature SAFE-113 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3677 feature SAFE-113 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3678 feature SAFE-114 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3679 feature SAFE-114 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3680 feature SAFE-114 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3681 feature SAFE-114 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3682 feature SAFE-114 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3683 feature SAFE-115 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3684 feature SAFE-115 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3685 feature SAFE-115 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3686 feature SAFE-115 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3687 feature SAFE-115 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3688 feature SAFE-116 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3689 feature SAFE-116 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3690 feature SAFE-116 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3691 feature SAFE-116 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3692 feature SAFE-116 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3693 feature SAFE-117 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3694 feature SAFE-117 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3695 feature SAFE-117 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3696 feature SAFE-117 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3697 feature SAFE-117 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3698 feature SAFE-118 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3699 feature SAFE-118 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3700 feature SAFE-118 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3701 feature SAFE-118 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3702 feature SAFE-118 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3703 feature SAFE-119 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3704 feature SAFE-119 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3705 feature SAFE-119 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3706 feature SAFE-119 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3707 feature SAFE-119 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3708 feature SAFE-120 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3709 feature SAFE-120 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3710 feature SAFE-120 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3711 feature SAFE-120 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3712 feature SAFE-120 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3713 feature SAFE-121 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3714 feature SAFE-121 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3715 feature SAFE-121 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3716 feature SAFE-121 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3717 feature SAFE-121 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3718 feature SAFE-122 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3719 feature SAFE-122 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3720 feature SAFE-122 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3721 feature SAFE-122 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3722 feature SAFE-122 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3723 feature SAFE-123 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3724 feature SAFE-123 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3725 feature SAFE-123 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3726 feature SAFE-123 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3727 feature SAFE-123 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3728 feature SAFE-124 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3729 feature SAFE-124 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3730 feature SAFE-124 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3731 feature SAFE-124 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3732 feature SAFE-124 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3733 feature SAFE-125 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3734 feature SAFE-125 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3735 feature SAFE-125 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3736 feature SAFE-125 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3737 feature SAFE-125 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3738 feature SAFE-126 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3739 feature SAFE-126 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3740 feature SAFE-126 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3741 feature SAFE-126 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3742 feature SAFE-126 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3743 feature SAFE-127 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3744 feature SAFE-127 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3745 feature SAFE-127 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3746 feature SAFE-127 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3747 feature SAFE-127 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3748 feature SAFE-128 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3749 feature SAFE-128 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3750 feature SAFE-128 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3751 feature SAFE-128 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3752 feature SAFE-128 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3753 feature SAFE-129 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3754 feature SAFE-129 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3755 feature SAFE-129 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3756 feature SAFE-129 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3757 feature SAFE-129 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3758 feature SAFE-130 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3759 feature SAFE-130 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3760 feature SAFE-130 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3761 feature SAFE-130 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3762 feature SAFE-130 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3763 feature SAFE-131 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3764 feature SAFE-131 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3765 feature SAFE-131 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3766 feature SAFE-131 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3767 feature SAFE-131 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3768 feature SAFE-132 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3769 feature SAFE-132 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3770 feature SAFE-132 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3771 feature SAFE-132 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3772 feature SAFE-132 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3773 feature SAFE-133 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3774 feature SAFE-133 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3775 feature SAFE-133 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3776 feature SAFE-133 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3777 feature SAFE-133 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3778 feature SAFE-134 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3779 feature SAFE-134 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3780 feature SAFE-134 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3781 feature SAFE-134 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3782 feature SAFE-134 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3783 feature SAFE-135 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3784 feature SAFE-135 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3785 feature SAFE-135 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3786 feature SAFE-135 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3787 feature SAFE-135 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3788 feature SAFE-136 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3789 feature SAFE-136 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3790 feature SAFE-136 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3791 feature SAFE-136 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3792 feature SAFE-136 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3793 feature SAFE-137 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3794 feature SAFE-137 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3795 feature SAFE-137 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3796 feature SAFE-137 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3797 feature SAFE-137 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3798 feature SAFE-138 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3799 feature SAFE-138 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3800 feature SAFE-138 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3801 feature SAFE-138 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3802 feature SAFE-138 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3803 feature SAFE-139 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3804 feature SAFE-139 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3805 feature SAFE-139 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3806 feature SAFE-139 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3807 feature SAFE-139 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3808 feature SAFE-140 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3809 feature SAFE-140 UI need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3810 feature SAFE-140 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3811 feature SAFE-140 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3812 feature SAFE-140 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3813 feature SAFE-141 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3814 feature SAFE-141 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3815 feature SAFE-141 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3816 feature SAFE-141 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3817 feature SAFE-141 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3818 feature SAFE-142 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3819 feature SAFE-142 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3820 feature SAFE-142 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3821 feature SAFE-142 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3822 feature SAFE-142 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3823 feature SAFE-143 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3824 feature SAFE-143 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3825 feature SAFE-143 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3826 feature SAFE-143 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3827 feature SAFE-143 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3828 feature SAFE-144 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3829 feature SAFE-144 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3830 feature SAFE-144 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3831 feature SAFE-144 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3832 feature SAFE-144 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3833 feature SAFE-145 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3834 feature SAFE-145 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3835 feature SAFE-145 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3836 feature SAFE-145 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3837 feature SAFE-145 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3838 feature SAFE-146 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3839 feature SAFE-146 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3840 feature SAFE-146 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3841 feature SAFE-146 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3842 feature SAFE-146 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3843 feature SAFE-147 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3844 feature SAFE-147 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3845 feature SAFE-147 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3846 feature SAFE-147 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3847 feature SAFE-147 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3848 feature SAFE-148 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3849 feature SAFE-148 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3850 feature SAFE-148 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3851 feature SAFE-148 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3852 feature SAFE-148 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3853 feature SAFE-149 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3854 feature SAFE-149 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3855 feature SAFE-149 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3856 feature SAFE-149 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3857 feature SAFE-149 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3858 feature SAFE-150 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3859 feature SAFE-150 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3860 feature SAFE-150 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3861 feature SAFE-150 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3862 feature SAFE-150 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3863 feature SAFE-151 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3864 feature SAFE-151 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3865 feature SAFE-151 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3866 feature SAFE-151 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3867 feature SAFE-151 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3868 feature SAFE-152 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3869 feature SAFE-152 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3870 feature SAFE-152 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3871 feature SAFE-152 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3872 feature SAFE-152 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3873 feature SAFE-153 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3874 feature SAFE-153 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3875 feature SAFE-153 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3876 feature SAFE-153 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3877 feature SAFE-153 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3878 feature SAFE-154 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3879 feature SAFE-154 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3880 feature SAFE-154 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3881 feature SAFE-154 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3882 feature SAFE-154 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3883 feature SAFE-155 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3884 feature SAFE-155 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3885 feature SAFE-155 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3886 feature SAFE-155 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3887 feature SAFE-155 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3888 feature SAFE-156 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3889 feature SAFE-156 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3890 feature SAFE-156 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3891 feature SAFE-156 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3892 feature SAFE-156 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3893 feature SAFE-157 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3894 feature SAFE-157 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3895 feature SAFE-157 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3896 feature SAFE-157 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3897 feature SAFE-157 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3898 feature SAFE-158 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3899 feature SAFE-158 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3900 feature SAFE-158 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3901 feature SAFE-158 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3902 feature SAFE-158 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3903 feature SAFE-159 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3904 feature SAFE-159 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3905 feature SAFE-159 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3906 feature SAFE-159 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3907 feature SAFE-159 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3908 feature SAFE-160 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3909 feature SAFE-160 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3910 feature SAFE-160 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3911 feature SAFE-160 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3912 feature SAFE-160 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3913 feature SAFE-161 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3914 feature SAFE-161 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3915 feature SAFE-161 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3916 feature SAFE-161 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3917 feature SAFE-161 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3918 feature SAFE-162 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3919 feature SAFE-162 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3920 feature SAFE-162 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3921 feature SAFE-162 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3922 feature SAFE-162 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3923 feature SAFE-163 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3924 feature SAFE-163 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3925 feature SAFE-163 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3926 feature SAFE-163 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3927 feature SAFE-163 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3928 feature SAFE-164 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3929 feature SAFE-164 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3930 feature SAFE-164 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3931 feature SAFE-164 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3932 feature SAFE-164 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3933 feature SAFE-165 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3934 feature SAFE-165 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3935 feature SAFE-165 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3936 feature SAFE-165 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3937 feature SAFE-165 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3938 feature SAFE-166 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3939 feature SAFE-166 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3940 feature SAFE-166 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3941 feature SAFE-166 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3942 feature SAFE-166 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3943 feature SAFE-167 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3944 feature SAFE-167 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3945 feature SAFE-167 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3946 feature SAFE-167 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3947 feature SAFE-167 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3948 feature SAFE-168 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3949 feature SAFE-168 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3950 feature SAFE-168 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3951 feature SAFE-168 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3952 feature SAFE-168 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3953 feature SAFE-169 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3954 feature SAFE-169 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3955 feature SAFE-169 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3956 feature SAFE-169 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3957 feature SAFE-169 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3958 feature SAFE-170 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3959 feature SAFE-170 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3960 feature SAFE-170 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3961 feature SAFE-170 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3962 feature SAFE-170 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3963 feature SAFE-171 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3964 feature SAFE-171 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3965 feature SAFE-171 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3966 feature SAFE-171 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3967 feature SAFE-171 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3968 feature SAFE-172 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3969 feature SAFE-172 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3970 feature SAFE-172 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3971 feature SAFE-172 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3972 feature SAFE-172 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3973 feature SAFE-173 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3974 feature SAFE-173 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3975 feature SAFE-173 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3976 feature SAFE-173 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3977 feature SAFE-173 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3978 feature SAFE-174 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3979 feature SAFE-174 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3980 feature SAFE-174 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3981 feature SAFE-174 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3982 feature SAFE-174 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3983 feature SAFE-175 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3984 feature SAFE-175 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3985 feature SAFE-175 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3986 feature SAFE-175 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3987 feature SAFE-175 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3988 feature SAFE-176 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3989 feature SAFE-176 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3990 feature SAFE-176 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3991 feature SAFE-176 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3992 feature SAFE-176 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3993 feature SAFE-177 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3994 feature SAFE-177 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3995 feature SAFE-177 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3996 feature SAFE-177 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3997 feature SAFE-177 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3998 feature SAFE-178 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 3999 feature SAFE-178 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4000 feature SAFE-178 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4001 feature SAFE-178 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4002 feature SAFE-178 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4003 feature SAFE-179 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4004 feature SAFE-179 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4005 feature SAFE-179 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4006 feature SAFE-179 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4007 feature SAFE-179 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4008 feature SAFE-180 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4009 feature SAFE-180 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4010 feature SAFE-180 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4011 feature SAFE-180 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4012 feature SAFE-180 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4013 feature SAFE-181 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4014 feature SAFE-181 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4015 feature SAFE-181 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4016 feature SAFE-181 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4017 feature SAFE-181 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4018 feature SAFE-182 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4019 feature SAFE-182 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4020 feature SAFE-182 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4021 feature SAFE-182 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4022 feature SAFE-182 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4023 feature SAFE-183 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4024 feature SAFE-183 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4025 feature SAFE-183 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4026 feature SAFE-183 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4027 feature SAFE-183 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4028 feature SAFE-184 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4029 feature SAFE-184 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4030 feature SAFE-184 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4031 feature SAFE-184 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4032 feature SAFE-184 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4033 feature SAFE-185 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4034 feature SAFE-185 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4035 feature SAFE-185 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4036 feature SAFE-185 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4037 feature SAFE-185 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4038 feature SAFE-186 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4039 feature SAFE-186 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4040 feature SAFE-186 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4041 feature SAFE-186 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4042 feature SAFE-186 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4043 feature SAFE-187 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4044 feature SAFE-187 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4045 feature SAFE-187 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4046 feature SAFE-187 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4047 feature SAFE-187 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4048 feature SAFE-188 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4049 feature SAFE-188 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4050 feature SAFE-188 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4051 feature SAFE-188 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4052 feature SAFE-188 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4053 feature SAFE-189 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4054 feature SAFE-189 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4055 feature SAFE-189 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4056 feature SAFE-189 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4057 feature SAFE-189 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4058 feature SAFE-190 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4059 feature SAFE-190 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4060 feature SAFE-190 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4061 feature SAFE-190 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4062 feature SAFE-190 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4063 feature SAFE-191 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4064 feature SAFE-191 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4065 feature SAFE-191 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4066 feature SAFE-191 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4067 feature SAFE-191 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4068 feature SAFE-192 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4069 feature SAFE-192 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4070 feature SAFE-192 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4071 feature SAFE-192 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4072 feature SAFE-192 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4073 feature SAFE-193 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4074 feature SAFE-193 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4075 feature SAFE-193 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4076 feature SAFE-193 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4077 feature SAFE-193 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4078 feature SAFE-194 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4079 feature SAFE-194 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4080 feature SAFE-194 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4081 feature SAFE-194 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4082 feature SAFE-194 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4083 feature SAFE-195 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4084 feature SAFE-195 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4085 feature SAFE-195 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4086 feature SAFE-195 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4087 feature SAFE-195 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4088 feature SAFE-196 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4089 feature SAFE-196 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4090 feature SAFE-196 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4091 feature SAFE-196 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4092 feature SAFE-196 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4093 feature SAFE-197 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4094 feature SAFE-197 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4095 feature SAFE-197 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4096 feature SAFE-197 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4097 feature SAFE-197 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4098 feature SAFE-198 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4099 feature SAFE-198 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4100 feature SAFE-198 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4101 feature SAFE-198 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4102 feature SAFE-198 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4103 feature SAFE-199 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4104 feature SAFE-199 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4105 feature SAFE-199 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4106 feature SAFE-199 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4107 feature SAFE-199 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4108 feature SAFE-200 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4109 feature SAFE-200 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4110 feature SAFE-200 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4111 feature SAFE-200 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4112 feature SAFE-200 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4113 feature SAFE-201 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4114 feature SAFE-201 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4115 feature SAFE-201 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4116 feature SAFE-201 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4117 feature SAFE-201 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4118 feature SAFE-202 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4119 feature SAFE-202 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4120 feature SAFE-202 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4121 feature SAFE-202 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4122 feature SAFE-202 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4123 feature SAFE-203 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4124 feature SAFE-203 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4125 feature SAFE-203 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4126 feature SAFE-203 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4127 feature SAFE-203 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4128 feature SAFE-204 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4129 feature SAFE-204 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4130 feature SAFE-204 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4131 feature SAFE-204 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4132 feature SAFE-204 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4133 feature SAFE-205 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4134 feature SAFE-205 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4135 feature SAFE-205 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4136 feature SAFE-205 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4137 feature SAFE-205 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4138 feature SAFE-206 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4139 feature SAFE-206 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4140 feature SAFE-206 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4141 feature SAFE-206 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4142 feature SAFE-206 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4143 feature SAFE-207 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4144 feature SAFE-207 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4145 feature SAFE-207 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4146 feature SAFE-207 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4147 feature SAFE-207 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4148 feature SAFE-208 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4149 feature SAFE-208 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4150 feature SAFE-208 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4151 feature SAFE-208 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4152 feature SAFE-208 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4153 feature SAFE-209 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4154 feature SAFE-209 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4155 feature SAFE-209 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4156 feature SAFE-209 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4157 feature SAFE-209 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4158 feature SAFE-210 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4159 feature SAFE-210 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4160 feature SAFE-210 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4161 feature SAFE-210 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4162 feature SAFE-210 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4163 feature SAFE-211 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4164 feature SAFE-211 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4165 feature SAFE-211 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4166 feature SAFE-211 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4167 feature SAFE-211 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4168 feature SAFE-212 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4169 feature SAFE-212 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4170 feature SAFE-212 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4171 feature SAFE-212 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4172 feature SAFE-212 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4173 feature SAFE-213 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4174 feature SAFE-213 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4175 feature SAFE-213 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4176 feature SAFE-213 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4177 feature SAFE-213 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4178 feature SAFE-214 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4179 feature SAFE-214 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4180 feature SAFE-214 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4181 feature SAFE-214 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4182 feature SAFE-214 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4183 feature SAFE-215 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4184 feature SAFE-215 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4185 feature SAFE-215 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4186 feature SAFE-215 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4187 feature SAFE-215 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4188 feature SAFE-216 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4189 feature SAFE-216 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4190 feature SAFE-216 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4191 feature SAFE-216 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4192 feature SAFE-216 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4193 feature SAFE-217 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4194 feature SAFE-217 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4195 feature SAFE-217 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4196 feature SAFE-217 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4197 feature SAFE-217 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4198 feature OPS-035 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4199 feature OPS-035 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4200 feature OPS-035 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4201 feature OPS-035 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4202 feature OPS-035 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4203 feature OPS-036 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4204 feature OPS-036 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4205 feature OPS-036 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4206 feature OPS-036 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4207 feature OPS-036 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4208 feature OPS-037 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4209 feature OPS-037 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4210 feature OPS-037 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4211 feature OPS-037 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4212 feature OPS-037 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4213 feature OPS-038 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4214 feature OPS-038 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4215 feature OPS-038 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4216 feature OPS-038 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4217 feature OPS-038 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4218 feature OPS-039 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4219 feature OPS-039 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4220 feature OPS-039 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4221 feature OPS-039 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4222 feature OPS-039 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4223 feature OPS-040 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4224 feature OPS-040 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4225 feature OPS-040 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4226 feature OPS-040 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4227 feature OPS-040 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4228 feature OPS-041 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4229 feature OPS-041 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4230 feature OPS-041 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4231 feature OPS-041 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4232 feature OPS-041 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4233 feature OPS-042 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4234 feature OPS-042 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4235 feature OPS-042 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4236 feature OPS-042 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4237 feature OPS-042 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4238 feature OPS-043 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4239 feature OPS-043 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4240 feature OPS-043 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4241 feature OPS-043 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4242 feature OPS-043 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4243 feature OPS-044 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4244 feature OPS-044 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4245 feature OPS-044 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4246 feature OPS-044 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4247 feature OPS-044 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4248 feature OPS-045 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4249 feature OPS-045 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4250 feature OPS-045 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4251 feature OPS-045 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4252 feature OPS-045 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4253 feature OPS-046 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4254 feature OPS-046 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4255 feature OPS-046 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4256 feature OPS-046 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4257 feature OPS-046 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4258 feature OPS-047 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4259 feature OPS-047 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4260 feature OPS-047 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4261 feature OPS-047 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4262 feature OPS-047 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4263 feature OPS-048 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4264 feature OPS-048 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4265 feature OPS-048 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4266 feature OPS-048 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4267 feature OPS-048 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4268 feature OPS-049 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4269 feature OPS-049 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4270 feature OPS-049 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4271 feature OPS-049 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4272 feature OPS-049 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4273 feature OPS-050 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4274 feature OPS-050 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4275 feature OPS-050 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4276 feature OPS-050 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4277 feature OPS-050 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4278 feature OPS-051 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4279 feature OPS-051 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4280 feature OPS-051 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4281 feature OPS-051 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4282 feature OPS-051 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4283 feature OPS-052 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4284 feature OPS-052 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4285 feature OPS-052 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4286 feature OPS-052 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4287 feature OPS-052 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4288 feature OPS-053 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4289 feature OPS-053 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4290 feature OPS-053 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4291 feature OPS-053 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4292 feature OPS-053 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4293 feature OPS-054 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4294 feature OPS-054 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4295 feature OPS-054 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4296 feature OPS-054 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4297 feature OPS-054 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4298 feature OPS-055 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4299 feature OPS-055 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4300 feature OPS-055 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4301 feature OPS-055 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4302 feature OPS-055 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4303 feature OPS-056 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4304 feature OPS-056 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4305 feature OPS-056 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4306 feature OPS-056 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4307 feature OPS-056 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4308 feature OPS-057 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4309 feature OPS-057 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4310 feature OPS-057 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4311 feature OPS-057 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4312 feature OPS-057 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4313 feature OPS-058 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4314 feature OPS-058 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4315 feature OPS-058 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4316 feature OPS-058 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4317 feature OPS-058 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4318 feature OPS-059 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4319 feature OPS-059 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4320 feature OPS-059 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4321 feature OPS-059 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4322 feature OPS-059 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4323 feature OPS-060 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4324 feature OPS-060 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4325 feature OPS-060 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4326 feature OPS-060 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4327 feature OPS-060 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4328 feature OPS-061 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4329 feature OPS-061 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4330 feature OPS-061 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4331 feature OPS-061 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4332 feature OPS-061 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4333 feature OPS-062 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4334 feature OPS-062 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4335 feature OPS-062 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4336 feature OPS-062 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4337 feature OPS-062 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4338 feature OPS-063 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4339 feature OPS-063 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4340 feature OPS-063 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4341 feature OPS-063 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4342 feature OPS-063 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4343 feature OPS-064 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4344 feature OPS-064 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4345 feature OPS-064 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4346 feature OPS-064 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4347 feature OPS-064 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4348 feature OPS-065 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4349 feature OPS-065 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4350 feature OPS-065 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4351 feature OPS-065 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4352 feature OPS-065 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4353 feature OPS-066 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4354 feature OPS-066 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4355 feature OPS-066 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4356 feature OPS-066 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4357 feature OPS-066 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4358 feature OPS-067 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4359 feature OPS-067 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4360 feature OPS-067 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4361 feature OPS-067 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4362 feature OPS-067 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4363 feature OPS-068 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4364 feature OPS-068 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4365 feature OPS-068 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4366 feature OPS-068 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4367 feature OPS-068 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4368 feature OPS-069 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4369 feature OPS-069 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4370 feature OPS-069 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4371 feature OPS-069 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4372 feature OPS-069 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4373 feature OPS-070 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4374 feature OPS-070 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4375 feature OPS-070 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4376 feature OPS-070 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4377 feature OPS-070 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4378 feature OPS-071 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4379 feature OPS-071 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4380 feature OPS-071 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4381 feature OPS-071 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4382 feature OPS-071 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4383 feature OPS-072 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4384 feature OPS-072 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4385 feature OPS-072 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4386 feature OPS-072 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4387 feature OPS-072 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4388 feature OPS-073 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4389 feature OPS-073 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4390 feature OPS-073 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4391 feature OPS-073 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4392 feature OPS-073 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4393 feature OPS-074 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4394 feature OPS-074 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4395 feature OPS-074 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4396 feature OPS-074 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4397 feature OPS-074 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4398 feature OPS-075 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4399 feature OPS-075 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4400 feature OPS-075 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4401 feature OPS-075 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4402 feature OPS-075 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4403 feature OPS-076 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4404 feature OPS-076 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4405 feature OPS-076 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4406 feature OPS-076 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4407 feature OPS-076 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4408 feature OPS-077 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4409 feature OPS-077 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4410 feature OPS-077 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4411 feature OPS-077 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4412 feature OPS-077 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4413 feature OPS-078 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4414 feature OPS-078 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4415 feature OPS-078 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4416 feature OPS-078 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4417 feature OPS-078 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4418 feature OPS-079 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4419 feature OPS-079 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4420 feature OPS-079 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4421 feature OPS-079 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4422 feature OPS-079 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4423 feature OPS-080 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4424 feature OPS-080 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4425 feature OPS-080 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4426 feature OPS-080 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4427 feature OPS-080 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4428 feature OPS-081 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4429 feature OPS-081 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4430 feature OPS-081 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4431 feature OPS-081 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4432 feature OPS-081 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4433 feature OPS-082 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4434 feature OPS-082 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4435 feature OPS-082 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4436 feature OPS-082 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4437 feature OPS-082 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4438 feature OPS-083 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4439 feature OPS-083 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4440 feature OPS-083 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4441 feature OPS-083 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4442 feature OPS-083 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4443 feature OPS-084 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4444 feature OPS-084 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4445 feature OPS-084 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4446 feature OPS-084 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4447 feature OPS-084 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4448 feature OPS-085 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4449 feature OPS-085 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4450 feature OPS-085 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4451 feature OPS-085 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4452 feature OPS-085 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4453 feature OPS-086 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4454 feature OPS-086 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4455 feature OPS-086 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4456 feature OPS-086 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4457 feature OPS-086 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4458 feature OPS-087 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4459 feature OPS-087 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4460 feature OPS-087 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4461 feature OPS-087 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4462 feature OPS-087 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4463 feature OPS-088 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4464 feature OPS-088 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4465 feature OPS-088 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4466 feature OPS-088 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4467 feature OPS-088 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4468 feature OPS-089 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4469 feature OPS-089 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4470 feature OPS-089 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4471 feature OPS-089 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4472 feature OPS-089 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4473 feature OPS-090 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4474 feature OPS-090 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4475 feature OPS-090 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4476 feature OPS-090 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4477 feature OPS-090 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4478 feature OPS-091 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4479 feature OPS-091 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4480 feature OPS-091 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4481 feature OPS-091 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4482 feature OPS-091 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4483 feature OPS-092 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4484 feature OPS-092 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4485 feature OPS-092 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4486 feature OPS-092 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4487 feature OPS-092 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4488 feature OPS-093 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4489 feature OPS-093 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4490 feature OPS-093 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4491 feature OPS-093 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4492 feature OPS-093 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4493 feature OPS-094 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4494 feature OPS-094 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4495 feature OPS-094 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4496 feature OPS-094 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4497 feature OPS-094 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4498 feature OPS-095 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4499 feature OPS-095 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4500 feature OPS-095 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4501 feature OPS-095 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4502 feature OPS-095 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4503 feature OPS-096 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4504 feature OPS-096 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4505 feature OPS-096 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4506 feature OPS-096 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4507 feature OPS-096 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4508 feature OPS-097 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4509 feature OPS-097 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4510 feature OPS-097 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4511 feature OPS-097 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4512 feature OPS-097 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4513 feature OPS-098 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4514 feature OPS-098 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4515 feature OPS-098 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4516 feature OPS-098 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4517 feature OPS-098 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4518 feature OPS-099 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4519 feature OPS-099 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4520 feature OPS-099 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4521 feature OPS-099 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4522 feature OPS-099 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4523 feature OPS-100 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4524 feature OPS-100 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4525 feature OPS-100 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4526 feature OPS-100 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4527 feature OPS-100 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4528 feature OPS-101 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4529 feature OPS-101 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4530 feature OPS-101 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4531 feature OPS-101 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4532 feature OPS-101 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4533 feature OPS-102 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4534 feature OPS-102 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4535 feature OPS-102 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4536 feature OPS-102 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4537 feature OPS-102 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4538 feature OPS-103 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4539 feature OPS-103 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4540 feature OPS-103 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4541 feature OPS-103 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4542 feature OPS-103 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4543 feature OPS-104 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4544 feature OPS-104 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4545 feature OPS-104 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4546 feature OPS-104 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4547 feature OPS-104 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4548 feature OPS-105 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4549 feature OPS-105 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4550 feature OPS-105 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4551 feature OPS-105 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4552 feature OPS-105 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4553 feature OPS-106 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4554 feature OPS-106 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4555 feature OPS-106 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4556 feature OPS-106 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4557 feature OPS-106 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4558 feature OPS-107 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4559 feature OPS-107 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4560 feature OPS-107 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4561 feature OPS-107 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4562 feature OPS-107 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4563 feature OPS-108 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4564 feature OPS-108 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4565 feature OPS-108 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4566 feature OPS-108 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4567 feature OPS-108 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4568 feature OPS-109 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4569 feature OPS-109 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4570 feature OPS-109 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4571 feature OPS-109 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4572 feature OPS-109 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4573 feature OPS-110 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4574 feature OPS-110 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4575 feature OPS-110 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4576 feature OPS-110 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4577 feature OPS-110 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4578 feature OPS-111 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4579 feature OPS-111 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4580 feature OPS-111 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4581 feature OPS-111 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4582 feature OPS-111 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4583 feature OPS-112 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4584 feature OPS-112 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4585 feature OPS-112 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4586 feature OPS-112 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4587 feature OPS-112 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4588 feature OPS-113 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4589 feature OPS-113 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4590 feature OPS-113 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4591 feature OPS-113 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4592 feature OPS-113 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4593 feature OPS-114 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4594 feature OPS-114 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4595 feature OPS-114 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4596 feature OPS-114 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4597 feature OPS-114 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4598 feature OPS-115 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4599 feature OPS-115 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4600 feature OPS-115 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4601 feature OPS-115 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4602 feature OPS-115 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4603 feature OPS-116 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4604 feature OPS-116 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4605 feature OPS-116 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4606 feature OPS-116 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4607 feature OPS-116 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4608 feature OPS-117 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4609 feature OPS-117 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4610 feature OPS-117 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4611 feature OPS-117 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4612 feature OPS-117 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4613 feature OPS-118 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4614 feature OPS-118 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4615 feature OPS-118 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4616 feature OPS-118 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4617 feature OPS-118 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4618 feature OPS-119 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4619 feature OPS-119 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4620 feature OPS-119 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4621 feature OPS-119 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4622 feature OPS-119 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4623 feature OPS-120 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4624 feature OPS-120 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4625 feature OPS-120 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4626 feature OPS-120 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4627 feature OPS-120 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4628 feature OPS-121 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4629 feature OPS-121 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4630 feature OPS-121 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4631 feature OPS-121 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4632 feature OPS-121 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4633 feature OPS-122 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4634 feature OPS-122 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4635 feature OPS-122 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4636 feature OPS-122 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4637 feature OPS-122 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4638 feature OPS-123 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4639 feature OPS-123 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4640 feature OPS-123 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4641 feature OPS-123 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4642 feature OPS-123 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4643 feature OPS-124 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4644 feature OPS-124 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4645 feature OPS-124 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4646 feature OPS-124 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4647 feature OPS-124 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4648 feature OPS-125 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4649 feature OPS-125 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4650 feature OPS-125 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4651 feature OPS-125 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4652 feature OPS-125 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4653 feature OPS-126 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4654 feature OPS-126 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4655 feature OPS-126 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4656 feature OPS-126 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4657 feature OPS-126 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4658 feature OPS-127 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4659 feature OPS-127 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4660 feature OPS-127 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4661 feature OPS-127 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4662 feature OPS-127 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4663 feature OPS-128 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4664 feature OPS-128 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4665 feature OPS-128 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4666 feature OPS-128 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4667 feature OPS-128 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4668 feature OPS-129 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4669 feature OPS-129 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4670 feature OPS-129 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4671 feature OPS-129 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4672 feature OPS-129 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4673 feature OPS-130 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4674 feature OPS-130 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4675 feature OPS-130 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4676 feature OPS-130 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4677 feature OPS-130 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4678 feature OPS-131 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4679 feature OPS-131 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4680 feature OPS-131 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4681 feature OPS-131 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4682 feature OPS-131 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4683 feature OPS-132 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4684 feature OPS-132 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4685 feature OPS-132 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4686 feature OPS-132 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4687 feature OPS-132 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4688 feature OPS-133 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4689 feature OPS-133 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4690 feature OPS-133 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4691 feature OPS-133 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4692 feature OPS-133 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4693 feature OPS-134 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4694 feature OPS-134 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4695 feature OPS-134 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4696 feature OPS-134 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4697 feature OPS-134 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4698 feature OPS-135 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4699 feature OPS-135 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4700 feature OPS-135 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4701 feature OPS-135 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4702 feature OPS-135 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4703 feature OPS-136 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4704 feature OPS-136 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4705 feature OPS-136 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4706 feature OPS-136 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4707 feature OPS-136 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4708 feature OPS-137 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4709 feature OPS-137 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4710 feature OPS-137 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4711 feature OPS-137 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4712 feature OPS-137 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4713 feature OPS-138 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4714 feature OPS-138 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4715 feature OPS-138 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4716 feature OPS-138 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4717 feature OPS-138 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4718 feature OPS-139 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4719 feature OPS-139 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4720 feature OPS-139 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4721 feature OPS-139 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4722 feature OPS-139 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4723 feature OPS-140 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4724 feature OPS-140 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4725 feature OPS-140 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4726 feature OPS-140 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4727 feature OPS-140 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4728 feature OPS-141 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4729 feature OPS-141 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4730 feature OPS-141 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4731 feature OPS-141 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4732 feature OPS-141 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4733 feature OPS-142 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4734 feature OPS-142 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4735 feature OPS-142 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4736 feature OPS-142 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4737 feature OPS-142 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4738 feature OPS-143 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4739 feature OPS-143 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4740 feature OPS-143 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4741 feature OPS-143 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4742 feature OPS-143 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4743 feature OPS-144 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4744 feature OPS-144 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4745 feature OPS-144 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4746 feature OPS-144 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4747 feature OPS-144 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4748 feature OPS-145 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4749 feature OPS-145 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4750 feature OPS-145 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4751 feature OPS-145 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4752 feature OPS-145 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4753 feature OPS-146 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4754 feature OPS-146 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4755 feature OPS-146 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4756 feature OPS-146 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4757 feature OPS-146 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4758 feature OPS-147 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4759 feature OPS-147 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4760 feature OPS-147 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4761 feature OPS-147 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4762 feature OPS-147 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4763 feature OPS-148 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4764 feature OPS-148 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4765 feature OPS-148 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4766 feature OPS-148 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4767 feature OPS-148 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4768 feature OPS-149 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4769 feature OPS-149 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4770 feature OPS-149 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4771 feature OPS-149 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4772 feature OPS-149 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4773 feature OPS-150 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4774 feature OPS-150 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4775 feature OPS-150 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4776 feature OPS-150 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4777 feature OPS-150 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4778 feature OPS-151 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4779 feature OPS-151 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4780 feature OPS-151 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4781 feature OPS-151 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4782 feature OPS-151 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4783 feature OPS-152 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4784 feature OPS-152 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4785 feature OPS-152 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4786 feature OPS-152 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4787 feature OPS-152 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4788 feature OPS-153 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4789 feature OPS-153 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4790 feature OPS-153 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4791 feature OPS-153 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4792 feature OPS-153 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4793 feature OPS-154 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4794 feature OPS-154 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4795 feature OPS-154 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4796 feature OPS-154 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4797 feature OPS-154 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4798 feature OPS-155 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4799 feature OPS-155 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4800 feature OPS-155 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4801 feature OPS-155 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4802 feature OPS-155 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4803 feature OPS-156 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4804 feature OPS-156 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4805 feature OPS-156 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4806 feature OPS-156 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4807 feature OPS-156 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4808 feature OPS-157 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4809 feature OPS-157 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4810 feature OPS-157 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4811 feature OPS-157 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4812 feature OPS-157 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4813 feature OPS-158 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4814 feature OPS-158 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4815 feature OPS-158 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4816 feature OPS-158 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4817 feature OPS-158 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4818 feature OPS-159 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4819 feature OPS-159 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4820 feature OPS-159 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4821 feature OPS-159 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4822 feature OPS-159 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4823 feature OPS-160 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4824 feature OPS-160 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4825 feature OPS-160 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4826 feature OPS-160 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4827 feature OPS-160 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4828 feature OPS-161 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4829 feature OPS-161 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4830 feature OPS-161 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4831 feature OPS-161 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4832 feature OPS-161 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4833 feature OPS-162 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4834 feature OPS-162 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4835 feature OPS-162 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4836 feature OPS-162 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4837 feature OPS-162 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4838 feature OPS-163 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4839 feature OPS-163 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4840 feature OPS-163 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4841 feature OPS-163 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4842 feature OPS-163 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4843 feature OPS-164 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4844 feature OPS-164 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4845 feature OPS-164 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4846 feature OPS-164 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4847 feature OPS-164 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4848 feature OPS-165 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4849 feature OPS-165 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4850 feature OPS-165 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4851 feature OPS-165 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4852 feature OPS-165 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4853 feature OPS-166 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4854 feature OPS-166 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4855 feature OPS-166 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4856 feature OPS-166 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4857 feature OPS-166 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4858 feature OPS-167 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4859 feature OPS-167 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4860 feature OPS-167 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4861 feature OPS-167 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4862 feature OPS-167 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4863 feature OPS-168 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4864 feature OPS-168 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4865 feature OPS-168 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4866 feature OPS-168 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4867 feature OPS-168 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4868 feature OPS-169 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4869 feature OPS-169 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4870 feature OPS-169 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4871 feature OPS-169 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4872 feature OPS-169 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4873 feature OPS-170 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4874 feature OPS-170 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4875 feature OPS-170 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4876 feature OPS-170 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4877 feature OPS-170 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4878 feature OPS-171 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4879 feature OPS-171 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4880 feature OPS-171 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4881 feature OPS-171 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4882 feature OPS-171 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4883 feature OPS-172 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4884 feature OPS-172 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4885 feature OPS-172 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4886 feature OPS-172 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4887 feature OPS-172 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4888 feature OPS-173 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4889 feature OPS-173 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4890 feature OPS-173 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4891 feature OPS-173 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4892 feature OPS-173 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4893 feature OPS-174 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4894 feature OPS-174 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4895 feature OPS-174 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4896 feature OPS-174 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4897 feature OPS-174 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4898 feature OPS-175 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4899 feature OPS-175 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4900 feature OPS-175 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4901 feature OPS-175 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4902 feature OPS-175 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4903 feature OPS-176 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4904 feature OPS-176 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4905 feature OPS-176 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4906 feature OPS-176 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4907 feature OPS-176 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4908 feature OPS-177 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4909 feature OPS-177 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4910 feature OPS-177 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4911 feature OPS-177 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4912 feature OPS-177 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4913 feature OPS-178 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4914 feature OPS-178 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4915 feature OPS-178 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4916 feature OPS-178 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4917 feature OPS-178 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4918 feature OPS-179 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4919 feature OPS-179 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4920 feature OPS-179 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4921 feature OPS-179 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4922 feature OPS-179 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4923 feature OPS-180 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4924 feature OPS-180 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4925 feature OPS-180 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4926 feature OPS-180 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4927 feature OPS-180 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4928 feature OPS-181 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4929 feature OPS-181 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4930 feature OPS-181 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4931 feature OPS-181 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4932 feature OPS-181 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4933 feature OPS-182 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4934 feature OPS-182 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4935 feature OPS-182 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4936 feature OPS-182 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4937 feature OPS-182 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4938 feature OPS-183 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4939 feature OPS-183 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4940 feature OPS-183 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4941 feature OPS-183 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4942 feature OPS-183 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4943 feature OPS-184 name present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4944 feature OPS-184 UI need 비대상 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4945 feature OPS-184 test need 필요 | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4946 feature OPS-184 test area assigned | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4947 feature OPS-184 pass criteria present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4948 feature rows have required matrix columns | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4949 inventory rejects separate test-area labels | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4950 coverage wording separates mapping from execution | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4951 current feature expansion rows exist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4952 manual UI docs reference inventory | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4953 manual checklist references seed fixture | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4954 manual result template references seed fixture | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4955 VA seed inventory commands select the latest published baseline explicitly | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4956 AGENTS requires individual future feature test rows | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4957 manual UI seed account role admin | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4958 manual UI seed account role operator | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4959 manual UI seed account role viewer | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4960 manual UI seed account role integrator | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4961 manual UI seed profile 9101 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4962 manual UI seed profile 9101 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4963 manual UI seed profile 9102 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4964 manual UI seed profile 9102 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4965 manual UI seed profile 9103 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4966 manual UI seed profile 9103 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4967 manual UI seed profile 9104 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4968 manual UI seed profile 9104 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4969 manual UI seed profile 9105 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4970 manual UI seed profile 9105 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4971 manual UI seed profile 9106 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4972 manual UI seed profile 9106 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4973 manual UI seed profile 9107 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4974 manual UI seed profile 9107 tracking classes present | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4975 manual UI seed event type presence | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4976 manual UI seed event type enter | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4977 manual UI seed event type exit | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4978 manual UI seed event type line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4979 manual UI seed event type intrusion-dwell | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4980 manual UI seed event type re-entry | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4981 manual UI seed event type wrong-direction | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4982 manual UI seed event type intrusion-after-line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4983 manual UI seed event type loitering | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4984 manual UI seed event type zone-occupancy | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4985 manual UI seed event template 9201 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4986 manual UI seed event template 9201 event type presence | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4987 manual UI seed event template 9201 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4988 manual UI seed event template 9202 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4989 manual UI seed event template 9202 event type enter | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4990 manual UI seed event template 9202 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4991 manual UI seed event template 9203 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4992 manual UI seed event template 9203 event type exit | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4993 manual UI seed event template 9203 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4994 manual UI seed event template 9204 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4995 manual UI seed event template 9204 event type line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4996 manual UI seed event template 9204 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4997 manual UI seed event template 9205 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4998 manual UI seed event template 9205 event type line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 4999 manual UI seed event template 9205 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5000 manual UI seed event template 9206 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5001 manual UI seed event template 9206 event type line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5002 manual UI seed event template 9206 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5003 manual UI seed event template 9207 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5004 manual UI seed event template 9207 event type intrusion-dwell | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5005 manual UI seed event template 9207 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5006 manual UI seed event template 9208 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5007 manual UI seed event template 9208 event type re-entry | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5008 manual UI seed event template 9208 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5009 manual UI seed event template 9209 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5010 manual UI seed event template 9209 event type wrong-direction | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5011 manual UI seed event template 9209 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5012 manual UI seed event template 9210 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5013 manual UI seed event template 9210 event type intrusion-after-line-crossing | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5014 manual UI seed event template 9210 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5015 manual UI seed event template 9211 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5016 manual UI seed event template 9211 event type loitering | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5017 manual UI seed event template 9211 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5018 manual UI seed event template 9212 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5019 manual UI seed event template 9212 event type zone-occupancy | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5020 manual UI seed event template 9212 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5021 manual UI seed line direction any | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5022 manual UI seed line direction forward | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5023 manual UI seed line direction reverse | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5024 manual UI seed scenario preset default | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5025 manual UI seed scenario preset road | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5026 manual UI seed scenario preset retail | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5027 manual UI seed scenario preset park | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5028 manual UI seed scenario preset indoor | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5029 manual UI seed scenario preset lobby | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5030 manual UI seed scenario preset platform | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5031 manual UI seed scenario preset entrance | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5032 manual UI seed scenario preset doorway | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5033 manual UI seed scenario preset parking | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5034 manual UI seed scenario preset elevator | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5035 manual UI seed scenario preset custom | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5036 manual UI seed vaRule 9301 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5037 manual UI seed vaRule 9301 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5038 manual UI seed vaRule 9301 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5039 manual UI seed vaRule 9302 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5040 manual UI seed vaRule 9302 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5041 manual UI seed vaRule 9302 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5042 manual UI seed vaRule 9303 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5043 manual UI seed vaRule 9303 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5044 manual UI seed vaRule 9303 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5045 manual UI seed vaRule 9304 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5046 manual UI seed vaRule 9304 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5047 manual UI seed vaRule 9304 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5048 manual UI seed vaRule 9305 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5049 manual UI seed vaRule 9305 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5050 manual UI seed vaRule 9305 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5051 manual UI seed vaRule 9306 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5052 manual UI seed vaRule 9306 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5053 manual UI seed vaRule 9306 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5054 manual UI seed vaRule 9307 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5055 manual UI seed vaRule 9307 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5056 manual UI seed vaRule 9307 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5057 manual UI seed vaRule 9308 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5058 manual UI seed vaRule 9308 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5059 manual UI seed vaRule 9308 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5060 manual UI seed vaRule 9309 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5061 manual UI seed vaRule 9309 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5062 manual UI seed vaRule 9309 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5063 manual UI seed vaRule 9310 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5064 manual UI seed vaRule 9310 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5065 manual UI seed vaRule 9310 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5066 manual UI seed vaRule 9311 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5067 manual UI seed vaRule 9311 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5068 manual UI seed vaRule 9311 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5069 manual UI seed vaRule 9312 numeric id | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5070 manual UI seed vaRule 9312 profile reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5071 manual UI seed vaRule 9312 event template reference | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5072 manual UI seed tracker Re-ID pair none/off | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5073 manual UI seed tracker Re-ID pair lite/off | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5074 manual UI seed tracker Re-ID pair kalman-lite/off | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5075 manual UI seed tracker Re-ID pair bytetrack/off | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5076 manual UI seed tracker Re-ID pair lite/assist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5077 manual UI seed tracker Re-ID pair kalman-lite/assist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5078 manual UI seed tracker Re-ID pair bytetrack/assist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5079 manual UI seed invalid policy tracker none Re-ID assist | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5080 manual UI seed final state minimum vaRules | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| inventory 5081 manual UI VA seed matrix covers required current release cases | ./server.sh verify-project-inventory; exit 0 | pass | b13-inventory.log.gz |
| auth-users 1 server health ok (http://127.0.0.1:8091) | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 2 weak admin password rejected: 400 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 3 initial admin password setup: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 4 auth users file owner-only mode: 600 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 5 setup blocked after completion: 302:/login | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 6 admin login landing: 302:/ops/home | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 7 admin whoami username and role | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 8 ops users access request selectors | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 9 permissive auth users file re-hardened: 600 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 10 viewer view scope assigned | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 11 viewer privileged scopes blocked | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 12 user API hash redaction | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 13 viewer custom privileged scope rejected: 400 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 14 integrator live view scope rejected: 400 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 15 viewer login: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 16 viewer ops forbidden: 403 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 17 admin reset password: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 18 admin reset revokes existing viewer session: 401 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 19 admin reset forces next-login password change | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 20 mustChangePassword landing: 302:/password/change | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 21 password change auth shell selectors | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 22 password change to temporary password succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 23 temporary password login succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 24 password_history original password immediate history reuse rejected: 400 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 25 password history count rotation succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 26 history rotation password login succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 27 original password restored after history count rotation: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 28 SaveUsersFile-backed password change lifecycle final login succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 29 admin disables viewer: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 30 disabled user login rejected: 401 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 31 admin restores viewer: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 32 restored viewer login succeeds: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 33 last active admin disable rejected: 409 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 34 last active admin role downgrade rejected: 409 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 35 login lockout stored | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 36 invite token issued once | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 37 invite expiry and setup URL visible once | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 38 invite list API exposes issued invite summary | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 39 invite list API redacts token material | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 40 users-only save after pending invite: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 41 pending invite preserved across users save | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 42 invite setup HTTP response renders required form | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 43 invite setup auth shell selectors | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 44 invite password setup: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 45 invited viewer login: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 46 invite.used consumed/expired token runtime status split: 401:410 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 47 existing invite target baseline login: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 48 existing invite baseline scope visible | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 49 pending invite keeps existing session: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 50 pending invite does not change existing role/scope | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 51 pending invite future scope not applied | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 52 existing invite accepted: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 53 accepted invite revokes previous session: 401 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 54 existing invite new password login: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 55 accepted invite applies role/scope | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 56 duplicate pending access request rejected: 409 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 57 access request unsafe viewId rejected: 400 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 58 oversized access request body rejected: 413 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 59 access request rate budget allows fourth counted attempt | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 60 access request rate budget allows fifth counted attempt: 201 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 61 access request per-peer rate limit enforced: 429 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 62 ops users access request reject API: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 63 rejected access request visible in ops API | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 64 pending access request form and pending-state copy | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 65 pending form submission remains denied login before approval: 401 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 66 approved request invite expiry visible once | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 67 approved request keeps user pending until invite setup | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 68 users-only save after approved request: 200 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 69 approved request preserved across users save | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 70 approved request invite preserved across users save | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 71 approved request password setup: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
| auth-users 72 approved request viewer login: 302 | ./server.sh verify-auth-users; exit 0 | pass | b13-auth-users.log.gz |
