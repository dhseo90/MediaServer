# B14 2번 전수 결과

독자: 증적 검토자. 수명: 과거 실패 포함 보존. 정책은 AGENTS.md. 원출력과 명령/exit/elapsed는 b14-step2-results.json.gz.

| 제목 | 수행내용 | 결과(pass/fail) |
| --- | --- | --- |
| agent-green.log | home 경로만 정제하고 판정·수치·한글을 유지한다 | pass |
| agent-green.log | JSON 값의 space·한글·escaped slash 경계를 깨지 않는다 | pass |
| agent-green.log | plain assertion 행에서 temp basename 뒤 PASS·숫자를 유지한다 | pass |
| agent-green.log | 정제는 멱등이고 두 번째 실행의 치환 수는 0이다 | pass |
| agent-green.log | policy secret pattern은 원문 없는 고정 코드로 거부한다 | pass |
| agent-green.log | 실제 값 형태의 password·token·cookie는 거부하되 정상 label은 허용한다 | pass |
| agent-green.log | findDeniedContent는 원문 없이 고정 분류만 반환한다 | pass |
| agent-green.log | 공개 transcript 경로는 원본 경로 hash로 결정되고 같은 디렉터리를 쓴다 | pass |
| agent-green.log | 공개 transcript source의 범위·확장자·모호한 경로를 거부한다 | pass |
| agent-review-green.log | home 경로만 정제하고 판정·수치·한글을 유지한다 | pass |
| agent-review-green.log | JSON 값의 space·한글·escaped slash 경계를 깨지 않는다 | pass |
| agent-review-green.log | plain assertion 행에서 temp root 뒤 PASS·숫자를 유지한다 | pass |
| agent-review-green.log | temp root 뒤 공백 path·route·판정 suffix를 문자 그대로 유지한다 | pass |
| agent-review-green.log | 고정 mac temp root가 아닌 애매한 경로는 치환하지 않고 거부한다 | pass |
| agent-review-green.log | 정제는 멱등이고 두 번째 실행의 치환 수는 0이다 | pass |
| agent-review-green.log | policy secret pattern은 원문 없는 고정 코드로 거부한다 | pass |
| agent-review-green.log | 실제 policy의 id·pattern 형식을 지원하고 malformed policy는 고정 코드로 거부한다 | pass |
| agent-review-green.log | 고정 policy 밖 password·token·cookie 문자열은 임의 비밀로 단정하지 않는다 | pass |
| agent-review-green.log | findDeniedContent는 원문 없이 고정 분류만 반환한다 | pass |
| agent-review-green.log | 공개 transcript 경로는 원본 경로 hash로 결정되고 같은 디렉터리를 쓴다 | pass |
| agent-review-green.log | 공개 transcript source의 범위·확장자·모호한 경로를 거부한다 | pass |
| agent-review-red.log | home 경로만 정제하고 판정·수치·한글을 유지한다 | pass |
| agent-review-red.log | JSON 값의 space·한글·escaped slash 경계를 깨지 않는다 | fail |
| agent-review-red.log | plain assertion 행에서 temp root 뒤 PASS·숫자를 유지한다 | pass |
| agent-review-red.log | temp root 뒤 공백 path·route·판정 suffix를 문자 그대로 유지한다 | fail |
| agent-review-red.log | 정제는 멱등이고 두 번째 실행의 치환 수는 0이다 | pass |
| agent-review-red.log | policy secret pattern은 원문 없는 고정 코드로 거부한다 | pass |
| agent-review-red.log | 실제 policy의 id·pattern 형식을 지원하고 malformed policy는 고정 코드로 거부한다 | fail |
| agent-review-red.log | 실제 값 형태의 password·token·cookie는 거부하되 정상 label은 허용한다 | fail |
| agent-review-red.log | findDeniedContent는 원문 없이 고정 분류만 반환한다 | fail |
| agent-review-red.log | 공개 transcript 경로는 원본 경로 hash로 결정되고 같은 디렉터리를 쓴다 | pass |
| agent-review-red.log | 공개 transcript source의 범위·확장자·모호한 경로를 거부한다 | pass |
| assets-green.log | B14-A01 검토 설정이 없으면 기존 허용 범위를 넓히지 않는다 | pass |
| assets-green.log | B14-A02 정확한 path 크기 SHA만 허용하고 같은 폴더 신규 파일은 허용하지 않는다 | pass |
| assets-green.log | B14-A03 manifest hash 불일치 거부 | pass |
| assets-green.log | B14-A04 이미지 변조와 크기 불일치 거부 | pass |
| assets-green.log | B14-A05 범위 밖 경로와 점점 경로 거부 | pass |
| assets-green.log | B14-A06 중복 및 count 불일치 거부 | pass |
| assets-green.log | B14-A07 미완료 증거의 PASS 승격 거부 | pass |
| assets-green.log | B14-A08 이미지 symlink 거부 | pass |
| assets-green.log | B14-A09 manifest 탈출 및 잘못된 schema 거부 | pass |
| migration-consumer.log | LP26-O09-A01 15초 첫/중간 경계와 즉시 실패 | pass |
| migration-consumer.log | LP26-O09-A02 identity·clock·pid 불일치 | pass |
| migration-consumer.log | LP26-O09-A03 보존 attempt3의 초과5건 중 첫 간격에서 실패 | pass |
| migration-consumer.log | LP26-O09-D01 실패 표본도 자원 요약에 보존하고 PASS 금지 | pass |
| migration-consumer.log | LP26-O09-D02 부족 표본과 잘못된 표본은 명시 상태 | pass |
| migration-consumer.log | LP26-O09-C02 slow 숫자행·완료/미완료·비밀 거부 | pass |
| migration-consumer.log | O28-D04 snapshot 진단이 판정 전 출력되고 최초 오류가 cleanup 뒤 재전파된다 | pass |
| migration-consumer.log | O28-D05 snapshot의 기존 15초·16KiB 상한과 성공 검사 계약을 유지한다 | pass |
| migration-consumer.log | B11-G03 삭제 미디어는 segment·event-link 조회 전에 fail-closed 한다 | pass |
| migration-consumer.log | O28-R03 observer wrapper는 실패 또는 cleanup-blocked root를 보존한다 | pass |
| migration-consumer.log | O28-R04 accumulation runner와 EXIT는 사전 manifest·parent/child 실패·미종료 group을 보존한다 | pass |
| migration-docs-assets.log | README uses only representative product UI screenshots | pass |
| migration-docs-assets.log | English README uses English UI screenshots | pass |
| migration-docs-assets.log | UI guide keeps product screenshots in the shared asset set | pass |
| migration-docs-assets.log | docs UI asset policy documents capture rules | pass |
| migration-docs-assets.log | managed UI asset manifest stays complete | pass |
| migration-docs-assets.log | capture script owns every documented UI asset | pass |
| migration-docs-assets.log | docs capture covers current screenshots | pass |
| migration-docs-assets.log | representative screenshot docs do not point at stale visual baselines | pass |
| migration-docs-assets.log | docs UI asset directory contains managed PNG files | pass |
| migration-docs-assets.log | VA documentation images keep full video frame bounds | pass |
| migration-inventory-final.log | S05 개별 동작 등록 exact 연결 (실행 증거 아님) | pass |
| migration-inventory-final.log | public docs index excludes internal feature inventory | pass |
| migration-inventory-final.log | feature inventory pins current release scope | pass |
| migration-inventory-final.log | required sections exist | pass |
| migration-inventory-final.log | historical V280 source-of-truth keeps the 2.x runway boundary explicit | pass |
| migration-inventory-final.log | historical V290 source-of-truth keeps source, published, and roadmap distinct | pass |
| migration-inventory-final.log | inventory summary count 전체 기능 항목 986 | pass |
| migration-inventory-final.log | inventory summary count UI 직접 필요 400 | pass |
| migration-inventory-final.log | inventory summary count UI 간접 필요 36 | pass |
| migration-inventory-final.log | inventory summary count UI 비대상 550 | pass |
| migration-inventory-final.log | inventory summary count 테스트 필요 986 | pass |
| migration-inventory-final.log | inventory summary count 안정화 대상 976 | pass |
| migration-inventory-final.log | inventory summary count UI 풀테스트 대상 424 | pass |
| migration-inventory-final.log | inventory summary count 30분 soak 대상 50 | pass |
| migration-inventory-final.log | inventory summary count 120분 대상 7 | pass |
| migration-inventory-final.log | summary counts match current feature IDs | pass |
| migration-inventory-final.log | implementation evidence manifest matches all feature rows | pass |
| migration-inventory-final.log | feature UI-001 name present | pass |
| migration-inventory-final.log | feature UI-001 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-001 test need 필요 | pass |
| migration-inventory-final.log | feature UI-001 test area assigned | pass |
| migration-inventory-final.log | feature UI-001 pass criteria present | pass |
| migration-inventory-final.log | feature UI-002 name present | pass |
| migration-inventory-final.log | feature UI-002 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-002 test need 필요 | pass |
| migration-inventory-final.log | feature UI-002 test area assigned | pass |
| migration-inventory-final.log | feature UI-002 pass criteria present | pass |
| migration-inventory-final.log | feature UI-003 name present | pass |
| migration-inventory-final.log | feature UI-003 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-003 test need 필요 | pass |
| migration-inventory-final.log | feature UI-003 test area assigned | pass |
| migration-inventory-final.log | feature UI-003 pass criteria present | pass |
| migration-inventory-final.log | feature UI-004 name present | pass |
| migration-inventory-final.log | feature UI-004 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-004 test need 필요 | pass |
| migration-inventory-final.log | feature UI-004 test area assigned | pass |
| migration-inventory-final.log | feature UI-004 pass criteria present | pass |
| migration-inventory-final.log | feature UI-005 name present | pass |
| migration-inventory-final.log | feature UI-005 UI need 간접 | pass |
| migration-inventory-final.log | feature UI-005 test need 필요 | pass |
| migration-inventory-final.log | feature UI-005 test area assigned | pass |
| migration-inventory-final.log | feature UI-005 pass criteria present | pass |
| migration-inventory-final.log | feature UI-006 name present | pass |
| migration-inventory-final.log | feature UI-006 UI need 간접 | pass |
| migration-inventory-final.log | feature UI-006 test need 필요 | pass |
| migration-inventory-final.log | feature UI-006 test area assigned | pass |
| migration-inventory-final.log | feature UI-006 pass criteria present | pass |
| migration-inventory-final.log | feature UI-007 name present | pass |
| migration-inventory-final.log | feature UI-007 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-007 test need 필요 | pass |
| migration-inventory-final.log | feature UI-007 test area assigned | pass |
| migration-inventory-final.log | feature UI-007 pass criteria present | pass |
| migration-inventory-final.log | feature UI-008 name present | pass |
| migration-inventory-final.log | feature UI-008 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-008 test need 필요 | pass |
| migration-inventory-final.log | feature UI-008 test area assigned | pass |
| migration-inventory-final.log | feature UI-008 pass criteria present | pass |
| migration-inventory-final.log | feature UI-009 name present | pass |
| migration-inventory-final.log | feature UI-009 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-009 test need 필요 | pass |
| migration-inventory-final.log | feature UI-009 test area assigned | pass |
| migration-inventory-final.log | feature UI-009 pass criteria present | pass |
| migration-inventory-final.log | feature UI-010 name present | pass |
| migration-inventory-final.log | feature UI-010 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-010 test need 필요 | pass |
| migration-inventory-final.log | feature UI-010 test area assigned | pass |
| migration-inventory-final.log | feature UI-010 pass criteria present | pass |
| migration-inventory-final.log | feature UI-011 name present | pass |
| migration-inventory-final.log | feature UI-011 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-011 test need 필요 | pass |
| migration-inventory-final.log | feature UI-011 test area assigned | pass |
| migration-inventory-final.log | feature UI-011 pass criteria present | pass |
| migration-inventory-final.log | feature UI-012 name present | pass |
| migration-inventory-final.log | feature UI-012 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-012 test need 필요 | pass |
| migration-inventory-final.log | feature UI-012 test area assigned | pass |
| migration-inventory-final.log | feature UI-012 pass criteria present | pass |
| migration-inventory-final.log | feature UI-013 name present | pass |
| migration-inventory-final.log | feature UI-013 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-013 test need 필요 | pass |
| migration-inventory-final.log | feature UI-013 test area assigned | pass |
| migration-inventory-final.log | feature UI-013 pass criteria present | pass |
| migration-inventory-final.log | feature UI-014 name present | pass |
| migration-inventory-final.log | feature UI-014 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-014 test need 필요 | pass |
| migration-inventory-final.log | feature UI-014 test area assigned | pass |
| migration-inventory-final.log | feature UI-014 pass criteria present | pass |
| migration-inventory-final.log | feature UI-015 name present | pass |
| migration-inventory-final.log | feature UI-015 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-015 test need 필요 | pass |
| migration-inventory-final.log | feature UI-015 test area assigned | pass |
| migration-inventory-final.log | feature UI-015 pass criteria present | pass |
| migration-inventory-final.log | feature UI-016 name present | pass |
| migration-inventory-final.log | feature UI-016 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-016 test need 필요 | pass |
| migration-inventory-final.log | feature UI-016 test area assigned | pass |
| migration-inventory-final.log | feature UI-016 pass criteria present | pass |
| migration-inventory-final.log | feature UI-017 name present | pass |
| migration-inventory-final.log | feature UI-017 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-017 test need 필요 | pass |
| migration-inventory-final.log | feature UI-017 test area assigned | pass |
| migration-inventory-final.log | feature UI-017 pass criteria present | pass |
| migration-inventory-final.log | feature UI-018 name present | pass |
| migration-inventory-final.log | feature UI-018 UI need 비대상 | pass |
| migration-inventory-final.log | feature UI-018 test need 필요 | pass |
| migration-inventory-final.log | feature UI-018 test area assigned | pass |
| migration-inventory-final.log | feature UI-018 pass criteria present | pass |
| migration-inventory-final.log | feature UI-019 name present | pass |
| migration-inventory-final.log | feature UI-019 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-019 test need 필요 | pass |
| migration-inventory-final.log | feature UI-019 test area assigned | pass |
| migration-inventory-final.log | feature UI-019 pass criteria present | pass |
| migration-inventory-final.log | feature UI-020 name present | pass |
| migration-inventory-final.log | feature UI-020 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-020 test need 필요 | pass |
| migration-inventory-final.log | feature UI-020 test area assigned | pass |
| migration-inventory-final.log | feature UI-020 pass criteria present | pass |
| migration-inventory-final.log | feature UI-021 name present | pass |
| migration-inventory-final.log | feature UI-021 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-021 test need 필요 | pass |
| migration-inventory-final.log | feature UI-021 test area assigned | pass |
| migration-inventory-final.log | feature UI-021 pass criteria present | pass |
| migration-inventory-final.log | feature UI-022 name present | pass |
| migration-inventory-final.log | feature UI-022 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-022 test need 필요 | pass |
| migration-inventory-final.log | feature UI-022 test area assigned | pass |
| migration-inventory-final.log | feature UI-022 pass criteria present | pass |
| migration-inventory-final.log | feature UI-023 name present | pass |
| migration-inventory-final.log | feature UI-023 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-023 test need 필요 | pass |
| migration-inventory-final.log | feature UI-023 test area assigned | pass |
| migration-inventory-final.log | feature UI-023 pass criteria present | pass |
| migration-inventory-final.log | feature UI-024 name present | pass |
| migration-inventory-final.log | feature UI-024 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-024 test need 필요 | pass |
| migration-inventory-final.log | feature UI-024 test area assigned | pass |
| migration-inventory-final.log | feature UI-024 pass criteria present | pass |
| migration-inventory-final.log | feature UI-025 name present | pass |
| migration-inventory-final.log | feature UI-025 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-025 test need 필요 | pass |
| migration-inventory-final.log | feature UI-025 test area assigned | pass |
| migration-inventory-final.log | feature UI-025 pass criteria present | pass |
| migration-inventory-final.log | feature UI-026 name present | pass |
| migration-inventory-final.log | feature UI-026 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-026 test need 필요 | pass |
| migration-inventory-final.log | feature UI-026 test area assigned | pass |
| migration-inventory-final.log | feature UI-026 pass criteria present | pass |
| migration-inventory-final.log | feature UI-027 name present | pass |
| migration-inventory-final.log | feature UI-027 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-027 test need 필요 | pass |
| migration-inventory-final.log | feature UI-027 test area assigned | pass |
| migration-inventory-final.log | feature UI-027 pass criteria present | pass |
| migration-inventory-final.log | feature UI-028 name present | pass |
| migration-inventory-final.log | feature UI-028 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-028 test need 필요 | pass |
| migration-inventory-final.log | feature UI-028 test area assigned | pass |
| migration-inventory-final.log | feature UI-028 pass criteria present | pass |
| migration-inventory-final.log | feature UI-029 name present | pass |
| migration-inventory-final.log | feature UI-029 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-029 test need 필요 | pass |
| migration-inventory-final.log | feature UI-029 test area assigned | pass |
| migration-inventory-final.log | feature UI-029 pass criteria present | pass |
| migration-inventory-final.log | feature UI-030 name present | pass |
| migration-inventory-final.log | feature UI-030 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-030 test need 필요 | pass |
| migration-inventory-final.log | feature UI-030 test area assigned | pass |
| migration-inventory-final.log | feature UI-030 pass criteria present | pass |
| migration-inventory-final.log | feature UI-031 name present | pass |
| migration-inventory-final.log | feature UI-031 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-031 test need 필요 | pass |
| migration-inventory-final.log | feature UI-031 test area assigned | pass |
| migration-inventory-final.log | feature UI-031 pass criteria present | pass |
| migration-inventory-final.log | feature UI-032 name present | pass |
| migration-inventory-final.log | feature UI-032 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-032 test need 필요 | pass |
| migration-inventory-final.log | feature UI-032 test area assigned | pass |
| migration-inventory-final.log | feature UI-032 pass criteria present | pass |
| migration-inventory-final.log | feature UI-033 name present | pass |
| migration-inventory-final.log | feature UI-033 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-033 test need 필요 | pass |
| migration-inventory-final.log | feature UI-033 test area assigned | pass |
| migration-inventory-final.log | feature UI-033 pass criteria present | pass |
| migration-inventory-final.log | feature UI-034 name present | pass |
| migration-inventory-final.log | feature UI-034 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-034 test need 필요 | pass |
| migration-inventory-final.log | feature UI-034 test area assigned | pass |
| migration-inventory-final.log | feature UI-034 pass criteria present | pass |
| migration-inventory-final.log | feature UI-035 name present | pass |
| migration-inventory-final.log | feature UI-035 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-035 test need 필요 | pass |
| migration-inventory-final.log | feature UI-035 test area assigned | pass |
| migration-inventory-final.log | feature UI-035 pass criteria present | pass |
| migration-inventory-final.log | feature UI-036 name present | pass |
| migration-inventory-final.log | feature UI-036 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-036 test need 필요 | pass |
| migration-inventory-final.log | feature UI-036 test area assigned | pass |
| migration-inventory-final.log | feature UI-036 pass criteria present | pass |
| migration-inventory-final.log | feature UI-037 name present | pass |
| migration-inventory-final.log | feature UI-037 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-037 test need 필요 | pass |
| migration-inventory-final.log | feature UI-037 test area assigned | pass |
| migration-inventory-final.log | feature UI-037 pass criteria present | pass |
| migration-inventory-final.log | feature UI-038 name present | pass |
| migration-inventory-final.log | feature UI-038 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-038 test need 필요 | pass |
| migration-inventory-final.log | feature UI-038 test area assigned | pass |
| migration-inventory-final.log | feature UI-038 pass criteria present | pass |
| migration-inventory-final.log | feature UI-039 name present | pass |
| migration-inventory-final.log | feature UI-039 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-039 test need 필요 | pass |
| migration-inventory-final.log | feature UI-039 test area assigned | pass |
| migration-inventory-final.log | feature UI-039 pass criteria present | pass |
| migration-inventory-final.log | feature UI-040 name present | pass |
| migration-inventory-final.log | feature UI-040 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-040 test need 필요 | pass |
| migration-inventory-final.log | feature UI-040 test area assigned | pass |
| migration-inventory-final.log | feature UI-040 pass criteria present | pass |
| migration-inventory-final.log | feature UI-041 name present | pass |
| migration-inventory-final.log | feature UI-041 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-041 test need 필요 | pass |
| migration-inventory-final.log | feature UI-041 test area assigned | pass |
| migration-inventory-final.log | feature UI-041 pass criteria present | pass |
| migration-inventory-final.log | feature UI-042 name present | pass |
| migration-inventory-final.log | feature UI-042 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-042 test need 필요 | pass |
| migration-inventory-final.log | feature UI-042 test area assigned | pass |
| migration-inventory-final.log | feature UI-042 pass criteria present | pass |
| migration-inventory-final.log | feature UI-043 name present | pass |
| migration-inventory-final.log | feature UI-043 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-043 test need 필요 | pass |
| migration-inventory-final.log | feature UI-043 test area assigned | pass |
| migration-inventory-final.log | feature UI-043 pass criteria present | pass |
| migration-inventory-final.log | feature UI-044 name present | pass |
| migration-inventory-final.log | feature UI-044 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-044 test need 필요 | pass |
| migration-inventory-final.log | feature UI-044 test area assigned | pass |
| migration-inventory-final.log | feature UI-044 pass criteria present | pass |
| migration-inventory-final.log | feature UI-045 name present | pass |
| migration-inventory-final.log | feature UI-045 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-045 test need 필요 | pass |
| migration-inventory-final.log | feature UI-045 test area assigned | pass |
| migration-inventory-final.log | feature UI-045 pass criteria present | pass |
| migration-inventory-final.log | feature UI-046 name present | pass |
| migration-inventory-final.log | feature UI-046 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-046 test need 필요 | pass |
| migration-inventory-final.log | feature UI-046 test area assigned | pass |
| migration-inventory-final.log | feature UI-046 pass criteria present | pass |
| migration-inventory-final.log | feature UI-047 name present | pass |
| migration-inventory-final.log | feature UI-047 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-047 test need 필요 | pass |
| migration-inventory-final.log | feature UI-047 test area assigned | pass |
| migration-inventory-final.log | feature UI-047 pass criteria present | pass |
| migration-inventory-final.log | feature UI-048 name present | pass |
| migration-inventory-final.log | feature UI-048 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-048 test need 필요 | pass |
| migration-inventory-final.log | feature UI-048 test area assigned | pass |
| migration-inventory-final.log | feature UI-048 pass criteria present | pass |
| migration-inventory-final.log | feature UI-049 name present | pass |
| migration-inventory-final.log | feature UI-049 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-049 test need 필요 | pass |
| migration-inventory-final.log | feature UI-049 test area assigned | pass |
| migration-inventory-final.log | feature UI-049 pass criteria present | pass |
| migration-inventory-final.log | feature UI-050 name present | pass |
| migration-inventory-final.log | feature UI-050 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-050 test need 필요 | pass |
| migration-inventory-final.log | feature UI-050 test area assigned | pass |
| migration-inventory-final.log | feature UI-050 pass criteria present | pass |
| migration-inventory-final.log | feature UI-051 name present | pass |
| migration-inventory-final.log | feature UI-051 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-051 test need 필요 | pass |
| migration-inventory-final.log | feature UI-051 test area assigned | pass |
| migration-inventory-final.log | feature UI-051 pass criteria present | pass |
| migration-inventory-final.log | feature UI-052 name present | pass |
| migration-inventory-final.log | feature UI-052 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-052 test need 필요 | pass |
| migration-inventory-final.log | feature UI-052 test area assigned | pass |
| migration-inventory-final.log | feature UI-052 pass criteria present | pass |
| migration-inventory-final.log | feature UI-053 name present | pass |
| migration-inventory-final.log | feature UI-053 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-053 test need 필요 | pass |
| migration-inventory-final.log | feature UI-053 test area assigned | pass |
| migration-inventory-final.log | feature UI-053 pass criteria present | pass |
| migration-inventory-final.log | feature UI-054 name present | pass |
| migration-inventory-final.log | feature UI-054 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-054 test need 필요 | pass |
| migration-inventory-final.log | feature UI-054 test area assigned | pass |
| migration-inventory-final.log | feature UI-054 pass criteria present | pass |
| migration-inventory-final.log | feature UI-055 name present | pass |
| migration-inventory-final.log | feature UI-055 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-055 test need 필요 | pass |
| migration-inventory-final.log | feature UI-055 test area assigned | pass |
| migration-inventory-final.log | feature UI-055 pass criteria present | pass |
| migration-inventory-final.log | feature UI-056 name present | pass |
| migration-inventory-final.log | feature UI-056 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-056 test need 필요 | pass |
| migration-inventory-final.log | feature UI-056 test area assigned | pass |
| migration-inventory-final.log | feature UI-056 pass criteria present | pass |
| migration-inventory-final.log | feature UI-057 name present | pass |
| migration-inventory-final.log | feature UI-057 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-057 test need 필요 | pass |
| migration-inventory-final.log | feature UI-057 test area assigned | pass |
| migration-inventory-final.log | feature UI-057 pass criteria present | pass |
| migration-inventory-final.log | feature UI-058 name present | pass |
| migration-inventory-final.log | feature UI-058 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-058 test need 필요 | pass |
| migration-inventory-final.log | feature UI-058 test area assigned | pass |
| migration-inventory-final.log | feature UI-058 pass criteria present | pass |
| migration-inventory-final.log | feature UI-059 name present | pass |
| migration-inventory-final.log | feature UI-059 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-059 test need 필요 | pass |
| migration-inventory-final.log | feature UI-059 test area assigned | pass |
| migration-inventory-final.log | feature UI-059 pass criteria present | pass |
| migration-inventory-final.log | feature UI-060 name present | pass |
| migration-inventory-final.log | feature UI-060 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-060 test need 필요 | pass |
| migration-inventory-final.log | feature UI-060 test area assigned | pass |
| migration-inventory-final.log | feature UI-060 pass criteria present | pass |
| migration-inventory-final.log | feature UI-061 name present | pass |
| migration-inventory-final.log | feature UI-061 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-061 test need 필요 | pass |
| migration-inventory-final.log | feature UI-061 test area assigned | pass |
| migration-inventory-final.log | feature UI-061 pass criteria present | pass |
| migration-inventory-final.log | feature UI-062 name present | pass |
| migration-inventory-final.log | feature UI-062 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-062 test need 필요 | pass |
| migration-inventory-final.log | feature UI-062 test area assigned | pass |
| migration-inventory-final.log | feature UI-062 pass criteria present | pass |
| migration-inventory-final.log | feature UI-063 name present | pass |
| migration-inventory-final.log | feature UI-063 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-063 test need 필요 | pass |
| migration-inventory-final.log | feature UI-063 test area assigned | pass |
| migration-inventory-final.log | feature UI-063 pass criteria present | pass |
| migration-inventory-final.log | feature UI-064 name present | pass |
| migration-inventory-final.log | feature UI-064 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-064 test need 필요 | pass |
| migration-inventory-final.log | feature UI-064 test area assigned | pass |
| migration-inventory-final.log | feature UI-064 pass criteria present | pass |
| migration-inventory-final.log | feature UI-065 name present | pass |
| migration-inventory-final.log | feature UI-065 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-065 test need 필요 | pass |
| migration-inventory-final.log | feature UI-065 test area assigned | pass |
| migration-inventory-final.log | feature UI-065 pass criteria present | pass |
| migration-inventory-final.log | feature UI-066 name present | pass |
| migration-inventory-final.log | feature UI-066 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-066 test need 필요 | pass |
| migration-inventory-final.log | feature UI-066 test area assigned | pass |
| migration-inventory-final.log | feature UI-066 pass criteria present | pass |
| migration-inventory-final.log | feature UI-067 name present | pass |
| migration-inventory-final.log | feature UI-067 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-067 test need 필요 | pass |
| migration-inventory-final.log | feature UI-067 test area assigned | pass |
| migration-inventory-final.log | feature UI-067 pass criteria present | pass |
| migration-inventory-final.log | feature UI-068 name present | pass |
| migration-inventory-final.log | feature UI-068 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-068 test need 필요 | pass |
| migration-inventory-final.log | feature UI-068 test area assigned | pass |
| migration-inventory-final.log | feature UI-068 pass criteria present | pass |
| migration-inventory-final.log | feature UI-069 name present | pass |
| migration-inventory-final.log | feature UI-069 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-069 test need 필요 | pass |
| migration-inventory-final.log | feature UI-069 test area assigned | pass |
| migration-inventory-final.log | feature UI-069 pass criteria present | pass |
| migration-inventory-final.log | feature UI-070 name present | pass |
| migration-inventory-final.log | feature UI-070 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-070 test need 필요 | pass |
| migration-inventory-final.log | feature UI-070 test area assigned | pass |
| migration-inventory-final.log | feature UI-070 pass criteria present | pass |
| migration-inventory-final.log | feature UI-071 name present | pass |
| migration-inventory-final.log | feature UI-071 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-071 test need 필요 | pass |
| migration-inventory-final.log | feature UI-071 test area assigned | pass |
| migration-inventory-final.log | feature UI-071 pass criteria present | pass |
| migration-inventory-final.log | feature UI-072 name present | pass |
| migration-inventory-final.log | feature UI-072 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-072 test need 필요 | pass |
| migration-inventory-final.log | feature UI-072 test area assigned | pass |
| migration-inventory-final.log | feature UI-072 pass criteria present | pass |
| migration-inventory-final.log | feature UI-073 name present | pass |
| migration-inventory-final.log | feature UI-073 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-073 test need 필요 | pass |
| migration-inventory-final.log | feature UI-073 test area assigned | pass |
| migration-inventory-final.log | feature UI-073 pass criteria present | pass |
| migration-inventory-final.log | feature UI-074 name present | pass |
| migration-inventory-final.log | feature UI-074 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-074 test need 필요 | pass |
| migration-inventory-final.log | feature UI-074 test area assigned | pass |
| migration-inventory-final.log | feature UI-074 pass criteria present | pass |
| migration-inventory-final.log | feature UI-075 name present | pass |
| migration-inventory-final.log | feature UI-075 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-075 test need 필요 | pass |
| migration-inventory-final.log | feature UI-075 test area assigned | pass |
| migration-inventory-final.log | feature UI-075 pass criteria present | pass |
| migration-inventory-final.log | feature UI-076 name present | pass |
| migration-inventory-final.log | feature UI-076 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-076 test need 필요 | pass |
| migration-inventory-final.log | feature UI-076 test area assigned | pass |
| migration-inventory-final.log | feature UI-076 pass criteria present | pass |
| migration-inventory-final.log | feature UI-077 name present | pass |
| migration-inventory-final.log | feature UI-077 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-077 test need 필요 | pass |
| migration-inventory-final.log | feature UI-077 test area assigned | pass |
| migration-inventory-final.log | feature UI-077 pass criteria present | pass |
| migration-inventory-final.log | feature UI-078 name present | pass |
| migration-inventory-final.log | feature UI-078 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-078 test need 필요 | pass |
| migration-inventory-final.log | feature UI-078 test area assigned | pass |
| migration-inventory-final.log | feature UI-078 pass criteria present | pass |
| migration-inventory-final.log | feature UI-079 name present | pass |
| migration-inventory-final.log | feature UI-079 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-079 test need 필요 | pass |
| migration-inventory-final.log | feature UI-079 test area assigned | pass |
| migration-inventory-final.log | feature UI-079 pass criteria present | pass |
| migration-inventory-final.log | feature UI-080 name present | pass |
| migration-inventory-final.log | feature UI-080 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-080 test need 필요 | pass |
| migration-inventory-final.log | feature UI-080 test area assigned | pass |
| migration-inventory-final.log | feature UI-080 pass criteria present | pass |
| migration-inventory-final.log | feature UI-081 name present | pass |
| migration-inventory-final.log | feature UI-081 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-081 test need 필요 | pass |
| migration-inventory-final.log | feature UI-081 test area assigned | pass |
| migration-inventory-final.log | feature UI-081 pass criteria present | pass |
| migration-inventory-final.log | feature UI-082 name present | pass |
| migration-inventory-final.log | feature UI-082 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-082 test need 필요 | pass |
| migration-inventory-final.log | feature UI-082 test area assigned | pass |
| migration-inventory-final.log | feature UI-082 pass criteria present | pass |
| migration-inventory-final.log | feature UI-083 name present | pass |
| migration-inventory-final.log | feature UI-083 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-083 test need 필요 | pass |
| migration-inventory-final.log | feature UI-083 test area assigned | pass |
| migration-inventory-final.log | feature UI-083 pass criteria present | pass |
| migration-inventory-final.log | feature UI-084 name present | pass |
| migration-inventory-final.log | feature UI-084 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-084 test need 필요 | pass |
| migration-inventory-final.log | feature UI-084 test area assigned | pass |
| migration-inventory-final.log | feature UI-084 pass criteria present | pass |
| migration-inventory-final.log | feature UI-085 name present | pass |
| migration-inventory-final.log | feature UI-085 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-085 test need 필요 | pass |
| migration-inventory-final.log | feature UI-085 test area assigned | pass |
| migration-inventory-final.log | feature UI-085 pass criteria present | pass |
| migration-inventory-final.log | feature UI-086 name present | pass |
| migration-inventory-final.log | feature UI-086 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-086 test need 필요 | pass |
| migration-inventory-final.log | feature UI-086 test area assigned | pass |
| migration-inventory-final.log | feature UI-086 pass criteria present | pass |
| migration-inventory-final.log | feature UI-087 name present | pass |
| migration-inventory-final.log | feature UI-087 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-087 test need 필요 | pass |
| migration-inventory-final.log | feature UI-087 test area assigned | pass |
| migration-inventory-final.log | feature UI-087 pass criteria present | pass |
| migration-inventory-final.log | feature UI-088 name present | pass |
| migration-inventory-final.log | feature UI-088 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-088 test need 필요 | pass |
| migration-inventory-final.log | feature UI-088 test area assigned | pass |
| migration-inventory-final.log | feature UI-088 pass criteria present | pass |
| migration-inventory-final.log | feature UI-089 name present | pass |
| migration-inventory-final.log | feature UI-089 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-089 test need 필요 | pass |
| migration-inventory-final.log | feature UI-089 test area assigned | pass |
| migration-inventory-final.log | feature UI-089 pass criteria present | pass |
| migration-inventory-final.log | feature UI-090 name present | pass |
| migration-inventory-final.log | feature UI-090 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-090 test need 필요 | pass |
| migration-inventory-final.log | feature UI-090 test area assigned | pass |
| migration-inventory-final.log | feature UI-090 pass criteria present | pass |
| migration-inventory-final.log | feature UI-091 name present | pass |
| migration-inventory-final.log | feature UI-091 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-091 test need 필요 | pass |
| migration-inventory-final.log | feature UI-091 test area assigned | pass |
| migration-inventory-final.log | feature UI-091 pass criteria present | pass |
| migration-inventory-final.log | feature UI-092 name present | pass |
| migration-inventory-final.log | feature UI-092 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-092 test need 필요 | pass |
| migration-inventory-final.log | feature UI-092 test area assigned | pass |
| migration-inventory-final.log | feature UI-092 pass criteria present | pass |
| migration-inventory-final.log | feature UI-093 name present | pass |
| migration-inventory-final.log | feature UI-093 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-093 test need 필요 | pass |
| migration-inventory-final.log | feature UI-093 test area assigned | pass |
| migration-inventory-final.log | feature UI-093 pass criteria present | pass |
| migration-inventory-final.log | feature UI-094 name present | pass |
| migration-inventory-final.log | feature UI-094 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-094 test need 필요 | pass |
| migration-inventory-final.log | feature UI-094 test area assigned | pass |
| migration-inventory-final.log | feature UI-094 pass criteria present | pass |
| migration-inventory-final.log | feature UI-095 name present | pass |
| migration-inventory-final.log | feature UI-095 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-095 test need 필요 | pass |
| migration-inventory-final.log | feature UI-095 test area assigned | pass |
| migration-inventory-final.log | feature UI-095 pass criteria present | pass |
| migration-inventory-final.log | feature UI-096 name present | pass |
| migration-inventory-final.log | feature UI-096 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-096 test need 필요 | pass |
| migration-inventory-final.log | feature UI-096 test area assigned | pass |
| migration-inventory-final.log | feature UI-096 pass criteria present | pass |
| migration-inventory-final.log | feature UI-097 name present | pass |
| migration-inventory-final.log | feature UI-097 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-097 test need 필요 | pass |
| migration-inventory-final.log | feature UI-097 test area assigned | pass |
| migration-inventory-final.log | feature UI-097 pass criteria present | pass |
| migration-inventory-final.log | feature UI-098 name present | pass |
| migration-inventory-final.log | feature UI-098 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-098 test need 필요 | pass |
| migration-inventory-final.log | feature UI-098 test area assigned | pass |
| migration-inventory-final.log | feature UI-098 pass criteria present | pass |
| migration-inventory-final.log | feature UI-099 name present | pass |
| migration-inventory-final.log | feature UI-099 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-099 test need 필요 | pass |
| migration-inventory-final.log | feature UI-099 test area assigned | pass |
| migration-inventory-final.log | feature UI-099 pass criteria present | pass |
| migration-inventory-final.log | feature UI-100 name present | pass |
| migration-inventory-final.log | feature UI-100 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-100 test need 필요 | pass |
| migration-inventory-final.log | feature UI-100 test area assigned | pass |
| migration-inventory-final.log | feature UI-100 pass criteria present | pass |
| migration-inventory-final.log | feature UI-101 name present | pass |
| migration-inventory-final.log | feature UI-101 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-101 test need 필요 | pass |
| migration-inventory-final.log | feature UI-101 test area assigned | pass |
| migration-inventory-final.log | feature UI-101 pass criteria present | pass |
| migration-inventory-final.log | feature UI-102 name present | pass |
| migration-inventory-final.log | feature UI-102 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-102 test need 필요 | pass |
| migration-inventory-final.log | feature UI-102 test area assigned | pass |
| migration-inventory-final.log | feature UI-102 pass criteria present | pass |
| migration-inventory-final.log | feature UI-103 name present | pass |
| migration-inventory-final.log | feature UI-103 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-103 test need 필요 | pass |
| migration-inventory-final.log | feature UI-103 test area assigned | pass |
| migration-inventory-final.log | feature UI-103 pass criteria present | pass |
| migration-inventory-final.log | feature UI-104 name present | pass |
| migration-inventory-final.log | feature UI-104 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-104 test need 필요 | pass |
| migration-inventory-final.log | feature UI-104 test area assigned | pass |
| migration-inventory-final.log | feature UI-104 pass criteria present | pass |
| migration-inventory-final.log | feature UI-105 name present | pass |
| migration-inventory-final.log | feature UI-105 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-105 test need 필요 | pass |
| migration-inventory-final.log | feature UI-105 test area assigned | pass |
| migration-inventory-final.log | feature UI-105 pass criteria present | pass |
| migration-inventory-final.log | feature UI-106 name present | pass |
| migration-inventory-final.log | feature UI-106 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-106 test need 필요 | pass |
| migration-inventory-final.log | feature UI-106 test area assigned | pass |
| migration-inventory-final.log | feature UI-106 pass criteria present | pass |
| migration-inventory-final.log | feature UI-107 name present | pass |
| migration-inventory-final.log | feature UI-107 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-107 test need 필요 | pass |
| migration-inventory-final.log | feature UI-107 test area assigned | pass |
| migration-inventory-final.log | feature UI-107 pass criteria present | pass |
| migration-inventory-final.log | feature UI-108 name present | pass |
| migration-inventory-final.log | feature UI-108 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-108 test need 필요 | pass |
| migration-inventory-final.log | feature UI-108 test area assigned | pass |
| migration-inventory-final.log | feature UI-108 pass criteria present | pass |
| migration-inventory-final.log | feature UI-109 name present | pass |
| migration-inventory-final.log | feature UI-109 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-109 test need 필요 | pass |
| migration-inventory-final.log | feature UI-109 test area assigned | pass |
| migration-inventory-final.log | feature UI-109 pass criteria present | pass |
| migration-inventory-final.log | feature UI-110 name present | pass |
| migration-inventory-final.log | feature UI-110 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-110 test need 필요 | pass |
| migration-inventory-final.log | feature UI-110 test area assigned | pass |
| migration-inventory-final.log | feature UI-110 pass criteria present | pass |
| migration-inventory-final.log | feature UI-111 name present | pass |
| migration-inventory-final.log | feature UI-111 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-111 test need 필요 | pass |
| migration-inventory-final.log | feature UI-111 test area assigned | pass |
| migration-inventory-final.log | feature UI-111 pass criteria present | pass |
| migration-inventory-final.log | feature UI-112 name present | pass |
| migration-inventory-final.log | feature UI-112 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-112 test need 필요 | pass |
| migration-inventory-final.log | feature UI-112 test area assigned | pass |
| migration-inventory-final.log | feature UI-112 pass criteria present | pass |
| migration-inventory-final.log | feature UI-113 name present | pass |
| migration-inventory-final.log | feature UI-113 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-113 test need 필요 | pass |
| migration-inventory-final.log | feature UI-113 test area assigned | pass |
| migration-inventory-final.log | feature UI-113 pass criteria present | pass |
| migration-inventory-final.log | feature UI-114 name present | pass |
| migration-inventory-final.log | feature UI-114 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-114 test need 필요 | pass |
| migration-inventory-final.log | feature UI-114 test area assigned | pass |
| migration-inventory-final.log | feature UI-114 pass criteria present | pass |
| migration-inventory-final.log | feature UI-115 name present | pass |
| migration-inventory-final.log | feature UI-115 UI need 필요 | pass |
| migration-inventory-final.log | feature UI-115 test need 필요 | pass |
| migration-inventory-final.log | feature UI-115 test area assigned | pass |
| migration-inventory-final.log | feature UI-115 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-001 name present | pass |
| migration-inventory-final.log | feature AUTH-001 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-001 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-001 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-001 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-002 name present | pass |
| migration-inventory-final.log | feature AUTH-002 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-002 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-002 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-002 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-003 name present | pass |
| migration-inventory-final.log | feature AUTH-003 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-003 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-003 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-003 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-004 name present | pass |
| migration-inventory-final.log | feature AUTH-004 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-004 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-004 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-004 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-005 name present | pass |
| migration-inventory-final.log | feature AUTH-005 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-005 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-005 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-005 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-006 name present | pass |
| migration-inventory-final.log | feature AUTH-006 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-006 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-006 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-006 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-007 name present | pass |
| migration-inventory-final.log | feature AUTH-007 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-007 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-007 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-007 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-008 name present | pass |
| migration-inventory-final.log | feature AUTH-008 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-008 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-008 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-008 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-009 name present | pass |
| migration-inventory-final.log | feature AUTH-009 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-009 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-009 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-009 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-010 name present | pass |
| migration-inventory-final.log | feature AUTH-010 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-010 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-010 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-010 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-011 name present | pass |
| migration-inventory-final.log | feature AUTH-011 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-011 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-011 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-011 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-012 name present | pass |
| migration-inventory-final.log | feature AUTH-012 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-012 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-012 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-012 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-013 name present | pass |
| migration-inventory-final.log | feature AUTH-013 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-013 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-013 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-013 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-014 name present | pass |
| migration-inventory-final.log | feature AUTH-014 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-014 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-014 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-014 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-015 name present | pass |
| migration-inventory-final.log | feature AUTH-015 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-015 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-015 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-015 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-016 name present | pass |
| migration-inventory-final.log | feature AUTH-016 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-016 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-016 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-016 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-017 name present | pass |
| migration-inventory-final.log | feature AUTH-017 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-017 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-017 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-017 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-018 name present | pass |
| migration-inventory-final.log | feature AUTH-018 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-018 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-018 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-018 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-019 name present | pass |
| migration-inventory-final.log | feature AUTH-019 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-019 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-019 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-019 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-020 name present | pass |
| migration-inventory-final.log | feature AUTH-020 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-020 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-020 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-020 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-021 name present | pass |
| migration-inventory-final.log | feature AUTH-021 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-021 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-021 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-021 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-022 name present | pass |
| migration-inventory-final.log | feature AUTH-022 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-022 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-022 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-022 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-023 name present | pass |
| migration-inventory-final.log | feature AUTH-023 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-023 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-023 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-023 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-024 name present | pass |
| migration-inventory-final.log | feature AUTH-024 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-024 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-024 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-024 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-025 name present | pass |
| migration-inventory-final.log | feature AUTH-025 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-025 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-025 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-025 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-026 name present | pass |
| migration-inventory-final.log | feature AUTH-026 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-026 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-026 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-026 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-027 name present | pass |
| migration-inventory-final.log | feature AUTH-027 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-027 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-027 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-027 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-028 name present | pass |
| migration-inventory-final.log | feature AUTH-028 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-028 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-028 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-028 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-029 name present | pass |
| migration-inventory-final.log | feature AUTH-029 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-029 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-029 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-029 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-030 name present | pass |
| migration-inventory-final.log | feature AUTH-030 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-030 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-030 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-030 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-031 name present | pass |
| migration-inventory-final.log | feature AUTH-031 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-031 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-031 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-031 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-032 name present | pass |
| migration-inventory-final.log | feature AUTH-032 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-032 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-032 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-032 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-033 name present | pass |
| migration-inventory-final.log | feature AUTH-033 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-033 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-033 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-033 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-034 name present | pass |
| migration-inventory-final.log | feature AUTH-034 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-034 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-034 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-034 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-035 name present | pass |
| migration-inventory-final.log | feature AUTH-035 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-035 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-035 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-035 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-036 name present | pass |
| migration-inventory-final.log | feature AUTH-036 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-036 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-036 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-036 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-037 name present | pass |
| migration-inventory-final.log | feature AUTH-037 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-037 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-037 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-037 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-038 name present | pass |
| migration-inventory-final.log | feature AUTH-038 UI need 필요 | pass |
| migration-inventory-final.log | feature AUTH-038 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-038 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-038 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-039 name present | pass |
| migration-inventory-final.log | feature AUTH-039 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-039 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-039 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-039 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-040 name present | pass |
| migration-inventory-final.log | feature AUTH-040 UI need 간접 | pass |
| migration-inventory-final.log | feature AUTH-040 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-040 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-040 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-041 name present | pass |
| migration-inventory-final.log | feature AUTH-041 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-041 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-041 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-041 pass criteria present | pass |
| migration-inventory-final.log | feature AUTH-042 name present | pass |
| migration-inventory-final.log | feature AUTH-042 UI need 비대상 | pass |
| migration-inventory-final.log | feature AUTH-042 test need 필요 | pass |
| migration-inventory-final.log | feature AUTH-042 test area assigned | pass |
| migration-inventory-final.log | feature AUTH-042 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-001 name present | pass |
| migration-inventory-final.log | feature SRC-001 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-001 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-001 test area assigned | pass |
| migration-inventory-final.log | feature SRC-001 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-002 name present | pass |
| migration-inventory-final.log | feature SRC-002 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-002 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-002 test area assigned | pass |
| migration-inventory-final.log | feature SRC-002 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-003 name present | pass |
| migration-inventory-final.log | feature SRC-003 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-003 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-003 test area assigned | pass |
| migration-inventory-final.log | feature SRC-003 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-004 name present | pass |
| migration-inventory-final.log | feature SRC-004 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-004 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-004 test area assigned | pass |
| migration-inventory-final.log | feature SRC-004 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-005 name present | pass |
| migration-inventory-final.log | feature SRC-005 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-005 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-005 test area assigned | pass |
| migration-inventory-final.log | feature SRC-005 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-006 name present | pass |
| migration-inventory-final.log | feature SRC-006 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-006 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-006 test area assigned | pass |
| migration-inventory-final.log | feature SRC-006 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-007 name present | pass |
| migration-inventory-final.log | feature SRC-007 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-007 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-007 test area assigned | pass |
| migration-inventory-final.log | feature SRC-007 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-008 name present | pass |
| migration-inventory-final.log | feature SRC-008 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-008 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-008 test area assigned | pass |
| migration-inventory-final.log | feature SRC-008 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-009 name present | pass |
| migration-inventory-final.log | feature SRC-009 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-009 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-009 test area assigned | pass |
| migration-inventory-final.log | feature SRC-009 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-010 name present | pass |
| migration-inventory-final.log | feature SRC-010 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-010 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-010 test area assigned | pass |
| migration-inventory-final.log | feature SRC-010 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-011 name present | pass |
| migration-inventory-final.log | feature SRC-011 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-011 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-011 test area assigned | pass |
| migration-inventory-final.log | feature SRC-011 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-012 name present | pass |
| migration-inventory-final.log | feature SRC-012 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-012 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-012 test area assigned | pass |
| migration-inventory-final.log | feature SRC-012 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-013 name present | pass |
| migration-inventory-final.log | feature SRC-013 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-013 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-013 test area assigned | pass |
| migration-inventory-final.log | feature SRC-013 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-014 name present | pass |
| migration-inventory-final.log | feature SRC-014 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-014 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-014 test area assigned | pass |
| migration-inventory-final.log | feature SRC-014 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-015 name present | pass |
| migration-inventory-final.log | feature SRC-015 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-015 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-015 test area assigned | pass |
| migration-inventory-final.log | feature SRC-015 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-016 name present | pass |
| migration-inventory-final.log | feature SRC-016 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-016 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-016 test area assigned | pass |
| migration-inventory-final.log | feature SRC-016 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-017 name present | pass |
| migration-inventory-final.log | feature SRC-017 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-017 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-017 test area assigned | pass |
| migration-inventory-final.log | feature SRC-017 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-018 name present | pass |
| migration-inventory-final.log | feature SRC-018 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-018 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-018 test area assigned | pass |
| migration-inventory-final.log | feature SRC-018 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-019 name present | pass |
| migration-inventory-final.log | feature SRC-019 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-019 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-019 test area assigned | pass |
| migration-inventory-final.log | feature SRC-019 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-020 name present | pass |
| migration-inventory-final.log | feature SRC-020 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-020 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-020 test area assigned | pass |
| migration-inventory-final.log | feature SRC-020 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-021 name present | pass |
| migration-inventory-final.log | feature SRC-021 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-021 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-021 test area assigned | pass |
| migration-inventory-final.log | feature SRC-021 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-022 name present | pass |
| migration-inventory-final.log | feature SRC-022 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-022 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-022 test area assigned | pass |
| migration-inventory-final.log | feature SRC-022 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-023 name present | pass |
| migration-inventory-final.log | feature SRC-023 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-023 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-023 test area assigned | pass |
| migration-inventory-final.log | feature SRC-023 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-024 name present | pass |
| migration-inventory-final.log | feature SRC-024 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-024 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-024 test area assigned | pass |
| migration-inventory-final.log | feature SRC-024 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-025 name present | pass |
| migration-inventory-final.log | feature SRC-025 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-025 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-025 test area assigned | pass |
| migration-inventory-final.log | feature SRC-025 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-026 name present | pass |
| migration-inventory-final.log | feature SRC-026 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-026 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-026 test area assigned | pass |
| migration-inventory-final.log | feature SRC-026 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-027 name present | pass |
| migration-inventory-final.log | feature SRC-027 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-027 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-027 test area assigned | pass |
| migration-inventory-final.log | feature SRC-027 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-028 name present | pass |
| migration-inventory-final.log | feature SRC-028 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-028 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-028 test area assigned | pass |
| migration-inventory-final.log | feature SRC-028 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-029 name present | pass |
| migration-inventory-final.log | feature SRC-029 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-029 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-029 test area assigned | pass |
| migration-inventory-final.log | feature SRC-029 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-030 name present | pass |
| migration-inventory-final.log | feature SRC-030 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-030 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-030 test area assigned | pass |
| migration-inventory-final.log | feature SRC-030 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-031 name present | pass |
| migration-inventory-final.log | feature SRC-031 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-031 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-031 test area assigned | pass |
| migration-inventory-final.log | feature SRC-031 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-032 name present | pass |
| migration-inventory-final.log | feature SRC-032 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-032 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-032 test area assigned | pass |
| migration-inventory-final.log | feature SRC-032 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-033 name present | pass |
| migration-inventory-final.log | feature SRC-033 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-033 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-033 test area assigned | pass |
| migration-inventory-final.log | feature SRC-033 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-034 name present | pass |
| migration-inventory-final.log | feature SRC-034 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-034 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-034 test area assigned | pass |
| migration-inventory-final.log | feature SRC-034 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-035 name present | pass |
| migration-inventory-final.log | feature SRC-035 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-035 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-035 test area assigned | pass |
| migration-inventory-final.log | feature SRC-035 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-036 name present | pass |
| migration-inventory-final.log | feature SRC-036 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-036 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-036 test area assigned | pass |
| migration-inventory-final.log | feature SRC-036 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-037 name present | pass |
| migration-inventory-final.log | feature SRC-037 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-037 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-037 test area assigned | pass |
| migration-inventory-final.log | feature SRC-037 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-038 name present | pass |
| migration-inventory-final.log | feature SRC-038 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-038 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-038 test area assigned | pass |
| migration-inventory-final.log | feature SRC-038 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-039 name present | pass |
| migration-inventory-final.log | feature SRC-039 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-039 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-039 test area assigned | pass |
| migration-inventory-final.log | feature SRC-039 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-040 name present | pass |
| migration-inventory-final.log | feature SRC-040 UI need 필요 | pass |
| migration-inventory-final.log | feature SRC-040 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-040 test area assigned | pass |
| migration-inventory-final.log | feature SRC-040 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-041 name present | pass |
| migration-inventory-final.log | feature SRC-041 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-041 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-041 test area assigned | pass |
| migration-inventory-final.log | feature SRC-041 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-042 name present | pass |
| migration-inventory-final.log | feature SRC-042 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-042 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-042 test area assigned | pass |
| migration-inventory-final.log | feature SRC-042 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-043 name present | pass |
| migration-inventory-final.log | feature SRC-043 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-043 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-043 test area assigned | pass |
| migration-inventory-final.log | feature SRC-043 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-044 name present | pass |
| migration-inventory-final.log | feature SRC-044 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-044 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-044 test area assigned | pass |
| migration-inventory-final.log | feature SRC-044 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-045 name present | pass |
| migration-inventory-final.log | feature SRC-045 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-045 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-045 test area assigned | pass |
| migration-inventory-final.log | feature SRC-045 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-046 name present | pass |
| migration-inventory-final.log | feature SRC-046 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-046 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-046 test area assigned | pass |
| migration-inventory-final.log | feature SRC-046 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-047 name present | pass |
| migration-inventory-final.log | feature SRC-047 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-047 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-047 test area assigned | pass |
| migration-inventory-final.log | feature SRC-047 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-048 name present | pass |
| migration-inventory-final.log | feature SRC-048 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-048 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-048 test area assigned | pass |
| migration-inventory-final.log | feature SRC-048 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-049 name present | pass |
| migration-inventory-final.log | feature SRC-049 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-049 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-049 test area assigned | pass |
| migration-inventory-final.log | feature SRC-049 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-050 name present | pass |
| migration-inventory-final.log | feature SRC-050 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-050 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-050 test area assigned | pass |
| migration-inventory-final.log | feature SRC-050 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-051 name present | pass |
| migration-inventory-final.log | feature SRC-051 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-051 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-051 test area assigned | pass |
| migration-inventory-final.log | feature SRC-051 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-052 name present | pass |
| migration-inventory-final.log | feature SRC-052 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-052 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-052 test area assigned | pass |
| migration-inventory-final.log | feature SRC-052 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-053 name present | pass |
| migration-inventory-final.log | feature SRC-053 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-053 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-053 test area assigned | pass |
| migration-inventory-final.log | feature SRC-053 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-054 name present | pass |
| migration-inventory-final.log | feature SRC-054 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-054 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-054 test area assigned | pass |
| migration-inventory-final.log | feature SRC-054 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-055 name present | pass |
| migration-inventory-final.log | feature SRC-055 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-055 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-055 test area assigned | pass |
| migration-inventory-final.log | feature SRC-055 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-056 name present | pass |
| migration-inventory-final.log | feature SRC-056 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-056 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-056 test area assigned | pass |
| migration-inventory-final.log | feature SRC-056 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-057 name present | pass |
| migration-inventory-final.log | feature SRC-057 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-057 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-057 test area assigned | pass |
| migration-inventory-final.log | feature SRC-057 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-058 name present | pass |
| migration-inventory-final.log | feature SRC-058 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-058 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-058 test area assigned | pass |
| migration-inventory-final.log | feature SRC-058 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-059 name present | pass |
| migration-inventory-final.log | feature SRC-059 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-059 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-059 test area assigned | pass |
| migration-inventory-final.log | feature SRC-059 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-060 name present | pass |
| migration-inventory-final.log | feature SRC-060 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-060 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-060 test area assigned | pass |
| migration-inventory-final.log | feature SRC-060 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-061 name present | pass |
| migration-inventory-final.log | feature SRC-061 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-061 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-061 test area assigned | pass |
| migration-inventory-final.log | feature SRC-061 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-062 name present | pass |
| migration-inventory-final.log | feature SRC-062 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-062 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-062 test area assigned | pass |
| migration-inventory-final.log | feature SRC-062 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-063 name present | pass |
| migration-inventory-final.log | feature SRC-063 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-063 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-063 test area assigned | pass |
| migration-inventory-final.log | feature SRC-063 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-064 name present | pass |
| migration-inventory-final.log | feature SRC-064 UI need 비대상 | pass |
| migration-inventory-final.log | feature SRC-064 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-064 test area assigned | pass |
| migration-inventory-final.log | feature SRC-064 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-065 name present | pass |
| migration-inventory-final.log | feature SRC-065 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-065 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-065 test area assigned | pass |
| migration-inventory-final.log | feature SRC-065 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-066 name present | pass |
| migration-inventory-final.log | feature SRC-066 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-066 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-066 test area assigned | pass |
| migration-inventory-final.log | feature SRC-066 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-067 name present | pass |
| migration-inventory-final.log | feature SRC-067 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-067 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-067 test area assigned | pass |
| migration-inventory-final.log | feature SRC-067 pass criteria present | pass |
| migration-inventory-final.log | feature SRC-068 name present | pass |
| migration-inventory-final.log | feature SRC-068 UI need 간접 | pass |
| migration-inventory-final.log | feature SRC-068 test need 필요 | pass |
| migration-inventory-final.log | feature SRC-068 test area assigned | pass |
| migration-inventory-final.log | feature SRC-068 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-001 name present | pass |
| migration-inventory-final.log | feature RULE-001 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-001 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-001 test area assigned | pass |
| migration-inventory-final.log | feature RULE-001 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-002 name present | pass |
| migration-inventory-final.log | feature RULE-002 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-002 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-002 test area assigned | pass |
| migration-inventory-final.log | feature RULE-002 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-003 name present | pass |
| migration-inventory-final.log | feature RULE-003 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-003 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-003 test area assigned | pass |
| migration-inventory-final.log | feature RULE-003 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-004 name present | pass |
| migration-inventory-final.log | feature RULE-004 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-004 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-004 test area assigned | pass |
| migration-inventory-final.log | feature RULE-004 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-005 name present | pass |
| migration-inventory-final.log | feature RULE-005 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-005 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-005 test area assigned | pass |
| migration-inventory-final.log | feature RULE-005 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-006 name present | pass |
| migration-inventory-final.log | feature RULE-006 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-006 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-006 test area assigned | pass |
| migration-inventory-final.log | feature RULE-006 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-007 name present | pass |
| migration-inventory-final.log | feature RULE-007 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-007 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-007 test area assigned | pass |
| migration-inventory-final.log | feature RULE-007 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-008 name present | pass |
| migration-inventory-final.log | feature RULE-008 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-008 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-008 test area assigned | pass |
| migration-inventory-final.log | feature RULE-008 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-009 name present | pass |
| migration-inventory-final.log | feature RULE-009 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-009 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-009 test area assigned | pass |
| migration-inventory-final.log | feature RULE-009 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-010 name present | pass |
| migration-inventory-final.log | feature RULE-010 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-010 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-010 test area assigned | pass |
| migration-inventory-final.log | feature RULE-010 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-011 name present | pass |
| migration-inventory-final.log | feature RULE-011 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-011 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-011 test area assigned | pass |
| migration-inventory-final.log | feature RULE-011 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-012 name present | pass |
| migration-inventory-final.log | feature RULE-012 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-012 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-012 test area assigned | pass |
| migration-inventory-final.log | feature RULE-012 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-013 name present | pass |
| migration-inventory-final.log | feature RULE-013 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-013 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-013 test area assigned | pass |
| migration-inventory-final.log | feature RULE-013 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-014 name present | pass |
| migration-inventory-final.log | feature RULE-014 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-014 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-014 test area assigned | pass |
| migration-inventory-final.log | feature RULE-014 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-015 name present | pass |
| migration-inventory-final.log | feature RULE-015 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-015 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-015 test area assigned | pass |
| migration-inventory-final.log | feature RULE-015 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-016 name present | pass |
| migration-inventory-final.log | feature RULE-016 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-016 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-016 test area assigned | pass |
| migration-inventory-final.log | feature RULE-016 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-017 name present | pass |
| migration-inventory-final.log | feature RULE-017 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-017 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-017 test area assigned | pass |
| migration-inventory-final.log | feature RULE-017 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-018 name present | pass |
| migration-inventory-final.log | feature RULE-018 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-018 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-018 test area assigned | pass |
| migration-inventory-final.log | feature RULE-018 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-019 name present | pass |
| migration-inventory-final.log | feature RULE-019 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-019 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-019 test area assigned | pass |
| migration-inventory-final.log | feature RULE-019 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-020 name present | pass |
| migration-inventory-final.log | feature RULE-020 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-020 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-020 test area assigned | pass |
| migration-inventory-final.log | feature RULE-020 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-021 name present | pass |
| migration-inventory-final.log | feature RULE-021 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-021 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-021 test area assigned | pass |
| migration-inventory-final.log | feature RULE-021 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-022 name present | pass |
| migration-inventory-final.log | feature RULE-022 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-022 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-022 test area assigned | pass |
| migration-inventory-final.log | feature RULE-022 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-023 name present | pass |
| migration-inventory-final.log | feature RULE-023 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-023 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-023 test area assigned | pass |
| migration-inventory-final.log | feature RULE-023 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-024 name present | pass |
| migration-inventory-final.log | feature RULE-024 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-024 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-024 test area assigned | pass |
| migration-inventory-final.log | feature RULE-024 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-025 name present | pass |
| migration-inventory-final.log | feature RULE-025 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-025 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-025 test area assigned | pass |
| migration-inventory-final.log | feature RULE-025 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-026 name present | pass |
| migration-inventory-final.log | feature RULE-026 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-026 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-026 test area assigned | pass |
| migration-inventory-final.log | feature RULE-026 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-027 name present | pass |
| migration-inventory-final.log | feature RULE-027 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-027 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-027 test area assigned | pass |
| migration-inventory-final.log | feature RULE-027 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-028 name present | pass |
| migration-inventory-final.log | feature RULE-028 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-028 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-028 test area assigned | pass |
| migration-inventory-final.log | feature RULE-028 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-029 name present | pass |
| migration-inventory-final.log | feature RULE-029 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-029 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-029 test area assigned | pass |
| migration-inventory-final.log | feature RULE-029 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-030 name present | pass |
| migration-inventory-final.log | feature RULE-030 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-030 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-030 test area assigned | pass |
| migration-inventory-final.log | feature RULE-030 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-031 name present | pass |
| migration-inventory-final.log | feature RULE-031 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-031 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-031 test area assigned | pass |
| migration-inventory-final.log | feature RULE-031 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-032 name present | pass |
| migration-inventory-final.log | feature RULE-032 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-032 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-032 test area assigned | pass |
| migration-inventory-final.log | feature RULE-032 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-033 name present | pass |
| migration-inventory-final.log | feature RULE-033 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-033 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-033 test area assigned | pass |
| migration-inventory-final.log | feature RULE-033 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-034 name present | pass |
| migration-inventory-final.log | feature RULE-034 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-034 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-034 test area assigned | pass |
| migration-inventory-final.log | feature RULE-034 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-035 name present | pass |
| migration-inventory-final.log | feature RULE-035 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-035 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-035 test area assigned | pass |
| migration-inventory-final.log | feature RULE-035 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-036 name present | pass |
| migration-inventory-final.log | feature RULE-036 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-036 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-036 test area assigned | pass |
| migration-inventory-final.log | feature RULE-036 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-037 name present | pass |
| migration-inventory-final.log | feature RULE-037 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-037 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-037 test area assigned | pass |
| migration-inventory-final.log | feature RULE-037 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-038 name present | pass |
| migration-inventory-final.log | feature RULE-038 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-038 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-038 test area assigned | pass |
| migration-inventory-final.log | feature RULE-038 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-039 name present | pass |
| migration-inventory-final.log | feature RULE-039 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-039 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-039 test area assigned | pass |
| migration-inventory-final.log | feature RULE-039 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-040 name present | pass |
| migration-inventory-final.log | feature RULE-040 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-040 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-040 test area assigned | pass |
| migration-inventory-final.log | feature RULE-040 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-041 name present | pass |
| migration-inventory-final.log | feature RULE-041 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-041 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-041 test area assigned | pass |
| migration-inventory-final.log | feature RULE-041 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-042 name present | pass |
| migration-inventory-final.log | feature RULE-042 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-042 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-042 test area assigned | pass |
| migration-inventory-final.log | feature RULE-042 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-043 name present | pass |
| migration-inventory-final.log | feature RULE-043 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-043 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-043 test area assigned | pass |
| migration-inventory-final.log | feature RULE-043 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-044 name present | pass |
| migration-inventory-final.log | feature RULE-044 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-044 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-044 test area assigned | pass |
| migration-inventory-final.log | feature RULE-044 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-045 name present | pass |
| migration-inventory-final.log | feature RULE-045 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-045 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-045 test area assigned | pass |
| migration-inventory-final.log | feature RULE-045 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-046 name present | pass |
| migration-inventory-final.log | feature RULE-046 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-046 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-046 test area assigned | pass |
| migration-inventory-final.log | feature RULE-046 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-047 name present | pass |
| migration-inventory-final.log | feature RULE-047 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-047 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-047 test area assigned | pass |
| migration-inventory-final.log | feature RULE-047 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-048 name present | pass |
| migration-inventory-final.log | feature RULE-048 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-048 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-048 test area assigned | pass |
| migration-inventory-final.log | feature RULE-048 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-049 name present | pass |
| migration-inventory-final.log | feature RULE-049 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-049 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-049 test area assigned | pass |
| migration-inventory-final.log | feature RULE-049 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-050 name present | pass |
| migration-inventory-final.log | feature RULE-050 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-050 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-050 test area assigned | pass |
| migration-inventory-final.log | feature RULE-050 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-051 name present | pass |
| migration-inventory-final.log | feature RULE-051 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-051 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-051 test area assigned | pass |
| migration-inventory-final.log | feature RULE-051 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-052 name present | pass |
| migration-inventory-final.log | feature RULE-052 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-052 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-052 test area assigned | pass |
| migration-inventory-final.log | feature RULE-052 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-053 name present | pass |
| migration-inventory-final.log | feature RULE-053 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-053 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-053 test area assigned | pass |
| migration-inventory-final.log | feature RULE-053 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-054 name present | pass |
| migration-inventory-final.log | feature RULE-054 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-054 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-054 test area assigned | pass |
| migration-inventory-final.log | feature RULE-054 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-055 name present | pass |
| migration-inventory-final.log | feature RULE-055 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-055 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-055 test area assigned | pass |
| migration-inventory-final.log | feature RULE-055 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-056 name present | pass |
| migration-inventory-final.log | feature RULE-056 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-056 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-056 test area assigned | pass |
| migration-inventory-final.log | feature RULE-056 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-057 name present | pass |
| migration-inventory-final.log | feature RULE-057 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-057 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-057 test area assigned | pass |
| migration-inventory-final.log | feature RULE-057 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-058 name present | pass |
| migration-inventory-final.log | feature RULE-058 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-058 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-058 test area assigned | pass |
| migration-inventory-final.log | feature RULE-058 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-059 name present | pass |
| migration-inventory-final.log | feature RULE-059 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-059 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-059 test area assigned | pass |
| migration-inventory-final.log | feature RULE-059 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-060 name present | pass |
| migration-inventory-final.log | feature RULE-060 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-060 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-060 test area assigned | pass |
| migration-inventory-final.log | feature RULE-060 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-061 name present | pass |
| migration-inventory-final.log | feature RULE-061 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-061 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-061 test area assigned | pass |
| migration-inventory-final.log | feature RULE-061 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-062 name present | pass |
| migration-inventory-final.log | feature RULE-062 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-062 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-062 test area assigned | pass |
| migration-inventory-final.log | feature RULE-062 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-063 name present | pass |
| migration-inventory-final.log | feature RULE-063 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-063 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-063 test area assigned | pass |
| migration-inventory-final.log | feature RULE-063 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-064 name present | pass |
| migration-inventory-final.log | feature RULE-064 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-064 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-064 test area assigned | pass |
| migration-inventory-final.log | feature RULE-064 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-065 name present | pass |
| migration-inventory-final.log | feature RULE-065 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-065 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-065 test area assigned | pass |
| migration-inventory-final.log | feature RULE-065 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-066 name present | pass |
| migration-inventory-final.log | feature RULE-066 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-066 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-066 test area assigned | pass |
| migration-inventory-final.log | feature RULE-066 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-067 name present | pass |
| migration-inventory-final.log | feature RULE-067 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-067 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-067 test area assigned | pass |
| migration-inventory-final.log | feature RULE-067 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-068 name present | pass |
| migration-inventory-final.log | feature RULE-068 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-068 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-068 test area assigned | pass |
| migration-inventory-final.log | feature RULE-068 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-069 name present | pass |
| migration-inventory-final.log | feature RULE-069 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-069 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-069 test area assigned | pass |
| migration-inventory-final.log | feature RULE-069 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-070 name present | pass |
| migration-inventory-final.log | feature RULE-070 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-070 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-070 test area assigned | pass |
| migration-inventory-final.log | feature RULE-070 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-071 name present | pass |
| migration-inventory-final.log | feature RULE-071 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-071 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-071 test area assigned | pass |
| migration-inventory-final.log | feature RULE-071 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-072 name present | pass |
| migration-inventory-final.log | feature RULE-072 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-072 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-072 test area assigned | pass |
| migration-inventory-final.log | feature RULE-072 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-073 name present | pass |
| migration-inventory-final.log | feature RULE-073 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-073 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-073 test area assigned | pass |
| migration-inventory-final.log | feature RULE-073 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-074 name present | pass |
| migration-inventory-final.log | feature RULE-074 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-074 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-074 test area assigned | pass |
| migration-inventory-final.log | feature RULE-074 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-075 name present | pass |
| migration-inventory-final.log | feature RULE-075 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-075 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-075 test area assigned | pass |
| migration-inventory-final.log | feature RULE-075 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-076 name present | pass |
| migration-inventory-final.log | feature RULE-076 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-076 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-076 test area assigned | pass |
| migration-inventory-final.log | feature RULE-076 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-077 name present | pass |
| migration-inventory-final.log | feature RULE-077 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-077 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-077 test area assigned | pass |
| migration-inventory-final.log | feature RULE-077 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-078 name present | pass |
| migration-inventory-final.log | feature RULE-078 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-078 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-078 test area assigned | pass |
| migration-inventory-final.log | feature RULE-078 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-079 name present | pass |
| migration-inventory-final.log | feature RULE-079 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-079 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-079 test area assigned | pass |
| migration-inventory-final.log | feature RULE-079 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-080 name present | pass |
| migration-inventory-final.log | feature RULE-080 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-080 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-080 test area assigned | pass |
| migration-inventory-final.log | feature RULE-080 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-081 name present | pass |
| migration-inventory-final.log | feature RULE-081 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-081 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-081 test area assigned | pass |
| migration-inventory-final.log | feature RULE-081 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-082 name present | pass |
| migration-inventory-final.log | feature RULE-082 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-082 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-082 test area assigned | pass |
| migration-inventory-final.log | feature RULE-082 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-083 name present | pass |
| migration-inventory-final.log | feature RULE-083 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-083 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-083 test area assigned | pass |
| migration-inventory-final.log | feature RULE-083 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-084 name present | pass |
| migration-inventory-final.log | feature RULE-084 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-084 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-084 test area assigned | pass |
| migration-inventory-final.log | feature RULE-084 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-085 name present | pass |
| migration-inventory-final.log | feature RULE-085 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-085 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-085 test area assigned | pass |
| migration-inventory-final.log | feature RULE-085 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-086 name present | pass |
| migration-inventory-final.log | feature RULE-086 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-086 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-086 test area assigned | pass |
| migration-inventory-final.log | feature RULE-086 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-087 name present | pass |
| migration-inventory-final.log | feature RULE-087 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-087 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-087 test area assigned | pass |
| migration-inventory-final.log | feature RULE-087 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-088 name present | pass |
| migration-inventory-final.log | feature RULE-088 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-088 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-088 test area assigned | pass |
| migration-inventory-final.log | feature RULE-088 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-089 name present | pass |
| migration-inventory-final.log | feature RULE-089 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-089 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-089 test area assigned | pass |
| migration-inventory-final.log | feature RULE-089 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-090 name present | pass |
| migration-inventory-final.log | feature RULE-090 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-090 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-090 test area assigned | pass |
| migration-inventory-final.log | feature RULE-090 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-091 name present | pass |
| migration-inventory-final.log | feature RULE-091 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-091 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-091 test area assigned | pass |
| migration-inventory-final.log | feature RULE-091 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-092 name present | pass |
| migration-inventory-final.log | feature RULE-092 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-092 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-092 test area assigned | pass |
| migration-inventory-final.log | feature RULE-092 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-093 name present | pass |
| migration-inventory-final.log | feature RULE-093 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-093 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-093 test area assigned | pass |
| migration-inventory-final.log | feature RULE-093 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-094 name present | pass |
| migration-inventory-final.log | feature RULE-094 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-094 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-094 test area assigned | pass |
| migration-inventory-final.log | feature RULE-094 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-095 name present | pass |
| migration-inventory-final.log | feature RULE-095 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-095 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-095 test area assigned | pass |
| migration-inventory-final.log | feature RULE-095 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-096 name present | pass |
| migration-inventory-final.log | feature RULE-096 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-096 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-096 test area assigned | pass |
| migration-inventory-final.log | feature RULE-096 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-097 name present | pass |
| migration-inventory-final.log | feature RULE-097 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-097 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-097 test area assigned | pass |
| migration-inventory-final.log | feature RULE-097 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-098 name present | pass |
| migration-inventory-final.log | feature RULE-098 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-098 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-098 test area assigned | pass |
| migration-inventory-final.log | feature RULE-098 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-099 name present | pass |
| migration-inventory-final.log | feature RULE-099 UI need 간접 | pass |
| migration-inventory-final.log | feature RULE-099 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-099 test area assigned | pass |
| migration-inventory-final.log | feature RULE-099 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-100 name present | pass |
| migration-inventory-final.log | feature RULE-100 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-100 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-100 test area assigned | pass |
| migration-inventory-final.log | feature RULE-100 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-101 name present | pass |
| migration-inventory-final.log | feature RULE-101 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-101 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-101 test area assigned | pass |
| migration-inventory-final.log | feature RULE-101 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-102 name present | pass |
| migration-inventory-final.log | feature RULE-102 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-102 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-102 test area assigned | pass |
| migration-inventory-final.log | feature RULE-102 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-103 name present | pass |
| migration-inventory-final.log | feature RULE-103 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-103 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-103 test area assigned | pass |
| migration-inventory-final.log | feature RULE-103 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-104 name present | pass |
| migration-inventory-final.log | feature RULE-104 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-104 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-104 test area assigned | pass |
| migration-inventory-final.log | feature RULE-104 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-105 name present | pass |
| migration-inventory-final.log | feature RULE-105 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-105 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-105 test area assigned | pass |
| migration-inventory-final.log | feature RULE-105 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-106 name present | pass |
| migration-inventory-final.log | feature RULE-106 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-106 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-106 test area assigned | pass |
| migration-inventory-final.log | feature RULE-106 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-107 name present | pass |
| migration-inventory-final.log | feature RULE-107 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-107 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-107 test area assigned | pass |
| migration-inventory-final.log | feature RULE-107 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-108 name present | pass |
| migration-inventory-final.log | feature RULE-108 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-108 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-108 test area assigned | pass |
| migration-inventory-final.log | feature RULE-108 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-109 name present | pass |
| migration-inventory-final.log | feature RULE-109 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-109 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-109 test area assigned | pass |
| migration-inventory-final.log | feature RULE-109 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-110 name present | pass |
| migration-inventory-final.log | feature RULE-110 UI need 비대상 | pass |
| migration-inventory-final.log | feature RULE-110 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-110 test area assigned | pass |
| migration-inventory-final.log | feature RULE-110 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-111 name present | pass |
| migration-inventory-final.log | feature RULE-111 UI need 필요 | pass |
| migration-inventory-final.log | feature RULE-111 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-111 test area assigned | pass |
| migration-inventory-final.log | feature RULE-111 pass criteria present | pass |
| migration-inventory-final.log | feature RULE-112 name present | pass |
| migration-inventory-final.log | feature RULE-112 UI need 간접 | pass |
| migration-inventory-final.log | feature RULE-112 test need 필요 | pass |
| migration-inventory-final.log | feature RULE-112 test area assigned | pass |
| migration-inventory-final.log | feature RULE-112 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-001 name present | pass |
| migration-inventory-final.log | feature EVT-001 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-001 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-001 test area assigned | pass |
| migration-inventory-final.log | feature EVT-001 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-002 name present | pass |
| migration-inventory-final.log | feature EVT-002 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-002 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-002 test area assigned | pass |
| migration-inventory-final.log | feature EVT-002 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-003 name present | pass |
| migration-inventory-final.log | feature EVT-003 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-003 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-003 test area assigned | pass |
| migration-inventory-final.log | feature EVT-003 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-004 name present | pass |
| migration-inventory-final.log | feature EVT-004 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-004 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-004 test area assigned | pass |
| migration-inventory-final.log | feature EVT-004 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-005 name present | pass |
| migration-inventory-final.log | feature EVT-005 UI need 간접 | pass |
| migration-inventory-final.log | feature EVT-005 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-005 test area assigned | pass |
| migration-inventory-final.log | feature EVT-005 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-006 name present | pass |
| migration-inventory-final.log | feature EVT-006 UI need 간접 | pass |
| migration-inventory-final.log | feature EVT-006 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-006 test area assigned | pass |
| migration-inventory-final.log | feature EVT-006 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-007 name present | pass |
| migration-inventory-final.log | feature EVT-007 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-007 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-007 test area assigned | pass |
| migration-inventory-final.log | feature EVT-007 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-008 name present | pass |
| migration-inventory-final.log | feature EVT-008 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-008 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-008 test area assigned | pass |
| migration-inventory-final.log | feature EVT-008 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-009 name present | pass |
| migration-inventory-final.log | feature EVT-009 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-009 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-009 test area assigned | pass |
| migration-inventory-final.log | feature EVT-009 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-010 name present | pass |
| migration-inventory-final.log | feature EVT-010 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-010 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-010 test area assigned | pass |
| migration-inventory-final.log | feature EVT-010 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-011 name present | pass |
| migration-inventory-final.log | feature EVT-011 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-011 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-011 test area assigned | pass |
| migration-inventory-final.log | feature EVT-011 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-012 name present | pass |
| migration-inventory-final.log | feature EVT-012 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-012 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-012 test area assigned | pass |
| migration-inventory-final.log | feature EVT-012 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-013 name present | pass |
| migration-inventory-final.log | feature EVT-013 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-013 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-013 test area assigned | pass |
| migration-inventory-final.log | feature EVT-013 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-014 name present | pass |
| migration-inventory-final.log | feature EVT-014 UI need 간접 | pass |
| migration-inventory-final.log | feature EVT-014 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-014 test area assigned | pass |
| migration-inventory-final.log | feature EVT-014 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-015 name present | pass |
| migration-inventory-final.log | feature EVT-015 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-015 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-015 test area assigned | pass |
| migration-inventory-final.log | feature EVT-015 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-016 name present | pass |
| migration-inventory-final.log | feature EVT-016 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-016 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-016 test area assigned | pass |
| migration-inventory-final.log | feature EVT-016 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-017 name present | pass |
| migration-inventory-final.log | feature EVT-017 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-017 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-017 test area assigned | pass |
| migration-inventory-final.log | feature EVT-017 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-018 name present | pass |
| migration-inventory-final.log | feature EVT-018 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-018 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-018 test area assigned | pass |
| migration-inventory-final.log | feature EVT-018 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-019 name present | pass |
| migration-inventory-final.log | feature EVT-019 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-019 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-019 test area assigned | pass |
| migration-inventory-final.log | feature EVT-019 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-020 name present | pass |
| migration-inventory-final.log | feature EVT-020 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-020 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-020 test area assigned | pass |
| migration-inventory-final.log | feature EVT-020 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-021 name present | pass |
| migration-inventory-final.log | feature EVT-021 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-021 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-021 test area assigned | pass |
| migration-inventory-final.log | feature EVT-021 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-022 name present | pass |
| migration-inventory-final.log | feature EVT-022 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-022 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-022 test area assigned | pass |
| migration-inventory-final.log | feature EVT-022 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-023 name present | pass |
| migration-inventory-final.log | feature EVT-023 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-023 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-023 test area assigned | pass |
| migration-inventory-final.log | feature EVT-023 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-024 name present | pass |
| migration-inventory-final.log | feature EVT-024 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-024 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-024 test area assigned | pass |
| migration-inventory-final.log | feature EVT-024 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-025 name present | pass |
| migration-inventory-final.log | feature EVT-025 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-025 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-025 test area assigned | pass |
| migration-inventory-final.log | feature EVT-025 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-026 name present | pass |
| migration-inventory-final.log | feature EVT-026 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-026 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-026 test area assigned | pass |
| migration-inventory-final.log | feature EVT-026 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-027 name present | pass |
| migration-inventory-final.log | feature EVT-027 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-027 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-027 test area assigned | pass |
| migration-inventory-final.log | feature EVT-027 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-028 name present | pass |
| migration-inventory-final.log | feature EVT-028 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-028 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-028 test area assigned | pass |
| migration-inventory-final.log | feature EVT-028 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-029 name present | pass |
| migration-inventory-final.log | feature EVT-029 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-029 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-029 test area assigned | pass |
| migration-inventory-final.log | feature EVT-029 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-030 name present | pass |
| migration-inventory-final.log | feature EVT-030 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-030 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-030 test area assigned | pass |
| migration-inventory-final.log | feature EVT-030 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-031 name present | pass |
| migration-inventory-final.log | feature EVT-031 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-031 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-031 test area assigned | pass |
| migration-inventory-final.log | feature EVT-031 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-032 name present | pass |
| migration-inventory-final.log | feature EVT-032 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-032 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-032 test area assigned | pass |
| migration-inventory-final.log | feature EVT-032 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-033 name present | pass |
| migration-inventory-final.log | feature EVT-033 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-033 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-033 test area assigned | pass |
| migration-inventory-final.log | feature EVT-033 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-034 name present | pass |
| migration-inventory-final.log | feature EVT-034 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-034 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-034 test area assigned | pass |
| migration-inventory-final.log | feature EVT-034 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-035 name present | pass |
| migration-inventory-final.log | feature EVT-035 UI need 간접 | pass |
| migration-inventory-final.log | feature EVT-035 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-035 test area assigned | pass |
| migration-inventory-final.log | feature EVT-035 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-036 name present | pass |
| migration-inventory-final.log | feature EVT-036 UI need 간접 | pass |
| migration-inventory-final.log | feature EVT-036 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-036 test area assigned | pass |
| migration-inventory-final.log | feature EVT-036 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-037 name present | pass |
| migration-inventory-final.log | feature EVT-037 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-037 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-037 test area assigned | pass |
| migration-inventory-final.log | feature EVT-037 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-038 name present | pass |
| migration-inventory-final.log | feature EVT-038 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-038 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-038 test area assigned | pass |
| migration-inventory-final.log | feature EVT-038 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-039 name present | pass |
| migration-inventory-final.log | feature EVT-039 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-039 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-039 test area assigned | pass |
| migration-inventory-final.log | feature EVT-039 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-040 name present | pass |
| migration-inventory-final.log | feature EVT-040 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-040 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-040 test area assigned | pass |
| migration-inventory-final.log | feature EVT-040 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-041 name present | pass |
| migration-inventory-final.log | feature EVT-041 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-041 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-041 test area assigned | pass |
| migration-inventory-final.log | feature EVT-041 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-042 name present | pass |
| migration-inventory-final.log | feature EVT-042 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-042 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-042 test area assigned | pass |
| migration-inventory-final.log | feature EVT-042 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-043 name present | pass |
| migration-inventory-final.log | feature EVT-043 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-043 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-043 test area assigned | pass |
| migration-inventory-final.log | feature EVT-043 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-044 name present | pass |
| migration-inventory-final.log | feature EVT-044 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-044 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-044 test area assigned | pass |
| migration-inventory-final.log | feature EVT-044 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-045 name present | pass |
| migration-inventory-final.log | feature EVT-045 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-045 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-045 test area assigned | pass |
| migration-inventory-final.log | feature EVT-045 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-046 name present | pass |
| migration-inventory-final.log | feature EVT-046 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-046 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-046 test area assigned | pass |
| migration-inventory-final.log | feature EVT-046 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-047 name present | pass |
| migration-inventory-final.log | feature EVT-047 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-047 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-047 test area assigned | pass |
| migration-inventory-final.log | feature EVT-047 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-048 name present | pass |
| migration-inventory-final.log | feature EVT-048 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-048 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-048 test area assigned | pass |
| migration-inventory-final.log | feature EVT-048 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-049 name present | pass |
| migration-inventory-final.log | feature EVT-049 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-049 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-049 test area assigned | pass |
| migration-inventory-final.log | feature EVT-049 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-050 name present | pass |
| migration-inventory-final.log | feature EVT-050 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-050 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-050 test area assigned | pass |
| migration-inventory-final.log | feature EVT-050 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-051 name present | pass |
| migration-inventory-final.log | feature EVT-051 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-051 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-051 test area assigned | pass |
| migration-inventory-final.log | feature EVT-051 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-052 name present | pass |
| migration-inventory-final.log | feature EVT-052 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-052 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-052 test area assigned | pass |
| migration-inventory-final.log | feature EVT-052 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-053 name present | pass |
| migration-inventory-final.log | feature EVT-053 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-053 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-053 test area assigned | pass |
| migration-inventory-final.log | feature EVT-053 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-054 name present | pass |
| migration-inventory-final.log | feature EVT-054 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-054 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-054 test area assigned | pass |
| migration-inventory-final.log | feature EVT-054 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-055 name present | pass |
| migration-inventory-final.log | feature EVT-055 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-055 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-055 test area assigned | pass |
| migration-inventory-final.log | feature EVT-055 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-056 name present | pass |
| migration-inventory-final.log | feature EVT-056 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-056 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-056 test area assigned | pass |
| migration-inventory-final.log | feature EVT-056 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-057 name present | pass |
| migration-inventory-final.log | feature EVT-057 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-057 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-057 test area assigned | pass |
| migration-inventory-final.log | feature EVT-057 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-058 name present | pass |
| migration-inventory-final.log | feature EVT-058 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-058 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-058 test area assigned | pass |
| migration-inventory-final.log | feature EVT-058 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-059 name present | pass |
| migration-inventory-final.log | feature EVT-059 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-059 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-059 test area assigned | pass |
| migration-inventory-final.log | feature EVT-059 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-060 name present | pass |
| migration-inventory-final.log | feature EVT-060 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-060 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-060 test area assigned | pass |
| migration-inventory-final.log | feature EVT-060 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-061 name present | pass |
| migration-inventory-final.log | feature EVT-061 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-061 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-061 test area assigned | pass |
| migration-inventory-final.log | feature EVT-061 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-062 name present | pass |
| migration-inventory-final.log | feature EVT-062 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-062 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-062 test area assigned | pass |
| migration-inventory-final.log | feature EVT-062 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-063 name present | pass |
| migration-inventory-final.log | feature EVT-063 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-063 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-063 test area assigned | pass |
| migration-inventory-final.log | feature EVT-063 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-064 name present | pass |
| migration-inventory-final.log | feature EVT-064 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-064 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-064 test area assigned | pass |
| migration-inventory-final.log | feature EVT-064 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-065 name present | pass |
| migration-inventory-final.log | feature EVT-065 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-065 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-065 test area assigned | pass |
| migration-inventory-final.log | feature EVT-065 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-066 name present | pass |
| migration-inventory-final.log | feature EVT-066 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-066 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-066 test area assigned | pass |
| migration-inventory-final.log | feature EVT-066 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-067 name present | pass |
| migration-inventory-final.log | feature EVT-067 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-067 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-067 test area assigned | pass |
| migration-inventory-final.log | feature EVT-067 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-068 name present | pass |
| migration-inventory-final.log | feature EVT-068 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-068 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-068 test area assigned | pass |
| migration-inventory-final.log | feature EVT-068 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-069 name present | pass |
| migration-inventory-final.log | feature EVT-069 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-069 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-069 test area assigned | pass |
| migration-inventory-final.log | feature EVT-069 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-070 name present | pass |
| migration-inventory-final.log | feature EVT-070 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-070 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-070 test area assigned | pass |
| migration-inventory-final.log | feature EVT-070 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-071 name present | pass |
| migration-inventory-final.log | feature EVT-071 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-071 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-071 test area assigned | pass |
| migration-inventory-final.log | feature EVT-071 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-072 name present | pass |
| migration-inventory-final.log | feature EVT-072 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-072 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-072 test area assigned | pass |
| migration-inventory-final.log | feature EVT-072 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-073 name present | pass |
| migration-inventory-final.log | feature EVT-073 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-073 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-073 test area assigned | pass |
| migration-inventory-final.log | feature EVT-073 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-074 name present | pass |
| migration-inventory-final.log | feature EVT-074 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-074 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-074 test area assigned | pass |
| migration-inventory-final.log | feature EVT-074 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-075 name present | pass |
| migration-inventory-final.log | feature EVT-075 UI need 필요 | pass |
| migration-inventory-final.log | feature EVT-075 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-075 test area assigned | pass |
| migration-inventory-final.log | feature EVT-075 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-076 name present | pass |
| migration-inventory-final.log | feature EVT-076 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-076 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-076 test area assigned | pass |
| migration-inventory-final.log | feature EVT-076 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-077 name present | pass |
| migration-inventory-final.log | feature EVT-077 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-077 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-077 test area assigned | pass |
| migration-inventory-final.log | feature EVT-077 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-078 name present | pass |
| migration-inventory-final.log | feature EVT-078 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-078 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-078 test area assigned | pass |
| migration-inventory-final.log | feature EVT-078 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-079 name present | pass |
| migration-inventory-final.log | feature EVT-079 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-079 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-079 test area assigned | pass |
| migration-inventory-final.log | feature EVT-079 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-080 name present | pass |
| migration-inventory-final.log | feature EVT-080 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-080 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-080 test area assigned | pass |
| migration-inventory-final.log | feature EVT-080 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-081 name present | pass |
| migration-inventory-final.log | feature EVT-081 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-081 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-081 test area assigned | pass |
| migration-inventory-final.log | feature EVT-081 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-082 name present | pass |
| migration-inventory-final.log | feature EVT-082 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-082 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-082 test area assigned | pass |
| migration-inventory-final.log | feature EVT-082 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-083 name present | pass |
| migration-inventory-final.log | feature EVT-083 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-083 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-083 test area assigned | pass |
| migration-inventory-final.log | feature EVT-083 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-084 name present | pass |
| migration-inventory-final.log | feature EVT-084 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-084 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-084 test area assigned | pass |
| migration-inventory-final.log | feature EVT-084 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-085 name present | pass |
| migration-inventory-final.log | feature EVT-085 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-085 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-085 test area assigned | pass |
| migration-inventory-final.log | feature EVT-085 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-086 name present | pass |
| migration-inventory-final.log | feature EVT-086 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-086 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-086 test area assigned | pass |
| migration-inventory-final.log | feature EVT-086 pass criteria present | pass |
| migration-inventory-final.log | feature EVT-087 name present | pass |
| migration-inventory-final.log | feature EVT-087 UI need 비대상 | pass |
| migration-inventory-final.log | feature EVT-087 test need 필요 | pass |
| migration-inventory-final.log | feature EVT-087 test area assigned | pass |
| migration-inventory-final.log | feature EVT-087 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-001 name present | pass |
| migration-inventory-final.log | feature CLIENT-001 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-001 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-001 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-001 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-002 name present | pass |
| migration-inventory-final.log | feature CLIENT-002 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-002 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-002 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-002 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-003 name present | pass |
| migration-inventory-final.log | feature CLIENT-003 UI need 간접 | pass |
| migration-inventory-final.log | feature CLIENT-003 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-003 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-003 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-004 name present | pass |
| migration-inventory-final.log | feature CLIENT-004 UI need 간접 | pass |
| migration-inventory-final.log | feature CLIENT-004 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-004 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-004 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-005 name present | pass |
| migration-inventory-final.log | feature CLIENT-005 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-005 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-005 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-005 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-006 name present | pass |
| migration-inventory-final.log | feature CLIENT-006 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-006 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-006 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-006 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-007 name present | pass |
| migration-inventory-final.log | feature CLIENT-007 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-007 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-007 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-007 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-008 name present | pass |
| migration-inventory-final.log | feature CLIENT-008 UI need 간접 | pass |
| migration-inventory-final.log | feature CLIENT-008 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-008 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-008 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-009 name present | pass |
| migration-inventory-final.log | feature CLIENT-009 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-009 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-009 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-009 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-010 name present | pass |
| migration-inventory-final.log | feature CLIENT-010 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-010 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-010 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-010 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-011 name present | pass |
| migration-inventory-final.log | feature CLIENT-011 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-011 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-011 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-011 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-012 name present | pass |
| migration-inventory-final.log | feature CLIENT-012 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-012 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-012 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-012 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-013 name present | pass |
| migration-inventory-final.log | feature CLIENT-013 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-013 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-013 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-013 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-014 name present | pass |
| migration-inventory-final.log | feature CLIENT-014 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-014 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-014 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-014 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-015 name present | pass |
| migration-inventory-final.log | feature CLIENT-015 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-015 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-015 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-015 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-016 name present | pass |
| migration-inventory-final.log | feature CLIENT-016 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-016 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-016 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-016 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-017 name present | pass |
| migration-inventory-final.log | feature CLIENT-017 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-017 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-017 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-017 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-018 name present | pass |
| migration-inventory-final.log | feature CLIENT-018 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-018 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-018 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-018 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-019 name present | pass |
| migration-inventory-final.log | feature CLIENT-019 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-019 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-019 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-019 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-020 name present | pass |
| migration-inventory-final.log | feature CLIENT-020 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-020 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-020 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-020 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-021 name present | pass |
| migration-inventory-final.log | feature CLIENT-021 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-021 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-021 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-021 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-022 name present | pass |
| migration-inventory-final.log | feature CLIENT-022 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-022 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-022 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-022 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-023 name present | pass |
| migration-inventory-final.log | feature CLIENT-023 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-023 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-023 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-023 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-024 name present | pass |
| migration-inventory-final.log | feature CLIENT-024 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-024 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-024 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-024 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-025 name present | pass |
| migration-inventory-final.log | feature CLIENT-025 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-025 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-025 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-025 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-026 name present | pass |
| migration-inventory-final.log | feature CLIENT-026 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-026 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-026 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-026 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-027 name present | pass |
| migration-inventory-final.log | feature CLIENT-027 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-027 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-027 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-027 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-028 name present | pass |
| migration-inventory-final.log | feature CLIENT-028 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-028 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-028 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-028 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-029 name present | pass |
| migration-inventory-final.log | feature CLIENT-029 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-029 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-029 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-029 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-030 name present | pass |
| migration-inventory-final.log | feature CLIENT-030 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-030 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-030 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-030 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-031 name present | pass |
| migration-inventory-final.log | feature CLIENT-031 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-031 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-031 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-031 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-032 name present | pass |
| migration-inventory-final.log | feature CLIENT-032 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-032 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-032 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-032 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-033 name present | pass |
| migration-inventory-final.log | feature CLIENT-033 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-033 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-033 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-033 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-034 name present | pass |
| migration-inventory-final.log | feature CLIENT-034 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-034 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-034 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-034 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-035 name present | pass |
| migration-inventory-final.log | feature CLIENT-035 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-035 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-035 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-035 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-036 name present | pass |
| migration-inventory-final.log | feature CLIENT-036 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-036 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-036 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-036 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-037 name present | pass |
| migration-inventory-final.log | feature CLIENT-037 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-037 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-037 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-037 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-038 name present | pass |
| migration-inventory-final.log | feature CLIENT-038 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-038 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-038 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-038 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-039 name present | pass |
| migration-inventory-final.log | feature CLIENT-039 UI need 비대상 | pass |
| migration-inventory-final.log | feature CLIENT-039 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-039 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-039 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-040 name present | pass |
| migration-inventory-final.log | feature CLIENT-040 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-040 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-040 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-040 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-041 name present | pass |
| migration-inventory-final.log | feature CLIENT-041 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-041 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-041 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-041 pass criteria present | pass |
| migration-inventory-final.log | feature CLIENT-042 name present | pass |
| migration-inventory-final.log | feature CLIENT-042 UI need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-042 test need 필요 | pass |
| migration-inventory-final.log | feature CLIENT-042 test area assigned | pass |
| migration-inventory-final.log | feature CLIENT-042 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-001 name present | pass |
| migration-inventory-final.log | feature MEDIA-001 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-001 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-001 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-001 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-002 name present | pass |
| migration-inventory-final.log | feature MEDIA-002 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-002 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-002 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-002 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-003 name present | pass |
| migration-inventory-final.log | feature MEDIA-003 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-003 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-003 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-003 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-004 name present | pass |
| migration-inventory-final.log | feature MEDIA-004 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-004 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-004 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-004 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-005 name present | pass |
| migration-inventory-final.log | feature MEDIA-005 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-005 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-005 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-005 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-006 name present | pass |
| migration-inventory-final.log | feature MEDIA-006 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-006 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-006 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-006 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-007 name present | pass |
| migration-inventory-final.log | feature MEDIA-007 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-007 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-007 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-007 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-008 name present | pass |
| migration-inventory-final.log | feature MEDIA-008 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-008 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-008 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-008 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-009 name present | pass |
| migration-inventory-final.log | feature MEDIA-009 UI need 간접 | pass |
| migration-inventory-final.log | feature MEDIA-009 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-009 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-009 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-010 name present | pass |
| migration-inventory-final.log | feature MEDIA-010 UI need 간접 | pass |
| migration-inventory-final.log | feature MEDIA-010 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-010 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-010 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-011 name present | pass |
| migration-inventory-final.log | feature MEDIA-011 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-011 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-011 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-011 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-012 name present | pass |
| migration-inventory-final.log | feature MEDIA-012 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-012 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-012 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-012 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-013 name present | pass |
| migration-inventory-final.log | feature MEDIA-013 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-013 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-013 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-013 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-014 name present | pass |
| migration-inventory-final.log | feature MEDIA-014 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-014 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-014 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-014 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-015 name present | pass |
| migration-inventory-final.log | feature MEDIA-015 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-015 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-015 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-015 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-016 name present | pass |
| migration-inventory-final.log | feature MEDIA-016 UI need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-016 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-016 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-016 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-017 name present | pass |
| migration-inventory-final.log | feature MEDIA-017 UI need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-017 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-017 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-017 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-018 name present | pass |
| migration-inventory-final.log | feature MEDIA-018 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-018 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-018 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-018 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-019 name present | pass |
| migration-inventory-final.log | feature MEDIA-019 UI need 간접 | pass |
| migration-inventory-final.log | feature MEDIA-019 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-019 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-019 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-020 name present | pass |
| migration-inventory-final.log | feature MEDIA-020 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-020 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-020 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-020 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-021 name present | pass |
| migration-inventory-final.log | feature MEDIA-021 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-021 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-021 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-021 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-022 name present | pass |
| migration-inventory-final.log | feature MEDIA-022 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-022 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-022 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-022 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-023 name present | pass |
| migration-inventory-final.log | feature MEDIA-023 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-023 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-023 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-023 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-024 name present | pass |
| migration-inventory-final.log | feature MEDIA-024 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-024 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-024 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-024 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-025 name present | pass |
| migration-inventory-final.log | feature MEDIA-025 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-025 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-025 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-025 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-026 name present | pass |
| migration-inventory-final.log | feature MEDIA-026 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-026 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-026 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-026 pass criteria present | pass |
| migration-inventory-final.log | feature MEDIA-027 name present | pass |
| migration-inventory-final.log | feature MEDIA-027 UI need 비대상 | pass |
| migration-inventory-final.log | feature MEDIA-027 test need 필요 | pass |
| migration-inventory-final.log | feature MEDIA-027 test area assigned | pass |
| migration-inventory-final.log | feature MEDIA-027 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-001 name present | pass |
| migration-inventory-final.log | feature LAB-001 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-001 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-001 test area assigned | pass |
| migration-inventory-final.log | feature LAB-001 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-002 name present | pass |
| migration-inventory-final.log | feature LAB-002 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-002 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-002 test area assigned | pass |
| migration-inventory-final.log | feature LAB-002 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-003 name present | pass |
| migration-inventory-final.log | feature LAB-003 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-003 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-003 test area assigned | pass |
| migration-inventory-final.log | feature LAB-003 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-004 name present | pass |
| migration-inventory-final.log | feature LAB-004 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-004 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-004 test area assigned | pass |
| migration-inventory-final.log | feature LAB-004 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-005 name present | pass |
| migration-inventory-final.log | feature LAB-005 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-005 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-005 test area assigned | pass |
| migration-inventory-final.log | feature LAB-005 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-006 name present | pass |
| migration-inventory-final.log | feature LAB-006 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-006 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-006 test area assigned | pass |
| migration-inventory-final.log | feature LAB-006 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-007 name present | pass |
| migration-inventory-final.log | feature LAB-007 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-007 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-007 test area assigned | pass |
| migration-inventory-final.log | feature LAB-007 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-008 name present | pass |
| migration-inventory-final.log | feature LAB-008 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-008 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-008 test area assigned | pass |
| migration-inventory-final.log | feature LAB-008 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-009 name present | pass |
| migration-inventory-final.log | feature LAB-009 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-009 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-009 test area assigned | pass |
| migration-inventory-final.log | feature LAB-009 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-010 name present | pass |
| migration-inventory-final.log | feature LAB-010 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-010 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-010 test area assigned | pass |
| migration-inventory-final.log | feature LAB-010 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-011 name present | pass |
| migration-inventory-final.log | feature LAB-011 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-011 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-011 test area assigned | pass |
| migration-inventory-final.log | feature LAB-011 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-012 name present | pass |
| migration-inventory-final.log | feature LAB-012 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-012 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-012 test area assigned | pass |
| migration-inventory-final.log | feature LAB-012 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-013 name present | pass |
| migration-inventory-final.log | feature LAB-013 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-013 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-013 test area assigned | pass |
| migration-inventory-final.log | feature LAB-013 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-014 name present | pass |
| migration-inventory-final.log | feature LAB-014 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-014 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-014 test area assigned | pass |
| migration-inventory-final.log | feature LAB-014 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-015 name present | pass |
| migration-inventory-final.log | feature LAB-015 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-015 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-015 test area assigned | pass |
| migration-inventory-final.log | feature LAB-015 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-016 name present | pass |
| migration-inventory-final.log | feature LAB-016 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-016 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-016 test area assigned | pass |
| migration-inventory-final.log | feature LAB-016 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-017 name present | pass |
| migration-inventory-final.log | feature LAB-017 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-017 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-017 test area assigned | pass |
| migration-inventory-final.log | feature LAB-017 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-018 name present | pass |
| migration-inventory-final.log | feature LAB-018 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-018 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-018 test area assigned | pass |
| migration-inventory-final.log | feature LAB-018 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-019 name present | pass |
| migration-inventory-final.log | feature LAB-019 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-019 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-019 test area assigned | pass |
| migration-inventory-final.log | feature LAB-019 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-020 name present | pass |
| migration-inventory-final.log | feature LAB-020 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-020 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-020 test area assigned | pass |
| migration-inventory-final.log | feature LAB-020 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-021 name present | pass |
| migration-inventory-final.log | feature LAB-021 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-021 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-021 test area assigned | pass |
| migration-inventory-final.log | feature LAB-021 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-022 name present | pass |
| migration-inventory-final.log | feature LAB-022 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-022 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-022 test area assigned | pass |
| migration-inventory-final.log | feature LAB-022 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-023 name present | pass |
| migration-inventory-final.log | feature LAB-023 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-023 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-023 test area assigned | pass |
| migration-inventory-final.log | feature LAB-023 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-024 name present | pass |
| migration-inventory-final.log | feature LAB-024 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-024 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-024 test area assigned | pass |
| migration-inventory-final.log | feature LAB-024 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-025 name present | pass |
| migration-inventory-final.log | feature LAB-025 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-025 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-025 test area assigned | pass |
| migration-inventory-final.log | feature LAB-025 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-026 name present | pass |
| migration-inventory-final.log | feature LAB-026 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-026 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-026 test area assigned | pass |
| migration-inventory-final.log | feature LAB-026 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-027 name present | pass |
| migration-inventory-final.log | feature LAB-027 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-027 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-027 test area assigned | pass |
| migration-inventory-final.log | feature LAB-027 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-028 name present | pass |
| migration-inventory-final.log | feature LAB-028 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-028 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-028 test area assigned | pass |
| migration-inventory-final.log | feature LAB-028 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-029 name present | pass |
| migration-inventory-final.log | feature LAB-029 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-029 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-029 test area assigned | pass |
| migration-inventory-final.log | feature LAB-029 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-030 name present | pass |
| migration-inventory-final.log | feature LAB-030 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-030 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-030 test area assigned | pass |
| migration-inventory-final.log | feature LAB-030 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-031 name present | pass |
| migration-inventory-final.log | feature LAB-031 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-031 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-031 test area assigned | pass |
| migration-inventory-final.log | feature LAB-031 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-032 name present | pass |
| migration-inventory-final.log | feature LAB-032 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-032 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-032 test area assigned | pass |
| migration-inventory-final.log | feature LAB-032 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-033 name present | pass |
| migration-inventory-final.log | feature LAB-033 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-033 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-033 test area assigned | pass |
| migration-inventory-final.log | feature LAB-033 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-034 name present | pass |
| migration-inventory-final.log | feature LAB-034 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-034 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-034 test area assigned | pass |
| migration-inventory-final.log | feature LAB-034 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-035 name present | pass |
| migration-inventory-final.log | feature LAB-035 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-035 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-035 test area assigned | pass |
| migration-inventory-final.log | feature LAB-035 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-036 name present | pass |
| migration-inventory-final.log | feature LAB-036 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-036 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-036 test area assigned | pass |
| migration-inventory-final.log | feature LAB-036 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-037 name present | pass |
| migration-inventory-final.log | feature LAB-037 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-037 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-037 test area assigned | pass |
| migration-inventory-final.log | feature LAB-037 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-038 name present | pass |
| migration-inventory-final.log | feature LAB-038 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-038 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-038 test area assigned | pass |
| migration-inventory-final.log | feature LAB-038 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-039 name present | pass |
| migration-inventory-final.log | feature LAB-039 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-039 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-039 test area assigned | pass |
| migration-inventory-final.log | feature LAB-039 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-040 name present | pass |
| migration-inventory-final.log | feature LAB-040 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-040 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-040 test area assigned | pass |
| migration-inventory-final.log | feature LAB-040 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-041 name present | pass |
| migration-inventory-final.log | feature LAB-041 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-041 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-041 test area assigned | pass |
| migration-inventory-final.log | feature LAB-041 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-042 name present | pass |
| migration-inventory-final.log | feature LAB-042 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-042 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-042 test area assigned | pass |
| migration-inventory-final.log | feature LAB-042 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-043 name present | pass |
| migration-inventory-final.log | feature LAB-043 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-043 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-043 test area assigned | pass |
| migration-inventory-final.log | feature LAB-043 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-044 name present | pass |
| migration-inventory-final.log | feature LAB-044 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-044 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-044 test area assigned | pass |
| migration-inventory-final.log | feature LAB-044 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-045 name present | pass |
| migration-inventory-final.log | feature LAB-045 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-045 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-045 test area assigned | pass |
| migration-inventory-final.log | feature LAB-045 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-046 name present | pass |
| migration-inventory-final.log | feature LAB-046 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-046 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-046 test area assigned | pass |
| migration-inventory-final.log | feature LAB-046 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-047 name present | pass |
| migration-inventory-final.log | feature LAB-047 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-047 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-047 test area assigned | pass |
| migration-inventory-final.log | feature LAB-047 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-048 name present | pass |
| migration-inventory-final.log | feature LAB-048 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-048 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-048 test area assigned | pass |
| migration-inventory-final.log | feature LAB-048 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-049 name present | pass |
| migration-inventory-final.log | feature LAB-049 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-049 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-049 test area assigned | pass |
| migration-inventory-final.log | feature LAB-049 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-050 name present | pass |
| migration-inventory-final.log | feature LAB-050 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-050 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-050 test area assigned | pass |
| migration-inventory-final.log | feature LAB-050 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-051 name present | pass |
| migration-inventory-final.log | feature LAB-051 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-051 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-051 test area assigned | pass |
| migration-inventory-final.log | feature LAB-051 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-052 name present | pass |
| migration-inventory-final.log | feature LAB-052 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-052 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-052 test area assigned | pass |
| migration-inventory-final.log | feature LAB-052 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-053 name present | pass |
| migration-inventory-final.log | feature LAB-053 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-053 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-053 test area assigned | pass |
| migration-inventory-final.log | feature LAB-053 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-054 name present | pass |
| migration-inventory-final.log | feature LAB-054 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-054 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-054 test area assigned | pass |
| migration-inventory-final.log | feature LAB-054 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-055 name present | pass |
| migration-inventory-final.log | feature LAB-055 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-055 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-055 test area assigned | pass |
| migration-inventory-final.log | feature LAB-055 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-056 name present | pass |
| migration-inventory-final.log | feature LAB-056 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-056 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-056 test area assigned | pass |
| migration-inventory-final.log | feature LAB-056 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-057 name present | pass |
| migration-inventory-final.log | feature LAB-057 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-057 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-057 test area assigned | pass |
| migration-inventory-final.log | feature LAB-057 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-058 name present | pass |
| migration-inventory-final.log | feature LAB-058 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-058 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-058 test area assigned | pass |
| migration-inventory-final.log | feature LAB-058 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-059 name present | pass |
| migration-inventory-final.log | feature LAB-059 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-059 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-059 test area assigned | pass |
| migration-inventory-final.log | feature LAB-059 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-060 name present | pass |
| migration-inventory-final.log | feature LAB-060 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-060 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-060 test area assigned | pass |
| migration-inventory-final.log | feature LAB-060 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-061 name present | pass |
| migration-inventory-final.log | feature LAB-061 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-061 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-061 test area assigned | pass |
| migration-inventory-final.log | feature LAB-061 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-062 name present | pass |
| migration-inventory-final.log | feature LAB-062 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-062 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-062 test area assigned | pass |
| migration-inventory-final.log | feature LAB-062 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-063 name present | pass |
| migration-inventory-final.log | feature LAB-063 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-063 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-063 test area assigned | pass |
| migration-inventory-final.log | feature LAB-063 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-064 name present | pass |
| migration-inventory-final.log | feature LAB-064 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-064 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-064 test area assigned | pass |
| migration-inventory-final.log | feature LAB-064 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-065 name present | pass |
| migration-inventory-final.log | feature LAB-065 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-065 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-065 test area assigned | pass |
| migration-inventory-final.log | feature LAB-065 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-066 name present | pass |
| migration-inventory-final.log | feature LAB-066 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-066 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-066 test area assigned | pass |
| migration-inventory-final.log | feature LAB-066 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-067 name present | pass |
| migration-inventory-final.log | feature LAB-067 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-067 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-067 test area assigned | pass |
| migration-inventory-final.log | feature LAB-067 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-068 name present | pass |
| migration-inventory-final.log | feature LAB-068 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-068 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-068 test area assigned | pass |
| migration-inventory-final.log | feature LAB-068 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-069 name present | pass |
| migration-inventory-final.log | feature LAB-069 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-069 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-069 test area assigned | pass |
| migration-inventory-final.log | feature LAB-069 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-070 name present | pass |
| migration-inventory-final.log | feature LAB-070 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-070 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-070 test area assigned | pass |
| migration-inventory-final.log | feature LAB-070 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-071 name present | pass |
| migration-inventory-final.log | feature LAB-071 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-071 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-071 test area assigned | pass |
| migration-inventory-final.log | feature LAB-071 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-072 name present | pass |
| migration-inventory-final.log | feature LAB-072 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-072 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-072 test area assigned | pass |
| migration-inventory-final.log | feature LAB-072 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-073 name present | pass |
| migration-inventory-final.log | feature LAB-073 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-073 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-073 test area assigned | pass |
| migration-inventory-final.log | feature LAB-073 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-074 name present | pass |
| migration-inventory-final.log | feature LAB-074 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-074 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-074 test area assigned | pass |
| migration-inventory-final.log | feature LAB-074 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-075 name present | pass |
| migration-inventory-final.log | feature LAB-075 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-075 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-075 test area assigned | pass |
| migration-inventory-final.log | feature LAB-075 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-076 name present | pass |
| migration-inventory-final.log | feature LAB-076 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-076 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-076 test area assigned | pass |
| migration-inventory-final.log | feature LAB-076 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-077 name present | pass |
| migration-inventory-final.log | feature LAB-077 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-077 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-077 test area assigned | pass |
| migration-inventory-final.log | feature LAB-077 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-078 name present | pass |
| migration-inventory-final.log | feature LAB-078 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-078 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-078 test area assigned | pass |
| migration-inventory-final.log | feature LAB-078 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-079 name present | pass |
| migration-inventory-final.log | feature LAB-079 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-079 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-079 test area assigned | pass |
| migration-inventory-final.log | feature LAB-079 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-080 name present | pass |
| migration-inventory-final.log | feature LAB-080 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-080 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-080 test area assigned | pass |
| migration-inventory-final.log | feature LAB-080 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-081 name present | pass |
| migration-inventory-final.log | feature LAB-081 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-081 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-081 test area assigned | pass |
| migration-inventory-final.log | feature LAB-081 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-082 name present | pass |
| migration-inventory-final.log | feature LAB-082 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-082 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-082 test area assigned | pass |
| migration-inventory-final.log | feature LAB-082 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-083 name present | pass |
| migration-inventory-final.log | feature LAB-083 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-083 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-083 test area assigned | pass |
| migration-inventory-final.log | feature LAB-083 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-084 name present | pass |
| migration-inventory-final.log | feature LAB-084 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-084 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-084 test area assigned | pass |
| migration-inventory-final.log | feature LAB-084 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-085 name present | pass |
| migration-inventory-final.log | feature LAB-085 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-085 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-085 test area assigned | pass |
| migration-inventory-final.log | feature LAB-085 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-086 name present | pass |
| migration-inventory-final.log | feature LAB-086 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-086 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-086 test area assigned | pass |
| migration-inventory-final.log | feature LAB-086 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-087 name present | pass |
| migration-inventory-final.log | feature LAB-087 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-087 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-087 test area assigned | pass |
| migration-inventory-final.log | feature LAB-087 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-088 name present | pass |
| migration-inventory-final.log | feature LAB-088 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-088 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-088 test area assigned | pass |
| migration-inventory-final.log | feature LAB-088 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-089 name present | pass |
| migration-inventory-final.log | feature LAB-089 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-089 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-089 test area assigned | pass |
| migration-inventory-final.log | feature LAB-089 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-090 name present | pass |
| migration-inventory-final.log | feature LAB-090 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-090 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-090 test area assigned | pass |
| migration-inventory-final.log | feature LAB-090 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-091 name present | pass |
| migration-inventory-final.log | feature LAB-091 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-091 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-091 test area assigned | pass |
| migration-inventory-final.log | feature LAB-091 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-092 name present | pass |
| migration-inventory-final.log | feature LAB-092 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-092 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-092 test area assigned | pass |
| migration-inventory-final.log | feature LAB-092 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-093 name present | pass |
| migration-inventory-final.log | feature LAB-093 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-093 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-093 test area assigned | pass |
| migration-inventory-final.log | feature LAB-093 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-094 name present | pass |
| migration-inventory-final.log | feature LAB-094 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-094 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-094 test area assigned | pass |
| migration-inventory-final.log | feature LAB-094 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-095 name present | pass |
| migration-inventory-final.log | feature LAB-095 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-095 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-095 test area assigned | pass |
| migration-inventory-final.log | feature LAB-095 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-096 name present | pass |
| migration-inventory-final.log | feature LAB-096 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-096 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-096 test area assigned | pass |
| migration-inventory-final.log | feature LAB-096 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-097 name present | pass |
| migration-inventory-final.log | feature LAB-097 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-097 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-097 test area assigned | pass |
| migration-inventory-final.log | feature LAB-097 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-098 name present | pass |
| migration-inventory-final.log | feature LAB-098 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-098 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-098 test area assigned | pass |
| migration-inventory-final.log | feature LAB-098 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-099 name present | pass |
| migration-inventory-final.log | feature LAB-099 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-099 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-099 test area assigned | pass |
| migration-inventory-final.log | feature LAB-099 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-100 name present | pass |
| migration-inventory-final.log | feature LAB-100 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-100 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-100 test area assigned | pass |
| migration-inventory-final.log | feature LAB-100 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-101 name present | pass |
| migration-inventory-final.log | feature LAB-101 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-101 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-101 test area assigned | pass |
| migration-inventory-final.log | feature LAB-101 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-102 name present | pass |
| migration-inventory-final.log | feature LAB-102 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-102 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-102 test area assigned | pass |
| migration-inventory-final.log | feature LAB-102 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-103 name present | pass |
| migration-inventory-final.log | feature LAB-103 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-103 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-103 test area assigned | pass |
| migration-inventory-final.log | feature LAB-103 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-104 name present | pass |
| migration-inventory-final.log | feature LAB-104 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-104 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-104 test area assigned | pass |
| migration-inventory-final.log | feature LAB-104 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-105 name present | pass |
| migration-inventory-final.log | feature LAB-105 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-105 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-105 test area assigned | pass |
| migration-inventory-final.log | feature LAB-105 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-106 name present | pass |
| migration-inventory-final.log | feature LAB-106 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-106 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-106 test area assigned | pass |
| migration-inventory-final.log | feature LAB-106 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-107 name present | pass |
| migration-inventory-final.log | feature LAB-107 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-107 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-107 test area assigned | pass |
| migration-inventory-final.log | feature LAB-107 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-108 name present | pass |
| migration-inventory-final.log | feature LAB-108 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-108 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-108 test area assigned | pass |
| migration-inventory-final.log | feature LAB-108 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-109 name present | pass |
| migration-inventory-final.log | feature LAB-109 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-109 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-109 test area assigned | pass |
| migration-inventory-final.log | feature LAB-109 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-110 name present | pass |
| migration-inventory-final.log | feature LAB-110 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-110 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-110 test area assigned | pass |
| migration-inventory-final.log | feature LAB-110 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-111 name present | pass |
| migration-inventory-final.log | feature LAB-111 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-111 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-111 test area assigned | pass |
| migration-inventory-final.log | feature LAB-111 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-112 name present | pass |
| migration-inventory-final.log | feature LAB-112 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-112 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-112 test area assigned | pass |
| migration-inventory-final.log | feature LAB-112 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-113 name present | pass |
| migration-inventory-final.log | feature LAB-113 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-113 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-113 test area assigned | pass |
| migration-inventory-final.log | feature LAB-113 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-114 name present | pass |
| migration-inventory-final.log | feature LAB-114 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-114 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-114 test area assigned | pass |
| migration-inventory-final.log | feature LAB-114 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-115 name present | pass |
| migration-inventory-final.log | feature LAB-115 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-115 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-115 test area assigned | pass |
| migration-inventory-final.log | feature LAB-115 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-116 name present | pass |
| migration-inventory-final.log | feature LAB-116 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-116 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-116 test area assigned | pass |
| migration-inventory-final.log | feature LAB-116 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-117 name present | pass |
| migration-inventory-final.log | feature LAB-117 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-117 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-117 test area assigned | pass |
| migration-inventory-final.log | feature LAB-117 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-118 name present | pass |
| migration-inventory-final.log | feature LAB-118 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-118 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-118 test area assigned | pass |
| migration-inventory-final.log | feature LAB-118 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-119 name present | pass |
| migration-inventory-final.log | feature LAB-119 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-119 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-119 test area assigned | pass |
| migration-inventory-final.log | feature LAB-119 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-120 name present | pass |
| migration-inventory-final.log | feature LAB-120 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-120 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-120 test area assigned | pass |
| migration-inventory-final.log | feature LAB-120 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-121 name present | pass |
| migration-inventory-final.log | feature LAB-121 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-121 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-121 test area assigned | pass |
| migration-inventory-final.log | feature LAB-121 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-122 name present | pass |
| migration-inventory-final.log | feature LAB-122 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-122 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-122 test area assigned | pass |
| migration-inventory-final.log | feature LAB-122 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-123 name present | pass |
| migration-inventory-final.log | feature LAB-123 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-123 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-123 test area assigned | pass |
| migration-inventory-final.log | feature LAB-123 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-124 name present | pass |
| migration-inventory-final.log | feature LAB-124 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-124 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-124 test area assigned | pass |
| migration-inventory-final.log | feature LAB-124 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-125 name present | pass |
| migration-inventory-final.log | feature LAB-125 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-125 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-125 test area assigned | pass |
| migration-inventory-final.log | feature LAB-125 pass criteria present | pass |
| migration-inventory-final.log | feature LAB-126 name present | pass |
| migration-inventory-final.log | feature LAB-126 UI need 비대상 | pass |
| migration-inventory-final.log | feature LAB-126 test need 필요 | pass |
| migration-inventory-final.log | feature LAB-126 test area assigned | pass |
| migration-inventory-final.log | feature LAB-126 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-001 name present | pass |
| migration-inventory-final.log | feature SAFE-001 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-001 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-001 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-001 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-002 name present | pass |
| migration-inventory-final.log | feature SAFE-002 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-002 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-002 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-002 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-003 name present | pass |
| migration-inventory-final.log | feature SAFE-003 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-003 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-003 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-003 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-004 name present | pass |
| migration-inventory-final.log | feature SAFE-004 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-004 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-004 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-004 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-005 name present | pass |
| migration-inventory-final.log | feature SAFE-005 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-005 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-005 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-005 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-006 name present | pass |
| migration-inventory-final.log | feature SAFE-006 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-006 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-006 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-006 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-007 name present | pass |
| migration-inventory-final.log | feature SAFE-007 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-007 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-007 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-007 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-008 name present | pass |
| migration-inventory-final.log | feature SAFE-008 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-008 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-008 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-008 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-009 name present | pass |
| migration-inventory-final.log | feature SAFE-009 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-009 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-009 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-009 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-010 name present | pass |
| migration-inventory-final.log | feature SAFE-010 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-010 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-010 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-010 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-011 name present | pass |
| migration-inventory-final.log | feature SAFE-011 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-011 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-011 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-011 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-012 name present | pass |
| migration-inventory-final.log | feature SAFE-012 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-012 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-012 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-012 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-013 name present | pass |
| migration-inventory-final.log | feature SAFE-013 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-013 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-013 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-013 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-014 name present | pass |
| migration-inventory-final.log | feature SAFE-014 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-014 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-014 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-014 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-015 name present | pass |
| migration-inventory-final.log | feature SAFE-015 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-015 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-015 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-015 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-016 name present | pass |
| migration-inventory-final.log | feature SAFE-016 UI need 간접 | pass |
| migration-inventory-final.log | feature SAFE-016 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-016 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-016 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-017 name present | pass |
| migration-inventory-final.log | feature SAFE-017 UI need 간접 | pass |
| migration-inventory-final.log | feature SAFE-017 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-017 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-017 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-018 name present | pass |
| migration-inventory-final.log | feature SAFE-018 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-018 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-018 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-018 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-019 name present | pass |
| migration-inventory-final.log | feature SAFE-019 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-019 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-019 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-019 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-020 name present | pass |
| migration-inventory-final.log | feature SAFE-020 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-020 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-020 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-020 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-021 name present | pass |
| migration-inventory-final.log | feature SAFE-021 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-021 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-021 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-021 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-022 name present | pass |
| migration-inventory-final.log | feature SAFE-022 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-022 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-022 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-022 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-023 name present | pass |
| migration-inventory-final.log | feature SAFE-023 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-023 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-023 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-023 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-024 name present | pass |
| migration-inventory-final.log | feature SAFE-024 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-024 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-024 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-024 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-025 name present | pass |
| migration-inventory-final.log | feature SAFE-025 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-025 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-025 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-025 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-026 name present | pass |
| migration-inventory-final.log | feature SAFE-026 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-026 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-026 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-026 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-027 name present | pass |
| migration-inventory-final.log | feature SAFE-027 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-027 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-027 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-027 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-028 name present | pass |
| migration-inventory-final.log | feature SAFE-028 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-028 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-028 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-028 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-029 name present | pass |
| migration-inventory-final.log | feature SAFE-029 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-029 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-029 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-029 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-030 name present | pass |
| migration-inventory-final.log | feature SAFE-030 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-030 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-030 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-030 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-031 name present | pass |
| migration-inventory-final.log | feature SAFE-031 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-031 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-031 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-031 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-032 name present | pass |
| migration-inventory-final.log | feature SAFE-032 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-032 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-032 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-032 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-033 name present | pass |
| migration-inventory-final.log | feature SAFE-033 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-033 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-033 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-033 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-034 name present | pass |
| migration-inventory-final.log | feature SAFE-034 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-034 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-034 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-034 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-035 name present | pass |
| migration-inventory-final.log | feature SAFE-035 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-035 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-035 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-035 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-036 name present | pass |
| migration-inventory-final.log | feature SAFE-036 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-036 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-036 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-036 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-037 name present | pass |
| migration-inventory-final.log | feature SAFE-037 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-037 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-037 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-037 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-038 name present | pass |
| migration-inventory-final.log | feature SAFE-038 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-038 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-038 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-038 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-039 name present | pass |
| migration-inventory-final.log | feature SAFE-039 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-039 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-039 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-039 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-040 name present | pass |
| migration-inventory-final.log | feature SAFE-040 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-040 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-040 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-040 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-041 name present | pass |
| migration-inventory-final.log | feature SAFE-041 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-041 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-041 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-041 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-042 name present | pass |
| migration-inventory-final.log | feature SAFE-042 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-042 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-042 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-042 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-043 name present | pass |
| migration-inventory-final.log | feature SAFE-043 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-043 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-043 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-043 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-044 name present | pass |
| migration-inventory-final.log | feature SAFE-044 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-044 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-044 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-044 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-045 name present | pass |
| migration-inventory-final.log | feature SAFE-045 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-045 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-045 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-045 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-046 name present | pass |
| migration-inventory-final.log | feature SAFE-046 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-046 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-046 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-046 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-047 name present | pass |
| migration-inventory-final.log | feature SAFE-047 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-047 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-047 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-047 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-048 name present | pass |
| migration-inventory-final.log | feature SAFE-048 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-048 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-048 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-048 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-049 name present | pass |
| migration-inventory-final.log | feature SAFE-049 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-049 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-049 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-049 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-050 name present | pass |
| migration-inventory-final.log | feature SAFE-050 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-050 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-050 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-050 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-051 name present | pass |
| migration-inventory-final.log | feature SAFE-051 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-051 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-051 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-051 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-052 name present | pass |
| migration-inventory-final.log | feature SAFE-052 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-052 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-052 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-052 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-053 name present | pass |
| migration-inventory-final.log | feature SAFE-053 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-053 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-053 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-053 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-054 name present | pass |
| migration-inventory-final.log | feature SAFE-054 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-054 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-054 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-054 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-055 name present | pass |
| migration-inventory-final.log | feature SAFE-055 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-055 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-055 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-055 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-056 name present | pass |
| migration-inventory-final.log | feature SAFE-056 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-056 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-056 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-056 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-057 name present | pass |
| migration-inventory-final.log | feature SAFE-057 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-057 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-057 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-057 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-058 name present | pass |
| migration-inventory-final.log | feature SAFE-058 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-058 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-058 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-058 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-059 name present | pass |
| migration-inventory-final.log | feature SAFE-059 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-059 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-059 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-059 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-060 name present | pass |
| migration-inventory-final.log | feature SAFE-060 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-060 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-060 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-060 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-061 name present | pass |
| migration-inventory-final.log | feature SAFE-061 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-061 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-061 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-061 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-062 name present | pass |
| migration-inventory-final.log | feature SAFE-062 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-062 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-062 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-062 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-063 name present | pass |
| migration-inventory-final.log | feature SAFE-063 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-063 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-063 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-063 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-064 name present | pass |
| migration-inventory-final.log | feature SAFE-064 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-064 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-064 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-064 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-065 name present | pass |
| migration-inventory-final.log | feature SAFE-065 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-065 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-065 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-065 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-066 name present | pass |
| migration-inventory-final.log | feature SAFE-066 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-066 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-066 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-066 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-067 name present | pass |
| migration-inventory-final.log | feature SAFE-067 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-067 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-067 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-067 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-068 name present | pass |
| migration-inventory-final.log | feature SAFE-068 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-068 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-068 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-068 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-069 name present | pass |
| migration-inventory-final.log | feature SAFE-069 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-069 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-069 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-069 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-070 name present | pass |
| migration-inventory-final.log | feature SAFE-070 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-070 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-070 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-070 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-071 name present | pass |
| migration-inventory-final.log | feature SAFE-071 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-071 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-071 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-071 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-072 name present | pass |
| migration-inventory-final.log | feature SAFE-072 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-072 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-072 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-072 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-073 name present | pass |
| migration-inventory-final.log | feature SAFE-073 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-073 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-073 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-073 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-074 name present | pass |
| migration-inventory-final.log | feature SAFE-074 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-074 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-074 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-074 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-075 name present | pass |
| migration-inventory-final.log | feature SAFE-075 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-075 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-075 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-075 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-076 name present | pass |
| migration-inventory-final.log | feature SAFE-076 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-076 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-076 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-076 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-077 name present | pass |
| migration-inventory-final.log | feature SAFE-077 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-077 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-077 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-077 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-078 name present | pass |
| migration-inventory-final.log | feature SAFE-078 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-078 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-078 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-078 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-079 name present | pass |
| migration-inventory-final.log | feature SAFE-079 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-079 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-079 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-079 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-080 name present | pass |
| migration-inventory-final.log | feature SAFE-080 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-080 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-080 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-080 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-081 name present | pass |
| migration-inventory-final.log | feature SAFE-081 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-081 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-081 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-081 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-082 name present | pass |
| migration-inventory-final.log | feature SAFE-082 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-082 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-082 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-082 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-083 name present | pass |
| migration-inventory-final.log | feature SAFE-083 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-083 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-083 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-083 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-084 name present | pass |
| migration-inventory-final.log | feature SAFE-084 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-084 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-084 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-084 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-085 name present | pass |
| migration-inventory-final.log | feature SAFE-085 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-085 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-085 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-085 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-086 name present | pass |
| migration-inventory-final.log | feature SAFE-086 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-086 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-086 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-086 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-087 name present | pass |
| migration-inventory-final.log | feature SAFE-087 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-087 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-087 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-087 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-088 name present | pass |
| migration-inventory-final.log | feature SAFE-088 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-088 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-088 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-088 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-089 name present | pass |
| migration-inventory-final.log | feature SAFE-089 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-089 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-089 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-089 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-090 name present | pass |
| migration-inventory-final.log | feature SAFE-090 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-090 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-090 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-090 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-091 name present | pass |
| migration-inventory-final.log | feature SAFE-091 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-091 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-091 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-091 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-092 name present | pass |
| migration-inventory-final.log | feature SAFE-092 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-092 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-092 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-092 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-093 name present | pass |
| migration-inventory-final.log | feature SAFE-093 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-093 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-093 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-093 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-094 name present | pass |
| migration-inventory-final.log | feature SAFE-094 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-094 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-094 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-094 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-095 name present | pass |
| migration-inventory-final.log | feature SAFE-095 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-095 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-095 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-095 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-096 name present | pass |
| migration-inventory-final.log | feature SAFE-096 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-096 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-096 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-096 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-097 name present | pass |
| migration-inventory-final.log | feature SAFE-097 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-097 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-097 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-097 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-098 name present | pass |
| migration-inventory-final.log | feature SAFE-098 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-098 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-098 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-098 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-099 name present | pass |
| migration-inventory-final.log | feature SAFE-099 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-099 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-099 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-099 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-100 name present | pass |
| migration-inventory-final.log | feature SAFE-100 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-100 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-100 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-100 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-101 name present | pass |
| migration-inventory-final.log | feature SAFE-101 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-101 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-101 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-101 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-102 name present | pass |
| migration-inventory-final.log | feature SAFE-102 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-102 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-102 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-102 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-103 name present | pass |
| migration-inventory-final.log | feature SAFE-103 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-103 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-103 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-103 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-104 name present | pass |
| migration-inventory-final.log | feature SAFE-104 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-104 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-104 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-104 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-105 name present | pass |
| migration-inventory-final.log | feature SAFE-105 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-105 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-105 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-105 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-106 name present | pass |
| migration-inventory-final.log | feature SAFE-106 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-106 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-106 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-106 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-107 name present | pass |
| migration-inventory-final.log | feature SAFE-107 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-107 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-107 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-107 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-108 name present | pass |
| migration-inventory-final.log | feature SAFE-108 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-108 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-108 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-108 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-109 name present | pass |
| migration-inventory-final.log | feature SAFE-109 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-109 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-109 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-109 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-110 name present | pass |
| migration-inventory-final.log | feature SAFE-110 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-110 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-110 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-110 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-111 name present | pass |
| migration-inventory-final.log | feature SAFE-111 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-111 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-111 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-111 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-112 name present | pass |
| migration-inventory-final.log | feature SAFE-112 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-112 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-112 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-112 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-113 name present | pass |
| migration-inventory-final.log | feature SAFE-113 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-113 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-113 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-113 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-114 name present | pass |
| migration-inventory-final.log | feature SAFE-114 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-114 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-114 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-114 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-115 name present | pass |
| migration-inventory-final.log | feature SAFE-115 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-115 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-115 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-115 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-116 name present | pass |
| migration-inventory-final.log | feature SAFE-116 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-116 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-116 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-116 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-117 name present | pass |
| migration-inventory-final.log | feature SAFE-117 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-117 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-117 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-117 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-118 name present | pass |
| migration-inventory-final.log | feature SAFE-118 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-118 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-118 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-118 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-119 name present | pass |
| migration-inventory-final.log | feature SAFE-119 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-119 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-119 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-119 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-120 name present | pass |
| migration-inventory-final.log | feature SAFE-120 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-120 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-120 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-120 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-121 name present | pass |
| migration-inventory-final.log | feature SAFE-121 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-121 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-121 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-121 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-122 name present | pass |
| migration-inventory-final.log | feature SAFE-122 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-122 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-122 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-122 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-123 name present | pass |
| migration-inventory-final.log | feature SAFE-123 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-123 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-123 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-123 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-124 name present | pass |
| migration-inventory-final.log | feature SAFE-124 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-124 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-124 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-124 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-125 name present | pass |
| migration-inventory-final.log | feature SAFE-125 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-125 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-125 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-125 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-126 name present | pass |
| migration-inventory-final.log | feature SAFE-126 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-126 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-126 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-126 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-127 name present | pass |
| migration-inventory-final.log | feature SAFE-127 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-127 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-127 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-127 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-128 name present | pass |
| migration-inventory-final.log | feature SAFE-128 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-128 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-128 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-128 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-129 name present | pass |
| migration-inventory-final.log | feature SAFE-129 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-129 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-129 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-129 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-130 name present | pass |
| migration-inventory-final.log | feature SAFE-130 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-130 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-130 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-130 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-131 name present | pass |
| migration-inventory-final.log | feature SAFE-131 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-131 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-131 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-131 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-132 name present | pass |
| migration-inventory-final.log | feature SAFE-132 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-132 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-132 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-132 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-133 name present | pass |
| migration-inventory-final.log | feature SAFE-133 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-133 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-133 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-133 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-134 name present | pass |
| migration-inventory-final.log | feature SAFE-134 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-134 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-134 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-134 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-135 name present | pass |
| migration-inventory-final.log | feature SAFE-135 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-135 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-135 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-135 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-136 name present | pass |
| migration-inventory-final.log | feature SAFE-136 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-136 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-136 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-136 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-137 name present | pass |
| migration-inventory-final.log | feature SAFE-137 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-137 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-137 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-137 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-138 name present | pass |
| migration-inventory-final.log | feature SAFE-138 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-138 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-138 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-138 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-139 name present | pass |
| migration-inventory-final.log | feature SAFE-139 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-139 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-139 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-139 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-140 name present | pass |
| migration-inventory-final.log | feature SAFE-140 UI need 필요 | pass |
| migration-inventory-final.log | feature SAFE-140 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-140 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-140 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-141 name present | pass |
| migration-inventory-final.log | feature SAFE-141 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-141 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-141 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-141 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-142 name present | pass |
| migration-inventory-final.log | feature SAFE-142 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-142 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-142 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-142 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-143 name present | pass |
| migration-inventory-final.log | feature SAFE-143 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-143 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-143 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-143 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-144 name present | pass |
| migration-inventory-final.log | feature SAFE-144 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-144 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-144 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-144 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-145 name present | pass |
| migration-inventory-final.log | feature SAFE-145 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-145 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-145 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-145 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-146 name present | pass |
| migration-inventory-final.log | feature SAFE-146 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-146 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-146 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-146 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-147 name present | pass |
| migration-inventory-final.log | feature SAFE-147 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-147 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-147 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-147 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-148 name present | pass |
| migration-inventory-final.log | feature SAFE-148 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-148 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-148 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-148 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-149 name present | pass |
| migration-inventory-final.log | feature SAFE-149 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-149 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-149 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-149 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-150 name present | pass |
| migration-inventory-final.log | feature SAFE-150 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-150 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-150 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-150 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-151 name present | pass |
| migration-inventory-final.log | feature SAFE-151 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-151 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-151 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-151 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-152 name present | pass |
| migration-inventory-final.log | feature SAFE-152 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-152 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-152 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-152 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-153 name present | pass |
| migration-inventory-final.log | feature SAFE-153 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-153 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-153 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-153 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-154 name present | pass |
| migration-inventory-final.log | feature SAFE-154 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-154 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-154 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-154 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-155 name present | pass |
| migration-inventory-final.log | feature SAFE-155 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-155 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-155 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-155 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-156 name present | pass |
| migration-inventory-final.log | feature SAFE-156 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-156 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-156 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-156 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-157 name present | pass |
| migration-inventory-final.log | feature SAFE-157 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-157 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-157 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-157 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-158 name present | pass |
| migration-inventory-final.log | feature SAFE-158 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-158 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-158 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-158 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-159 name present | pass |
| migration-inventory-final.log | feature SAFE-159 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-159 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-159 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-159 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-160 name present | pass |
| migration-inventory-final.log | feature SAFE-160 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-160 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-160 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-160 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-161 name present | pass |
| migration-inventory-final.log | feature SAFE-161 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-161 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-161 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-161 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-162 name present | pass |
| migration-inventory-final.log | feature SAFE-162 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-162 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-162 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-162 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-163 name present | pass |
| migration-inventory-final.log | feature SAFE-163 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-163 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-163 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-163 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-164 name present | pass |
| migration-inventory-final.log | feature SAFE-164 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-164 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-164 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-164 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-165 name present | pass |
| migration-inventory-final.log | feature SAFE-165 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-165 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-165 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-165 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-166 name present | pass |
| migration-inventory-final.log | feature SAFE-166 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-166 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-166 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-166 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-167 name present | pass |
| migration-inventory-final.log | feature SAFE-167 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-167 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-167 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-167 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-168 name present | pass |
| migration-inventory-final.log | feature SAFE-168 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-168 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-168 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-168 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-169 name present | pass |
| migration-inventory-final.log | feature SAFE-169 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-169 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-169 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-169 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-170 name present | pass |
| migration-inventory-final.log | feature SAFE-170 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-170 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-170 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-170 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-171 name present | pass |
| migration-inventory-final.log | feature SAFE-171 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-171 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-171 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-171 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-172 name present | pass |
| migration-inventory-final.log | feature SAFE-172 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-172 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-172 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-172 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-173 name present | pass |
| migration-inventory-final.log | feature SAFE-173 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-173 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-173 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-173 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-174 name present | pass |
| migration-inventory-final.log | feature SAFE-174 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-174 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-174 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-174 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-175 name present | pass |
| migration-inventory-final.log | feature SAFE-175 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-175 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-175 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-175 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-176 name present | pass |
| migration-inventory-final.log | feature SAFE-176 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-176 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-176 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-176 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-177 name present | pass |
| migration-inventory-final.log | feature SAFE-177 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-177 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-177 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-177 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-178 name present | pass |
| migration-inventory-final.log | feature SAFE-178 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-178 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-178 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-178 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-179 name present | pass |
| migration-inventory-final.log | feature SAFE-179 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-179 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-179 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-179 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-180 name present | pass |
| migration-inventory-final.log | feature SAFE-180 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-180 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-180 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-180 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-181 name present | pass |
| migration-inventory-final.log | feature SAFE-181 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-181 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-181 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-181 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-182 name present | pass |
| migration-inventory-final.log | feature SAFE-182 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-182 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-182 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-182 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-183 name present | pass |
| migration-inventory-final.log | feature SAFE-183 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-183 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-183 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-183 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-184 name present | pass |
| migration-inventory-final.log | feature SAFE-184 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-184 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-184 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-184 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-185 name present | pass |
| migration-inventory-final.log | feature SAFE-185 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-185 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-185 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-185 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-186 name present | pass |
| migration-inventory-final.log | feature SAFE-186 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-186 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-186 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-186 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-187 name present | pass |
| migration-inventory-final.log | feature SAFE-187 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-187 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-187 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-187 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-188 name present | pass |
| migration-inventory-final.log | feature SAFE-188 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-188 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-188 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-188 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-189 name present | pass |
| migration-inventory-final.log | feature SAFE-189 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-189 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-189 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-189 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-190 name present | pass |
| migration-inventory-final.log | feature SAFE-190 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-190 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-190 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-190 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-191 name present | pass |
| migration-inventory-final.log | feature SAFE-191 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-191 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-191 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-191 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-192 name present | pass |
| migration-inventory-final.log | feature SAFE-192 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-192 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-192 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-192 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-193 name present | pass |
| migration-inventory-final.log | feature SAFE-193 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-193 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-193 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-193 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-194 name present | pass |
| migration-inventory-final.log | feature SAFE-194 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-194 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-194 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-194 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-195 name present | pass |
| migration-inventory-final.log | feature SAFE-195 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-195 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-195 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-195 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-196 name present | pass |
| migration-inventory-final.log | feature SAFE-196 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-196 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-196 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-196 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-197 name present | pass |
| migration-inventory-final.log | feature SAFE-197 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-197 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-197 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-197 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-198 name present | pass |
| migration-inventory-final.log | feature SAFE-198 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-198 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-198 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-198 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-199 name present | pass |
| migration-inventory-final.log | feature SAFE-199 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-199 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-199 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-199 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-200 name present | pass |
| migration-inventory-final.log | feature SAFE-200 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-200 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-200 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-200 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-201 name present | pass |
| migration-inventory-final.log | feature SAFE-201 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-201 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-201 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-201 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-202 name present | pass |
| migration-inventory-final.log | feature SAFE-202 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-202 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-202 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-202 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-203 name present | pass |
| migration-inventory-final.log | feature SAFE-203 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-203 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-203 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-203 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-204 name present | pass |
| migration-inventory-final.log | feature SAFE-204 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-204 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-204 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-204 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-205 name present | pass |
| migration-inventory-final.log | feature SAFE-205 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-205 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-205 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-205 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-206 name present | pass |
| migration-inventory-final.log | feature SAFE-206 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-206 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-206 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-206 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-207 name present | pass |
| migration-inventory-final.log | feature SAFE-207 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-207 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-207 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-207 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-208 name present | pass |
| migration-inventory-final.log | feature SAFE-208 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-208 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-208 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-208 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-209 name present | pass |
| migration-inventory-final.log | feature SAFE-209 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-209 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-209 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-209 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-210 name present | pass |
| migration-inventory-final.log | feature SAFE-210 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-210 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-210 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-210 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-211 name present | pass |
| migration-inventory-final.log | feature SAFE-211 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-211 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-211 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-211 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-212 name present | pass |
| migration-inventory-final.log | feature SAFE-212 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-212 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-212 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-212 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-213 name present | pass |
| migration-inventory-final.log | feature SAFE-213 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-213 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-213 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-213 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-214 name present | pass |
| migration-inventory-final.log | feature SAFE-214 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-214 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-214 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-214 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-215 name present | pass |
| migration-inventory-final.log | feature SAFE-215 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-215 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-215 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-215 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-216 name present | pass |
| migration-inventory-final.log | feature SAFE-216 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-216 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-216 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-216 pass criteria present | pass |
| migration-inventory-final.log | feature SAFE-217 name present | pass |
| migration-inventory-final.log | feature SAFE-217 UI need 비대상 | pass |
| migration-inventory-final.log | feature SAFE-217 test need 필요 | pass |
| migration-inventory-final.log | feature SAFE-217 test area assigned | pass |
| migration-inventory-final.log | feature SAFE-217 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-035 name present | pass |
| migration-inventory-final.log | feature OPS-035 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-035 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-035 test area assigned | pass |
| migration-inventory-final.log | feature OPS-035 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-036 name present | pass |
| migration-inventory-final.log | feature OPS-036 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-036 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-036 test area assigned | pass |
| migration-inventory-final.log | feature OPS-036 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-037 name present | pass |
| migration-inventory-final.log | feature OPS-037 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-037 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-037 test area assigned | pass |
| migration-inventory-final.log | feature OPS-037 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-038 name present | pass |
| migration-inventory-final.log | feature OPS-038 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-038 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-038 test area assigned | pass |
| migration-inventory-final.log | feature OPS-038 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-039 name present | pass |
| migration-inventory-final.log | feature OPS-039 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-039 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-039 test area assigned | pass |
| migration-inventory-final.log | feature OPS-039 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-040 name present | pass |
| migration-inventory-final.log | feature OPS-040 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-040 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-040 test area assigned | pass |
| migration-inventory-final.log | feature OPS-040 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-041 name present | pass |
| migration-inventory-final.log | feature OPS-041 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-041 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-041 test area assigned | pass |
| migration-inventory-final.log | feature OPS-041 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-042 name present | pass |
| migration-inventory-final.log | feature OPS-042 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-042 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-042 test area assigned | pass |
| migration-inventory-final.log | feature OPS-042 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-043 name present | pass |
| migration-inventory-final.log | feature OPS-043 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-043 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-043 test area assigned | pass |
| migration-inventory-final.log | feature OPS-043 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-044 name present | pass |
| migration-inventory-final.log | feature OPS-044 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-044 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-044 test area assigned | pass |
| migration-inventory-final.log | feature OPS-044 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-045 name present | pass |
| migration-inventory-final.log | feature OPS-045 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-045 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-045 test area assigned | pass |
| migration-inventory-final.log | feature OPS-045 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-046 name present | pass |
| migration-inventory-final.log | feature OPS-046 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-046 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-046 test area assigned | pass |
| migration-inventory-final.log | feature OPS-046 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-047 name present | pass |
| migration-inventory-final.log | feature OPS-047 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-047 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-047 test area assigned | pass |
| migration-inventory-final.log | feature OPS-047 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-048 name present | pass |
| migration-inventory-final.log | feature OPS-048 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-048 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-048 test area assigned | pass |
| migration-inventory-final.log | feature OPS-048 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-049 name present | pass |
| migration-inventory-final.log | feature OPS-049 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-049 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-049 test area assigned | pass |
| migration-inventory-final.log | feature OPS-049 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-050 name present | pass |
| migration-inventory-final.log | feature OPS-050 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-050 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-050 test area assigned | pass |
| migration-inventory-final.log | feature OPS-050 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-051 name present | pass |
| migration-inventory-final.log | feature OPS-051 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-051 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-051 test area assigned | pass |
| migration-inventory-final.log | feature OPS-051 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-052 name present | pass |
| migration-inventory-final.log | feature OPS-052 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-052 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-052 test area assigned | pass |
| migration-inventory-final.log | feature OPS-052 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-053 name present | pass |
| migration-inventory-final.log | feature OPS-053 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-053 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-053 test area assigned | pass |
| migration-inventory-final.log | feature OPS-053 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-054 name present | pass |
| migration-inventory-final.log | feature OPS-054 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-054 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-054 test area assigned | pass |
| migration-inventory-final.log | feature OPS-054 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-055 name present | pass |
| migration-inventory-final.log | feature OPS-055 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-055 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-055 test area assigned | pass |
| migration-inventory-final.log | feature OPS-055 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-056 name present | pass |
| migration-inventory-final.log | feature OPS-056 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-056 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-056 test area assigned | pass |
| migration-inventory-final.log | feature OPS-056 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-057 name present | pass |
| migration-inventory-final.log | feature OPS-057 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-057 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-057 test area assigned | pass |
| migration-inventory-final.log | feature OPS-057 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-058 name present | pass |
| migration-inventory-final.log | feature OPS-058 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-058 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-058 test area assigned | pass |
| migration-inventory-final.log | feature OPS-058 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-059 name present | pass |
| migration-inventory-final.log | feature OPS-059 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-059 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-059 test area assigned | pass |
| migration-inventory-final.log | feature OPS-059 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-060 name present | pass |
| migration-inventory-final.log | feature OPS-060 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-060 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-060 test area assigned | pass |
| migration-inventory-final.log | feature OPS-060 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-061 name present | pass |
| migration-inventory-final.log | feature OPS-061 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-061 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-061 test area assigned | pass |
| migration-inventory-final.log | feature OPS-061 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-062 name present | pass |
| migration-inventory-final.log | feature OPS-062 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-062 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-062 test area assigned | pass |
| migration-inventory-final.log | feature OPS-062 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-063 name present | pass |
| migration-inventory-final.log | feature OPS-063 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-063 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-063 test area assigned | pass |
| migration-inventory-final.log | feature OPS-063 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-064 name present | pass |
| migration-inventory-final.log | feature OPS-064 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-064 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-064 test area assigned | pass |
| migration-inventory-final.log | feature OPS-064 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-065 name present | pass |
| migration-inventory-final.log | feature OPS-065 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-065 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-065 test area assigned | pass |
| migration-inventory-final.log | feature OPS-065 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-066 name present | pass |
| migration-inventory-final.log | feature OPS-066 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-066 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-066 test area assigned | pass |
| migration-inventory-final.log | feature OPS-066 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-067 name present | pass |
| migration-inventory-final.log | feature OPS-067 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-067 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-067 test area assigned | pass |
| migration-inventory-final.log | feature OPS-067 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-068 name present | pass |
| migration-inventory-final.log | feature OPS-068 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-068 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-068 test area assigned | pass |
| migration-inventory-final.log | feature OPS-068 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-069 name present | pass |
| migration-inventory-final.log | feature OPS-069 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-069 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-069 test area assigned | pass |
| migration-inventory-final.log | feature OPS-069 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-070 name present | pass |
| migration-inventory-final.log | feature OPS-070 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-070 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-070 test area assigned | pass |
| migration-inventory-final.log | feature OPS-070 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-071 name present | pass |
| migration-inventory-final.log | feature OPS-071 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-071 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-071 test area assigned | pass |
| migration-inventory-final.log | feature OPS-071 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-072 name present | pass |
| migration-inventory-final.log | feature OPS-072 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-072 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-072 test area assigned | pass |
| migration-inventory-final.log | feature OPS-072 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-073 name present | pass |
| migration-inventory-final.log | feature OPS-073 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-073 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-073 test area assigned | pass |
| migration-inventory-final.log | feature OPS-073 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-074 name present | pass |
| migration-inventory-final.log | feature OPS-074 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-074 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-074 test area assigned | pass |
| migration-inventory-final.log | feature OPS-074 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-075 name present | pass |
| migration-inventory-final.log | feature OPS-075 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-075 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-075 test area assigned | pass |
| migration-inventory-final.log | feature OPS-075 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-076 name present | pass |
| migration-inventory-final.log | feature OPS-076 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-076 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-076 test area assigned | pass |
| migration-inventory-final.log | feature OPS-076 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-077 name present | pass |
| migration-inventory-final.log | feature OPS-077 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-077 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-077 test area assigned | pass |
| migration-inventory-final.log | feature OPS-077 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-078 name present | pass |
| migration-inventory-final.log | feature OPS-078 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-078 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-078 test area assigned | pass |
| migration-inventory-final.log | feature OPS-078 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-079 name present | pass |
| migration-inventory-final.log | feature OPS-079 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-079 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-079 test area assigned | pass |
| migration-inventory-final.log | feature OPS-079 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-080 name present | pass |
| migration-inventory-final.log | feature OPS-080 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-080 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-080 test area assigned | pass |
| migration-inventory-final.log | feature OPS-080 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-081 name present | pass |
| migration-inventory-final.log | feature OPS-081 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-081 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-081 test area assigned | pass |
| migration-inventory-final.log | feature OPS-081 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-082 name present | pass |
| migration-inventory-final.log | feature OPS-082 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-082 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-082 test area assigned | pass |
| migration-inventory-final.log | feature OPS-082 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-083 name present | pass |
| migration-inventory-final.log | feature OPS-083 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-083 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-083 test area assigned | pass |
| migration-inventory-final.log | feature OPS-083 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-084 name present | pass |
| migration-inventory-final.log | feature OPS-084 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-084 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-084 test area assigned | pass |
| migration-inventory-final.log | feature OPS-084 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-085 name present | pass |
| migration-inventory-final.log | feature OPS-085 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-085 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-085 test area assigned | pass |
| migration-inventory-final.log | feature OPS-085 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-086 name present | pass |
| migration-inventory-final.log | feature OPS-086 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-086 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-086 test area assigned | pass |
| migration-inventory-final.log | feature OPS-086 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-087 name present | pass |
| migration-inventory-final.log | feature OPS-087 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-087 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-087 test area assigned | pass |
| migration-inventory-final.log | feature OPS-087 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-088 name present | pass |
| migration-inventory-final.log | feature OPS-088 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-088 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-088 test area assigned | pass |
| migration-inventory-final.log | feature OPS-088 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-089 name present | pass |
| migration-inventory-final.log | feature OPS-089 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-089 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-089 test area assigned | pass |
| migration-inventory-final.log | feature OPS-089 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-090 name present | pass |
| migration-inventory-final.log | feature OPS-090 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-090 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-090 test area assigned | pass |
| migration-inventory-final.log | feature OPS-090 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-091 name present | pass |
| migration-inventory-final.log | feature OPS-091 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-091 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-091 test area assigned | pass |
| migration-inventory-final.log | feature OPS-091 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-092 name present | pass |
| migration-inventory-final.log | feature OPS-092 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-092 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-092 test area assigned | pass |
| migration-inventory-final.log | feature OPS-092 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-093 name present | pass |
| migration-inventory-final.log | feature OPS-093 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-093 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-093 test area assigned | pass |
| migration-inventory-final.log | feature OPS-093 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-094 name present | pass |
| migration-inventory-final.log | feature OPS-094 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-094 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-094 test area assigned | pass |
| migration-inventory-final.log | feature OPS-094 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-095 name present | pass |
| migration-inventory-final.log | feature OPS-095 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-095 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-095 test area assigned | pass |
| migration-inventory-final.log | feature OPS-095 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-096 name present | pass |
| migration-inventory-final.log | feature OPS-096 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-096 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-096 test area assigned | pass |
| migration-inventory-final.log | feature OPS-096 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-097 name present | pass |
| migration-inventory-final.log | feature OPS-097 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-097 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-097 test area assigned | pass |
| migration-inventory-final.log | feature OPS-097 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-098 name present | pass |
| migration-inventory-final.log | feature OPS-098 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-098 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-098 test area assigned | pass |
| migration-inventory-final.log | feature OPS-098 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-099 name present | pass |
| migration-inventory-final.log | feature OPS-099 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-099 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-099 test area assigned | pass |
| migration-inventory-final.log | feature OPS-099 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-100 name present | pass |
| migration-inventory-final.log | feature OPS-100 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-100 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-100 test area assigned | pass |
| migration-inventory-final.log | feature OPS-100 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-101 name present | pass |
| migration-inventory-final.log | feature OPS-101 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-101 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-101 test area assigned | pass |
| migration-inventory-final.log | feature OPS-101 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-102 name present | pass |
| migration-inventory-final.log | feature OPS-102 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-102 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-102 test area assigned | pass |
| migration-inventory-final.log | feature OPS-102 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-103 name present | pass |
| migration-inventory-final.log | feature OPS-103 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-103 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-103 test area assigned | pass |
| migration-inventory-final.log | feature OPS-103 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-104 name present | pass |
| migration-inventory-final.log | feature OPS-104 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-104 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-104 test area assigned | pass |
| migration-inventory-final.log | feature OPS-104 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-105 name present | pass |
| migration-inventory-final.log | feature OPS-105 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-105 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-105 test area assigned | pass |
| migration-inventory-final.log | feature OPS-105 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-106 name present | pass |
| migration-inventory-final.log | feature OPS-106 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-106 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-106 test area assigned | pass |
| migration-inventory-final.log | feature OPS-106 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-107 name present | pass |
| migration-inventory-final.log | feature OPS-107 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-107 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-107 test area assigned | pass |
| migration-inventory-final.log | feature OPS-107 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-108 name present | pass |
| migration-inventory-final.log | feature OPS-108 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-108 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-108 test area assigned | pass |
| migration-inventory-final.log | feature OPS-108 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-109 name present | pass |
| migration-inventory-final.log | feature OPS-109 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-109 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-109 test area assigned | pass |
| migration-inventory-final.log | feature OPS-109 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-110 name present | pass |
| migration-inventory-final.log | feature OPS-110 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-110 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-110 test area assigned | pass |
| migration-inventory-final.log | feature OPS-110 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-111 name present | pass |
| migration-inventory-final.log | feature OPS-111 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-111 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-111 test area assigned | pass |
| migration-inventory-final.log | feature OPS-111 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-112 name present | pass |
| migration-inventory-final.log | feature OPS-112 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-112 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-112 test area assigned | pass |
| migration-inventory-final.log | feature OPS-112 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-113 name present | pass |
| migration-inventory-final.log | feature OPS-113 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-113 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-113 test area assigned | pass |
| migration-inventory-final.log | feature OPS-113 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-114 name present | pass |
| migration-inventory-final.log | feature OPS-114 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-114 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-114 test area assigned | pass |
| migration-inventory-final.log | feature OPS-114 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-115 name present | pass |
| migration-inventory-final.log | feature OPS-115 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-115 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-115 test area assigned | pass |
| migration-inventory-final.log | feature OPS-115 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-116 name present | pass |
| migration-inventory-final.log | feature OPS-116 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-116 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-116 test area assigned | pass |
| migration-inventory-final.log | feature OPS-116 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-117 name present | pass |
| migration-inventory-final.log | feature OPS-117 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-117 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-117 test area assigned | pass |
| migration-inventory-final.log | feature OPS-117 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-118 name present | pass |
| migration-inventory-final.log | feature OPS-118 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-118 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-118 test area assigned | pass |
| migration-inventory-final.log | feature OPS-118 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-119 name present | pass |
| migration-inventory-final.log | feature OPS-119 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-119 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-119 test area assigned | pass |
| migration-inventory-final.log | feature OPS-119 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-120 name present | pass |
| migration-inventory-final.log | feature OPS-120 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-120 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-120 test area assigned | pass |
| migration-inventory-final.log | feature OPS-120 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-121 name present | pass |
| migration-inventory-final.log | feature OPS-121 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-121 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-121 test area assigned | pass |
| migration-inventory-final.log | feature OPS-121 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-122 name present | pass |
| migration-inventory-final.log | feature OPS-122 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-122 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-122 test area assigned | pass |
| migration-inventory-final.log | feature OPS-122 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-123 name present | pass |
| migration-inventory-final.log | feature OPS-123 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-123 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-123 test area assigned | pass |
| migration-inventory-final.log | feature OPS-123 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-124 name present | pass |
| migration-inventory-final.log | feature OPS-124 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-124 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-124 test area assigned | pass |
| migration-inventory-final.log | feature OPS-124 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-125 name present | pass |
| migration-inventory-final.log | feature OPS-125 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-125 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-125 test area assigned | pass |
| migration-inventory-final.log | feature OPS-125 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-126 name present | pass |
| migration-inventory-final.log | feature OPS-126 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-126 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-126 test area assigned | pass |
| migration-inventory-final.log | feature OPS-126 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-127 name present | pass |
| migration-inventory-final.log | feature OPS-127 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-127 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-127 test area assigned | pass |
| migration-inventory-final.log | feature OPS-127 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-128 name present | pass |
| migration-inventory-final.log | feature OPS-128 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-128 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-128 test area assigned | pass |
| migration-inventory-final.log | feature OPS-128 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-129 name present | pass |
| migration-inventory-final.log | feature OPS-129 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-129 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-129 test area assigned | pass |
| migration-inventory-final.log | feature OPS-129 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-130 name present | pass |
| migration-inventory-final.log | feature OPS-130 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-130 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-130 test area assigned | pass |
| migration-inventory-final.log | feature OPS-130 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-131 name present | pass |
| migration-inventory-final.log | feature OPS-131 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-131 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-131 test area assigned | pass |
| migration-inventory-final.log | feature OPS-131 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-132 name present | pass |
| migration-inventory-final.log | feature OPS-132 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-132 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-132 test area assigned | pass |
| migration-inventory-final.log | feature OPS-132 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-133 name present | pass |
| migration-inventory-final.log | feature OPS-133 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-133 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-133 test area assigned | pass |
| migration-inventory-final.log | feature OPS-133 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-134 name present | pass |
| migration-inventory-final.log | feature OPS-134 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-134 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-134 test area assigned | pass |
| migration-inventory-final.log | feature OPS-134 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-135 name present | pass |
| migration-inventory-final.log | feature OPS-135 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-135 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-135 test area assigned | pass |
| migration-inventory-final.log | feature OPS-135 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-136 name present | pass |
| migration-inventory-final.log | feature OPS-136 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-136 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-136 test area assigned | pass |
| migration-inventory-final.log | feature OPS-136 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-137 name present | pass |
| migration-inventory-final.log | feature OPS-137 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-137 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-137 test area assigned | pass |
| migration-inventory-final.log | feature OPS-137 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-138 name present | pass |
| migration-inventory-final.log | feature OPS-138 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-138 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-138 test area assigned | pass |
| migration-inventory-final.log | feature OPS-138 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-139 name present | pass |
| migration-inventory-final.log | feature OPS-139 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-139 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-139 test area assigned | pass |
| migration-inventory-final.log | feature OPS-139 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-140 name present | pass |
| migration-inventory-final.log | feature OPS-140 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-140 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-140 test area assigned | pass |
| migration-inventory-final.log | feature OPS-140 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-141 name present | pass |
| migration-inventory-final.log | feature OPS-141 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-141 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-141 test area assigned | pass |
| migration-inventory-final.log | feature OPS-141 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-142 name present | pass |
| migration-inventory-final.log | feature OPS-142 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-142 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-142 test area assigned | pass |
| migration-inventory-final.log | feature OPS-142 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-143 name present | pass |
| migration-inventory-final.log | feature OPS-143 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-143 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-143 test area assigned | pass |
| migration-inventory-final.log | feature OPS-143 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-144 name present | pass |
| migration-inventory-final.log | feature OPS-144 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-144 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-144 test area assigned | pass |
| migration-inventory-final.log | feature OPS-144 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-145 name present | pass |
| migration-inventory-final.log | feature OPS-145 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-145 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-145 test area assigned | pass |
| migration-inventory-final.log | feature OPS-145 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-146 name present | pass |
| migration-inventory-final.log | feature OPS-146 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-146 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-146 test area assigned | pass |
| migration-inventory-final.log | feature OPS-146 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-147 name present | pass |
| migration-inventory-final.log | feature OPS-147 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-147 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-147 test area assigned | pass |
| migration-inventory-final.log | feature OPS-147 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-148 name present | pass |
| migration-inventory-final.log | feature OPS-148 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-148 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-148 test area assigned | pass |
| migration-inventory-final.log | feature OPS-148 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-149 name present | pass |
| migration-inventory-final.log | feature OPS-149 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-149 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-149 test area assigned | pass |
| migration-inventory-final.log | feature OPS-149 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-150 name present | pass |
| migration-inventory-final.log | feature OPS-150 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-150 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-150 test area assigned | pass |
| migration-inventory-final.log | feature OPS-150 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-151 name present | pass |
| migration-inventory-final.log | feature OPS-151 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-151 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-151 test area assigned | pass |
| migration-inventory-final.log | feature OPS-151 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-152 name present | pass |
| migration-inventory-final.log | feature OPS-152 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-152 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-152 test area assigned | pass |
| migration-inventory-final.log | feature OPS-152 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-153 name present | pass |
| migration-inventory-final.log | feature OPS-153 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-153 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-153 test area assigned | pass |
| migration-inventory-final.log | feature OPS-153 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-154 name present | pass |
| migration-inventory-final.log | feature OPS-154 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-154 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-154 test area assigned | pass |
| migration-inventory-final.log | feature OPS-154 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-155 name present | pass |
| migration-inventory-final.log | feature OPS-155 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-155 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-155 test area assigned | pass |
| migration-inventory-final.log | feature OPS-155 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-156 name present | pass |
| migration-inventory-final.log | feature OPS-156 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-156 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-156 test area assigned | pass |
| migration-inventory-final.log | feature OPS-156 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-157 name present | pass |
| migration-inventory-final.log | feature OPS-157 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-157 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-157 test area assigned | pass |
| migration-inventory-final.log | feature OPS-157 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-158 name present | pass |
| migration-inventory-final.log | feature OPS-158 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-158 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-158 test area assigned | pass |
| migration-inventory-final.log | feature OPS-158 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-159 name present | pass |
| migration-inventory-final.log | feature OPS-159 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-159 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-159 test area assigned | pass |
| migration-inventory-final.log | feature OPS-159 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-160 name present | pass |
| migration-inventory-final.log | feature OPS-160 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-160 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-160 test area assigned | pass |
| migration-inventory-final.log | feature OPS-160 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-161 name present | pass |
| migration-inventory-final.log | feature OPS-161 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-161 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-161 test area assigned | pass |
| migration-inventory-final.log | feature OPS-161 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-162 name present | pass |
| migration-inventory-final.log | feature OPS-162 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-162 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-162 test area assigned | pass |
| migration-inventory-final.log | feature OPS-162 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-163 name present | pass |
| migration-inventory-final.log | feature OPS-163 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-163 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-163 test area assigned | pass |
| migration-inventory-final.log | feature OPS-163 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-164 name present | pass |
| migration-inventory-final.log | feature OPS-164 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-164 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-164 test area assigned | pass |
| migration-inventory-final.log | feature OPS-164 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-165 name present | pass |
| migration-inventory-final.log | feature OPS-165 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-165 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-165 test area assigned | pass |
| migration-inventory-final.log | feature OPS-165 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-166 name present | pass |
| migration-inventory-final.log | feature OPS-166 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-166 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-166 test area assigned | pass |
| migration-inventory-final.log | feature OPS-166 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-167 name present | pass |
| migration-inventory-final.log | feature OPS-167 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-167 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-167 test area assigned | pass |
| migration-inventory-final.log | feature OPS-167 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-168 name present | pass |
| migration-inventory-final.log | feature OPS-168 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-168 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-168 test area assigned | pass |
| migration-inventory-final.log | feature OPS-168 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-169 name present | pass |
| migration-inventory-final.log | feature OPS-169 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-169 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-169 test area assigned | pass |
| migration-inventory-final.log | feature OPS-169 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-170 name present | pass |
| migration-inventory-final.log | feature OPS-170 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-170 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-170 test area assigned | pass |
| migration-inventory-final.log | feature OPS-170 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-171 name present | pass |
| migration-inventory-final.log | feature OPS-171 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-171 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-171 test area assigned | pass |
| migration-inventory-final.log | feature OPS-171 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-172 name present | pass |
| migration-inventory-final.log | feature OPS-172 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-172 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-172 test area assigned | pass |
| migration-inventory-final.log | feature OPS-172 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-173 name present | pass |
| migration-inventory-final.log | feature OPS-173 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-173 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-173 test area assigned | pass |
| migration-inventory-final.log | feature OPS-173 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-174 name present | pass |
| migration-inventory-final.log | feature OPS-174 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-174 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-174 test area assigned | pass |
| migration-inventory-final.log | feature OPS-174 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-175 name present | pass |
| migration-inventory-final.log | feature OPS-175 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-175 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-175 test area assigned | pass |
| migration-inventory-final.log | feature OPS-175 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-176 name present | pass |
| migration-inventory-final.log | feature OPS-176 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-176 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-176 test area assigned | pass |
| migration-inventory-final.log | feature OPS-176 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-177 name present | pass |
| migration-inventory-final.log | feature OPS-177 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-177 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-177 test area assigned | pass |
| migration-inventory-final.log | feature OPS-177 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-178 name present | pass |
| migration-inventory-final.log | feature OPS-178 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-178 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-178 test area assigned | pass |
| migration-inventory-final.log | feature OPS-178 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-179 name present | pass |
| migration-inventory-final.log | feature OPS-179 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-179 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-179 test area assigned | pass |
| migration-inventory-final.log | feature OPS-179 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-180 name present | pass |
| migration-inventory-final.log | feature OPS-180 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-180 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-180 test area assigned | pass |
| migration-inventory-final.log | feature OPS-180 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-181 name present | pass |
| migration-inventory-final.log | feature OPS-181 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-181 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-181 test area assigned | pass |
| migration-inventory-final.log | feature OPS-181 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-182 name present | pass |
| migration-inventory-final.log | feature OPS-182 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-182 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-182 test area assigned | pass |
| migration-inventory-final.log | feature OPS-182 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-183 name present | pass |
| migration-inventory-final.log | feature OPS-183 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-183 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-183 test area assigned | pass |
| migration-inventory-final.log | feature OPS-183 pass criteria present | pass |
| migration-inventory-final.log | feature OPS-184 name present | pass |
| migration-inventory-final.log | feature OPS-184 UI need 비대상 | pass |
| migration-inventory-final.log | feature OPS-184 test need 필요 | pass |
| migration-inventory-final.log | feature OPS-184 test area assigned | pass |
| migration-inventory-final.log | feature OPS-184 pass criteria present | pass |
| migration-inventory-final.log | feature rows have required matrix columns | pass |
| migration-inventory-final.log | inventory rejects separate test-area labels | pass |
| migration-inventory-final.log | coverage wording separates mapping from execution | pass |
| migration-inventory-final.log | current feature expansion rows exist | pass |
| migration-inventory-final.log | manual UI docs reference inventory | pass |
| migration-inventory-final.log | manual checklist references seed fixture | pass |
| migration-inventory-final.log | manual result template references seed fixture | pass |
| migration-inventory-final.log | VA seed inventory commands select the latest published baseline explicitly | pass |
| migration-inventory-final.log | AGENTS requires individual future feature test rows | pass |
| migration-inventory-final.log | manual UI seed account role admin | pass |
| migration-inventory-final.log | manual UI seed account role operator | pass |
| migration-inventory-final.log | manual UI seed account role viewer | pass |
| migration-inventory-final.log | manual UI seed account role integrator | pass |
| migration-inventory-final.log | manual UI seed profile 9101 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9101 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9102 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9102 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9103 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9103 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9104 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9104 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9105 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9105 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9106 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9106 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed profile 9107 numeric id | pass |
| migration-inventory-final.log | manual UI seed profile 9107 tracking classes present | pass |
| migration-inventory-final.log | manual UI seed event type presence | pass |
| migration-inventory-final.log | manual UI seed event type enter | pass |
| migration-inventory-final.log | manual UI seed event type exit | pass |
| migration-inventory-final.log | manual UI seed event type line-crossing | pass |
| migration-inventory-final.log | manual UI seed event type intrusion-dwell | pass |
| migration-inventory-final.log | manual UI seed event type re-entry | pass |
| migration-inventory-final.log | manual UI seed event type wrong-direction | pass |
| migration-inventory-final.log | manual UI seed event type intrusion-after-line-crossing | pass |
| migration-inventory-final.log | manual UI seed event type loitering | pass |
| migration-inventory-final.log | manual UI seed event type zone-occupancy | pass |
| migration-inventory-final.log | manual UI seed event template 9201 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9201 event type presence | pass |
| migration-inventory-final.log | manual UI seed event template 9201 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9202 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9202 event type enter | pass |
| migration-inventory-final.log | manual UI seed event template 9202 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9203 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9203 event type exit | pass |
| migration-inventory-final.log | manual UI seed event template 9203 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9204 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9204 event type line-crossing | pass |
| migration-inventory-final.log | manual UI seed event template 9204 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9205 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9205 event type line-crossing | pass |
| migration-inventory-final.log | manual UI seed event template 9205 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9206 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9206 event type line-crossing | pass |
| migration-inventory-final.log | manual UI seed event template 9206 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9207 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9207 event type intrusion-dwell | pass |
| migration-inventory-final.log | manual UI seed event template 9207 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9208 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9208 event type re-entry | pass |
| migration-inventory-final.log | manual UI seed event template 9208 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9209 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9209 event type wrong-direction | pass |
| migration-inventory-final.log | manual UI seed event template 9209 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9210 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9210 event type intrusion-after-line-crossing | pass |
| migration-inventory-final.log | manual UI seed event template 9210 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9211 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9211 event type loitering | pass |
| migration-inventory-final.log | manual UI seed event template 9211 profile reference | pass |
| migration-inventory-final.log | manual UI seed event template 9212 numeric id | pass |
| migration-inventory-final.log | manual UI seed event template 9212 event type zone-occupancy | pass |
| migration-inventory-final.log | manual UI seed event template 9212 profile reference | pass |
| migration-inventory-final.log | manual UI seed line direction any | pass |
| migration-inventory-final.log | manual UI seed line direction forward | pass |
| migration-inventory-final.log | manual UI seed line direction reverse | pass |
| migration-inventory-final.log | manual UI seed scenario preset default | pass |
| migration-inventory-final.log | manual UI seed scenario preset road | pass |
| migration-inventory-final.log | manual UI seed scenario preset retail | pass |
| migration-inventory-final.log | manual UI seed scenario preset park | pass |
| migration-inventory-final.log | manual UI seed scenario preset indoor | pass |
| migration-inventory-final.log | manual UI seed scenario preset lobby | pass |
| migration-inventory-final.log | manual UI seed scenario preset platform | pass |
| migration-inventory-final.log | manual UI seed scenario preset entrance | pass |
| migration-inventory-final.log | manual UI seed scenario preset doorway | pass |
| migration-inventory-final.log | manual UI seed scenario preset parking | pass |
| migration-inventory-final.log | manual UI seed scenario preset elevator | pass |
| migration-inventory-final.log | manual UI seed scenario preset custom | pass |
| migration-inventory-final.log | manual UI seed vaRule 9301 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9301 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9301 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9302 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9302 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9302 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9303 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9303 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9303 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9304 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9304 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9304 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9305 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9305 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9305 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9306 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9306 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9306 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9307 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9307 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9307 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9308 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9308 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9308 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9309 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9309 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9309 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9310 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9310 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9310 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9311 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9311 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9311 event template reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9312 numeric id | pass |
| migration-inventory-final.log | manual UI seed vaRule 9312 profile reference | pass |
| migration-inventory-final.log | manual UI seed vaRule 9312 event template reference | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair none/off | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair lite/off | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair kalman-lite/off | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair bytetrack/off | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair lite/assist | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair kalman-lite/assist | pass |
| migration-inventory-final.log | manual UI seed tracker Re-ID pair bytetrack/assist | pass |
| migration-inventory-final.log | manual UI seed invalid policy tracker none Re-ID assist | pass |
| migration-inventory-final.log | manual UI seed final state minimum vaRules | pass |
| migration-inventory-final.log | manual UI VA seed matrix covers required current release cases | pass |
| migration-unit.log | B14-M01 모든 바이트·원본 해시·실패·링크 보존 후 원본 정리 | pass |
| migration-unit.log | B14-M02 기존 목적지 충돌은 쓰기 없이 거부 | pass |
| migration-unit.log | B14-M03 원본 지문 변화와 계획 후 변경은 삭제 전에 거부 | pass |
| migration-unit.log | B14-M04 gzip 원본은 검사 가능한 평문으로 이행 | pass |
| migration-unit.log | B14-M05 JSON 수치·판정·raw 해시 의미는 그대로 유지 | pass |
| migration-unit.log | B14-M06 위험 경로·symlink·잘못된 UTF8를 쓰기 전에 거부 | pass |
| migration-unit.log | B14-M07 외부 URL·역사적 문자열은 불변, 현재 링크만 변경 | pass |
| public-current-final.log | required public docs exist | pass |
| public-current-final.log | tracked denied paths are absent | pass |
| public-current-final.log | tracked release artifacts are bounded | pass |
| public-current-final.log | tracked content has no personal or ephemeral paths | pass |
| public-current-final.log | tracked file sizes stay public-friendly | pass |
| public-current-final.log | tracked media assets are allowlisted | pass |
| public-current-final.log | current tracked content has no high-confidence secrets | pass |
| public-current-final.log | git history has no high-confidence secrets | pass |
| public-current.log | required public docs exist | pass |
| public-current.log | tracked denied paths are absent | pass |
| public-current.log | tracked release artifacts are bounded | pass |
| public-current.log | tracked content has no personal or ephemeral paths: denied content path(s): | fail |
| public-current.log | tracked file sizes stay public-friendly | pass |
| public-current.log | tracked media assets are allowlisted | pass |
| public-current.log | current tracked content has no high-confidence secrets | pass |
| public-current.log | git history has no high-confidence secrets | pass |
| step2-units-final.log | 실제 기록의 slash 없는 temp root는 뒤 문구를 보존한다 | pass |
| step2-units-final.log | 중첩 JSON의 slash 없는 home 값은 뒤 필드까지 삼키지 않는다 | pass |
| step2-units-final.log | home 경로만 정제하고 판정·수치·한글을 유지한다 | pass |
| step2-units-final.log | JSON 값의 space·한글·escaped slash 경계를 깨지 않는다 | pass |
| step2-units-final.log | plain assertion 행에서 temp root 뒤 PASS·숫자를 유지한다 | pass |
| step2-units-final.log | temp root 뒤 공백 path·route·판정 suffix를 문자 그대로 유지한다 | pass |
| step2-units-final.log | 고정 mac temp root가 아닌 애매한 경로는 치환하지 않고 거부한다 | pass |
| step2-units-final.log | 정제는 멱등이고 두 번째 실행의 치환 수는 0이다 | pass |
| step2-units-final.log | policy secret pattern은 원문 없는 고정 코드로 거부한다 | pass |
| step2-units-final.log | 실제 policy의 id·pattern 형식을 지원하고 malformed policy는 고정 코드로 거부한다 | pass |
| step2-units-final.log | 고정 policy 밖 password·token·cookie 문자열은 임의 비밀로 단정하지 않는다 | pass |
| step2-units-final.log | findDeniedContent는 원문 없이 고정 분류만 반환한다 | pass |
| step2-units-final.log | 공개 transcript 경로는 원본 경로 hash로 결정되고 같은 디렉터리를 쓴다 | pass |
| step2-units-final.log | 공개 transcript source의 범위·확장자·모호한 경로를 거부한다 | pass |
| step2-units-final.log | B14-M01 모든 바이트·원본 해시·실패·링크 보존 후 원본 정리 | pass |
| step2-units-final.log | B14-M02 기존 목적지 충돌은 쓰기 없이 거부 | pass |
| step2-units-final.log | B14-M03 원본 지문 변화와 계획 후 변경은 삭제 전에 거부 | pass |
| step2-units-final.log | B14-M04 gzip 원본은 검사 가능한 평문으로 이행 | pass |
| step2-units-final.log | B14-M05 JSON 수치·판정·raw 해시 의미는 그대로 유지 | pass |
| step2-units-final.log | B14-M06 위험 경로·symlink·잘못된 UTF8를 쓰기 전에 거부 | pass |
| step2-units-final.log | B14-M07 외부 URL·역사적 문자열은 불변, 현재 링크만 변경 | pass |
| step2-units-final.log | B14-A01 검토 설정이 없으면 기존 허용 범위를 넓히지 않는다 | pass |
| step2-units-final.log | B14-A02 정확한 path 크기 SHA만 허용하고 같은 폴더 신규 파일은 허용하지 않는다 | pass |
| step2-units-final.log | B14-A03 manifest hash 불일치 거부 | pass |
| step2-units-final.log | B14-A04 이미지 변조와 크기 불일치 거부 | pass |
| step2-units-final.log | B14-A05 범위 밖 경로와 점점 경로 거부 | pass |
| step2-units-final.log | B14-A06 중복 및 count 불일치 거부 | pass |
| step2-units-final.log | B14-A07 미완료 증거의 PASS 승격 거부 | pass |
| step2-units-final.log | B14-A08 이미지 symlink 거부 | pass |
| step2-units-final.log | B14-A09 manifest 탈출 및 잘못된 schema 거부 | pass |
| step2-units.log | 실제 기록의 slash 없는 temp root는 뒤 문구를 보존한다 | pass |
| step2-units.log | home 경로만 정제하고 판정·수치·한글을 유지한다 | pass |
| step2-units.log | JSON 값의 space·한글·escaped slash 경계를 깨지 않는다 | pass |
| step2-units.log | plain assertion 행에서 temp root 뒤 PASS·숫자를 유지한다 | pass |
| step2-units.log | temp root 뒤 공백 path·route·판정 suffix를 문자 그대로 유지한다 | pass |
| step2-units.log | 고정 mac temp root가 아닌 애매한 경로는 치환하지 않고 거부한다 | pass |
| step2-units.log | 정제는 멱등이고 두 번째 실행의 치환 수는 0이다 | pass |
| step2-units.log | policy secret pattern은 원문 없는 고정 코드로 거부한다 | pass |
| step2-units.log | 실제 policy의 id·pattern 형식을 지원하고 malformed policy는 고정 코드로 거부한다 | pass |
| step2-units.log | 고정 policy 밖 password·token·cookie 문자열은 임의 비밀로 단정하지 않는다 | pass |
| step2-units.log | findDeniedContent는 원문 없이 고정 분류만 반환한다 | pass |
| step2-units.log | 공개 transcript 경로는 원본 경로 hash로 결정되고 같은 디렉터리를 쓴다 | pass |
| step2-units.log | 공개 transcript source의 범위·확장자·모호한 경로를 거부한다 | pass |
| step2-units.log | B14-M01 모든 바이트·원본 해시·실패·링크 보존 후 원본 정리 | pass |
| step2-units.log | B14-M02 기존 목적지 충돌은 쓰기 없이 거부 | pass |
| step2-units.log | B14-M03 원본 지문 변화와 계획 후 변경은 삭제 전에 거부 | pass |
| step2-units.log | B14-M04 gzip 원본은 검사 가능한 평문으로 이행 | pass |
| step2-units.log | B14-M05 JSON 수치·판정·raw 해시 의미는 그대로 유지 | pass |
| step2-units.log | B14-M06 위험 경로·symlink·잘못된 UTF8를 쓰기 전에 거부 | pass |
| step2-units.log | B14-M07 외부 URL·역사적 문자열은 불변, 현재 링크만 변경 | pass |
| step2-units.log | B14-A01 검토 설정이 없으면 기존 허용 범위를 넓히지 않는다 | pass |
| step2-units.log | B14-A02 정확한 path 크기 SHA만 허용하고 같은 폴더 신규 파일은 허용하지 않는다 | pass |
| step2-units.log | B14-A03 manifest hash 불일치 거부 | pass |
| step2-units.log | B14-A04 이미지 변조와 크기 불일치 거부 | pass |
| step2-units.log | B14-A05 범위 밖 경로와 점점 경로 거부 | pass |
| step2-units.log | B14-A06 중복 및 count 불일치 거부 | pass |
| step2-units.log | B14-A07 미완료 증거의 PASS 승격 거부 | pass |
| step2-units.log | B14-A08 이미지 symlink 거부 | pass |
| step2-units.log | B14-A09 manifest 탈출 및 잘못된 schema 거부 | pass |
