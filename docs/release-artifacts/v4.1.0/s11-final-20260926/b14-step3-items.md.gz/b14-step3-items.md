# B14 공개 준비 전수 실행 결과

독자: 릴리즈 검토자. 수명: 이번 실행의 역사적 기록. 정책은 AGENTS.md, 결과 source-of-truth는 중앙 테스트 기록이다.
원출력은 b14-step3-results.json.gz에 보존하며 명령 성공과 detector·반례 성공을 구분한다.

| 제목 | 테스트내용 | pass/fail | 비고 |
| --- | --- | --- | --- |
| notice.log:1 | dependency notice is current: THIRD_PARTY_NOTICES.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:1 | required public docs exist | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:2 | tracked denied paths are absent | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:3 | tracked release artifacts are bounded | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:4 | tracked content has no personal or ephemeral paths | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:5 | tracked file sizes stay public-friendly | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:6 | tracked media assets are allowlisted | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:7 | current tracked content has no high-confidence secrets | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| public-history500.log:8 | git history has no high-confidence secrets | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-snapshot.log:1 | dependency snapshot written: ../../../..<B14-owned-root>/dependency.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-snapshot.log:2 | dependency snapshot json written: ../../../..<B14-owned-root>/dependency.json | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:8 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:10 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:12 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:14 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib -> /opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstlibav.dylib (compatibility version 0.0.0, current version 0.0.0) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:16 | ffmpeg-libraries: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib -> /opt/homebrew/opt/ffmpeg/lib/libavcodec.62.dylib (compatibility version 62.0.0, current version 62.11.100) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:18 | ffmpeg-libraries: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib -> /opt/homebrew/opt/ffmpeg/lib/libavfilter.11.dylib (compatibility version 11.0.0, current version 11.4.100) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:20 | ffmpeg-libraries: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib -> /opt/homebrew/opt/ffmpeg/lib/libavformat.62.dylib (compatibility version 62.0.0, current version 62.3.100) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:22 | ffmpeg-libraries: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib -> /opt/homebrew/opt/ffmpeg/lib/libavutil.60.dylib (compatibility version 60.0.0, current version 60.8.100) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:24 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib -> /opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstx264.dylib (compatibility version 0.0.0, current version 0.0.0) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:26 | x264-x265-runtime: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib -> /opt/homebrew/opt/x264/lib/libx264.165.dylib (compatibility version 0.0.0, current version 0.0.0) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:28 | gstreamer-gpl-risk-plugins: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib -> /opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstx265.dylib (compatibility version 0.0.0, current version 0.0.0) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-policy.log:30 | x264-x265-runtime: .media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib -> /opt/homebrew/opt/x265/lib/libx265.215.dylib (compatibility version 215.0.0, current version 215.0.0) | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-red.log:3 | source tree 제외는 로컬 GStreamer cache 이름 한 개만 정확히 추가한다 | FAIL | 사전 정의한 반례 RED; 뒤 GREEN 별도 보존 |
| bundle-boundary-red.log:55 | explicit bundle에서는 source tree 제외를 적용하지 않고 위험 경로 세 개를 검출한다 | PASS | 사전 정의한 반례 RED; 뒤 GREEN 별도 보존 |
| bundle-boundary-red.log:61 | 공개 저장소의 media_server 추적 거부 패턴은 그대로 유지한다 | PASS | 사전 정의한 반례 RED; 뒤 GREEN 별도 보존 |
| bundle-boundary-green.log:3 | source tree 제외는 로컬 GStreamer cache 이름 한 개만 정확히 추가한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-green.log:9 | explicit bundle에서는 source tree 제외를 적용하지 않고 위험 경로 세 개를 검출한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-green.log:15 | 공개 저장소의 media_server 추적 거부 패턴은 그대로 유지한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-final.log:3 | source tree 제외는 로컬 GStreamer cache 이름 한 개만 정확히 추가한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-final.log:9 | explicit bundle에서는 source tree 제외를 적용하지 않고 위험 경로 세 개를 검출한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| bundle-boundary-final.log:15 | 공개 저장소의 media_server 추적 거부 패턴은 그대로 유지한다 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-headless.log:1 | dependency snapshot written: ../../../..<B14-owned-root>/dependency-headless.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-headless.log:2 | dependency snapshot json written: ../../../..<B14-owned-root>/dependency-headless.json | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-final.log:1 | dependency snapshot written: ../../../..<B14-owned-root>/dependency-final.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency-final.log:2 | dependency snapshot json written: ../../../..<B14-owned-root>/dependency-final.json | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-offer.log:1 | source offer checklist written: ../../../..<B14-owned-root>/source-offer.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:9 | blocked risky fixture: binary-ffmpeg-cli -> ffmpeg-cli | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:10 | blocked risky fixture: offline-model-binary -> model-binary | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:11 | blocked risky fixture: container-onnx-runtime-package -> onnx-runtime-package | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:12 | blocked risky fixture: container-gstreamer-gpl-plugin -> gstreamer-gpl-risk-plugins | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:13 | release bundle dry-run workspace prepared <B14-owned-root>/source-only | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:14 | release bundle candidate source-only policy status pass | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:15 | release bundle candidate source-only files scanned 16 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:16 | release bundle candidate source-only path hit count 0 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:17 | release bundle candidate source-only linked hit count 0 | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:18 | release bundle candidate source-only markdown report ../../../..<B14-owned-root>/source-only/bundle-policy-report.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:19 | release bundle candidate source-only json report ../../../..<B14-owned-root>/source-only/bundle-policy-report.json | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:20 | release bundle dry-run markdown summary written <B14-owned-root>/source-only/release-bundle-dry-run-summary.md | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| source-only.log:21 | release bundle dry-run json summary written <B14-owned-root>/source-only/release-bundle-dry-run-summary.json | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:1 | workflow command parity matrix is complete | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:2 | preflight keeps shell/node syntax gates local and CI-visible | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:3 | guardrail workflow publishes source-only release evidence | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:4 | rc workflow keeps longrun gates explicit and artifact-backed | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:5 | server and docs expose CI/local parity verifier | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| ci-parity.log:6 | negative missing workflow command fixture fails | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:1 | dispatch parser recognizes explicit bash and node interpreters | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:2 | server.sh dispatch targets exist and are executable | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:3 | documented server.sh commands resolve to dispatch table | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:4 | tracked scripts are classified and referenced | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:5 | project inventory delegates script file inventory to this verifier | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:6 | project inventory maps verifier families without duplicating dispatch details | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:7 | CMake does not define a separate untracked CTest registry | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:8 | test entry scripts are reachable from test_all | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:9 | auth verifier has no hardcoded test password defaults | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:10 | VA EventRecord dispatch verifier fails early and dispatches every poll by default | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:11 | critical verifier pass output avoids grouped feature-result wording | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| script-inventory.log:12 | user-facing JS option parsers reject unknown options | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:1 | S05 개별 동작 등록 exact 연결 (실행 증거 아님) | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:2 | inventory row count is stable | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:3 | inventory uses only the four approved test areas | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:4 | coverage docs and server command are wired | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:5 | exact implementation evidence manifest is valid | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:6 | all feature IDs have exact coverage targets | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:7 | negative missing-ID fixture fails | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| feature-coverage.log:8 | SAFE-200 canonical coverage wording truthfulness boundary | PASS | 실제 원출력. failed→최종 pass 이력 구분 |
| code-comments.log:1 | 상단 용도 주석 누락 | FAIL | 실제 원출력. failed→최종 pass 이력 구분 |
| dependency.json sqlite3 detector1 | sqlite3: ok; version=3.51.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector1 | gstreamer-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector2 | gstreamer-rtsp-server-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector3 | gstreamer-pbutils-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector4 | gstreamer-app-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector5 | gstreamer-webrtc-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json gstreamer detector6 | gstreamer-sdp-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json libnice detector1 | nice: ok; version=0.1.23 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json cairo-pango detector1 | pangocairo: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json cairo-pango detector2 | cairo: ok; version=1.18.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json cairo-pango detector3 | pango: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json onnxruntime detector1 | libonnxruntime: ok; version=1.25.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json libsodium detector1 | libsodium: ok; version=1.0.21 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json ffmpeg detector1 | ffmpeg: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json ffmpeg detector2 | ffprobe: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json ultralytics-yolo-model asset1 | {"label":"models/yolo11n.onnx","path":"models/yolo11n.onnx","status":"ok","expectedVersion":"Ultralytics assets v8.4.0","source":"https://github.com/ultralytics/assets/releases/download/v8.4.0/yolo11n.onnx","bytes":10930182,"sha256":"634279b40c07c6391472c51ad45b81ebc48706a9a1fe72dd3396322acd0c053b","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json optional-yolo-layout-models asset1 | {"label":"models/yolov5n.onnx","path":"models/yolov5n.onnx","status":"ok","expectedVersion":"Ultralytics YOLOv5 v7.0 release asset","source":"https://github.com/ultralytics/yolov5/releases/download/v7.0/yolov5n.onnx","bytes":3981910,"sha256":"04f0e55c26f58d17145b36045780fe1250d5bd2187543e11568e5141d05b3262","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json optional-yolo-layout-models asset2 | {"label":"models/yolov8n-640x640-end2end.onnx","path":"models/yolov8n-640x640-end2end.onnx","status":"ok","expectedVersion":"YOLOv8 end-to-end ONNX sample","source":"https://github.com/namas191297/yolov8-segmentation-end2end-onnxruntime/raw/main/models/yolov8n-640x640-end2end.onnx","bytes":13869046,"sha256":"d056ca1cf43372d39dc0c30cbb044e0c161988fc72d3d16c17071e220879b7fa","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json coco-labels asset1 | {"label":"models/coco.names","path":"models/coco.names","status":"ok","expectedVersion":"","source":"","bytes":621,"sha256":"bd17f1ee35d5f3c862a4894605855abbb9dda4b0621fdb0ac4c2c8c7bb7e730a","lineCount":80} | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json opencv-python detector1 | cv2: ok; version=4.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json build-and-script-tools detector1 | cmake: ok; version=4.2.3 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json build-and-script-tools detector2 | pkg-config: ok; version=2.5.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json build-and-script-tools detector3 | node: ok; version=24.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json build-and-script-tools detector4 | python3: ok; version=3.14.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json build-and-script-tools detector5 | curl: ok; version=8.7.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json yt-dlp-deno detector1 | yt-dlp: ok; version=2026.03.17 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json yt-dlp-deno detector2 | deno: ok; version=2.7.13 | PASS | 실제 원출력·이전 실패 보존 |
| dependency.json x264enc | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency.json x265enc | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency.json avdec_h264 | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency.json avdec_h265 | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency.json avenc_aac | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-headless.json sqlite3 detector1 | sqlite3: ok; version=3.51.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector1 | gstreamer-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector2 | gstreamer-rtsp-server-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector3 | gstreamer-pbutils-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector4 | gstreamer-app-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector5 | gstreamer-webrtc-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json gstreamer detector6 | gstreamer-sdp-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json libnice detector1 | nice: ok; version=0.1.23 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json cairo-pango detector1 | pangocairo: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json cairo-pango detector2 | cairo: ok; version=1.18.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json cairo-pango detector3 | pango: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json onnxruntime detector1 | libonnxruntime: ok; version=1.25.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json libsodium detector1 | libsodium: ok; version=1.0.21 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json ffmpeg detector1 | ffmpeg: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json ffmpeg detector2 | ffprobe: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json ultralytics-yolo-model asset1 | {"label":"models/yolo11n.onnx","path":"models/yolo11n.onnx","status":"ok","expectedVersion":"Ultralytics assets v8.4.0","source":"https://github.com/ultralytics/assets/releases/download/v8.4.0/yolo11n.onnx","bytes":10930182,"sha256":"634279b40c07c6391472c51ad45b81ebc48706a9a1fe72dd3396322acd0c053b","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json optional-yolo-layout-models asset1 | {"label":"models/yolov5n.onnx","path":"models/yolov5n.onnx","status":"ok","expectedVersion":"Ultralytics YOLOv5 v7.0 release asset","source":"https://github.com/ultralytics/yolov5/releases/download/v7.0/yolov5n.onnx","bytes":3981910,"sha256":"04f0e55c26f58d17145b36045780fe1250d5bd2187543e11568e5141d05b3262","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json optional-yolo-layout-models asset2 | {"label":"models/yolov8n-640x640-end2end.onnx","path":"models/yolov8n-640x640-end2end.onnx","status":"ok","expectedVersion":"YOLOv8 end-to-end ONNX sample","source":"https://github.com/namas191297/yolov8-segmentation-end2end-onnxruntime/raw/main/models/yolov8n-640x640-end2end.onnx","bytes":13869046,"sha256":"d056ca1cf43372d39dc0c30cbb044e0c161988fc72d3d16c17071e220879b7fa","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json coco-labels asset1 | {"label":"models/coco.names","path":"models/coco.names","status":"ok","expectedVersion":"","source":"","bytes":621,"sha256":"bd17f1ee35d5f3c862a4894605855abbb9dda4b0621fdb0ac4c2c8c7bb7e730a","lineCount":80} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json opencv-python detector1 | cv2: ok; version=4.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json build-and-script-tools detector1 | cmake: ok; version=4.2.3 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json build-and-script-tools detector2 | pkg-config: ok; version=2.5.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json build-and-script-tools detector3 | node: ok; version=24.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json build-and-script-tools detector4 | python3: ok; version=3.14.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json build-and-script-tools detector5 | curl: ok; version=8.7.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json yt-dlp-deno detector1 | yt-dlp: ok; version=2026.03.17 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json yt-dlp-deno detector2 | deno: ok; version=2.7.13 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-headless.json x264enc | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-headless.json x265enc | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-headless.json avdec_h264 | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-headless.json avdec_h265 | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-headless.json avenc_aac | status=timeout; plugin=; version=; spawnSync gst-inspect-1.0 ETIMEDOUT | FAIL | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-final.json sqlite3 detector1 | sqlite3: ok; version=3.51.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector1 | gstreamer-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector2 | gstreamer-rtsp-server-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector3 | gstreamer-pbutils-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector4 | gstreamer-app-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector5 | gstreamer-webrtc-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json gstreamer detector6 | gstreamer-sdp-1.0: ok; version=1.28.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json libnice detector1 | nice: ok; version=0.1.23 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json cairo-pango detector1 | pangocairo: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json cairo-pango detector2 | cairo: ok; version=1.18.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json cairo-pango detector3 | pango: ok; version=1.57.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json onnxruntime detector1 | libonnxruntime: ok; version=1.25.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json libsodium detector1 | libsodium: ok; version=1.0.21 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json ffmpeg detector1 | ffmpeg: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json ffmpeg detector2 | ffprobe: ok; version=8.0.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json ultralytics-yolo-model asset1 | {"label":"models/yolo11n.onnx","path":"models/yolo11n.onnx","status":"ok","expectedVersion":"Ultralytics assets v8.4.0","source":"https://github.com/ultralytics/assets/releases/download/v8.4.0/yolo11n.onnx","bytes":10930182,"sha256":"634279b40c07c6391472c51ad45b81ebc48706a9a1fe72dd3396322acd0c053b","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json optional-yolo-layout-models asset1 | {"label":"models/yolov5n.onnx","path":"models/yolov5n.onnx","status":"ok","expectedVersion":"Ultralytics YOLOv5 v7.0 release asset","source":"https://github.com/ultralytics/yolov5/releases/download/v7.0/yolov5n.onnx","bytes":3981910,"sha256":"04f0e55c26f58d17145b36045780fe1250d5bd2187543e11568e5141d05b3262","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json optional-yolo-layout-models asset2 | {"label":"models/yolov8n-640x640-end2end.onnx","path":"models/yolov8n-640x640-end2end.onnx","status":"ok","expectedVersion":"YOLOv8 end-to-end ONNX sample","source":"https://github.com/namas191297/yolov8-segmentation-end2end-onnxruntime/raw/main/models/yolov8n-640x640-end2end.onnx","bytes":13869046,"sha256":"d056ca1cf43372d39dc0c30cbb044e0c161988fc72d3d16c17071e220879b7fa","lineCount":null} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json coco-labels asset1 | {"label":"models/coco.names","path":"models/coco.names","status":"ok","expectedVersion":"","source":"","bytes":621,"sha256":"bd17f1ee35d5f3c862a4894605855abbb9dda4b0621fdb0ac4c2c8c7bb7e730a","lineCount":80} | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json opencv-python detector1 | cv2: ok; version=4.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json build-and-script-tools detector1 | cmake: ok; version=4.2.3 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json build-and-script-tools detector2 | pkg-config: ok; version=2.5.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json build-and-script-tools detector3 | node: ok; version=24.13.0 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json build-and-script-tools detector4 | python3: ok; version=3.14.4 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json build-and-script-tools detector5 | curl: ok; version=8.7.1 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json yt-dlp-deno detector1 | yt-dlp: ok; version=2026.03.17 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json yt-dlp-deno detector2 | deno: ok; version=2.7.13 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final.json x264enc | status=ok; plugin=x264; version=1.28.1;  | PASS | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-final.json x265enc | status=ok; plugin=x265; version=1.28.1;  | PASS | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-final.json avdec_h264 | status=ok; plugin=libav; version=1.28.1;  | PASS | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-final.json avdec_h265 | status=ok; plugin=libav; version=1.28.1;  | PASS | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| dependency-final.json avenc_aac | status=ok; plugin=libav; version=1.28.1;  | PASS | writer exit0와 개별 detector 성공은 다름. 최초2실행 timeout5개; 최종5개 ok |
| step3-public-runs.json notice | ["./server.sh","write-dependency-notice","--check"]; exit=0; elapsedMs=31.094499999999996 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-public-runs.json public-history500 | ["./server.sh","verify-public-repo-readiness","--report","<B14-owned-root>/public-history500.md"]; exit=0; elapsedMs=840351.6317919999 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-runs.json dependency-snapshot | ["./server.sh","dependency-snapshot","--stable","--output","<B14-owned-root>/dependency.md","--json-output","<B14-owned-root>/dependency.json","--no-linked-libs"]; exit=0; elapsedMs=28081.875792000003 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-runs.json bundle-policy | ["./server.sh","verify-bundle-policy","--output","<B14-owned-root>/bundle.md","--json-output","<B14-owned-root>/bundle.json"]; exit=1; elapsedMs=2394.5548750000016 | FAIL | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-final-runs.json bundle-policy-final | ["./server.sh","verify-bundle-policy","--output","<B14-owned-root>/bundle-final.md","--json-output","<B14-owned-root>/bundle-final.json"]; exit=0; elapsedMs=79.64295899999999 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-final-runs.json source-offer | ["./server.sh","source-offer-checklist","--stable","--bundle-policy-report","<B14-owned-root>/bundle-final.json","--output","<B14-owned-root>/source-offer.md"]; exit=0; elapsedMs=385.452333 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-final-runs.json source-only | ["./server.sh","verify-release-bundle-dry-run","--candidate","source-only","--work-dir","<B14-owned-root>/source-only"]; exit=0; elapsedMs=175.77137499999998 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-final-runs.json actions-security | ["./server.sh","verify-actions-security"]; exit=0; elapsedMs=38.11562500000002 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-distribution-final-runs.json ci-parity | ["./server.sh","verify-ci-local-gate-parity"]; exit=0; elapsedMs=39.72149999999999 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-static-runs.json script-inventory | ["./server.sh","verify-script-inventory"]; exit=0; elapsedMs=59911.848833000004 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-static-runs.json feature-coverage | ["./server.sh","verify-feature-inventory-coverage"]; exit=0; elapsedMs=80856.87349999999 | PASS | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| step3-static-runs.json code-comments | ["./server.sh","verify-code-comments"]; exit=1; elapsedMs=251.0793329999724 | FAIL | 명령 실행 판정. dependency writer의 개별 조회 실패는 별도 행 |
| code-comments-final.json | ["./server.sh","verify-code-comments"]; exit=0; elapsedMs=245.687042 | PASS | 실제 원출력·이전 실패 보존 |
| bundle-boundary-final.json | "node --test --test-reporter=tap docs/release-artifacts/v4.1.0/s11-final-20260926/b14-bundle-boundary.test.mjs"; exit=0; elapsedMs=87.555166 | PASS | 실제 원출력·이전 실패 보존 |
| dependency-final-run.json | ["/bin/bash","-c","set -euo pipefail; source \"$1\"; export MEDIA_SERVER_GST_CACHE_DIR=\"$2/dependency-headless\" MEDIA_SERVER_GST_PLUGIN_PROFILE=headless GST_REGISTRY=\"$2/dependency-headless/registry-final.bin\" GST_REGISTRY_1_0=\"$2/dependency-headless/registry-final.bin\" XDG_CACHE_HOME=\"$2/dependency-cache\"; unset GST_DEBUG GST_PLUGIN_PATH GST_PLUGIN_PATH_1_0 GST_PLUGIN_SYSTEM_PATH GST_PLUGIN_SYSTEM_PATH_1_0 MEDIA_SERVER_GST_MANAGED_REGISTRY MEDIA_SERVER_GST_MANAGED_PLUGIN_PATH MEDIA_SERVER_GST_INPUT_PLUGIN_PATH; media_server_apply_homebrew_gst_env; shift 2; exec \"$@\"","b14-dependency-final","scripts/internal/env_common.sh","<B14-owned-root>","./server.sh","dependency-snapshot","--stable","--output","<B14-owned-root>/dependency-final.md","--json-output","<B14-owned-root>/dependency-final.json","--no-linked-libs"]; exit=0; elapsedMs=1747.9196670000001 | PASS | 실제 원출력·이전 실패 보존 |
| code-comments 최초 | 1265파일 중 신규 보조 파일6개 상단 용도 주석 형식 누락; exit1 | FAIL | 6개 주석만 보완 후 최종 exit0 |
| code-comments 최종 | 1265파일·missing headers0·english-only0; exit0 | PASS | 제품·검사 로직 불변 |
| bundle 최초 hit1 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"path","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit2 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"path","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib","line":"","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit3 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"path","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib","line":"","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit4 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"/opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstlibav.dylib (compatibility version 0.0.0, current version 0.0.0)","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit5 | {"ruleId":"ffmpeg-libraries","title":"FFmpeg libav runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"/opt/homebrew/opt/ffmpeg/lib/libavcodec.62.dylib (compatibility version 62.0.0, current version 62.11.100)","reason":"libav*를 bundle하면 FFmpeg LGPL/GPL 의무와 build flag 확인이 필요합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit6 | {"ruleId":"ffmpeg-libraries","title":"FFmpeg libav runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"/opt/homebrew/opt/ffmpeg/lib/libavfilter.11.dylib (compatibility version 11.0.0, current version 11.4.100)","reason":"libav*를 bundle하면 FFmpeg LGPL/GPL 의무와 build flag 확인이 필요합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit7 | {"ruleId":"ffmpeg-libraries","title":"FFmpeg libav runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"/opt/homebrew/opt/ffmpeg/lib/libavformat.62.dylib (compatibility version 62.0.0, current version 62.3.100)","reason":"libav*를 bundle하면 FFmpeg LGPL/GPL 의무와 build flag 확인이 필요합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit8 | {"ruleId":"ffmpeg-libraries","title":"FFmpeg libav runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstlibav.dylib","line":"/opt/homebrew/opt/ffmpeg/lib/libavutil.60.dylib (compatibility version 60.0.0, current version 60.8.100)","reason":"libav*를 bundle하면 FFmpeg LGPL/GPL 의무와 build flag 확인이 필요합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit9 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib","line":"/opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstx264.dylib (compatibility version 0.0.0, current version 0.0.0)","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit10 | {"ruleId":"x264-x265-runtime","title":"x264/x265 runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx264.dylib","line":"/opt/homebrew/opt/x264/lib/libx264.165.dylib (compatibility version 0.0.0, current version 0.0.0)","reason":"x264/x265는 FFmpeg/GStreamer 경유 시 GPL 의무를 만들 수 있어 기본 bundle에서 제외합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit11 | {"ruleId":"gstreamer-gpl-risk-plugins","title":"GStreamer GPL-risk plugin bundle","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib","line":"/opt/homebrew/opt/gstreamer/lib/gstreamer-1.0/libgstx265.dylib (compatibility version 0.0.0, current version 0.0.0)","reason":"gst-libav, x264/x265 plugin, gst-plugins-ugly 계열은 배포자가 license/patent/GPL 영향을 별도 확인해야 합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| bundle 최초 hit12 | {"ruleId":"x264-x265-runtime","title":"x264/x265 runtime library","severity":"block","kind":"linked","file":".media_server.gstreamer/v1-d92853ce03738291feaa55a35ffe575057932db40ba4ea18267fc78150035b43/plugins/0000/libgstx265.dylib","line":"/opt/homebrew/opt/x265/lib/libx265.215.dylib (compatibility version 215.0.0, current version 215.0.0)","reason":"x264/x265는 FFmpeg/GStreamer 경유 시 GPL 의무를 만들 수 있어 기본 bundle에서 제외합니다."} | FAIL | Git 비추적 캐시를 source-tree 배포물로 집계한 경계 오류. 명시 bundle 차단은 유지 |
| 리허설 source-only | files=16; path=0; linked=0 | PASS | 실제 원출력·이전 실패 보존 |
| 위험 후보 binary-ffmpeg-cli | {"fixture":"binary-ffmpeg-cli","status":"blocked","expectedRule":"ffmpeg-cli","hitCount":1} | PASS | 위험 후보가 차단되어야 PASS |
| 위험 후보 offline-model-binary | {"fixture":"offline-model-binary","status":"blocked","expectedRule":"model-binary","hitCount":1} | PASS | 위험 후보가 차단되어야 PASS |
| 위험 후보 container-onnx-runtime-package | {"fixture":"container-onnx-runtime-package","status":"blocked","expectedRule":"onnx-runtime-package","hitCount":1} | PASS | 위험 후보가 차단되어야 PASS |
| 위험 후보 container-gstreamer-gpl-plugin | {"fixture":"container-gstreamer-gpl-plugin","status":"blocked","expectedRule":"gstreamer-gpl-risk-plugins","hitCount":1} | PASS | 위험 후보가 차단되어야 PASS |
