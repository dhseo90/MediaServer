# B15 개별 실행 결과

독자: 릴리즈 검토자. 수명: v4.1.0 cut. 정책은 AGENTS.md이며 실제 원출력은 각 json.gz다.

최초 unit-01의 개별 등록 누락은 원출력 통과와 별도로 완료 증거 무효다. unit-02만 현재 증거로 사용한다. 촬영 명령 exit0과 직접 이미지 PASS는 별개이며 최종20개만 manifest에 결속했다.

| 제목 | 테스트내용 | pass/fail | 비고(실패 후 pass됨 등을 기록) |
| --- | --- | --- | --- |
| b15-capture-syntax | node --check docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs; exit=0; elapsed=29.21ms | pass | 원출력: b15-capture-syntax.json.gz |
| b15-capture-01 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.1Yu4Oj; exit=1; elapsed=17684.720333ms | fail | 원출력: b15-capture-01.json.gz |
| b15-capture-01-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.baAkZC","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-01-9 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-36jK0Y","rootBeforeBytes":5082498,"rootBeforeEntries":433,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":12789,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":49646,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":49647,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":771,"verifierElapsedMs":17548,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01 | ./server.sh verify-v410-entry-baseline; exit=0; elapsed=122.30145800000001ms | pass | 원출력: b15-docs-entry-01.json.gz |
| b15-docs-entry-01-1 | [PASS] VERSION=4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-2 | [PASS] branch context=v4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-3 | [PASS] CMake source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-4 | [PASS] README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-5 | [PASS] README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-6 | [PASS] README live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-7 | [PASS] README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-8 | [PASS] README prior baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-9 | [PASS] README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-10 | [PASS] English README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-11 | [PASS] English README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-12 | [PASS] English README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-13 | [PASS] English README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-14 | [PASS] docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-15 | [PASS] docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-16 | [PASS] docs index release notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-17 | [PASS] English docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-18 | [PASS] English docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-19 | [PASS] versioning policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-20 | [PASS] versioning policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-21 | [PASS] versioning policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-22 | [PASS] release policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-23 | [PASS] release policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-24 | [PASS] release policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-25 | [PASS] public review source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-26 | [PASS] public review local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-27 | [PASS] UI guide release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-28 | [PASS] UI assets source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-29 | [PASS] UI assets release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-30 | [PASS] UI asset manifest source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-31 | [PASS] UI asset manifest release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-32 | [PASS] UI asset manifest published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-33 | [PASS] UI asset verifier published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-34 | [PASS] backlog source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-35 | [PASS] backlog current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-36 | [PASS] backlog release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-37 | [PASS] backlog local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-38 | [PASS] roadmap source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-39 | [PASS] roadmap S00 status | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-40 | [PASS] cut-prior published baseline remains v4.0.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-41 | [PASS] release evidence exists | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-42 | [PASS] research gate dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-43 | [PASS] entry baseline dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-44 | [PASS] release metadata current tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-45 | [PASS] release metadata target tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-entry-01-46 | [PASS] release metadata current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01 | ./server.sh verify-release-metadata; exit=1; elapsed=79.42291700000001ms | fail | 원출력: b15-docs-metadata-01.json.gz |
| b15-docs-metadata-01-1 | [pass] VERSION matches CMake project VERSION | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-2 | [pass] README.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-3 | [pass] README.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-4 | [pass] README.en.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-5 | [pass] README.en.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-6 | [pass] historical v2.9 source-of-truth remains distinct from latest published v2.8 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-7 | [pass] default mode records published metadata verification as external gate | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-8 | [pass] versioning policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-9 | [pass] versioning policy pins semver source fields | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-10 | [pass] release policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-11 | [pass] release policy links the current release note source and preserves historical v4.0 notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-12 | [pass] release policies require future signed tags | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-13 | [pass] development backlog pins current source roadmap and public release boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-14 | [pass] docs index points to backlog as current release source of truth | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-15 | [pass] public entry docs keep release evidence source-of-truth deduped | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-16 | [pass] public review pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-17 | [fail] UI guide pins current release wording: docs/ui-guide.md prior baseline wording drifted | fail | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-01-18 | [pass] UI asset policy pins current source and published baseline wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.1Yu4Oj; exit=1; elapsed=50891.2575ms | fail | 원출력: b15-capture-02.json.gz |
| b15-capture-02-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.PDzO4c","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-9 | {"captured":"ko-ops-rules.png","width":1504,"height":346,"bytes":37866} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-10 | {"captured":"ko-ops-users.png","width":1504,"height":580,"bytes":82504} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-11 | {"captured":"ko-client-dashboard.png","width":1145,"height":473,"bytes":49733} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-12 | {"captured":"ko-client-live.png","width":1680,"height":1119,"bytes":1538621} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-02-13 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-MDyqjk","rootBeforeBytes":5680953,"rootBeforeEntries":436,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":13340,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":49807,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":49808,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":1373,"verifierElapsedMs":50772,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02 | ./server.sh verify-release-metadata; exit=0; elapsed=79.73525ms | pass | 원출력: b15-docs-metadata-02.json.gz |
| b15-docs-metadata-02-1 | [pass] VERSION matches CMake project VERSION | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-2 | [pass] README.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-3 | [pass] README.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-4 | [pass] README.en.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-5 | [pass] README.en.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-6 | [pass] historical v2.9 source-of-truth remains distinct from latest published v2.8 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-7 | [pass] default mode records published metadata verification as external gate | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-8 | [pass] versioning policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-9 | [pass] versioning policy pins semver source fields | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-10 | [pass] release policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-11 | [pass] release policy links the current release note source and preserves historical v4.0 notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-12 | [pass] release policies require future signed tags | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-13 | [pass] development backlog pins current source roadmap and public release boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-14 | [pass] docs index points to backlog as current release source of truth | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-15 | [pass] public entry docs keep release evidence source-of-truth deduped | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-16 | [pass] public review pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-17 | [pass] UI guide pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-metadata-02-18 | [pass] UI asset policy pins current source and published baseline wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.fxSGTG; exit=1; elapsed=11924.051958ms | fail | 원출력: b15-capture-03.json.gz |
| b15-capture-03-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.8WLR4x","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-03-9 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-PcB48I","rootBeforeBytes":5022144,"rootBeforeEntries":434,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":13593,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":50157,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":50158,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":900,"verifierElapsedMs":11800,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-unit-01 | node --test docs/release-artifacts/v4.1.0/s11-final-20260926/b15-metadata.test.mjs; exit=0; elapsed=1090.641625ms | pass | 원출력: b15-metadata-unit-01.json.gz; 개별 사전등록 누락으로 완료 증거 무효 |
| b15-metadata-unit-01-1 | ✔ published metadata는 v4.1.0 list/API/view/tag/landing과 branch HEAD를 모두 확인한다 (591.143917ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-unit-01-2 | ✔ published metadata는 cut 직전 v4.0.0을 현재 target의 외부 증거로 받지 않는다 (385.316667ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.fxSGTG; exit=1; elapsed=51274.640959000004ms | fail | 원출력: b15-capture-04.json.gz |
| b15-capture-04-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.A0c6Cu","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-9 | {"captured":"ko-ops-rules.png","width":1504,"height":491,"bytes":68388} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-10 | {"captured":"ko-ops-users.png","width":1504,"height":580,"bytes":84396} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-11 | {"captured":"ko-client-dashboard.png","width":1145,"height":473,"bytes":49733} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-12 | {"captured":"ko-client-live.png","width":1680,"height":1359,"bytes":1536228} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-13 | {"captured":"en-ops-rules.png","width":1504,"height":508,"bytes":75262} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-14 | {"captured":"en-ops-users.png","width":1504,"height":596,"bytes":84078} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-15 | {"captured":"en-client-dashboard.png","width":1145,"height":473,"bytes":55283} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-04-16 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-Ft6xRq","rootBeforeBytes":5704978,"rootBeforeEntries":438,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":13799,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":50242,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":50243,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":754,"verifierElapsedMs":51156,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-links-01 | ./server.sh verify-docs-links; exit=0; elapsed=188.277792ms | pass | 원출력: b15-docs-links-01.json.gz |
| b15-capture-05 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.ZJW3yz en-ops-users,en-client-live; exit=0; elapsed=16095.899541ms | pass | 원출력: b15-capture-05.json.gz |
| b15-capture-05-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.SMO2ks","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-9 | {"captured":"en-ops-users.png","width":1504,"height":596,"bytes":83342} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-10 | {"captured":"en-client-live.png","width":1680,"height":1359,"bytes":1569859} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-05-11 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-MjxIhz","rootBeforeBytes":5074284,"rootBeforeEntries":434,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":14153,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":50649,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":50650,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":496,"verifierElapsedMs":15971,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.kFOSN8 ko-client-live,en-client-live; exit=0; elapsed=18374.657167ms | pass | 원출력: b15-capture-06.json.gz |
| b15-capture-06-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.6CIxz2","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-9 | {"captured":"ko-client-live.png","width":1547,"height":1032,"bytes":1915694} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-10 | {"captured":"en-client-live.png","width":1547,"height":1032,"bytes":1922843} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-06-11 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-HfnAiQ","rootBeforeBytes":5119563,"rootBeforeEntries":434,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":14389,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":50840,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":50841,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":1014,"verifierElapsedMs":18251,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07 | node docs/release-artifacts/v4.1.0/s11-final-20260926/b15-capture.mjs /private/tmp/media-server-b15.ozWcZx ko-client-live,en-client-live; exit=0; elapsed=18141.614999999998ms | pass | 원출력: b15-capture-07.json.gz |
| b15-capture-07-1 | PASS: LP26-U06-A managed Catalog reopen public timeline and persistent generation unchanged | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-2 | PASS: B06-V02 actual Runtime B seed and fresh reopen preserve authoritative files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-3 | PASS: LP26-U01-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-4 | PASS: LP26-U02-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-5 | PASS: LP26-U03-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-6 | PASS: LP26-U04-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-7 | PASS: LP26-U05-A current managed UI seed oracle | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-8 | [cleanup] {"path":"<owned-temp>/media-server-current-ui-seed.2I7ObI","bytes":11929116,"removed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-9 | {"captured":"ko-client-live.png","width":1547,"height":1032,"bytes":1917843} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-10 | {"captured":"en-client-live.png","width":1547,"height":1032,"bytes":1966077} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-capture-07-11 | [cleanup] PASS {"root":"<owned-temp>/media-server-v410-s06-srBDFM","rootBeforeBytes":5119089,"rootBeforeEntries":434,"rootSymlinksNotFollowed":277,"rootAbsent":true,"process":{"pid":14661,"exitCode":0,"signalCode":null,"graceful":true},"ports":[{"kind":"rtsp","port":51136,"closed":true,"evidence":"ECONNREFUSED"},{"kind":"http","port":51137,"closed":true,"evidence":"ECONNREFUSED"}],"attempted":6,"failureCount":0,"cleanupElapsedMs":1245,"verifierElapsedMs":18014,"uiUdpClosed":true} | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01 | node --test docs/release-artifacts/v4.1.0/s11-final-20260926/b15-assets.test.mjs; exit=0; elapsed=1081.720875ms | pass | 원출력: b15-assets-unit-01.json.gz; 개별 사전등록 누락으로 완료 증거 무효 |
| b15-assets-unit-01-1 | ✔ 최종 directReview 20개 receipt는 현재 이미지와 일치하면 통과한다 (398.252416ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01-2 | ✔ directReview SHA-256 변조를 거부한다 (132.84075ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01-3 | ✔ directReview receipt 누락을 거부한다 (126.348833ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01-4 | ✔ directReview 중복 path를 거부한다 (123.040375ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01-5 | ✔ directReview repository 밖 path를 거부한다 (119.704083ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-01-6 | ✔ receipt hash를 다시 맞춰도 너무 긴 UI 이미지를 거부한다 (122.2865ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02 | node --test docs/release-artifacts/v4.1.0/s11-final-20260926/b15-assets.test.mjs; exit=0; elapsed=813.198416ms | pass | 원출력: b15-assets-unit-02.json.gz |
| b15-assets-unit-02-1 | ✔ 최종 directReview 20개 receipt는 현재 이미지와 일치하면 통과한다 (186.382208ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02-2 | ✔ directReview SHA-256 변조를 거부한다 (112.150709ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02-3 | ✔ directReview receipt 누락을 거부한다 (114.47ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02-4 | ✔ directReview 중복 path를 거부한다 (114.036792ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02-5 | ✔ directReview repository 밖 path를 거부한다 (116.94825ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-unit-02-6 | ✔ receipt hash를 다시 맞춰도 너무 긴 UI 이미지를 거부한다 (113.439875ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-unit-02 | node --test docs/release-artifacts/v4.1.0/s11-final-20260926/b15-metadata.test.mjs; exit=0; elapsed=1006.999209ms | pass | 원출력: b15-metadata-unit-02.json.gz |
| b15-metadata-unit-02-1 | ✔ published metadata는 v4.1.0 list/API/view/tag/landing과 branch HEAD를 모두 확인한다 (572.851791ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-unit-02-2 | ✔ published metadata는 cut 직전 v4.0.0을 현재 target의 외부 증거로 받지 않는다 (377.08125ms) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02 | ./server.sh verify-v410-entry-baseline; exit=0; elapsed=99.185375ms | pass | 원출력: b15-entry-02.json.gz |
| b15-entry-02-1 | [PASS] VERSION=4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-2 | [PASS] branch context=v4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-3 | [PASS] CMake source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-4 | [PASS] README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-5 | [PASS] README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-6 | [PASS] README live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-7 | [PASS] README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-8 | [PASS] README prior baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-9 | [PASS] README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-10 | [PASS] English README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-11 | [PASS] English README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-12 | [PASS] English README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-13 | [PASS] English README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-14 | [PASS] docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-15 | [PASS] docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-16 | [PASS] docs index release notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-17 | [PASS] English docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-18 | [PASS] English docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-19 | [PASS] versioning policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-20 | [PASS] versioning policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-21 | [PASS] versioning policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-22 | [PASS] release policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-23 | [PASS] release policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-24 | [PASS] release policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-25 | [PASS] public review source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-26 | [PASS] public review local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-27 | [PASS] UI guide release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-28 | [PASS] UI assets source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-29 | [PASS] UI assets release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-30 | [PASS] UI asset manifest source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-31 | [PASS] UI asset manifest release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-32 | [PASS] UI asset manifest published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-33 | [PASS] UI asset verifier published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-34 | [PASS] backlog source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-35 | [PASS] backlog current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-36 | [PASS] backlog release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-37 | [PASS] backlog local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-38 | [PASS] roadmap source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-39 | [PASS] roadmap S00 status | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-40 | [PASS] cut-prior published baseline remains v4.0.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-41 | [PASS] release evidence exists | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-42 | [PASS] research gate dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-43 | [PASS] entry baseline dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-44 | [PASS] release metadata current tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-45 | [PASS] release metadata target tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-02-46 | [PASS] release metadata current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03 | ./server.sh verify-release-metadata; exit=0; elapsed=101.137833ms | pass | 원출력: b15-metadata-03.json.gz |
| b15-metadata-03-1 | [pass] VERSION matches CMake project VERSION | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-2 | [pass] README.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-3 | [pass] README.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-4 | [pass] README.en.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-5 | [pass] README.en.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-6 | [pass] historical v2.9 source-of-truth remains distinct from latest published v2.8 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-7 | [pass] default mode records published metadata verification as external gate | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-8 | [pass] versioning policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-9 | [pass] versioning policy pins semver source fields | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-10 | [pass] release policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-11 | [pass] release policy links the current release note source and preserves historical v4.0 notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-12 | [pass] release policies require future signed tags | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-13 | [pass] development backlog pins current source roadmap and public release boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-14 | [pass] docs index points to backlog as current release source of truth | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-15 | [pass] public entry docs keep release evidence source-of-truth deduped | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-16 | [pass] public review pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-17 | [pass] UI guide pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-03-18 | [pass] UI asset policy pins current source and published baseline wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01 | ./server.sh verify-docs-ui-assets; exit=0; elapsed=55.693625ms | pass | 원출력: b15-assets-01.json.gz |
| b15-assets-01-1 | [pass] README uses only representative product UI screenshots | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-2 | [pass] English README uses English UI screenshots | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-3 | [pass] UI guide keeps product screenshots in the shared asset set | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-4 | [pass] docs UI asset policy documents capture rules | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-5 | [pass] managed UI asset manifest stays complete | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-6 | [pass] capture script owns every documented UI asset | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-7 | [pass] docs capture covers current screenshots | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-8 | [pass] representative screenshot docs do not point at stale visual baselines | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-9 | [pass] docs UI asset directory contains managed PNG files | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-assets-01-10 | [pass] VA documentation images keep full video frame bounds | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01 | ./server.sh verify-script-inventory; exit=0; elapsed=59906.103375ms | pass | 원출력: b15-script-inventory-01.json.gz |
| b15-script-inventory-01-1 | [pass] dispatch parser recognizes explicit bash and node interpreters | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-2 | [pass] server.sh dispatch targets exist and are executable | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-3 | [pass] documented server.sh commands resolve to dispatch table | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-4 | [pass] tracked scripts are classified and referenced | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-5 | [pass] project inventory delegates script file inventory to this verifier | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-6 | [pass] project inventory maps verifier families without duplicating dispatch details | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-7 | [pass] CMake does not define a separate untracked CTest registry | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-8 | [pass] test entry scripts are reachable from test_all | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-9 | [pass] auth verifier has no hardcoded test password defaults | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-10 | [pass] VA EventRecord dispatch verifier fails early and dispatches every poll by default | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-11 | [pass] critical verifier pass output avoids grouped feature-result wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-script-inventory-01-12 | [pass] user-facing JS option parsers reject unknown options | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-github-ruleset | gh api repos/dhseo90/MediaServer/rulesets/16171792; exit=0; elapsed=376.88908399999997ms | pass | 원출력: b15-github-ruleset.json.gz |
| b15-feature-coverage-01 | ./server.sh verify-feature-inventory-coverage; exit=1; elapsed=81441.91483299999ms | fail | 원출력: b15-feature-coverage-01.json.gz |
| b15-feature-coverage-01-1 | [pass] S05 개별 동작 등록 exact 연결 (실행 증거 아님) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-2 | [pass] inventory row count is stable | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-3 | [pass] inventory uses only the four approved test areas | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-4 | [pass] coverage docs and server command are wired | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-5 | [fail] exact implementation evidence manifest is valid: UI-019 REVIEW4 verifier file trust binding drift; OPS-041 REVIEW4 verifier file trust binding drift | fail | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-6 | [pass] all feature IDs have exact coverage targets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-7 | [pass] negative missing-ID fixture fails | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-01-8 | [pass] SAFE-200 canonical coverage wording truthfulness boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-github-actions-permissions | gh api repos/dhseo90/MediaServer/actions/permissions/workflow; exit=0; elapsed=349.1075ms | pass | 원출력: b15-github-actions-permissions.json.gz |
| b15-github-repository | gh repo view dhseo90/MediaServer --json nameWithOwner,description,visibility,defaultBranchRef,viewerPermission,repositoryTopics,url; exit=0; elapsed=719.7345ms | pass | 원출력: b15-github-repository.json.gz |
| b15-trust-producer-01 | ./server.sh produce-v390-review4-migration-aware-approvals --write-ledger --prior-audit /private/tmp/media-server-b15-review4.X2KPku/prior-audit.json --prior-approvals /private/tmp/media-server-b15-review4.X2KPku/prior-approvals.json --migration-evidence /private/tmp/media-server-b15-review4.X2KPku/migration-evidence.json --decisions /private/tmp/media-server-b15-review4.X2KPku/independent-decisions.json --review-package /private/tmp/media-server-b15-review4.X2KPku/review-package.json; exit=0; elapsed=79279.870167ms | pass | 원출력: b15-trust-producer-01.json.gz |
| b15-feature-coverage-02 | ./server.sh verify-feature-inventory-coverage; exit=0; elapsed=81500.66608299999ms | pass | 원출력: b15-feature-coverage-02.json.gz |
| b15-feature-coverage-02-1 | [pass] S05 개별 동작 등록 exact 연결 (실행 증거 아님) | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-2 | [pass] inventory row count is stable | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-3 | [pass] inventory uses only the four approved test areas | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-4 | [pass] coverage docs and server command are wired | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-5 | [pass] exact implementation evidence manifest is valid | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-6 | [pass] all feature IDs have exact coverage targets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-7 | [pass] negative missing-ID fixture fails | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-feature-coverage-02-8 | [pass] SAFE-200 canonical coverage wording truthfulness boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-code-comments-01 | ./server.sh verify-code-comments; exit=0; elapsed=257.40099999999995ms | pass | 원출력: b15-verify-code-comments-01.json.gz |
| b15-verify-release-closeout-helper-01 | ./server.sh verify-release-closeout-helper; exit=1; elapsed=154.771916ms | fail | 원출력: b15-verify-release-closeout-helper-01.json.gz |
| b15-verify-release-closeout-helper-01-1 | [pass] release close-out commands are available | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-01-2 | [fail] release docs keep publish gates manual: versioning policy missing snippet: source-only release 기준 tag | fail | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-01-3 | [pass] release visual baseline automation is wired for release workflow | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-01-4 | [pass] dry-run report marks release actions as not executed | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-01-5 | [pass] one-shot close-out gate is ordered and fail-stop | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-01-6 | [pass] one-shot close-out docs keep destructive actions manual | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02 | ./server.sh verify-release-closeout-helper --dry-run; exit=0; elapsed=204.47375ms | pass | 원출력: b15-verify-release-closeout-helper-02.json.gz |
| b15-verify-release-closeout-helper-02-1 | [pass] release close-out commands are available | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02-2 | [pass] release docs keep publish gates manual | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02-3 | [pass] release visual baseline automation is wired for release workflow | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02-4 | [pass] dry-run report marks release actions as not executed | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02-5 | [pass] one-shot close-out gate is ordered and fail-stop | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-release-closeout-helper-02-6 | [pass] one-shot close-out docs keep destructive actions manual | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-actions-security-01 | ./server.sh verify-actions-security; exit=0; elapsed=33.857916ms | pass | 원출력: b15-verify-actions-security-01.json.gz |
| b15-verify-ci-local-gate-parity-01 | ./server.sh verify-ci-local-gate-parity; exit=0; elapsed=34.568708ms | pass | 원출력: b15-verify-ci-local-gate-parity-01.json.gz |
| b15-verify-ci-local-gate-parity-01-1 | [pass] workflow command parity matrix is complete | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-ci-local-gate-parity-01-2 | [pass] preflight keeps shell/node syntax gates local and CI-visible | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-ci-local-gate-parity-01-3 | [pass] guardrail workflow publishes source-only release evidence | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-ci-local-gate-parity-01-4 | [pass] rc workflow keeps longrun gates explicit and artifact-backed | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-ci-local-gate-parity-01-5 | [pass] server and docs expose CI/local parity verifier | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-verify-ci-local-gate-parity-01-6 | [pass] negative missing workflow command fixture fails | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-syntax-shell-01 | bash -n server.sh scripts/internal/verify_v410_entry_baseline.sh; exit=0; elapsed=4.879791000000001ms | pass | 원출력: b15-syntax-shell-01.json.gz |
| b15-verify-v390-review4-feature-semantic-source-approvals-01 | ./server.sh verify-v390-review4-feature-semantic-source-approvals; exit=0; elapsed=19823.200999999997ms | pass | 원출력: b15-verify-v390-review4-feature-semantic-source-approvals-01.json.gz |
| b15-verify-v390-ui-native-exact-cases-01 | ./server.sh verify-v390-ui-native-exact-cases; exit=0; elapsed=1130.705708ms | pass | 원출력: b15-verify-v390-ui-native-exact-cases-01.json.gz |
| b15-metadata-04 | ./server.sh verify-release-metadata; exit=0; elapsed=78.543791ms | pass | 원출력: b15-metadata-04.json.gz |
| b15-metadata-04-1 | [pass] VERSION matches CMake project VERSION | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-2 | [pass] README.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-3 | [pass] README.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-4 | [pass] README.en.md separates release target, cut-prior baseline, and live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-5 | [pass] README.en.md keeps release source-of-truth links lightweight | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-6 | [pass] historical v2.9 source-of-truth remains distinct from latest published v2.8 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-7 | [pass] default mode records published metadata verification as external gate | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-8 | [pass] versioning policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-9 | [pass] versioning policy pins semver source fields | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-10 | [pass] release policy separates source version and published release | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-11 | [pass] release policy links the current release note source and preserves historical v4.0 notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-12 | [pass] release policies require future signed tags | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-13 | [pass] development backlog pins current source roadmap and public release boundary | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-14 | [pass] docs index points to backlog as current release source of truth | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-15 | [pass] public entry docs keep release evidence source-of-truth deduped | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-16 | [pass] public review pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-17 | [pass] UI guide pins current release wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-metadata-04-18 | [pass] UI asset policy pins current source and published baseline wording | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-links-02 | ./server.sh verify-docs-links; exit=1; elapsed=171.85637499999999ms | fail | 원출력: b15-docs-links-02.json.gz |
| b15-docs-links-02-1 | [fail] 문서 로컬 링크/이미지 참조 오류 | fail | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-links-03 | ./server.sh verify-docs-links; exit=0; elapsed=172.047667ms | pass | 원출력: b15-docs-links-03.json.gz |
| b15-public-current-01 | ./server.sh verify-public-repo-readiness --no-history; exit=0; elapsed=1261.857459ms | pass | 원출력: b15-public-current-01.json.gz |
| b15-public-current-01-1 | [pass] required public docs exist | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-2 | [pass] tracked denied paths are absent | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-3 | [pass] tracked release artifacts are bounded | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-4 | [pass] tracked content has no personal or ephemeral paths | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-5 | [pass] tracked file sizes stay public-friendly | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-6 | [pass] tracked media assets are allowlisted | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-01-7 | [pass] current tracked content has no high-confidence secrets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-links-04 | ./server.sh verify-docs-links; exit=0; elapsed=173.07825ms | pass | 원출력: b15-docs-links-04.json.gz |
| b15-entry-03 | ./server.sh verify-v410-entry; exit=1; elapsed=14.679625000000001ms | fail | 원출력: b15-entry-03.json.gz |
| b15-entry-04 | ./server.sh verify-v410-entry-baseline; exit=0; elapsed=97.763291ms | pass | 원출력: b15-entry-04.json.gz |
| b15-entry-04-1 | [PASS] VERSION=4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-2 | [PASS] branch context=v4.1.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-3 | [PASS] CMake source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-4 | [PASS] README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-5 | [PASS] README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-6 | [PASS] README live latest | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-7 | [PASS] README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-8 | [PASS] README prior baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-9 | [PASS] README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-10 | [PASS] English README source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-11 | [PASS] English README current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-12 | [PASS] English README release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-13 | [PASS] English README local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-14 | [PASS] docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-15 | [PASS] docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-16 | [PASS] docs index release notes | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-17 | [PASS] English docs index source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-18 | [PASS] English docs index current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-19 | [PASS] versioning policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-20 | [PASS] versioning policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-21 | [PASS] versioning policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-22 | [PASS] release policy source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-23 | [PASS] release policy current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-24 | [PASS] release policy release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-25 | [PASS] public review source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-26 | [PASS] public review local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-27 | [PASS] UI guide release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-28 | [PASS] UI assets source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-29 | [PASS] UI assets release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-30 | [PASS] UI asset manifest source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-31 | [PASS] UI asset manifest release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-32 | [PASS] UI asset manifest published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-33 | [PASS] UI asset verifier published baseline | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-34 | [PASS] backlog source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-35 | [PASS] backlog current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-36 | [PASS] backlog release target | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-37 | [PASS] backlog local readiness | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-38 | [PASS] roadmap source version | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-39 | [PASS] roadmap S00 status | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-40 | [PASS] cut-prior published baseline remains v4.0.0 | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-41 | [PASS] release evidence exists | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-42 | [PASS] research gate dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-43 | [PASS] entry baseline dispatch | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-44 | [PASS] release metadata current tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-45 | [PASS] release metadata target tag | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-entry-04-46 | [PASS] release metadata current roadmap | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02 | ./server.sh verify-public-repo-readiness --no-history; exit=0; elapsed=1260.147208ms | pass | 원출력: b15-public-current-02.json.gz |
| b15-public-current-02-1 | [pass] required public docs exist | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-2 | [pass] tracked denied paths are absent | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-3 | [pass] tracked release artifacts are bounded | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-4 | [pass] tracked content has no personal or ephemeral paths | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-5 | [pass] tracked file sizes stay public-friendly | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-6 | [pass] tracked media assets are allowlisted | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-current-02-7 | [pass] current tracked content has no high-confidence secrets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01 | ./server.sh verify-public-repo-readiness --max-history 1; exit=0; elapsed=3359.680833ms | pass | 원출력: b15-public-history-01.json.gz |
| b15-public-history-01-1 | [pass] required public docs exist | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-2 | [pass] tracked denied paths are absent | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-3 | [pass] tracked release artifacts are bounded | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-4 | [pass] tracked content has no personal or ephemeral paths | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-5 | [pass] tracked file sizes stay public-friendly | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-6 | [pass] tracked media assets are allowlisted | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-7 | [pass] current tracked content has no high-confidence secrets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-public-history-01-8 | [pass] git history has no high-confidence secrets | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-docs-links-final | ./server.sh verify-docs-links; exit=0; elapsed=170.247666ms | pass | 원출력: b15-docs-links-final.json.gz |
| b15-template-closeout | ./server.sh verify-release-closeout-helper --dry-run; exit=0; elapsed=90.91512499999999ms | pass | 원출력: b15-template-closeout.json.gz |
| b15-template-closeout-1 | [pass] release close-out commands are available | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-closeout-2 | [pass] release docs keep publish gates manual | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-closeout-3 | [pass] release visual baseline automation is wired for release workflow | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-closeout-4 | [pass] dry-run report marks release actions as not executed | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-closeout-5 | [pass] one-shot close-out gate is ordered and fail-stop | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-closeout-6 | [pass] one-shot close-out docs keep destructive actions manual | pass | 명령의 실제 하위 결과. UI 생성 성공을 시각 PASS로 확대하지 않음 |
| b15-template-links | ./server.sh verify-docs-links; exit=0; elapsed=207.81991699999998ms | pass | 원출력: b15-template-links.json.gz |

## 직접 이미지 전수

| 제목 | 테스트내용 | pass/fail | 비고(실패 후 pass됨 등을 기록) |
| --- | --- | --- | --- |
| docs/assets/ui/ops-home.png | 1716×713; 72716B; SHA 746e6a02174ea10806a99c1a981a8f90751e47ca7b922014fce5e74bb958d479; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/ops-channels.png | 1716×1183; 196374B; SHA 95f61669cb3c1117b37f9473d0bc1746fef8ad6522170186f9109031c07d7d30; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/ops-rules.png | 1504×491; 68388B; SHA 85504cc1b46fde47effd2f9c51649d2cf300ab489edefd825b998cb2855558d6; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/ops-rules-preview.png | 1716×1131; 1691100B; SHA 62a2211f9aa86b5ff820a2f96f9fce05161d3fdfb5ced52b695e769fe74cea7e; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/ops-users.png | 1504×580; 84396B; SHA 98e9541c44bd1cc2880cf82f3f9c2403f4b3fa601ff25a952b58145fa7805a05; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/client-live.png | 1547×1032; 1917843B; SHA ce76caa4f88c0531b981c3f4567c5f3b65d133e6c43d3d930824aa549262587b; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/ops-dashboard.png | 1716×771; 97942B; SHA f5d3d478a9bb920e84cc7f92fe9dc4c7e73a5f209ef196988706eb980ec80c84; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/client-dashboard.png | 1145×473; 49733B; SHA 3c8c7255e108df9f910ff76e782de15b6f3a44d2b0051c21a516becc96478492; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/auth-login.png | 700×420; 8252B; SHA a5a85820ba2f00be47cdfe14b895495b327f3a56957b64c641cb0f04974bca3b; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-home.png | 1716×713; 82632B; SHA 1773f339884375f926150419468499edeb641f9c35ce973ea6a0a05f3790c1d0; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-channels.png | 1716×1183; 194615B; SHA 743db6e0632358f18b64b9654546b230761142a7200a8b4cc6d27b13d33c3904; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-rules.png | 1504×508; 75262B; SHA 0ff35536df6d0410e6db00a4d0659dd479f28a2440da5d7d97be5f030b764504; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-rules-preview.png | 1716×1131; 1716687B; SHA 397bca85ca10e48017ece37deee3669a7d32ea46000646ed70dc8c03e5cb1b21; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-users.png | 1504×596; 83342B; SHA 8c97af029a9fb0e5bf0b9a0089ff24fc037e6b5cdfe98cc550cbae2342cd5448; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/client-live.png | 1547×1032; 1966077B; SHA 433ace30958bf87c1a36a91519ea3d6d9e19098e9bb499e536c203d881fbf205; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/ops-dashboard.png | 1716×821; 109817B; SHA fbe2e09d2322564dec5b9ebaa0c77bd3990726f175196645bfd76f088dde8b36; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/client-dashboard.png | 1145×473; 55283B; SHA 104639f67b8113755085f8a77364ce41e66f265b52727f35ee203fd9fa115d95; 직접 이미지 열람 | pass | recaptured; 촬영=2026-09-28; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/ui/en/auth-login.png | 700×420; 8819B; SHA ac3eb618189cfbba2646e06d87cd157e86fb99f0114651e00591882b7a9a1865; 직접 이미지 열람 | pass | retained; 촬영=2026-08-31; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/va-four-scene-overlay-ko.jpg | 1280×720; 863853B; SHA 8ad0e6323b1aa87666fec0d9e6cabc1ae82d693befa35bcfb50c0312a71e08cf; 직접 이미지 열람 | pass | retained; 촬영=과거 정확한 시각 미확인; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |
| docs/assets/va-four-scene-sample.png | 1672×941; 2706249B; SHA cc19eca6b85ce2ea23d413273beec1d72fc7c0a8ce407d0182ac58cfa76fad76; 직접 이미지 열람 | pass | retained; 촬영=과거 정확한 시각 미확인; 검토=2026-09-28. 제품 UI전수 PASS가 아님 |

## 소유 임시자료 정리

| 경로 | 종류 | 삭제 전 크기 | 조치 | 삭제/보존 결과 | 근거 |
| --- | --- | --- | --- | --- | --- |
| <owned-temp>/media-server-b15.1Yu4Oj | 문서 촬영 임시 PNG/기하 영수증 | 1712410 | 선택8개와 원출력·실패/기하 기록 보존 후 삭제 | 부재 확인 | b15-cleanup.json |
| <owned-temp>/media-server-b15.fxSGTG | 문서 촬영 임시 PNG/기하 영수증 | 1959659 | 선택8개와 원출력·실패/기하 기록 보존 후 삭제 | 부재 확인 | b15-cleanup.json |
| <owned-temp>/media-server-b15.ZJW3yz | 문서 촬영 임시 PNG/기하 영수증 | 1655007 | 선택8개와 원출력·실패/기하 기록 보존 후 삭제 | 부재 확인 | b15-cleanup.json |
| <owned-temp>/media-server-b15.kFOSN8 | 문서 촬영 임시 PNG/기하 영수증 | 3839974 | 선택8개와 원출력·실패/기하 기록 보존 후 삭제 | 부재 확인 | b15-cleanup.json |
| <owned-temp>/media-server-b15.ozWcZx | 문서 촬영 임시 PNG/기하 영수증 | 3885691 | 선택8개와 원출력·실패/기하 기록 보존 후 삭제 | 부재 확인 | b15-cleanup.json |
