# User Test Failure Handoff

- suite: ui
- sourceCommit: 9c5b4316b741dbd2cda2d2d4f7b246b51549826f
- sourceBranch: v4.1.0
- sourceWorktreeClean: true
- failureStage: ui-exact-424
- testcaseId: EVT-058
- command: ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424 --http-base http://127.0.0.1:59853 --role-state-map /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/role-state-map.json --server-log /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/media-server.log --runtime-descriptor /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/runtime-descriptor.json --build-path build-gst-onnx/media_server
- exitCode: 1
- error: == v3.9.0 exact native UI runner summary == | - result: FAIL | - executionStatus: canonical-parent-complete-failure-census | - exactCases: 424 | - attempted: 424 | - pass: 423 | - fail: 1 | - notRun: 0 | - unsupported: 0 | - failureCensus: 1 | - uiFulltestPass: false | - summaryPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json
- logPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424.log
- reproductionCommand: ./test_ui.sh
- cleanup: pass

## Later Not Run

- stage:feature-gates — not selected by ui suite
- stage:server-longrun-30 — not selected by ui suite
- stage:ui-fulltest-qualification — not run after ui-exact-424 failure
- stage:longrun-120-decision — not run after ui-exact-424 failure
- stage:server-longrun-120 — not run after ui-exact-424 failure
- stage:final-integrity — not selected by ui suite

Compact JSON: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/test-run-summary.json
Source summary: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/summary.json

