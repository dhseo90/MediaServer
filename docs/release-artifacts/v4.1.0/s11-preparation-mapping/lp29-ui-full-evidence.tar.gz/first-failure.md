# v3.9.0 Acceptance First Failure

schema: media-server.v390-acceptance-first-failure.v1
recordedAt: 2026-09-21T21:13:37.987Z
runId: v390-test-acceptance-20260921204759-41958
sourceCommitSha: 9c5b4316b741dbd2cda2d2d4f7b246b51549826f
failedStage: ui-exact-424
testcaseId: EVT-058
error: == v3.9.0 exact native UI runner summary == | - result: FAIL | - executionStatus: canonical-parent-complete-failure-census | - exactCases: 424 | - attempted: 424 | - pass: 423 | - fail: 1 | - notRun: 0 | - unsupported: 0 | - failureCensus: 1 | - uiFulltestPass: false | - summaryPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json
logPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424.log
failedCommand: ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424 --http-base http://127.0.0.1:59853 --role-state-map /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/role-state-map.json --server-log /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/media-server.log --runtime-descriptor /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/runtime-descriptor.json --build-path build-gst-onnx/media_server
reproductionCommand: ./test_ui.sh
context: == v3.9.0 exact native UI runner summary == | - result: FAIL | - executionStatus: canonical-parent-complete-failure-census | - exactCases: 424 | - attempted: 424 | - pass: 423 | - fail: 1 | - notRun: 0 | - unsupported: 0 | - failureCensus: 1 | - uiFulltestPass: false | - summaryPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json
childFailurePhase: ui-exact-424
childFailureCase: EVT-058
childCleanupStatus: not-recorded

## Diagnostic artifact snapshots

### /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424.log

bytes: 420
sha256: e0d0dd4c36a049336ccb558b8b058a6724f45297f165320cfec50f9fcfafdc45

```text
== v3.9.0 exact native UI runner summary ==
- result: FAIL
- executionStatus: canonical-parent-complete-failure-census
- exactCases: 424
- attempted: 424
- pass: 423
- fail: 1
- notRun: 0
- unsupported: 0
- failureCensus: 1
- uiFulltestPass: false
- summaryPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json
```
