# v3.9.0 Test Acceptance Bundle

schema: media-server.v390-test-acceptance-bundle.v1
result: FAIL
executionMode: actual-ui-only
dryRun: false
sourceCommitSha: 9c5b4316b741dbd2cda2d2d4f7b246b51549826f
sourceBranch: v4.1.0
sourceWorktreeClean: true
failedStage: ui-exact-424
firstFailureCommand: ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424 --http-base http://127.0.0.1:59853 --role-state-map /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/role-state-map.json --server-log /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/media-server.log --runtime-descriptor /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/runtime-descriptor.json --build-path build-gst-onnx/media_server
firstFailureContext: == v3.9.0 exact native UI runner summary == | - result: FAIL | - executionStatus: canonical-parent-complete-failure-census | - exactCases: 424 | - attempted: 424 | - pass: 423 | - fail: 1 | - notRun: 0 | - unsupported: 0 | - failureCensus: 1 | - uiFulltestPass: false | - summaryPath: /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json
reproductionCommand: ./test_ui.sh
automatedAcceptanceStatus: failed
evidenceBoundary: actual automated acceptance is not Codex in-app manual UI fulltest, published metadata, or release-action evidence
exactUiCoverage: 424 attempted / 423 PASS / 1 FAIL / 0 not-run / 0 unsupported / 424 total

| stage | status | command | log/summary |
| --- | --- | --- | --- |
| preflight | PASS | validate actual bundle inputs | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/preflight.log |
| build | PASS | ./server.sh build | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/build.log |
| feature-gates | not-run |  | not selected by ui suite |
| server-longrun-30 | not-run |  | not selected by ui suite |
| ui-environment-bootstrap | PASS | bootstrap acceptance-owned throwaway server/auth roles/Playwright storage-state | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-environment-bootstrap.json |
| ui-exact-424 | FAIL | ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424 --http-base http://127.0.0.1:59853 --role-state-map /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/role-state-map.json --server-log /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/media-server.log --runtime-descriptor /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/runtime-descriptor.json --build-path build-gst-onnx/media_server | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424/summary.json |
| ui-server-cleanup | PASS | stop exact UI throwaway server and verify ports | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-server-cleanup.log |
| ui-fulltest-qualification | not-run |  | not run after ui-exact-424 failure |
| longrun-120-decision | not-run |  | not run after ui-exact-424 failure |
| server-longrun-120 | not-run |  | not run after ui-exact-424 failure |
| cleanup | PASS | validate child cleanup and preserved evidence | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/cleanup.log |
| ui-final-integrity | PASS | validate canonical UI parent/424 children/Policy/current run/source/cleanup | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-final-integrity.json |
| report | PASS | write acceptance summary/report | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/report.log |
| final-integrity | not-run |  | not selected by ui suite |

## Known UI closure blockers

- acceptance-execution-not-pass
- policy-evaluation-schema-mismatch
- policy-validation-not-pass
- policy-source-evidence-schema-mismatch
- policy-evidence-not-eligible
- policy-ui-fulltest-not-pass
- qualified-case-count-not-424
- qualified-case-id-list-not-424
- qualified-case-id-list-has-duplicates
- qualified-case-id-list-not-canonical
- full-suite-not-actual-browser-execution
- requested-exact-case-count-not-424
- full-suite-pass-count-not-424
- full-suite-fail-not-zero
- full-suite-notRun-not-zero
- full-suite-unsupported-not-zero
- full-suite-unapprovedExclusions-not-zero
- full-suite-manualIntervention-not-zero
- policy-source-summary-hash-missing

## Executed command ledger

| stage | id | status | command | exit | log |
| --- | --- | --- | --- | ---: | --- |
| preflight | preflight | PASS | validate actual bundle inputs | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/preflight.log |
| build | build | PASS | ./server.sh build | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/build.log |
| ui-environment-bootstrap | ui-environment-bootstrap | PASS | bootstrap acceptance-owned throwaway server/auth roles/Playwright storage-state | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-environment-bootstrap.log |
| ui-exact-424 | ui-exact-424 | FAIL | ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424 --http-base http://127.0.0.1:59853 --role-state-map /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/role-state-map.json --server-log /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/media-server.log --runtime-descriptor /private/tmp/media-server-lp29-ui.Ti6USB/tmp/media_server_v390_ui-ZtqOLQ/runtime-descriptor.json --build-path build-gst-onnx/media_server | 1 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-exact-424.log |
| ui-server-cleanup | ui-server-cleanup | PASS | stop exact UI throwaway server and verify ports | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-server-cleanup.log |
| cleanup | cleanup | PASS | validate child cleanup and preserved evidence | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/cleanup.log |
| ui-final-integrity | ui-final-integrity | PASS | validate canonical UI parent/424 children/Policy/current run/source/cleanup | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/ui-final-integrity.log |
| report | report | PASS | write acceptance summary/report | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921204759-41958/report.log |
