# v3.9.0 Test Acceptance Bundle

schema: media-server.v390-test-acceptance-bundle.v1
result: PASS
executionMode: actual-ui-only
dryRun: false
sourceCommitSha: 8fa98a9988bcbc55a072736e1d60a01fcb1ad23e
sourceBranch: v4.1.0
sourceWorktreeClean: true
failedStage: (none)
firstFailureCommand: (none)
firstFailureContext: (none)
reproductionCommand: 
automatedAcceptanceStatus: eligible
evidenceBoundary: actual automated acceptance is not Codex in-app manual UI fulltest, published metadata, or release-action evidence
exactUiCoverage: 424 attempted / 424 PASS / 0 FAIL / 0 not-run / 0 unsupported / 424 total

| stage | status | command | log/summary |
| --- | --- | --- | --- |
| preflight | PASS | validate actual bundle inputs | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/preflight.log |
| build | PASS | ./server.sh build | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/build.log |
| feature-gates | not-run |  | not selected by ui suite |
| server-longrun-30 | not-run |  | not selected by ui suite |
| ui-environment-bootstrap | PASS | bootstrap acceptance-owned throwaway server/auth roles/Playwright storage-state | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-environment-bootstrap.json |
| ui-exact-424 | PASS | ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424 --http-base http://127.0.0.1:60422 --role-state-map /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/role-state-map.json --server-log /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/media-server.log --runtime-descriptor /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/runtime-descriptor.json --build-path build-gst-onnx/media_server | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424/summary.json |
| ui-server-cleanup | PASS | stop exact UI throwaway server and verify ports | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-server-cleanup.log |
| ui-fulltest-qualification | PASS | ./server.sh verify-ui-fulltest-evidence-policy-v4 --summary /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424/policy-v4-summary.json --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-fulltest-qualification --require-eligible | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-fulltest-qualification/evaluation.json |
| longrun-120-decision | not-run |  | not selected by ui suite |
| server-longrun-120 | not-run |  | not selected by ui suite |
| cleanup | PASS | validate child cleanup and preserved evidence | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/cleanup.log |
| ui-final-integrity | PASS | validate canonical UI parent/424 children/Policy/current run/source/cleanup | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-final-integrity.json |
| report | PASS | write acceptance summary/report | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/report.log |
| final-integrity | not-run |  | not selected by ui suite |

## Known UI closure blockers

- 없음

## Executed command ledger

| stage | id | status | command | exit | log |
| --- | --- | --- | --- | ---: | --- |
| preflight | preflight | PASS | validate actual bundle inputs | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/preflight.log |
| build | build | PASS | ./server.sh build | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/build.log |
| ui-environment-bootstrap | ui-environment-bootstrap | PASS | bootstrap acceptance-owned throwaway server/auth roles/Playwright storage-state | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-environment-bootstrap.log |
| ui-exact-424 | ui-exact-424 | PASS | ./server.sh run-v390-ui-native-exact-cases --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424 --http-base http://127.0.0.1:60422 --role-state-map /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/role-state-map.json --server-log /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/media-server.log --runtime-descriptor /private/tmp/media-server-lp30-ui.wBzhhT/tmp/media_server_v390_ui-QvAo6u/runtime-descriptor.json --build-path build-gst-onnx/media_server | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424.log |
| ui-server-cleanup | ui-server-cleanup | PASS | stop exact UI throwaway server and verify ports | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-server-cleanup.log |
| ui-fulltest-qualification | ui-fulltest-qualification | PASS | ./server.sh verify-ui-fulltest-evidence-policy-v4 --summary /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-exact-424/policy-v4-summary.json --output-dir /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-fulltest-qualification --require-eligible | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-fulltest-qualification.log |
| cleanup | cleanup | PASS | validate child cleanup and preserved evidence | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/cleanup.log |
| ui-final-integrity | ui-final-integrity | PASS | validate canonical UI parent/424 children/Policy/current run/source/cleanup | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/ui-final-integrity.log |
| report | report | PASS | write acceptance summary/report | 0 | /Users/dhseo/Workspace/mediaServer/.media_server.test/v4.1.0/ui-acceptance-current/runs/v390-test-acceptance-20260921233735-22074/report.log |
