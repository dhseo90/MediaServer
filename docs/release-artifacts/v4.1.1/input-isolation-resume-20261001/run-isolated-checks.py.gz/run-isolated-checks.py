import pathlib,subprocess,json,os,tempfile,hashlib,time,datetime,stat
r=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path.cwd(); protected=pathlib.Path(tempfile.mkdtemp(prefix='v411-protected-recording-'))
(protected/'sentinel').write_text('owned protection fixture\n')
def snapshot(root):
 if not root.exists() and not root.is_symlink():return {'exists':False}
 rows=[]
 def walk(p):
  s=p.lstat();item={'path':str(p.relative_to(root)),'mode':stat.S_IMODE(s.st_mode),'type':stat.S_IFMT(s.st_mode)}
  if p.is_symlink():item['link']=os.readlink(p)
  elif p.is_file():item['sha256']=hashlib.sha256(p.read_bytes()).hexdigest();item['bytes']=s.st_size
  rows.append(item)
  if p.is_dir() and not p.is_symlink():
   for q in sorted(p.iterdir()):walk(q)
 walk(root);return {'exists':True,'entries':rows}
def process_rows():
 p=subprocess.run(['ps','-axo','pid,ppid,comm'],capture_output=True,text=True,check=True)
 rows=[]
 for line in p.stdout.splitlines()[1:]:
  a=line.strip().split(None,2)
  if len(a)==3 and a[0].isdigit():rows.append((int(a[0]),int(a[1]),a[2]))
 return rows
base=repo/'.media_server/recordings';before=snapshot(base);external=snapshot(protected);records=[]
prefixes=['media-server-v390-onvif-atomicity-','media-server-v390-analysis-durable-','media-server-v390-reid-readiness-','media-server-v390-vlm-promotion-']
existing=set(pathlib.Path(tempfile.gettempdir()).iterdir()); failure=None
try:
 for name in ['onvif-source-view-atomicity','analysis-registry-durable-write','vlm-promotion-trust-boundary','reid-readiness-consistency']:
  command=['./server.sh','verify-v390-'+name];started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic();seen={};dirs=set();observed={}
  with (r/(name+'.stdout.log')).open('wb') as out,(r/(name+'.stderr.log')).open('wb') as err:
   child=subprocess.Popen(command,stdout=out,stderr=err,env={**os.environ,'MEDIA_SERVER_RECORDING_STORAGE_ROOT':str(protected),'MEDIA_SERVER_SKIP_BUILD':'1'})
   while child.poll() is None:
    rows=process_rows(); parents={child.pid}
    while True:
     children={pid for pid,ppid,comm in rows if ppid in parents}
     if children<=parents:break
     parents|=children
    for pid,ppid,comm in rows:
     if pid in parents and pathlib.Path(comm).name=='media_server':
      seen[pid]=comm
      if str(pid) not in observed:
       l=subprocess.run(['lsof','-nP','-a','-p',str(pid),'-iTCP','-sTCP:LISTEN'],capture_output=True,text=True)
       if l.stdout:observed[str(pid)]={'exitCode':l.returncode,'listeners':l.stdout}
    for p in pathlib.Path(tempfile.gettempdir()).iterdir():
     if p not in existing and any(p.name.startswith(x) for x in prefixes):dirs.add(p)
    time.sleep(.4)
   code=child.wait()
  remaining=[pid for pid,ppid,comm in process_rows() if pid in seen and comm==seen[pid]]
  after=snapshot(base);protectedAfter=snapshot(protected)
  rec={'command':command,'startedAt':started,'elapsedSeconds':time.monotonic()-begin,'exitCode':code,'observedServerPids':sorted(seen),'listenersDuringRun':observed,'remainingServerPids':remaining,'observedOwnedWorkDirs':[str(p) for p in sorted(dirs)],'remainingOwnedWorkDirs':[str(p) for p in dirs if p.exists()],'defaultBefore':before,'defaultAfter':after,'protectedUnchanged':external==protectedAfter,'defaultUnchanged':before==after}
  records.append(rec);(r/'actual-isolation-checks.json').write_text(json.dumps(records,indent=2)+'\n');print(name,code,'default unchanged',rec['defaultUnchanged'],'protected unchanged',rec['protectedUnchanged'],'remaining',remaining,flush=True)
  if code or remaining or rec['remainingOwnedWorkDirs'] or before!=after or external!=protectedAfter:failure='actual child or isolation failed';break
finally:
 if snapshot(protected)==external:
  (protected/'sentinel').unlink();protected.rmdir()
 (r/'protection-cleanup.json').write_text(json.dumps({'path':str(protected),'absent':not protected.exists(),'failure':failure},indent=2)+'\n')
if failure:raise SystemExit(failure)
