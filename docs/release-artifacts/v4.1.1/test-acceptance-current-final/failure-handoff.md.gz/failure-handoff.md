# User Test Failure Handoff

- suite: release
- sourceCommit: f2547831bef8c2822a2f2ceff2e075e31b4cc989
- sourceBranch: v4.1.1
- sourceWorktreeClean: true
- failureStage: ui-fulltest-qualification
- testcaseId: ui-fulltest-qualification
- command: ./server.sh verify-ui-fulltest-evidence-policy-v4 --summary /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-exact-424/policy-v4-summary.json --output-dir /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-fulltest-qualification --require-eligible
- exitCode: 1
- error: == Policy v4 UI fulltest evidence qualification == | - policySchema: media-server.ui-fulltest-evidence-policy.v4 | - policyValidationResult: FAIL | - currentEvidenceStatus: actual-current-source-evidence | - currentCoverage: {"exactUiTestIds":424,"nativeExecutablePositive":423,"negativeRouteExecutable":1,"unsupported":0,"executedPass":424,"notRun":0} | - evidenceEligibility: eligible | - qualifiedCaseCount: 424 | - uiFulltestPass: true | - reasonCount: 0
- logPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-fulltest-qualification.log
- reproductionCommand: ./test_release.sh
- cleanup: pass

## Later Not Run

- stage:longrun-120-decision — not run after ui-fulltest-qualification failure
- stage:server-longrun-120 — not run after ui-fulltest-qualification failure
- stage:ui-final-integrity — not selected by release suite
- longrun30-delegated-step:longrun30/build
- longrun30-delegated-step:longrun30/external-turn-hard-gate

Compact JSON: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/test-run-summary.json
Source summary: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/summary.json

