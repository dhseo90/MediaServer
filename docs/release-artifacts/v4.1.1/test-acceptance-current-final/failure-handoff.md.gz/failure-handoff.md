# User Test Failure Handoff

- suite: release
- sourceCommit: 0478d1274d3e12cfbe87a138ebdaab9a57ece61a
- sourceBranch: v4.1.1
- sourceWorktreeClean: true
- failureStage: server-longrun-120
- testcaseId: server-longrun-120
- command: ./server.sh verify-v390-server-longrun --duration-minutes 120 --output-dir /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120
- exitCode: 1
- error: [progress] (9/9) report test; remaining=0 | == v3.9.0 server longrun runner summary == | - schema: media-server.v390-server-longrun.v2 | - result: FAIL | - durationMinutes: 120 | - stopOnFirstFail: true | - failedPhase: integrated-smoke | - failedCase: integrated-smoke | - delegatedPhaseLedgerValid: true | - longrunEvidenceStatus: real-duration-failed-no-pass-evidence | - summaryPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/summary.json | - reportPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/report.md
- logPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120.log
- reproductionCommand: ./test_release.sh
- cleanup: pass

## Later Not Run

- stage:ui-final-integrity — not selected by release suite
- longrun30-delegated-step:longrun30/build
- longrun30-delegated-step:longrun30/external-turn-hard-gate
- longrun120-phase:longrun120/soak-case-loop — delegated projection parent=soak-case-loop; status=not-run
- longrun120-phase:longrun120/runtime-idle — delegated projection parent=runtime-idle; status=not-run
- longrun120-phase:longrun120/runtime-idle
- longrun120-delegated-step:longrun120/build
- longrun120-delegated-step:longrun120/external-turn-hard-gate
- longrun120-delegated-step:longrun120/soak-case-loop
- longrun120-delegated-step:longrun120/main-runtime-idle
- longrun120-delegated-step:longrun120/server-start-queue-2
- longrun120-delegated-step:longrun120/event-post-queue
- longrun120-delegated-step:longrun120/queue-runtime-idle

Compact JSON: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/test-run-summary.json
Source summary: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/summary.json

