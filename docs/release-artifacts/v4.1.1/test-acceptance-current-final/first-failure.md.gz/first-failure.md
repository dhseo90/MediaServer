# v3.9.0 Acceptance First Failure

schema: media-server.v390-acceptance-first-failure.v1
recordedAt: 2026-10-01T10:40:45.675Z
runId: v390-test-acceptance-20261001092828-23548
sourceCommitSha: f2547831bef8c2822a2f2ceff2e075e31b4cc989
failedStage: ui-fulltest-qualification
testcaseId: ui-fulltest-qualification
error: == Policy v4 UI fulltest evidence qualification == | - policySchema: media-server.ui-fulltest-evidence-policy.v4 | - policyValidationResult: FAIL | - currentEvidenceStatus: actual-current-source-evidence | - currentCoverage: {"exactUiTestIds":424,"nativeExecutablePositive":423,"negativeRouteExecutable":1,"unsupported":0,"executedPass":424,"notRun":0} | - evidenceEligibility: eligible | - qualifiedCaseCount: 424 | - uiFulltestPass: true | - reasonCount: 0
logPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-fulltest-qualification.log
failedCommand: ./server.sh verify-ui-fulltest-evidence-policy-v4 --summary /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-exact-424/policy-v4-summary.json --output-dir /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-fulltest-qualification --require-eligible
reproductionCommand: ./test_release.sh
context: == Policy v4 UI fulltest evidence qualification == | - policySchema: media-server.ui-fulltest-evidence-policy.v4 | - policyValidationResult: FAIL | - currentEvidenceStatus: actual-current-source-evidence | - currentCoverage: {"exactUiTestIds":424,"nativeExecutablePositive":423,"negativeRouteExecutable":1,"unsupported":0,"executedPass":424,"notRun":0} | - evidenceEligibility: eligible | - qualifiedCaseCount: 424 | - uiFulltestPass: true | - reasonCount: 0
childFailurePhase: not-recorded
childFailureCase: not-recorded
childCleanupStatus: not-recorded

## Diagnostic artifact snapshots

### /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001092828-23548/ui-fulltest-qualification.log

bytes: 443
sha256: 2702ad952ca61c3249fa8f0d42be3824031684e8b7ddda09bf52785896e10617

```text
== Policy v4 UI fulltest evidence qualification ==
- policySchema: media-server.ui-fulltest-evidence-policy.v4
- policyValidationResult: FAIL
- currentEvidenceStatus: actual-current-source-evidence
- currentCoverage: {"exactUiTestIds":424,"nativeExecutablePositive":423,"negativeRouteExecutable":1,"unsupported":0,"executedPass":424,"notRun":0}
- evidenceEligibility: eligible
- qualifiedCaseCount: 424
- uiFulltestPass: true
- reasonCount: 0
```
