# v3.9.0 Acceptance First Failure

schema: media-server.v390-acceptance-first-failure.v1
recordedAt: 2026-10-01T12:31:56.927Z
runId: v390-test-acceptance-20261001111221-4624
sourceCommitSha: 0478d1274d3e12cfbe87a138ebdaab9a57ece61a
failedStage: server-longrun-120
testcaseId: server-longrun-120
error: [progress] (9/9) report test; remaining=0 | == v3.9.0 server longrun runner summary == | - schema: media-server.v390-server-longrun.v2 | - result: FAIL | - durationMinutes: 120 | - stopOnFirstFail: true | - failedPhase: integrated-smoke | - failedCase: integrated-smoke | - delegatedPhaseLedgerValid: true | - longrunEvidenceStatus: real-duration-failed-no-pass-evidence | - summaryPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/summary.json | - reportPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/report.md
logPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120.log
failedCommand: ./server.sh verify-v390-server-longrun --duration-minutes 120 --output-dir /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120
reproductionCommand: ./test_release.sh
context: [progress] (9/9) report test; remaining=0 | == v3.9.0 server longrun runner summary == | - schema: media-server.v390-server-longrun.v2 | - result: FAIL | - durationMinutes: 120 | - stopOnFirstFail: true | - failedPhase: integrated-smoke | - failedCase: integrated-smoke | - delegatedPhaseLedgerValid: true | - longrunEvidenceStatus: real-duration-failed-no-pass-evidence | - summaryPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/summary.json | - reportPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/report.md
childFailurePhase: not-recorded
childFailureCase: not-recorded
childCleanupStatus: not-recorded

## Diagnostic artifact snapshots

### /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120.log

bytes: 8454
sha256: 90e26aea4360f6358df4c703006d8213350cbed6dc42db34fbec838b819d130e

```text
[progress] (1/9) preflight test; remaining=8
[progress] (2/9) build test; remaining=7
[env] local override skipped
[1/2] configure: /Users/dhseo/Workspace/mediaServer/build-gst-onnx (ai=1, youtube=0)
-- Configuring done (0.1s)
-- Generating done (0.0s)
-- Build files have been written to: /Users/dhseo/Workspace/mediaServer/build-gst-onnx
[2/2] build
[ 98%] Built target media_server_runtime
[100%] Built target media_server
[done] build=/Users/dhseo/Workspace/mediaServer/build-gst-onnx/media_server
[progress] (3/9) seed test; remaining=6
[progress] (4/9) start-server test; remaining=5
[progress] (4/9) start-server test; remaining=5
[progress] (5/9) integrated-smoke test; remaining=4
[progress] (5/9) integrated-smoke test; remaining=4
[progress] (6/9) soak-case-loop test; remaining=3
[info] Codex 인앱 브라우저 환경: predev integrated smoke의 Chrome Rule UI 자동화를 제외하고, UI 풀테스트는 인앱 브라우저 evidence로 분리합니다.
[skip] build: --skip-build
[info] server 시작: rtsp=51414 http=51413 eventPostQueue=256 authMode=off
[pass] server 시작 pid=81391
[info] integrated-smoke 시작
[info] integrated-smoke 진행 중 (30s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [8] 실행환경 진단
[info] integrated-smoke 진행 중 (60s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [9] codec matrix: file H264/AAC -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (90s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [10] codec matrix: file H265/AAC -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (120s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [11] codec matrix: local RTSP H265/Opus -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (150s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [11] codec matrix: local RTSP H265/Opus -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (180s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [11] codec matrix: local RTSP H265/Opus -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (210s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [12] codec matrix: local RTSP H264/PCMU -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (240s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [12] codec matrix: local RTSP H264/PCMU -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (270s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [12] codec matrix: local RTSP H264/PCMU -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (301s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [13] codec matrix: local RTSP H264/PCMA -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (331s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [13] codec matrix: local RTSP H264/PCMA -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (361s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [13] codec matrix: local RTSP H264/PCMA -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (391s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [14] codec matrix: local WHIP publish -> RTSP/WebRTC
[info] integrated-smoke 진행 중 (421s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[stdout-tail]
[stdout-tail] == [15] codec matrix: local HTTP URI H264/AAC -> RTSP/WebRTC
[fail] integrated-smoke (428s) log=/tmp/media_server_predev-1790857474-81372/integrated_smoke.log
[first-fail] context: case=integrated-smoke; rtspPort=51414; httpPort=51413; httpBase=http://127.0.0.1:51413; authMode=off; workDir=/tmp/media_server_predev-1790857474-81372
[first-fail] stderr:
(empty)
[first-fail] reproduce: MEDIA_SERVER_LISTEN_PORT=51414 MEDIA_SERVER_HTTP_LISTEN_PORT=51413 MEDIA_SERVER_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_HTTP_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_SKIP_LOCAL_ENV=1 MEDIA_SERVER_AUTH_MODE=off ./server.sh test --no-start --fail-fast --skip-external --include-rules  --include-va-events --include-image-analysis --include-redaction
[not-run] external-turn-hard-gate: first failure=integrated-smoke
[not-run] soak-case-loop: first failure=integrated-smoke
[not-run] main-runtime-idle: first failure=integrated-smoke
[not-run] server-start-queue-2: first failure=integrated-smoke
[not-run] event-post-queue: first failure=integrated-smoke
[not-run] queue-runtime-idle: first failure=integrated-smoke
[pass] ports-clean
[info] predev summary=/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json
[info] summary-report 시작
[pass] summary-report (1s)
[info] predev summary=/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json
[info] summary-report refreshed log=/tmp/media_server_predev-1790857474-81372/summary_report_refresh.log
[info] predev summary=/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json
== predev 안정화 검증 요약 ==
- 통과: 3
- 실패: 1
- 건너뜀: 1
- summary: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json
- report: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.md
- report html: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.html
- logs: /tmp/media_server_predev-1790857474-81372
[first-fail] phase: soak-case-loop
[first-fail] case: integrated-smoke
[first-fail] context: case=integrated-smoke; rtspPort=51414; httpPort=51413; httpBase=http://127.0.0.1:51413; authMode=off; workDir=/tmp/media_server_predev-1790857474-81372
[first-fail] stderr: (empty)
[first-fail] reproduce: MEDIA_SERVER_LISTEN_PORT=51414 MEDIA_SERVER_HTTP_LISTEN_PORT=51413 MEDIA_SERVER_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_HTTP_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_SKIP_LOCAL_ENV=1 MEDIA_SERVER_AUTH_MODE=off ./server.sh test --no-start --fail-fast --skip-external --include-rules  --include-va-events --include-image-analysis --include-redaction
[first-fail] phase: integrated-smoke
[first-fail] case: integrated-smoke
[first-fail] context: case=integrated-smoke; rtspPort=51414; httpPort=51413; httpBase=http://127.0.0.1:51413; authMode=off; workDir=/tmp/media_server_predev-1790857474-81372
[first-fail] stderr: (empty)
[first-fail] reproduce: MEDIA_SERVER_LISTEN_PORT=51414 MEDIA_SERVER_HTTP_LISTEN_PORT=51413 MEDIA_SERVER_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_HTTP_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_SKIP_LOCAL_ENV=1 MEDIA_SERVER_AUTH_MODE=off ./server.sh test --no-start --fail-fast --skip-external --include-rules  --include-va-events --include-image-analysis --include-redaction
[progress] (7/9) runtime-idle not-run; remaining=2
[progress] (8/9) cleanup test; remaining=1
[progress] (9/9) report test; remaining=0
== v3.9.0 server longrun runner summary ==
- schema: media-server.v390-server-longrun.v2
- result: FAIL
- durationMinutes: 120
- stopOnFirstFail: true
- failedPhase: integrated-smoke
- failedCase: integrated-smoke
- delegatedPhaseLedgerValid: true
- longrunEvidenceStatus: real-duration-failed-no-pass-evidence
- summaryPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/summary.json
- reportPath: /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/report.md
```
