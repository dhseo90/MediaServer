# Policy v4 UI Fulltest Evidence Evaluation

- policy validation: FAIL
- current evidence: actual-current-source-evidence
- eligibility: eligible
- qualified case count: 424
- UI fulltest PASS: true
- boundary: policy-verifier-pass-is-not-ui-fulltest-pass

## Reasons

