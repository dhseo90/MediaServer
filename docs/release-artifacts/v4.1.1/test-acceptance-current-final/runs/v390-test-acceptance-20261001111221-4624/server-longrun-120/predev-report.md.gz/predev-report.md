# MediaServer 검증 요약

| 파일 | 유형 | 상태 | pass | fail | skip | 핵심 detail |
| --- | --- | --- | ---: | ---: | ---: | --- |
| /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json | predev | fail | 3 | 1 | 1 | durationSec=432 steps=11 failed=integrated-smoke skipped=build |

## 상세

### predev-summary.json

- durationSec: `432`
- soakMinutes: `120`
- step `build`: `skip` duration=`0.0` log=``
- step `server-start-queue-256`: `pass` duration=`0.0` log=`/tmp/media_server_predev-1790857474-81372/server.log`
- step `integrated-smoke`: `fail` duration=`428.0` log=`/tmp/media_server_predev-1790857474-81372/integrated_smoke.log`
- step `external-turn-hard-gate`: `not-run` duration=`0.0` log=``
- step `soak-case-loop`: `not-run` duration=`0.0` log=``
- step `main-runtime-idle`: `not-run` duration=`0.0` log=``
- step `server-start-queue-2`: `not-run` duration=`0.0` log=``
- step `event-post-queue`: `not-run` duration=`0.0` log=``
- step `queue-runtime-idle`: `not-run` duration=`0.0` log=``
- step `ports-clean`: `pass` duration=`0.0` log=`/tmp/media_server_predev-1790857474-81372/ports-clean.log`
- step `summary-report`: `pass` duration=`1.0` log=`/tmp/media_server_predev-1790857474-81372/summary_report.log`
