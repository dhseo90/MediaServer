# v3.9.0 Server Longrun Runner Report

schema: media-server.v390-server-longrun.v2
result: FAIL
durationMinutes: 120
durationClockSource: process.hrtime.bigint-monotonic
durationStartedMonotonicNs: 164708404354458
durationEndedMonotonicNs: 165142796180208
durationElapsedSeconds: 434.39182575
durationEligible: false
iterationLedgerValid: false
iterationCount: 0
stopOnFirstFail: true
failedPhase: integrated-smoke
failedCase: integrated-smoke
delegatedFailure: integrated-smoke
delegatedFirstFailContractSatisfied: true
delegatedPhaseLedgerSchema: media-server.v390-delegated-phase-ledger.v1
delegatedPhaseLedgerValid: true
delegatedPhaseLedgerCount: 11/11
delegatedPhaseLedgerDuplicates: (none)
delegatedPhaseLedgerErrors: (none)
failureContext: case=integrated-smoke; rtspPort=51414; httpPort=51413; httpBase=http://127.0.0.1:51413; authMode=off; workDir=/tmp/media_server_predev-1790857474-81372
stderrTail: (none)
reproductionCommand: MEDIA_SERVER_LISTEN_PORT=51414 MEDIA_SERVER_HTTP_LISTEN_PORT=51413 MEDIA_SERVER_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_HTTP_LISTEN_ADDRESS=127.0.0.1 MEDIA_SERVER_SKIP_LOCAL_ENV=1 MEDIA_SERVER_AUTH_MODE=off ./server.sh test --no-start --fail-fast --skip-external --include-rules  --include-va-events --include-image-analysis --include-redaction
realDurationEvidence: false
longrunEvidenceStatus: real-duration-failed-no-pass-evidence
cleanupVerificationSource: pid-port-artifact-before-after-observation
cleanupArtifactBytes: /tmp/media_server_predev-1790857474-81372:122317->0

| phase | status | command | log |
| --- | --- | --- | --- |
| preflight | PASS | validate duration/output-dir/tools | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/preflight.log |
| build | PASS | ./server.sh build | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/build.log |
| seed | PASS | write /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/seed.json | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/seed.log |
| start-server | PASS | ./server.sh verify-predev --soak-minutes 120 --skip-build --fail-fast --summary-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json --report-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.md --report-html-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.html | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/soak-case-loop.log |
| integrated-smoke | FAIL | ./server.sh verify-predev --soak-minutes 120 --skip-build --fail-fast --summary-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-summary.json --report-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.md --report-html-file /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/predev-report.html | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/soak-case-loop.log |
| soak-case-loop | not-run |  |  |
| runtime-idle | not-run |  |  |
| runtime-idle | not-run |  |  |
| cleanup | PASS | measured cleanup phase | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/cleanup.log |
| report | PASS | report phase | /Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.1.1/test-acceptance-current-final/runs/v390-test-acceptance-20261001111221-4624/server-longrun-120/report.log |

| delegated parent phase | valid | observed/expected | observed case IDs | errors |
| --- | --- | ---: | --- | --- |
| start-server | true | 1/1 | server-start-queue-256 |  |
| integrated-smoke | true | 1/1 | integrated-smoke |  |
| soak-case-loop | true | 1/1 | soak-case-loop |  |
| runtime-idle | true | 4/4 | main-runtime-idle,server-start-queue-2,event-post-queue,queue-runtime-idle |  |
