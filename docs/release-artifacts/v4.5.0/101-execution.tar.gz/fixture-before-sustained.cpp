// 파일 용도: R101 source-bound generation의 실제 자료량/검색/배경 작업 경합.
// 기존 R98 입력 생성과 R99 FinalizeBound 준비 경계를 재사용한다.
#define main managed_fixture_main
#include "recording_managed_writer_smoke.cpp"
#undef main
#include "recording_writer_test_isolation.h"
#include "ingress/recording_application_service.h"
#include "recording/recording_visual_source.h"
#include <future>
#include <thread>
#include <sys/resource.h>
namespace {
using VS=ingress::VisualSearchApplicationService;
using Clock=std::chrono::steady_clock;
void Need101(bool ok,const std::string& why){if(!ok)throw std::runtime_error(why);}
void Ready101(VS& service,const VS::Authorize& auth){
 const auto end=Clock::now()+std::chrono::seconds(180);std::string status;
 do{status=service.Status(auth).body;if(status.find("\"searchAvailable\":true")!=std::string::npos){std::cout<<"[R101-ready] "<<status<<std::endl;return;}std::this_thread::sleep_for(std::chrono::milliseconds(20));}while(Clock::now()<end);
 throw std::runtime_error("index-not-ready:"+status);
}
}
int main(int argc,char** argv){
 if(argc!=5)return 2;
 const std::filesystem::path root(argv[1]);if(!RecordingWriterTestIsolation(root)){std::cerr<<"isolation-rejected\n";return 2;}
 try{
 gst_init(nullptr,nullptr);using namespace recording;std::string error;const std::string scale=argv[3],mode=argv[4];
 Need101(scale=="4"||scale=="53"||scale=="cycle","scale");Need101(mode=="single"||mode=="parallel"||mode=="background","mode");
 RecordingResourceTrace trace("1");RecordingRuntimeStorage runtime(root/"recording");Need101(runtime.Open(&error),"open:"+error);auto& catalog=runtime.catalog();Need101(trace.Bind(catalog.SearchResidency(),catalog.ScratchResidency()),"trace-bind");
 auto input=MixedInput(root);input.packets.resize(60);
 for(auto& p:input.packets){auto& o=*p.observation;o.clock_process_id="r101-clock";o.mono_before_ns=1000000000+p.pts;o.mono_after_ns=o.mono_before_ns+1000;o.observed_utc_ns=1789200000000000000LL+p.pts;}
 const auto write=[&](const std::string& channel,GStreamerSegmentWriter::Options options){GStreamerSegmentWriter writer(options);Need101(writer.Start(channel,"unused",input.descriptor,[](auto,auto,auto*){return false;},&error),"writer-start:"+error);for(const auto& p:input.packets)writer.Push(p,0);writer.Stop();};
 constexpr std::uint64_t Q=87ULL*1024*1024,E=64ULL*1024*1024;std::uint64_t count=0;
 for(const auto& channel:{"9101","9201"}){
  write(channel,runtime.WriterOptions(2000));auto list=catalog.RetentionSnapshot();auto found=std::find_if(list.candidates.begin(),list.candidates.end(),[&](const auto& x){return x.Channel()==channel;});Need101(found!=list.candidates.end()&&found->segment_v2.has_value(),"template");
  const auto seed=*found->segment_v2;const auto file=found->media_path;auto binding=catalog.FindSourceBinding(seed.segment_id);Need101(binding&&binding->file_evidence&&seed.size_bytes>0&&seed.size_bytes<=36*1024,"template-bound");
  count=scale=="cycle"?(Q-E)/seed.size_bytes+2:std::stoul(scale);Need101(count<=2048,"count-cap");
  for(std::uint64_t i=1;i<count;++i){auto row=seed;row.segment_id="r101-"+std::string(channel)+"-"+std::to_string(i);row.order_request_id="order-"+row.segment_id;row.media_epoch_id="epoch-"+row.segment_id;
   RecordingOrderReservationV1 order;Need101(catalog.ReserveRecordingOrder(row.store_id,row.order_request_id,row.segment_id,channel,&order,&error),"reserve:"+error);row.order_sequence=order.sequence;
   auto bound=*binding;bound.segment_id=row.segment_id;bound.media_epoch_id=row.media_epoch_id;const auto target=root/"recording"/channel/(row.segment_id+".mp4");std::filesystem::create_directories(target.parent_path());std::filesystem::copy_file(file,target);
   const int fd=open(target.c_str(),O_RDONLY|O_CLOEXEC|O_NOFOLLOW);Need101(fd>=0,"clone-open");const bool good=VerifyRecordingFileEvidenceFd(fd,bound,&error);const int closed=close(fd);Need101(good&&closed==0,"clone-proof:"+error);Need101(catalog.FinalizeBoundSegmentV2(row,bound,target.string(),&error),"clone-finalize:"+error);
  }
  std::cout<<"[R101-state] channel="<<channel<<" active="<<count<<" uniqueOriginals="<<count<<" segmentBytes="<<seed.size_bytes<<" seedHash="<<seed.checksum_sha256<<" sampleCount="<<binding->samples.size()<<std::endl;
 }
 Need101(catalog.Checkpoint(&error),"baseline-checkpoint:"+error);Need101(trace.Emit("baseline"),"baseline-resource");
 RecordingReadService reader(catalog);ingress::RecordingApplicationService structured(reader,catalog,true,{});
 VS::Options options;options.enabled=true;options.model_directory=argv[2];options.cache_directory=(root/"visual-cache").string();options.scan_seconds=1;options.sample_seconds=1;
 const VS::Authorize auth=[](const std::string& c){return c=="9101"||c=="9201";};VS service(catalog,reader,options,[](auto* out){*out={"9101","9201"};return true;});Ready101(service,auth);
 VS::Query query{{"channelIds","9101,9201"},{"text","ball"},{"limit","20"},{"threshold","-1"}};
 VS::Query sq{{"channelIds","9101"},{"startTimeMs","1789199999000"},{"endTimeMs","1789201000000"},{"limit","20"},{"includeUnplaced","true"}};
 std::vector<double> times;unsigned failures=0;std::atomic<bool> start{false};std::exception_ptr bgerror;unsigned writes=0,removed=0;
 std::thread background;
 if(mode=="background")background=std::thread([&]{try{while(!start.load())std::this_thread::yield();RetentionCoordinator retention(catalog,[&]{return catalog.RetentionSnapshot();},[&](auto* b,auto*){*b=std::filesystem::space(root).available;return true;},[&](const auto& p,auto* e){const bool ok=RemoveContainedMediaFile(root/"recording",p,e,{},true);if(ok)++removed;return ok;},{0,E,root/"recording"});
  for(const auto& c:{"9101","9201"}){RetentionPolicy policy;policy.continuous_max_bytes=Q;policy.event_max_bytes=128ULL*1024*1024;Need101(retention.UpdateChannelPolicy(c,policy,&error),"policy");auto opts=runtime.WriterOptions(2000);opts.admit_segment=[&](const auto& c,std::uint64_t m){const auto a=retention.AdmitContinuousWrite(c,m,1789201000000LL);return SegmentAdmissionDecision{a.allowed,a.start_new_epoch,a.reserved_bytes};};opts.report_segment_progress=[&](const auto& c,std::uint64_t b){retention.UpdateContinuousWriteProgress(c,b);};opts.complete_segment=[&](const auto& c,std::uint64_t b){retention.CompleteContinuousWrite(c,b);++writes;};write(c,opts);}
 }catch(...){bgerror=std::current_exception();}});
 start=true;
 for(unsigned round=0;round<3;++round){
  const auto call=[&](bool visual,unsigned client){const auto t=Clock::now();const auto result=visual?service.Search(query,auth):structured.Search(sq,"r101","both",auth);const double ms=std::chrono::duration<double,std::milli>(Clock::now()-t).count();return std::make_tuple(visual,client,ms,result.status,result.body);};
  std::vector<std::future<decltype(call(true,0))>> jobs;const unsigned n=mode=="single"?1:4;
  for(unsigned i=0;i<n;++i)jobs.push_back(std::async(std::launch::async,call,i<2,i));
  for(auto& job:jobs){const auto [visual,client,ms,status,body]=job.get();times.push_back(ms);if(status!=200)++failures;std::cout<<"[R101-request] round="<<round<<" visual="<<visual<<" client="<<client<<" ms="<<ms<<" status="<<status<<" body="<<body<<std::endl;}
 }
 if(background.joinable())background.join();if(bgerror)std::rethrow_exception(bgerror);
 std::cout<<"[R101-background] completed="<<writes<<" removed="<<removed<<std::endl;
 service.Stop();Need101(trace.Emit("before-Finish"),"resource");Need101(runtime.Finish(&error),"finish:"+error);Need101(trace.Emit("after-Finish"),"finish-resource");
 std::sort(times.begin(),times.end());const double p95=times[std::min(times.size()-1,std::size_t(std::ceil(times.size()*0.95))-1)];
 struct rusage usage{};Need101(getrusage(RUSAGE_SELF,&usage)==0,"rss");std::uint64_t rss=usage.ru_maxrss;
#ifndef __APPLE__
 rss*=1024;
#endif
 std::cout<<"[R101-result] count="<<times.size()<<" failures="<<failures<<" p95="<<p95<<" max="<<times.back()<<" peakRss="<<rss<<" finish=1"<<std::endl;
 Need101(rss<=4ULL*1024*1024*1024,"RSS-cap");Need101(!failures&&p95<=2000&&times.back()<=5000,"request-gate");return 0;
 }catch(const std::exception& e){std::cerr<<"[R101-failure] "<<e.what()<<std::endl;return 1;}
}
