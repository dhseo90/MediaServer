import fs from 'node:fs';
import {collectProcess} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_foundation_observer.mjs';
import {measureCurrentRootStable,admitWorkspaceSnapshot,createWorkspaceFailureCapture} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs';
const root=process.argv[2],pid=Number(process.argv[3]),capture=createWorkspaceFailureCapture(root);
const file=fs.openSync(root+'/supplemental-space.jsonl','wx');let start=null,n=0,bytes=0,ended=false;
try{for(;;){let metrics;try{metrics=await collectProcess('/private/tmp/media-server-r101-efj0l7cx/process-metrics',pid);}catch(e){if(e.collectorDiagnostic?.measurement?.error==='process-exited-or-absent'){ended=true;break;}throw e;}
 start??=metrics.startIdentity;const storage=measureCurrentRootStable(root);
 const bounds=admitWorkspaceSnapshot({storage,baseline:{fixedBytes:0,capBytes:448*1024**2},metrics,expectedPid:pid,expectedStart:start},capture);
 if(metrics.rssBytes>4*1024**3)throw Error('RSS-cap');
 const line=JSON.stringify({sequence:n++,supplemental:true,metrics,storage,bounds})+'\n';if(bytes+Buffer.byteLength(line)>4*1024**2)throw Error('collector-log-cap');
 const written=fs.writeSync(file,line);if(written!==Buffer.byteLength(line))throw Error('collector-short-write');bytes+=written;
 await new Promise(r=>setTimeout(r,1000));
}}catch(e){capture.capture(e);throw e;}finally{capture.close();fs.closeSync(file);fs.writeFileSync(root+'/supplemental-summary.json',JSON.stringify({samples:n,bytes,lateStart:true,endedObserved:ended,scope:'supplemental sequential sample; does not prove startup or instantaneous peak'})+'\n');}
