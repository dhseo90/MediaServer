from pathlib import Path
import hashlib,json,tarfile,io,os,re
root=Path('/private/tmp/media-server-r101-efj0l7cx'); dest=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0/101-execution.tar.gz')
assert root.resolve()==root and root.stat().st_uid==os.getuid() and not dest.exists()
selected=[]
for f in root.iterdir():
 if f.is_file() and not f.is_symlink() and f.suffix in {'.json','.log','.patch','.py','.cpp','.h','.sh','.mjs','.first'}:selected.append(f)
 if f.is_dir() and not f.is_symlink():
  selected.extend(x for x in f.iterdir() if x.is_file() and not x.is_symlink() and (x.suffix in {'.json','.jsonl','.log'} or x.name=='mixed-input.mp4'))
selected=sorted(selected,key=lambda p:str(p.relative_to(root)))
patterns=[r'Bearer\s+[A-Za-z0-9_.-]{15,}',r'-----BEGIN .*PRIVATE KEY',r'passwordHash\s*["\s]*:',r'(?:rtsp|https?)://[^\s\"<>]*@',r'gh[pousr]_[A-Za-z0-9]{20,}']
rows=[]
for p in selected:
 data=p.read_bytes()
 if p.suffix!='.mp4' and p.name!='preserve101.py': # scanner's own regex literals are not credentials
  text=data.decode('utf8',errors='replace')
  assert not any(re.search(pattern,text) for pattern in patterns),p.name
 rows.append({'path':str(p.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'kind':'generated synthetic fixture media' if p.suffix=='.mp4' else 'original run output or source/derived analysis as named'})
manifest={'schema':'media-server.run-preservation.v1','task':101,'originalRoot':str(root),'policy':'Exact selected bytes, not redacted. Named derived analysis/patch/plan is separate from raw execution logs. No old archives, models, binaries, home/config/recording trees or user defaults/private95backup included. Synthetic mixed-input files only; no operating/customer media. Credential pattern check is limited and not a universal privacy proof.','files':rows}
with tarfile.open(dest,'x:gz',compresslevel=9) as tar:
 for p,row in zip(selected,rows):
  info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o644;tar.addfile(info,io.BytesIO(p.read_bytes()))
 data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('preservation-manifest.json');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'path':str(dest.relative_to(Path('/Users/dhseo/Workspace/mediaServer'))),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'compressedBytes':dest.stat().st_size,'sourceFiles':len(rows),'sourceBytes':sum(r['bytes'] for r in rows),'memberReadback':'all exact original selected bytes verified','manifestMember':'preservation-manifest.json'}
(root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
