p='scripts/internal/recording_visual_contention_check.py'
s=open(p).read();s=s.replace("root=parent/a.label;root.mkdir(mode=0o700);env=environment(root);", "assert a.label and pathlib.Path(a.label).name==a.label and a.label not in ('.','..')\nenvironment(parent) # validate owned namespace before creating any run leaf\nroot=parent/a.label;root.mkdir(mode=0o700);env=environment(root);")
s=s.replace("MEDIA_SERVER_VERIFY_FRAME_TRACE='bounded')", "MEDIA_SERVER_VERIFY_FRAME_TRACE='bounded',MEDIA_SERVER_VERIFY_CONTENTION_OBSERVER='1')")
a=s.index("(root/'execution.json').write_text")
s=s[:a]+'''(root/'execution.json').write_text(json.dumps(record,indent=2));t=time.monotonic()
child=None;monitor=None;sel=selectors.DefaultSelector();stop_at=None;ready=False;monitor_bytes=b''
record.update(collectionError=None,signal=None,monitorExit=None,observerReady=False,groupAbsent=False)
def terminate(proc,sig):
 if proc is None:return
 try:os.killpg(proc.pid,sig)
 except ProcessLookupError:pass
try:
 child=subprocess.Popen(command,cwd=root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);record['pid']=child.pid
 sel.register(child.stdout,selectors.EVENT_READ,'child')
 if a.action=='run':
  collector=parent/'process-metrics';assert collector.is_file()
  monitor=subprocess.Popen(['node',str(repo/'scripts/internal/recording_visual_contention_observer.mjs'),str(root),str(child.pid),str(collector)],cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
  sel.register(monitor.stdout,selectors.EVENT_READ,'monitor')
 with (root/'output.log').open('xb') as f:
  while sel.get_map():
   now=time.monotonic()
   if now-t>deadline and stop_at is None:record['timeout']=True;stop_at=now;terminate(child,signal.SIGTERM)
   if monitor and monitor.poll() not in (None,0) and stop_at is None:
    record['collectionError']='resource observer failed';stop_at=now;terminate(child,signal.SIGTERM)
   if stop_at is not None and now-stop_at>5:
    terminate(child,signal.SIGKILL);terminate(monitor,signal.SIGKILL)
    if now-stop_at>6:raise TimeoutError('output pipe did not close after group stop')
   for key,_ in sel.select(0.1):
    b=os.read(key.fileobj.fileno(),65536)
    if not b:sel.unregister(key.fileobj);continue
    record['receivedBytes']+=len(b)
    if record['savedBytes']+len(b)>cap:
     record['overflow']=True
     if stop_at is None:stop_at=time.monotonic();terminate(child,signal.SIGTERM)
    else:
     n=f.write(b);f.flush();record['savedBytes']+=n
     if n!=len(b):raise IOError('short write')
    if key.data=='monitor' and not ready:
     monitor_bytes+=b
     if b'[R101-space-ready]\\n' in monitor_bytes:
      child.stdin.write(b'continue\\n');child.stdin.flush();child.stdin.close();ready=True;record['observerReady']=True;monitor_bytes=b''
     elif len(monitor_bytes)>32768:raise IOError('observer readiness missing')
except BaseException as error:
 record['collectionError']=type(error).__name__+':'+str(error)
finally:
 sel.close()
 for proc in (child,monitor):
  if proc is None:continue
  if proc.poll() is None:
   terminate(proc,signal.SIGTERM)
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:terminate(proc,signal.SIGKILL);proc.wait(timeout=5)
  if proc.stdout:proc.stdout.close()
  if proc.stdin and not proc.stdin.closed:proc.stdin.close()
 if child:
  record['exit']=child.wait();record['signal']=-record['exit'] if record['exit']<0 else None
  try:
   os.killpg(child.pid,0)
   # A pipe-less descendant is still a cleanup failure, even if the leader exited.
   terminate(child,signal.SIGTERM);record['collectionError']=record['collectionError'] or 'child group remained after leader exit'
  except ProcessLookupError:record['groupAbsent']=True
 else:record['exit']=None
 if monitor:record['monitorExit']=monitor.wait()
 record['elapsedSeconds']=time.monotonic()-t
 (root/'execution.json').write_text(json.dumps(record,indent=2)+'\\n')
print(json.dumps(record));raise SystemExit(0 if record['exit']==0 and not record['timeout'] and not record['overflow'] and record['collectionError'] is None and record['receivedBytes']==record['savedBytes'] and record['groupAbsent'] and (a.action=='build' or (record['observerReady'] and record['monitorExit']==0)) else 1)
'''
open(p,'w').write(s)
