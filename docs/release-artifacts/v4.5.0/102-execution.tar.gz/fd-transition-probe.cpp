#include <cerrno>
#include <initializer_list>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>
#ifdef __APPLE__
#include <libproc.h>
#include <sys/proc_info.h>
#endif
int main(){int command[2],ack[2];if(pipe(command)||pipe(ack))return 2;pid_t child=fork();if(child<0)return 2;if(!child){close(command[1]);close(ack[0]);char name[]="fd102-XXXXXX";int fd=mkstemp(name);if(fd<0||dup2(fd,200)!=200)return 2;close(fd);char byte='r';write(ack[1],&byte,1);while(read(command[0],&byte,1)==1){if(byte=='q')break;if(byte=='c')close(200);if(byte=='v'){int n=open(name,O_RDWR);if(n<0||dup2(n,200)!=200)return 2;close(n);ftruncate(200,8192);}if(byte=='p'){int v[2];if(pipe(v)||dup2(v[0],200)!=200)return 2;close(v[0]);close(v[1]);}if(byte=='u'){unlink(name);ftruncate(200,16384);}if(byte=='t')ftruncate(200,4096);write(ack[1],&byte,1);}close(200);unlink(name);return 0;}close(command[0]);close(ack[1]);char b;read(ack[0],&b,1);for(char action: {'r','c','v','u','t','p'}){if(action!='r'){write(command[1],&action,1);if(read(ack[0],&b,1)!=1)return 3;}errno=0;
#ifdef __APPLE__
vnode_fdinfo value{};int result=proc_pidfdinfo(child,200,PROC_PIDFDVNODEINFO,&value,sizeof value);int error=errno;printf("{\"action\":\"%c\",\"return\":%d,\"errno\":%d,\"expectedBytes\":%zu,\"dev\":%u,\"ino\":%llu,\"links\":%u,\"size\":%lld}\n",action,result,error,sizeof value,value.pvi.vi_stat.vst_dev,(unsigned long long)value.pvi.vi_stat.vst_ino,value.pvi.vi_stat.vst_nlink,(long long)value.pvi.vi_stat.vst_size);
#else
char path[100];snprintf(path,sizeof path,"/proc/%d/fd/200",child);struct stat value{};int result=stat(path,&value);int error=errno;printf("{\"action\":\"%c\",\"return\":%d,\"errno\":%d,\"dev\":%llu,\"ino\":%llu,\"links\":%llu,\"size\":%lld,\"regular\":%s}\n",action,result,error,(unsigned long long)value.st_dev,(unsigned long long)value.st_ino,(unsigned long long)value.st_nlink,(long long)value.st_size,S_ISREG(value.st_mode)?"true":"false");
#endif
}b='q';write(command[1],&b,1);close(command[1]);close(ack[0]);int status;waitpid(child,&status,0);return WIFEXITED(status)?WEXITSTATUS(status):4;}
