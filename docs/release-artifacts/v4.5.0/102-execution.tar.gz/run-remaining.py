import pathlib,subprocess,json,hashlib,sys,time
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');parent=pathlib.Path('/private/tmp/media-server-r102-zsafslvd')
freeze=json.loads((parent/'matrix-freeze.json').read_text());first=json.loads((parent/'matrix-cycle-parallel/execution.json').read_text())
assert first['exit']==0 and first['collectionError'] is None and first['monitorExit']==0
for scale,mode in freeze['matrix'][1:]:
 for p,digest in freeze['files'].items():assert hashlib.sha256((repo/p).read_bytes()).hexdigest()==digest,p
 for p,digest in freeze['binaries'].items():assert hashlib.sha256((parent/p).read_bytes()).hexdigest()==digest,p
 label='matrix-'+scale+'-'+mode
 cmd=['python3','scripts/internal/recording_visual_contention_check.py','run',str(parent),'--label',label,'--scale',scale,'--mode',mode]
 with (parent/(label+'-parent.log')).open('xb') as out: result=subprocess.run(cmd,cwd=repo,stdout=out,stderr=subprocess.STDOUT)
 print(json.dumps({'label':label,'exit':result.returncode}),flush=True)
 if result.returncode:sys.exit(result.returncode)
