import pathlib,json,math,hashlib,statistics
P=pathlib.Path(__file__).parent
for label in ['before900-prepared','after900']:
 p=P/label;lines=(p/'run.log').read_text().splitlines()
 def tagged(prefix):return [json.loads(l[len(prefix)+1:]) for l in lines if l.startswith(prefix+' ')]
 final=next(json.loads(l) for l in reversed(lines) if l.startswith('{"workspaceFailure"'))
 samples=tagged('[current-observation]');lat=sorted(final['evidenceLoad']['searchLatencyMs']);requests=tagged('[mixed-http-timing]')
 visual=tagged('[visual-request-summary]')[0];holder=json.loads(next(p.rglob('catalog-holders-*.json')).read_text());root=next(p.glob('media-server-current-observer-*'))
 v={'label':label,'status':'FAIL','execution':json.loads((p/'execution.json').read_text()),'mainLastObservedSeconds':samples[-1]['progress']['elapsedMs']/1000,'samples':len(samples),'failureLines':[l for l in lines if l.startswith('[fail]')],
 'search':{'successfulPopulation':len(lat),'partialP95Ms':lat[math.ceil(len(lat)*.95)-1],'partialMaxMs':max(lat),'failedRequests':[x for x in requests if x['outcome']!='ok'],'finalGate':'not-run','population':'original successful four-client search array; excludes A auxiliary requests; timeouts separate, not removed from failure outcome'},
 'progress':samples[-1]['progress'],'aCompleted':len(final['aLoad']['completed']),'evidence':{k:final['evidenceLoad'][k] for k in ['cycles','searchSuccessByClient','createSuccess','createComplete','createPartial','visualCreated','retainedChecks']},
 'collector':{'samples':len(samples),'complete':all(x['fdObservation']['complete'] is True for x in samples)},'workspaceFailure':final['workspaceFailure'],'resources':final['resources'],
 'resourceTrace':tagged('[resource-trace-summary]')[0],'serverCapture':tagged('[server-diagnostic]')[0],'frames':tagged('[frame-trace-summary]')[0], 'cleanup':tagged('[process-cleanup]'),
 'holder':{k:holder[k] for k in ['status','end','windows'] if k in holder},'holderRows':len(holder['rows']),'holderLimits':'selected77/78/79 only; before79 missing, after first failing81/82 not selected; no whole-failure attribution','visualRequestSummary':visual,
 'notRun':['900-second completion','final latency gate','explicit disable','closed-journal assertion','45-minute run','120-minute controls/recovery/restart/reactivation'],
 'seed':json.loads((root/'seed.json').read_text()),'noRerun':True}
 (P/(label+'-analysis.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
 print(label,'seconds',round(v['mainLastObservedSeconds'],3),'p95',round(v['search']['partialP95Ms'],3),'max',round(v['search']['partialMaxMs'],3),'A',v['aCompleted'],'collector',v['collector'])
