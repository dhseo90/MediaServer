from pathlib import Path
import json, hashlib, tarfile, shutil, re, io
p=Path('/private/tmp/media-server-r103-zn_0_lki'); out=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0')
sha=lambda b:hashlib.sha256(b).hexdigest()
selected={};excluded=[];transforms=[]
def add(f):
 assert f.is_file() and not f.is_symlink()
 selected[str(f.relative_to(p))]=f.read_bytes()
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.log','.patch','.py','.sh','.txt'] and not f.name.startswith('prior102-') and f.name not in ['prefix-case.txt','archive-receipt.json']:add(f)
for f in (p/'launcher-checks').rglob('*'):
 if f.is_file() and f.suffix in ['.json','.log','.py','.sh']:add(f)
for n in ['before900','before900-prepared','after900']:
 root=p/n; obs=next(root.glob('media-server-current-observer-*'))
 for f in root.rglob('*'):
  if not f.is_file():continue
  rel=f.relative_to(root); parts=rel.parts
  if any(x in parts for x in ['state','gst-cache','tmp','events']):continue
  if f.is_symlink():raise RuntimeError('symlink:'+str(rel))
  if f.name in ['registry.bin','process-metrics','review-seed','normalize']:
   excluded.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes()),'reason':'rebuildable helper/registry; not original runtime bytes preserved'})
   continue
  if 'recordings' in parts and f.suffix=='.mp4' and 'active-1' not in f.name:
   excluded.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes()),'reason':'generated repetitive recording media; original metadata/packages/records retained; hash is not bytes preservation'})
   continue
  if f.name=='server-1.private.log':
   raw=f.read_bytes();lines=raw.splitlines(keepends=True); count=0; new=[]
   for line in lines:
    # Preserve all structured numeric diagnostics, redact only unstructured private startup lines.
    if not line.lstrip().startswith(b'{') and re.search(rb'password|token|credential|authorization|secret|cookie|source.?url|rtsp://|https?://',line,re.I):
     new.append(b'[r103-redacted-private-line] sha256='+sha(line).encode()+b'\n');count+=1
    else:new.append(line)
   data=b''.join(new); name=str(f.relative_to(p)).replace('.private.log','.sanitized.log');selected[name]=data
   transforms.append({'original':str(f.relative_to(p)),'originalBytes':len(raw),'originalSha256':sha(raw),'preserved':name,'preservedBytes':len(data),'preservedSha256':sha(data),'redactedLines':count,'relation':'line replacement, not identical bytes; original not uploaded'})
  else:add(f)
receipt={'schema':'r103-selected-byte-preservation-v1','scope':'New R103 outputs only. Private state, user configuration/backup, models, old archives and repeated bulk media excluded. Raw recordings metadata, evidence/A records and selected seed retained. Hash-only omissions cannot reconstruct full recording store.','transforms':transforms,'omittedHashOnly':excluded,'members':[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(selected.items())]}
selected['preservation-manifest.json']=(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode()
archive=out/'103-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(selected.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
 for name,data in selected.items():assert t.extractfile(name).read()==data
summary={'path':str(archive.relative_to(out.parent.parent.parent)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(selected),'memberBytes':sum(map(len,selected.values())),'omittedMediaCount':sum(x['reason'].startswith('generated') for x in excluded),'sanitization':transforms,'memberReadback':'all byte-identical to selected originals or explicitly transformed bytes'}
(p/'archive-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copyfile(p/'independent-result-review.json',out/'103-independent-review.json')
print(json.dumps(summary,indent=2))
