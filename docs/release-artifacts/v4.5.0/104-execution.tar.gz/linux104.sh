#!/bin/bash
set -euo pipefail
r=/tmp/media-server-r104-linux
mkdir -m 700 "$r"
mkdir -m 700 "$r/work" "$r/output"
trap 'prior=$?; for log in "$r"/output/*.log; do [ -f "$log" ] || continue; printf "[linux-log] %s\n" "$log"; cat "$log"; done; printf "[linux-exit] %s\n" "$prior"; exit "$prior"' EXIT
export TMPDIR="$r/work" HOME="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
id
cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" --target media_server -j 2 > "$r/output/build.log" 2>&1
timeout 180 bash /source/scripts/internal/verify_recording_retention_v2.sh > "$r/output/retention.log" 2>&1
timeout 360 bash /source/scripts/internal/verify_recording_generation_request_proof.sh > "$r/output/generation.log" 2>&1
timeout 360 bash /source/scripts/internal/verify_recording_generation_consumers.sh > "$r/output/consumers.log" 2>&1
c++ -std=c++17 -Wall -Wextra -Werror -I/source/include -DMEDIA_SERVER_USE_OPENSSL=0 /source/scripts/internal/recording_segment_parse_smoke.cpp /source/src/recording/recording_contracts.cpp /source/src/domain/strict_json.cpp -o "$r/parse"
"$r/parse" > "$r/output/parse.log"
printf 'R104 Linux product/retention/generation completed\n'
