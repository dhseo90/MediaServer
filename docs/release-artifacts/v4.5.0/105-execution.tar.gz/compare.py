from pathlib import Path
import json,hashlib,re,statistics
r=Path(__file__).parent
out={'scope':'native ApplicationService + actual model, not HTTP; 3 waves once per condition; fresh stores; no compilation during measurements','conditions':{}}
for mode in ['single','visual-pair','parallel','background']:
 pair={};bodies=[]
 for candidate in ['before','after']:
  p=r/candidate/('53-'+mode);record=json.loads((p/'execution.json').read_text());lines=(p/'output.log').read_text().splitlines()
  vs=[json.loads(l.split('] ',1)[1]) for l in lines if l.startswith('[visual-request] ')]
  qs=[]
  for l in lines:
   if l.startswith('[R101-request] '):
    head,body=l.split(' body=',1);fields=dict(re.findall(r'(\w+)=([^ ]+)',head));j=json.loads(body)
    qs.append(dict(fields,items=j.get('items'),kind=j.get('kind')))
  visuals=[x for x in qs if x['visual']=='1'];bodies.append([x['items'] for x in visuals])
  pair[candidate]={'execution':record,'visualRequests':vs,'requests':qs,'logSha256':hashlib.sha256((p/'output.log').read_bytes()).hexdigest(),'resourceLines':[l for l in lines if l.startswith(('[R101-result]','[R101-final]','[R101-space-final]','[R101-progress]'))],'media':{str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in p.rglob('*.mp4')}}
 pair['visualItemsEqualAcrossRuns']=bodies[0]==bodies[1]
 # Background publication and writer timing differ by design: mismatches are reported, never normalized to PASS.
 out['conditions'][mode]=pair
(r/'comparison.json').write_text(json.dumps(out,indent=2)+'\n')
for m,p in out['conditions'].items():
 print(m,'same visual items',p['visualItemsEqualAcrossRuns'])
 for c in ['before','after']:
  q=p[c]['execution'].get('qualification');print(c,json.dumps(q)[:900])
  print('catalog requests',[(v['id'],round(v['elapsedNs']/1e6,2),v['locks'][0]) for v in p[c]['visualRequests']])
