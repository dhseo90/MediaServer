from pathlib import Path
import json,tarfile,hashlib,stat
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');out=repo/'docs/release-artifacts/v4.5.0/105-execution.tar.gz';assert not out.exists()
exclude={'after-analysis.json','catalog-holders-96259.json','server-1.sanitized.log'}
files=[p for p in r.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py','.sh','.patch') and p.name not in exclude]
for stage in ['before','after']:
 for p in (r/stage).rglob('*'):
  if p.is_file() and p.name in ('execution.json','output.log','preparation-budget.json','mixed-input.mp4'):files.append(p)
p=r/'after900'
files += [p/x for x in ['execution.json','run.log','owned-recovery-groups.jsonl']]
files += [x for x in (p/'artifacts').rglob('*') if x.is_file()]
s=next(p.glob('media-server-current-observer-*'))
files += [s/x for x in ['server-1.sanitized.log','catalog-holders-3019.json','catalog-instrumented.cpp','seed.json']]
for directory in ['input','record-input','recordings']:
 files += [x for x in (s/directory).rglob('*') if x.is_file()]
files=sorted(set(files));rows=[]
for p in files:
 assert not p.is_symlink() and p.stat().st_uid==501,p
 assert 'private.log' not in p.name and not any(x in p.parts for x in ['state','home','gst-cache','models']),p
 data=p.read_bytes();rows.append({'path':str(p.relative_to(r)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'R105-owned-evidence-v1','members':rows,'totalBytes':sum(x['bytes'] for x in rows),'memberCount':len(rows),'omitted':'user/private settings never accessed; isolated auth/state/cache/registry, generated binaries, redundant direct media omitted; actual direct seeds and all new mixed recording source/packages retained; R104 extracted originals reused by archive references, not duplicated','sanitized':'sanitization.json distinguishes server raw hash from redacted source URL lines','rawRetention':'per-run outputs unchanged; source first preparation FAIL preserved'}
mp=r/'preservation-manifest.json';assert not mp.exists();mp.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out,'w:gz') as t:
 for p in files+[mp]:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(out) as t:
 for row in rows:assert hashlib.sha256(t.extractfile(row['path']).read()).hexdigest()==row['sha256'],row['path']
receipt={'archive':str(out.relative_to(repo)),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'memberCount':len(rows)+1,'sourceByteReadback':'PASS','rawBytes':manifest['totalBytes'],'manifestSha256':hashlib.sha256(mp.read_bytes()).hexdigest()}
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
