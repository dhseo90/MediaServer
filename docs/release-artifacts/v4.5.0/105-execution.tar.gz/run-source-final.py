import sys, pathlib, shlex, subprocess, json, time
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer'); root=pathlib.Path('/private/tmp/media-server-r105-a3cph15y'); build=repo/'build-gst-onnx'
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
fixture=root/'source-fixture-final';fixture.mkdir(mode=0o700);env=environment(fixture)
flags={}
for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);flags[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
cmd=[link[0]]+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-I'+str(repo/'scripts/internal'),str(repo/'scripts/internal/recording_visual_source_smoke.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(root/'source-check')]
results=[]
for name,command in [('compile',cmd),('run',[str(root/'source-check'),str(fixture)])]:
 start=time.monotonic()
 with (root/f'source-final-{name}.log').open('x') as out:
  try:code=subprocess.run(command,cwd=fixture,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90).returncode
  except subprocess.TimeoutExpired:code=124
 results.append(dict(phase=name,command=command,exit=code,elapsed=time.monotonic()-start));(root/'source-final-result.json').write_text(json.dumps(results,indent=2));print(name,code,flush=True)
 if code:sys.exit(code)
