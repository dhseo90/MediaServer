from pathlib import Path
from collections import defaultdict
import json
r=Path(__file__).parent
out={}
def union(spans):
 total=0;end=-1
 for a,b in sorted(spans):
  if b>a:total+=max(0,b-max(a,end));end=max(end,b)
 return total
for label in ['before-http-connected','after-http-connected']:
 h=json.loads((r/label/'holders.json').read_text()); rows=h['rows']; target=h['end']['request'];own=[v for v in rows if v['r']==target];waits=[(v['b'],v['a'],v['m']) for v in own]
 by=defaultdict(lambda:{'calls':0,'heldNs':0,'maxHeldNs':0,'overlapNs':0,'subcostNs':[0]*4});covered=[]
 for v in rows:
  if v['r']==target:continue
  g=by[v['site']];g['calls']+=1;g['heldNs']+=v['e']-v['a'];g['maxHeldNs']=max(g['maxHeldNs'],v['e']-v['a'])
  for i,n in enumerate(v['counts']):g['subcostNs'][i]+=n
  spans=[(max(a,v['a']),min(b,v['e'])) for a,b,m in waits if m==v['m'] and min(b,v['e'])>max(a,v['a'])]
  g['overlapNs']+=union(spans);covered.extend(spans)
 wait=sum(b-a for a,b,m in waits)
 out[label]={'selectedRequest':target,'completeness':h['end'],'waitNs':wait,'coveredUnionNs':union(covered),'unclassifiedNs':wait-union(covered),'sites':dict(sorted(by.items(),key=lambda kv:-kv[1]['overlapNs'])),'limits':'same selected request/mutex wait versus acquired-to-release intervals; elapsed not CPU; nested authority/cold costs not additive; different selected requests not paired identical execution'}
(r/'http-holder-comparison.json').write_text(json.dumps(out,indent=2)+'\n')
for label,v in out.items():print(label,'wait/unclassified ms',v['waitNs']/1e6,v['unclassifiedNs']/1e6,'top',[(k,x['calls'],x['overlapNs']/1e6) for k,x in list(v['sites'].items())[:5]])
