from pathlib import Path
import json,re,math
r=Path(__file__).parent
out={'scope':'closed106 originals plus actualHTTP/index/retention/writer; rebuilt caches; not reconstructed live106; no evidence/A direct load'}
for label in ['before-http-02','before-http-final','before-http-connected','after-http-connected']:
 p=r/label/'output.log'
 if not p.exists():continue
 text=p.read_text();lines=text.splitlines()
 def rows(prefix):return [json.loads(x[len(prefix):]) for x in lines if x.startswith(prefix)]
 req=[]
 for line in lines:
  m=re.fullmatch(r'\[R107-http\] round=(\d+) client=(\d+) ms=([0-9.e+-]+) response=(.*)',line)
  if m:
   rnd,c,ms,raw=m.groups();req.append({'round':int(rnd),'client':int(c),'ms':float(ms),'body':json.loads(raw)})
 times=sorted(x['ms'] for x in req);visual=rows('[visual-request] ');space=rows('[R101-space] ');owners=rows('[recording-resource] ')
 peaks={k:max((x['metrics'].get(k,0) or 0 for x in space),default=None) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']}
 phasePeaks={phase:{k:max((x['metrics'].get(k,0) or 0 for x in space if x['phase']==phase),default=None) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']} for phase in sorted({x['phase'] for x in space})}
 peaks['liveWorkspaceBytes']=max((x['bounds']['variableBytes'] for x in space if x['phase']=='live'),default=None)
 out[label]={'execution':json.loads((p.parent/'execution.json').read_text()),'requestCount':len(req),'allStatusBodiesHaveItems':all('items' in x['body'] for x in req),'p95Ms':times[math.ceil(len(times)*.95)-1] if times else None,'maxMs':max(times) if times else None,'requests':[{'round':x['round'],'client':x['client'],'ms':x['ms'],'count':len(x['body'].get('items',[]))} for x in req],'visual':visual,'samplePeaksAllPhases':peaks,'phaseSamplePeaks':phasePeaks,'sampleCount':len(space),'owner':owners,'progress':[x for x in lines if x.startswith(('[R107-background]','[R107-result]','[R107-fail]'))],'unmeasured':['instantaneouspeak','liveheap','actualCPU/scheduler attribution','10699/100 peers']}
(r/'direct-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for k,v in out.items():
 if isinstance(v,dict):print(k,{x:v[x] for x in ('requestCount','p95Ms','maxMs','sampleCount','samplePeaksAllPhases')})
