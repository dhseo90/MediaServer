// R107: exact closed original copy, real HTTP and actual source/writer/index consumers.
#define main ManagedInputFixtureMain
#include "recording_managed_writer_smoke.cpp"
#undef main
#include "recording_writer_test_isolation.h"
#include "ingress/recording_application_service.h"
#include "../../src/ingress/webrtc_http_server_detail.h"
#include <future>
#include "domain/strict_json.h"
#include <arpa/inet.h>
#include <netinet/tcp.h>
namespace ingress {struct RecordingHttpOwnershipProbe {
 static std::uint16_t Port(WebRtcHttpServer& s){sockaddr_in a{};socklen_t n=sizeof(a);if(getsockname(s.impl_->listen_fd,reinterpret_cast<sockaddr*>(&a),&n))throw std::runtime_error("port");return ntohs(a.sin_port);}
 static int Active(WebRtcHttpServer& s){return s.impl_->active_http_connections.load();}
};}
namespace {
using namespace ingress;using Clock=std::chrono::steady_clock;
void NeedHttp(bool ok,const char* why){if(!ok)throw std::runtime_error(why);}
void Observer107(const char* phase){
 if(const char* enabled=std::getenv("MEDIA_SERVER_VERIFY_CONTENTION_OBSERVER");enabled&&std::string(enabled)=="1"){
  if(phase)std::cout<<"[R101-phase] "<<phase<<std::endl;
  char token[16]{};std::cin.getline(token,sizeof(token));NeedHttp(std::string(token)=="continue","observer-not-ready");
 }
}
std::uint64_t Generation107(const std::string& body){
 StrictJsonObjectDocument doc,index;std::string error;
 NeedHttp(ParseStrictJsonObjectDocument(body,&doc,&error),"status-json");
 const auto raw=StrictJsonObjectField(doc,"index");NeedHttp(raw.has_value(),"status-index");
 NeedHttp(ParseStrictJsonObjectDocument(*raw,&index,&error),"index-json");
 const auto* g=index.Find("generation");NeedHttp(g&&g->type==StrictJsonType::Number,"index-generation");
 return std::stoull(g->raw);
}
struct Media final:WebRtcMediaApplicationService {
    std::shared_ptr<WebRtcMediaApplicationEgressSession> CreateEgressSession()override{return {};}
    std::shared_ptr<WebRtcMediaApplicationSourceSession> CreateSourceSession()override{return {};}
    bool CloseSession(const std::string&)override{return true;}
    WebRtcMediaApplicationRuntimeStateSnapshot RuntimeStateSnapshot()const override{return {};}
    std::vector<WebRtcMediaApplicationSourceReconnectStats> SourceReconnectStatsSnapshot()const override{return {};}
    std::vector<WebRtcMediaApplicationSourceDescriptorSnapshot> SourceDescriptorSnapshots()const override{return {};}
    std::vector<WebRtcMediaApplicationSourceEgressStats> SourceEgressStatsSnapshot()const override{return {};}
    std::vector<WebRtcMediaApplicationPublishedSourceSnapshot> PublishedSourceSnapshots()const override{return {};}
};
struct Lifecycle final:AnalysisSessionLifecycleApplicationService {
    AnalysisSessionLifecycleApplicationAttachResult Attach(const AnalysisSessionLifecycleApplicationRequest&)override{return {};}
    AnalysisSessionLifecycleApplicationDetachResult Detach(const std::string&)override{return {};}
};
struct Reads final:AnalysisSessionReadApplicationService {
    std::optional<AnalysisSessionApplicationSnapshot> Snapshot(const std::string&)const override{return {};}
    std::vector<AnalysisSessionApplicationSnapshot> Snapshots()const override{return {};}
    std::optional<AnalysisSessionApplicationResult> WaitResultNearPts(const std::string&,std::int64_t,std::int64_t,int)const override{return {};}
    std::optional<ImageCodecFrame> LatestFrame(const std::string&)const override{return {};}
    std::optional<AnalysisSessionApplicationLatestFrameAndResult> LatestFrameAndResult(const std::string&)const override{return {};}
    std::size_t ActiveTapCount()const override{return 0;}
};
struct Socket {int fd{-1};~Socket(){if(fd>=0)close(fd);}void Reset(){if(fd>=0){close(fd);fd=-1;}}};
void WaitIdle(WebRtcHttpServer& s){const auto end=Clock::now()+std::chrono::seconds(12);while(RecordingHttpOwnershipProbe::Active(s)&&Clock::now()<end)std::this_thread::sleep_for(std::chrono::milliseconds(5));NeedHttp(!RecordingHttpOwnershipProbe::Active(s),"HTTP connection worker completed");}
int Request(std::uint16_t port,const std::string& path,bool admin=true){
    Socket c;c.fd=socket(AF_INET,SOCK_STREAM,0);NeedHttp(c.fd>=0,"client socket");    timeval timeout{5,0};setsockopt(c.fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout));
    sockaddr_in a{};a.sin_family=AF_INET;a.sin_port=htons(port);inet_pton(AF_INET,"127.0.0.1",&a.sin_addr);
    NeedHttp(!connect(c.fd,reinterpret_cast<sockaddr*>(&a),sizeof(a)),"actual loopback connect");
    const auto request="GET "+path+" HTTP/1.1\r\nHost: localhost\r\nAuthorization: Bearer "+(admin?std::string("owned-http85-admin-token"):std::string("owned-http85-viewer-token"))+"\r\nConnection: close\r\n\r\n";
    NeedHttp(webrtc_http_server_detail::SendAll(c.fd,request),"normal HTTP request sent");return std::exchange(c.fd,-1);
}
std::string Drain(int fd,Clock::time_point deadline){std::string result;char b[4096];for(;;){const auto remaining=std::chrono::duration_cast<std::chrono::microseconds>(deadline-Clock::now()).count();if(remaining<=0)throw std::runtime_error("HTTP total deadline");timeval timeout{static_cast<time_t>(remaining/1000000),static_cast<suseconds_t>(remaining%1000000)};NeedHttp(!setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout)),"receive deadline");auto n=recv(fd,b,sizeof(b),0);if(n==0)break;if(n<0)throw std::runtime_error("client receive failed");if(result.size()+static_cast<std::size_t>(n)>4*1024*1024+8192)throw std::runtime_error("HTTP fixture result bound");result.append(b,n);}return result;}
}
int main(int argc,char** argv){
 if(argc!=3||!RecordingWriterTestIsolation(argv[1]))return 2;
 try {
 const std::filesystem::path root(argv[1]);std::string error;Observer107(nullptr);gst_init(nullptr,nullptr);
 recording::RecordingResourceTrace trace("1");recording::RecordingRuntimeStorage runtime(root/"recording");NeedHttp(runtime.Open(&error),error.c_str());
 auto& catalog=runtime.catalog();NeedHttp(trace.Bind(catalog.SearchResidency(),catalog.ScratchResidency()),"trace");
 recording::RecordingReadService reader(catalog);ingress::VisualSearchApplicationService::Options options;
 options.enabled=true;options.model_directory=argv[2];options.cache_directory=(root/"visual-cache").string();options.scan_seconds=1;options.sample_seconds=1;
 Observer107("model");std::promise<bool> gate;auto allowed=gate.get_future().share();
 ingress::VisualSearchApplicationService visual(catalog,reader,options,[allowed](auto* out){if(!allowed.get())return false;*out={"9101","9201"};return true;});
 struct Release {std::promise<bool>& gate;bool done=false;~Release(){if(!done)gate.set_value(false);}} release{gate};
 Observer107("live");gate.set_value(true);release.done=true;
 auto authorize=[](const std::string& c){return c=="9101"||c=="9201";};
 const auto ready_end=Clock::now()+std::chrono::seconds(500);bool ready=false;
 while(Clock::now()<ready_end){auto status=visual.Status(authorize);if(status.body.find("\"searchAvailable\":true")!=std::string::npos){ready=true;std::cout<<"[R107-ready] "<<status.body<<std::endl;break;}std::this_thread::sleep_for(std::chrono::milliseconds(100));}
 NeedHttp(ready,"index-ready");NeedHttp(trace.Emit("ready"),"trace-ready");const auto initial_generation=Generation107(visual.Status(authorize).body);
 ingress::RecordingApplicationService app(reader,catalog,true,{}, {},&visual);
 Media media;Lifecycle lifecycle;Reads reads;WebRtcHttpRuntimeConfig config;
 config.auth_mode=HttpAuthMode::Token;config.auth_admin_token="owned-http85-admin-token";config.auth_viewer_token="owned-http85-viewer-token";config.enable_ops=true;
 config.auth_users_file=(root/"users.json").string();config.source_registry_path=(root/"sources.json").string();config.analysis_registry_path=(root/"analysis.json").string();config.file_root_path=(root/"input").string();
 WebRtcHttpServer server(media,lifecycle,reads,config,&app);NeedHttp(server.Start("127.0.0.1",0,&error),error.c_str());const auto port=RecordingHttpOwnershipProbe::Port(server);
 std::cout<<"[R107-port] "<<port<<std::endl;
 auto input=MixedInput(root);input.packets.resize(60);std::atomic<unsigned> writes{0};std::exception_ptr bgerror;
 std::thread background([&]{try{std::array<std::unique_ptr<recording::GStreamerSegmentWriter>,2> writers;
  for(unsigned i=0;i<2;++i){auto o=runtime.WriterOptions(2000);o.complete_segment=[&](const auto&,std::uint64_t){++writes;};writers[i]=std::make_unique<recording::GStreamerSegmentWriter>(o);std::string detail;NeedHttp(writers[i]->Start(i?"9201":"9101","unused",input.descriptor,[](auto,auto,auto*){return false;},&detail),detail.c_str());}
  const auto begin=Clock::now();for(unsigned i=0;i<180;++i){auto packet=input.packets[i%60];const std::int64_t delta=std::int64_t(i/60)*2000000000;packet.pts+=delta;packet.dts+=delta;if(packet.observation){auto& o=*packet.observation;o.ordinal=i+1;o.pts_ns=packet.pts;o.dts_ns=packet.dts;o.mono_before_ns+=delta;o.mono_after_ns+=delta;o.observed_utc_ns+=delta;}
   for(auto& writer:writers)writer->Push(packet,0);std::this_thread::sleep_until(begin+std::chrono::nanoseconds((i+1)*1000000000ULL/30));}
  for(auto& writer:writers)writer->Stop();
 }catch(...){bgerror=std::current_exception();}});
 struct Join {std::thread& t;~Join(){if(t.joinable())t.join();}} join{background};
 unsigned failures=0;std::vector<double> elapsed;
 for(unsigned round=0;round<3;++round){
  std::vector<std::future<std::tuple<double,std::string>>> requests;
  for(unsigned client=0;client<4;++client)requests.push_back(std::async(std::launch::async,[&,client]{
   const std::string route=client<2?"/ops/api/recordings/visual-search?channelIds=9101,9201&text=ball&limit=20&threshold=-1":
    "/ops/api/recordings/search?channelIds=9101&startTimeMs=1789199999000&endTimeMs=1899999999000&limit=20&includeUnplaced=true";
   const auto begin=Clock::now();Socket socket;socket.fd=Request(port,route);auto wire=Drain(socket.fd,begin+std::chrono::seconds(5));return std::make_tuple(std::chrono::duration<double,std::milli>(Clock::now()-begin).count(),wire);
  }));
  for(unsigned client=0;client<4;++client){const auto [ms,wire]=requests[client].get();elapsed.push_back(ms);if(wire.rfind("HTTP/1.1 200",0)!=0)++failures;std::cout<<"[R107-http] round="<<round<<" client="<<client<<" ms="<<ms<<" response="<<wire.substr(wire.find("\r\n\r\n")+4)<<std::endl;}
  NeedHttp(trace.Emit("wave"),"trace-wave");
 }
 background.join();if(bgerror)std::rethrow_exception(bgerror);
 const auto publication_end=Clock::now()+std::chrono::seconds(30);bool published=false;
 while(Clock::now()<publication_end){const auto status=visual.Status(authorize);StrictJsonObjectDocument doc;NeedHttp(status.status==200&&ParseStrictJsonObjectDocument(status.body,&doc,&error),"publication-status");const auto state=StrictJsonStringField(doc,"state");NeedHttp(state&&*state!="degraded"&&*state!="stopped"&&*state!="unavailable","publication-failed");if((*state=="ready"||*state=="indexing")&&Generation107(status.body)>initial_generation){published=true;break;}std::this_thread::sleep_for(std::chrono::milliseconds(100));}
 NeedHttp(published,"new index publication after writer");
 std::cout<<"[R107-background] writes="<<writes<<" status="<<visual.Status(authorize).body<<std::endl;
 WaitIdle(server);server.Stop();visual.Stop();NeedHttp(runtime.Finish(&error),error.c_str());NeedHttp(trace.Emit("finished"),"trace-finish");
 std::sort(elapsed.begin(),elapsed.end());std::cout<<"[R107-result] failures="<<failures<<" count="<<elapsed.size()<<" p95="<<elapsed[std::size_t(std::ceil(elapsed.size()*.95))-1]<<" max="<<elapsed.back()<<std::endl;
 NeedHttp(writes==6,"six durable writer completions");NeedHttp(elapsed[std::size_t(std::ceil(elapsed.size()*.95))-1]<=2000&&elapsed.back()<=5000,"original latency criteria");return failures?1:0;
 }catch(const std::exception& e){std::cerr<<"[R107-fail] "<<e.what()<<std::endl;return 1;}
}
