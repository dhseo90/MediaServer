from pathlib import Path
p=Path('include/recording/recording_latency_trace.h');s=p.read_text();needle='inline thread_local std::array<std::uint64_t,4> segment_decode_cost{};'
at=s.index(needle)
s=s[:at]+'''// R107 opt-in elapsed subcosts, not CPU time: Journal wait, managed authority,
// identity lookup, cold mutation read/parse. Nested authority is inclusive.
inline bool SubcostEnabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS");return p&&std::strcmp(p,"1")==0;}();return yes;}
inline thread_local std::array<std::uint64_t,4> journal_subcost{};
struct JournalSubcost {
    unsigned field;std::uint64_t begin;bool active;
    explicit JournalSubcost(unsigned index) noexcept:field(index),begin(SubcostEnabled()?Now():0),active(SubcostEnabled()){}
    void End() noexcept {if(active){journal_subcost[field]+=Now()-begin;active=false;}}
    ~JournalSubcost() noexcept {End();}
};
'''+s[at:]
s=s.replace('begin_counts_=holder_counts;','begin_counts_=SubcostEnabled()?journal_subcost:holder_counts;')
s=s.replace('event_.counts[i]=holder_counts[i]-begin_counts_[i];','event_.counts[i]=(SubcostEnabled()?journal_subcost[i]:holder_counts[i])-begin_counts_[i];')
s=s.replace('if(holder_){event_.site=site;event_.counts=costs;retention_costs_=true;}','if(holder_){event_.site=site;if(!SubcostEnabled()){event_.counts=costs;retention_costs_=true;}}')
s=s.replace('std::array<std::uint64_t,6> counters_{};','std::array<std::uint64_t,6> counters_{};\n    std::array<std::uint64_t,4> journal_begin_{};')
s=s.replace('active_=true;start_=Now();current=this;','active_=true;start_=Now();journal_begin_=journal_subcost;current=this;')
s=s.replace('add("%s", "]}\\n");','add("%s", "]}\\n");') # exact below
old='add("%s","]}\\n");if(!valid'
new='''add("%s","]");if(SubcostEnabled()){add("%s",",\\"journalCostNs\\":[");for(unsigned i=0;i<4;++i)add("%s%llu",i?",":"",(unsigned long long)(journal_subcost[i]-journal_begin_[i]));add("%s","]");}add("%s","}\\n");if(!valid'''
assert old in s;s=s.replace(old,new)
# Explicit mode before holder rows; old parser ignores this additive fixed marker.
s=s.replace('void PrintSlow() noexcept {','void PrintSlow() noexcept {\n        if(SubcostEnabled())std::fputs("[catalog-subcost-basis] journal-wait,managed-authority,identity-lookup,cold-read-inclusive\\n",stderr);')
s=s.replace('if(slow){PrintSlow();return;}','if(slow){PrintSlow();return;}\n        if(SubcostEnabled())std::fputs("[catalog-subcost-basis] journal-wait,managed-authority,identity-lookup,cold-read-inclusive\\n",stderr);')
p.write_text(s)
p=Path('src/recording/recording_journal.cpp');s=p.read_text();start=s.index('bool RecordingJournal::AcquireMutationLinkWithProof(');end=s.index('bool RecordingJournal::MatchMutationLinkView',start);chunk=s[start:end]
chunk=chunk.replace('std::lock_guard lock(mu_);','latency::JournalSubcost wait_cost(0);std::lock_guard lock(mu_);wait_cost.End();')
chunk=chunk.replace('const auto found=state.identities.find(ref.mutation_id);','latency::JournalSubcost identity_cost(2);\n            const auto found=state.identities.find(ref.mutation_id);')
chunk=chunk.replace('const auto& location=found->second;','identity_cost.End();\n            const auto& location=found->second;\n            latency::JournalSubcost cold_cost(3);')
s=s[:start]+chunk+s[end:];s=s.replace('bool RecordingJournal::CheckManagedFdStateLocked(std::string* error) const {','bool RecordingJournal::CheckManagedFdStateLocked(std::string* error) const {\n    latency::JournalSubcost authority_cost(1);')
p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');s=p.read_text();s+='''
### R107-H01 / P01 — 실제 열화 자료의 Journal 하위 비용과 요청 전체

- H01: opt-in `MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS=1`에서 기존 holder의 고정4개 counts를 Journal mutex 대기·managed authority·identity lookup·cold read/parse 경과ns로 전환하고 basis 표식을 보존한다. 요청 summary의 journalCostNs는 같은 thread 요청 전후 차이다. CPU 시간이나 물리 I/O 시간으로 해석하지 않으며 cold와 그 안의 authority는 중복 합산하지 않는다. 기존8192행·320B행·4MiB로그·선택 구간 완전성은 유지한다. off에서는 이전 카운터 의미를 유지한다.
- P01: R106 종료 원본의 별도 소유 복사본(원래 파일 bytes 검증)을 이용해 재Open 후 실제 source Collect/준비/현재 검증 비용을 고정3회 관측한다. 재Open 상태는 연속 실행의 cache/reader 상태와 다르며 이를 동일한 HTTP 운용으로 표시하지 않는다. 지배 경계 확인 후 같은 원본의 독립 복사본과 동일 호출/계측으로 비교한다. 원인 대조와 실제 혼합 PASS를 구분한다. 자료 변경·손상·K/F·권한·취소·자원 회수는 기존 직접 소비자와 변경 경계 반례로 보호한다.
- P02: 필요한 실제 HTTP 재현은 분석으로 선택한 상태와 실행 전 고정한 횟수/순서로 실행한다. product/fixture source·모델·원본 hash·전체 응답·Catalog 하위 경과·배경 진행·소유를 함께 보존한다. 수정후900초는 직접 인과/정확성/독립 판단 통과 후1회이며45분/120분은 제외한다.
''';p.write_text(s)
