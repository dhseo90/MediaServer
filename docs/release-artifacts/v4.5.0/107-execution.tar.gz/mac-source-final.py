from pathlib import Path
import sys,subprocess,shlex,json,hashlib,time
repo=Path('/Users/dhseo/Workspace/mediaServer');r=Path(__file__).parent;b=repo/'build-gst-onnx';root=r/'mac-source-final';root.mkdir(mode=0o700)
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
env=environment(root);f={}
for line in (b/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);f[k]=shlex.split(v)
l=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());binary=r/'mac-source-check';src=repo/'scripts/internal/recording_visual_source_smoke.cpp'
cmd=[l[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(src),str(b/'libmedia_server_runtime.a')]+l[l.index('libmedia_server_runtime.a')+1:]+['-o',str(binary)]
rows=[]
with (r/'mac-source-final.log').open('x') as log:
 for command,timeout in [(cmd,90),([str(binary),str(root)],90)]:
  start=time.monotonic();p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout);rows.append({'command':command,'exit':p.returncode,'elapsed':time.monotonic()-start});
  if p.returncode:break
(r/'mac-source-final.json').write_text(json.dumps({'results':rows,'sourceSha256':hashlib.sha256(src.read_bytes()).hexdigest(),'runtimeSha256':hashlib.sha256((b/'libmedia_server_runtime.a').read_bytes()).hexdigest()},indent=2)+'\n');sys.exit(rows[-1]['exit'])
