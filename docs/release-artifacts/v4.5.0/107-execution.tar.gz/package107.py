from pathlib import Path
import json,hashlib,tarfile,io,os
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');dest=repo/'docs/release-artifacts/v4.5.0/107-execution.tar.gz'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
selected={}
# Explicit file categories; no config, cache, model, SDK, binaries or private backup.
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.py','.cpp','.sh','.patch') and p.name not in ('candidate.json','archive106-members.json','preservation-manifest.json','archive-receipt.json'):
  selected[p.name]=p
labels=['before-http','before-http-02','before-http-final','before-http-connected','after-http-connected','before-build','before-build-corrected','before-build-final','after-build-connected']
for label in labels:
 d=r/label
 if not d.exists():continue
 for name in ['execution.json','output.log','input-binding.json','preparation-budget.json','workspace-first-failure.json','holders.json','trace-analysis.json','http-bodies.json']:
  p=d/name
  if p.is_file():selected[label+'/'+name]=p
seed={p.relative_to(r/'seed106').as_posix():sha(p) for p in (r/'seed106').rglob('*') if p.is_file() and not p.is_symlink()}
reused=[];new=[]
for label in ['before-http-02','before-http-final','before-http-connected','after-http-connected','source-before','source-after','encode-before','encode-phases']:
 d=r/label/'recording'
 if not d.exists():continue
 for p in sorted(d.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(d).as_posix();h=sha(p)
  if seed.get(rel)==h:reused.append({'run':label,'path':rel,'sha256':h});continue
  name=label+'/recording/'+rel;selected[name]=p;new.append({'path':name,'bytes':p.stat().st_size,'sha256':h})
# Reused bytes resolve through the original R106 archive; never reconstructed evidence.
relation={'sourceCommit':'c1e6611bf0778ac58470acab7f56fe20a5ae6114','sourceArchiveParts':['106-execution.tar.gz.part001','106-execution.tar.gz.part002','106-execution.tar.gz.part003'],'sourceMemberPrefix':'after900/media-server-current-observer-VJTJaz/recordings/','sourceArchiveSha256':'19d22896e34a8d3074644b1e0a69467cb490f759ac98effb1c35fcfe85da8d5d','unchanged':reused,'newOrModified':new,'limitation':'Closed original copies; not point-in-time failed run heap/readers/cache. Current modified whole files retained separately; unchanged original archives/media not duplicated.'}
(r/'original-relations.json').write_text(json.dumps(relation,ensure_ascii=False,indent=2)+'\n');selected['original-relations.json']=r/'original-relations.json'
# Reject any accidental credential material in selected paths; synthetic public test token in fixture source is not a user secret.
for name,p in selected.items():
 assert not p.is_symlink() and p.resolve().is_relative_to(r)
 assert not any(x in name.split('/') for x in ['home','cache','models','users.json','sources.json','analysis.json'])
manifest={'schema':'r107-preservation-v1','scope':'selected non-sensitive new raw outputs/source bindings/analysis plus changed generated recordings; old R106 references unchanged','entries':[{'path':n,'bytes':p.stat().st_size,'sha256':sha(p),'kind':'generated-recording' if '/recording/' in n else ('analysis' if 'analysis' in n or n.startswith('analyze') else 'output-or-source-binding')} for n,p in sorted(selected.items())]}
data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();(r/'preservation-manifest.json').write_bytes(data)
with tarfile.open(dest,'w:gz') as tar:
 for name,p in sorted(selected.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('preservation-manifest.json');info.size=len(data);info.mode=0o600;tar.addfile(info,io.BytesIO(data))
with tarfile.open(dest) as tar:
 for e in manifest['entries']:assert hashlib.sha256(tar.extractfile(e['path']).read()).hexdigest()==e['sha256']
receipt={'archive':str(dest.relative_to(repo)),'bytes':dest.stat().st_size,'sha256':sha(dest),'entries':len(manifest['entries'])+1,'originalBytes':sum(x['bytes'] for x in manifest['entries'])+len(data),'changedRecordingFiles':len(new),'unchangedOriginalReferences':len(reused),'manifestSha256':hashlib.sha256(data).hexdigest(),'readback':'all member bytes hash matched'}
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
