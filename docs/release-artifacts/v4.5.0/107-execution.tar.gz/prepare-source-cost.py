from pathlib import Path
import io,tarfile,json,hashlib,os
r=Path(__file__).parent;seed=r/'seed106';seed.mkdir(mode=0o700)
class Parts(io.RawIOBase):
 def __init__(self,ps):self.ps=iter(ps);self.f=None
 def readable(self):return True
 def readinto(self,b):
  while True:
   if self.f is None:
    try:self.f=next(self.ps).open('rb')
    except StopIteration:return 0
   n=self.f.readinto(b)
   if n:return n
   self.f.close();self.f=None
ps=sorted(Path('docs/release-artifacts/v4.5.0').glob('106-execution.tar.gz.part*'));prefix='after900/media-server-current-observer-VJTJaz/recordings/';rows=[]
manifest=json.loads((r/'prior106/preservation-manifest.json').read_text());expected={x['path']:x for x in manifest['files']}
with tarfile.open(fileobj=io.BufferedReader(Parts(ps)),mode='r|gz') as t:
 for m in t:
  if not m.isfile() or not m.name.startswith(prefix):continue
  rel=Path(m.name[len(prefix):]);assert not rel.is_absolute() and '..' not in rel.parts
  b=t.extractfile(m).read();h=hashlib.sha256(b).hexdigest();assert h==expected[m.name]['sha256']
  p=seed/rel;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.write_bytes(b);p.chmod(0o600);rows.append({'path':str(rel),'bytes':len(b),'sha256':h})
(r/'seed106.json').write_text(json.dumps({'sourceCommit':'c1e6611bf0778ac58470acab7f56fe20a5ae6114','archivePrefix':prefix,'files':rows,'scope':'exact closed original bytes and retained media; not live cache/reader or failure-instant reconstruction'},indent=2)+'\n')
print(len(rows),sum(x['bytes'] for x in rows))
