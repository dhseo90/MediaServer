from pathlib import Path
import sys,subprocess,shlex,hashlib,json,shutil,os,time
repo=Path('/Users/dhseo/Workspace/mediaServer');r=Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
label=sys.argv[1];root=r/label;root.mkdir(mode=0o700);env=environment(root)
shutil.copytree(r/'seed106',root/'recording',dirs_exist_ok=True)
b=repo/'build-gst-onnx';flags={}
for line in (b/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);flags[k]=shlex.split(v)
link=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());binary=r/(label+'-probe')
command=[link[0]]+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(repo/'scripts/internal/recording_source_read_cost_smoke.cpp'),str(b/'libmedia_server_runtime.a')]+link[link.index('libmedia_server_runtime.a')+1:]+['-o',str(binary)]
with (r/(label+'-build.log')).open('x') as f:result=subprocess.run(command,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
assert result.returncode==0
record={'buildCommand':command,'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'sourceDiffSha256':hashlib.sha256(subprocess.check_output(['git','diff'],cwd=repo)).hexdigest(),'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'runtimeSha256':hashlib.sha256((b/'libmedia_server_runtime.a').read_bytes()).hexdigest(),'command':[str(binary),str(root)]+([str(repo/'models/v430-siglip2')] if len(sys.argv)>2 else []),'iterations':3,'scope':'closed byte-identical originals copied; cold Open, no continuous cache state; no HTTP; no model run','deadlineSeconds':180,'logCapBytes':4*1024*1024}
env.update(MEDIA_SERVER_VERIFY_RECORDING_LATENCY_TRACE='1',MEDIA_SERVER_VERIFY_RECORDING_LATENCY_SLOW_ONLY='0' if len(sys.argv)>2 else '1',MEDIA_SERVER_VERIFY_VISUAL_REQUEST_TRACE='1',MEDIA_SERVER_VERIFY_CATALOG_HOLDER_TRACE='1',MEDIA_SERVER_VERIFY_CATALOG_HOLDER_WHOLE_REQUESTS='1',MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS='1')
if len(sys.argv)>2:env['MEDIA_SERVER_VERIFY_VISUAL_LATENCY_TRACE']='1'
from run_v450_recording_a_mixed import run_owned
start=time.monotonic();record.update(run_owned(record['command'],r/(label+'.log'),180,root,env,lambda pid:None));record['logBytes']=(r/(label+'.log')).stat().st_size
if record['logBytes']>record['logCapBytes']:record['status']='FAIL';record['logOverflow']=True
(r/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(record['exit'])
