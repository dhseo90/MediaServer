import pathlib,json,statistics,collections
r=pathlib.Path(__file__).parent

def rows(text,prefix):return [json.loads(l[len(prefix):]) for l in text.splitlines() if l.startswith(prefix)]
result={'scope':'same911file closed seed; sequential before then after, no livecache restoration; baseline and finalsource distinct','cost':{},'http':{}}
for label in ('before','after','after2'):
 p=r/('cost-'+label+'-run/output.log')
 if not p.exists():continue
 text=p.read_text();c=rows(text,'[retention-path-cost] ');v=rows(text,'[visual-request] ');h=rows(text,'[catalog-holder] ')
 result['cost'][label]={'measurements':c,'snapshotMeanMs':statistics.mean(x['elapsedNs'] for x in c)/1e6,'catalogHeldMeanMs':statistics.mean(x['locks'][0][2] for x in v)/1e6,'catalogCount':[x['locks'][0][0] for x in v],'finish':'[finish] true' in text,'limits':'snapshot elapsed excludes Digest; visual summary includes subsequent Digest; charged owner includes caller All/expected/output, not process liveheap or instantaneouspeak','execution':json.loads(p.with_name('execution.json').read_text())}
for label in ('before','after2'):
 p=r/(label+'-http/output.log')
 if not p.exists():continue
 text=p.read_text();v=rows(text,'[visual-request] ');h=rows(text,'[catalog-holder] ');ends=rows(text,'[catalog-holder-end] ')
 d={'execution':json.loads(p.with_name('execution.json').read_text()),'visualRequests':v,'holderEnd':ends,'selected':[],'resource':rows(text,'[recording-resource] '),'background':[l for l in text.splitlines() if l.startswith(('[R107-background]','[R107-result]','[R107-fail]'))]}
 for end in ends:
  request=end.get('request');waits=[(x['b'],x['a']) for x in h if x['m']==1 and x['r']==request];g=collections.defaultdict(lambda:{'calls':0,'heldNs':0,'maxHeldNs':0,'overlapNs':0})
  for x in h:
   if x['m']!=1:continue
   overlap=sum(max(0,min(b,x['e'])-max(a,x['a'])) for a,b in waits)
   if not overlap:continue
   key=f"work{x['work']}/{x['site']}/t{x['t']}/r{x['r']}";z=g[key];z['calls']+=1;z['heldNs']+=x['e']-x['a'];z['maxHeldNs']=max(z['maxHeldNs'],x['e']-x['a']);z['overlapNs']+=overlap
  total=sum(b-a for a,b in waits);classified=sum(z['overlapNs'] for z in g.values());d['selected'].append({'request':request,'catalogWaitNs':total,'attributedHolderOverlapNs':classified,'unattributedWaitNs':total-classified,'groups':dict(sorted(g.items(),key=lambda kv:-kv[1]['overlapNs']))})
 result['http'][label]=d
(r/'final-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cost':{k:{x:v[x] for x in ('snapshotMeanMs','catalogHeldMeanMs','finish')} for k,v in result['cost'].items()},'http':{k:{'exit':v['execution'].get('exit'),'qualification':v['execution'].get('qualification'),'requests':len(v['visualRequests'])} for k,v in result['http'].items()}},indent=2))
