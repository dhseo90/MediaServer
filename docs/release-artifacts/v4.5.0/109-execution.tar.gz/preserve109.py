import pathlib,json,hashlib,tarfile,io,os,subprocess
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');dest=repo/'docs/release-artifacts/v4.5.0/109-execution.tar.gz'
assert not dest.exists();st=r.lstat();assert r.resolve()==r and st.st_uid==os.getuid() and r.name=='media-server-r109-tuw3d0ca'
selected={}
for p in r.iterdir():
 if p.is_file() and not p.is_symlink() and p.suffix in {'.json','.log','.jsonl','.txt','.py','.sh','.cpp','.patch'}:selected[p.name]=p
for name in ['before-build','after-build','before-http','after-http','timeline-before-run','timeline3-before-run','timeline3-after-run']:
 folder=r/name
 if not folder.exists():continue
 for p in folder.iterdir():
  if p.is_file() and not p.is_symlink() and (p.suffix in {'.json','.log'} or p.name=='resource-phase'):selected[str(p.relative_to(r))]=p
# Exact seed authority stays in prior106, not copied again. Store final mutations as exact byte deltas.
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
seed={str(p.relative_to(r/'seed106')):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (r/'seed106').rglob('*') if p.is_file() and not p.is_symlink()}
assert len(seed)==911 and sum(x['bytes'] for x in seed.values())==50664710
stores={}
for name in ['before-http','after-http','timeline-before-run','timeline3-before-run','timeline3-after-run']:
 folder=r/name/'recording';files={};changed=[]
 for p in sorted(folder.rglob('*')):
  if p.is_symlink():raise RuntimeError('symlink in store')
  if not p.is_file():continue
  rel=str(p.relative_to(folder));h=sha(p);files[rel]={'bytes':p.stat().st_size,'sha256':h}
  if seed.get(rel,{}).get('sha256')!=h:
   key=str(p.relative_to(r));selected[key]=p;changed.append(rel)
 stores[name]={'files':files,'deltaMembers':changed,'missingSeedPaths':sorted(seed.keys()-files.keys()),'unchangedSource':'same relative recording path in seedSource below'}
seed_source={'preservationCommit':subprocess.check_output(['git','rev-parse','5f9d86b343ca2f26a3f89f4d39fa789dc77c2bfc'],cwd=repo,text=True).strip(),'gitPaths':sorted(str(p.relative_to(repo)) for p in (repo/'docs/release-artifacts/v4.5.0').glob('106-execution.tar.gz*')),'archivePrefix':'after900/media-server-current-observer-VJTJaz/recordings/','files':seed}
(r/'store-delta-bindings.json').write_text(json.dumps({'seedSource':seed_source,'stores':stores},indent=2));selected['store-delta-bindings.json']=r/'store-delta-bindings.json'
manifest={'schema':'media-server.r109.selected-evidence.v1','rawRule':'logs/execution remain original bytes; analysis separate; no private config or prior large archives','members':{k:{'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in selected.items()}}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
with tarfile.open(dest,'w:gz') as t:
 for k,p in sorted(selected.items()):t.add(p,arcname=k,recursive=False)
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mode=0o600;t.addfile(info,io.BytesIO(raw))
assert dest.stat().st_size<95*1024*1024
with tarfile.open(dest) as t:
 for k,v in manifest['members'].items():
  b=t.extractfile(k).read();assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
record={'path':str(dest.relative_to(repo)),'bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(selected)+1,'payloadBytes':sum(v['bytes'] for v in manifest['members'].values()),'allSourceMemberBytesEqual':True,'storeDeltas':{k:len(v['deltaMembers']) for k,v in stores.items()},'seedReusedNotDuplicated':True}
(r/'preservation-local.json').write_text(json.dumps(record,indent=2));print(json.dumps(record))
