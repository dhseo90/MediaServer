import json,pathlib,re,math,statistics
p=pathlib.Path(__file__).parent;out={};bodies={}
for name in ['before-http','after-http']:
 r=p/name;lines=(r/'output.log').read_text().splitlines();rows=lambda s:[json.loads(x[len(s):]) for x in lines if x.startswith(s)]
 http=[];body=[]
 for x in lines:
  m=re.fullmatch(r'\[R107-http\] round=(\d+) client=(\d+) ms=([0-9.e+-]+) response=(.*)',x)
  if m:
   a,c,t,b=m.groups();http.append({'round':int(a),'client':int(c),'ms':float(t)});body.append({'round':int(a),'client':int(c),'body':json.loads(b)})
 bodies[name]=body;ts=sorted(x['ms'] for x in http);stages=rows('[recording-completion] ');stages=[x for x in stages if x['event']==15];stage={}
 for n in range(101,107):
  rr=[x for x in stages if x['n']==n];ms=[(int(x['end'])-int(x['begin']))/1e6 for x in rr];stage[n]={'calls':len(rr),'ms':ms,'meanMs':statistics.mean(ms) if ms else None,'visitedOrExcluded':[x['x'] for x in rr],'readsOrVisited':[x['y'] for x in rr]}
 space=rows('[R101-space] ');end=rows('[R101-space-end] ');owners=rows('[recording-resource] ');final=[x for x in owners if x['phase']=='after-storage-destruction'];resource={}
 for phase in ['initial','model','live']:
  rr=[x for x in space if x['phase']==phase];resource[phase]={'samples':len(rr),'maxima':{k:max((x['metrics'][k] for x in rr),default=None) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'workspaceVariableMax':max((x['bounds']['variableBytes'] for x in rr),default=None)}
 bg=next((x for x in lines if x.startswith('[R107-background] ')),None);ready=rows('[R107-ready] ')
 out[name]={'execution':json.loads((r/'execution.json').read_text()),'http':http,'p95Ms':ts[math.ceil(.95*len(ts))-1] if ts else None,'maxMs':max(ts,default=None),'result':[x for x in lines if x.startswith(('[R107-result]','[R107-fail]'))],'background':bg,'initialGeneration':ready[0]['index']['generation'] if ready else None,'stages':stage,'samples':len(space),'collectionComplete':bool(len(end)==1 and end[0]['samples']==len(space) and end[0]['endedObserved'] and all(x['metrics']['valid'] and x['metrics']['fdObservation']['complete'] for x in space)),'resources':resource,'finalOwner':final,'holderEnd':rows('[catalog-holder-end] '),'requestAnalysis':json.loads((r/'request-analysis-v2.json').read_text())}
 (r/'http-bodies-analysis.json').write_text(json.dumps(body,indent=2)+'\n')
visual=[];structured=[]
for a,b in zip(bodies['before-http'],bodies['after-http']):
 assert (a['round'],a['client'])==(b['round'],b['client'])
 ai=a['body']['items'];bi=b['body']['items']
 if a['client']<2:visual.append(ai==bi)
 else:
  aa={v['id']:v for v in ai};bb={v['id']:v for v in bi};common=set(aa)&set(bb);structured.append({'common':len(common),'equal':all(aa[k]==bb[k] for k in common),'beforeOnly':len(set(aa)-set(bb)),'afterOnly':len(set(bb)-set(aa))})
out['comparison']={'visualItemsExact':visual,'structuredCommon':structured,'limits':['single before then after; OS cache/scheduling and concurrent cut not identical','selected field public timeline hash only','stage time excludes CanRead/context setup/final save; lock remains held','sequential FD and sample maxima not instant peak','direct HTTP lacks repeated evidence/A workload; deleted0 not gate']}
(p/'final-http-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for k in ['before-http','after-http']:
 d=out[k];print(k,'p95',d['p95Ms'],'stages',[(n,v['meanMs'],v['calls']) for n,v in d['stages'].items()],'complete',d['collectionComplete'])
print(out['comparison'])
