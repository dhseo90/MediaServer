import pathlib,json,hashlib,tarfile,io
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');target=repo/'docs/release-artifacts/v4.5.0/110-execution.tar.gz';assert not target.exists()
selected={}
def add(p,member=None):
 assert p.is_file() and not p.is_symlink();b=p.read_bytes();selected[member or str(p.relative_to(r))]=(p,b)
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.mjs','.patch','.sh','.txt'):add(p)
deltas={}
for label in ['before-build','after-build','before-http','after-http','timeline-after-run']:
 folder=r/label
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ('.json','.log'):add(p)
 if (folder/'recording').is_dir():
  store={}
  for p in sorted((folder/'recording').rglob('*')):
   if not p.is_file():continue
   assert not p.is_symlink();rel=p.relative_to(folder/'recording');b=p.read_bytes();base=r/'seed106'/rel;sha=hashlib.sha256(b).hexdigest();same=base.is_file() and b==base.read_bytes()
   store[str(rel)]={'bytes':len(b),'sha256':sha,'source':'106 original seed reused' if same else 'new run delta'}
   if not same:add(p)
  deltas[label]=store
raw=json.dumps({'seed':'106 archive after900/media-server-current-observer-VJTJaz/recordings; same911files as109 input hash map','stores':deltas},indent=2).encode();selected['store-delta-bindings.json']=(None,raw)
manifest={k:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for k,(p,b) in selected.items()}
with tarfile.open(target,'w:gz') as t:
 for k,(p,b) in selected.items():
  i=tarfile.TarInfo(k);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(target) as t:
 for k,(p,b) in selected.items():assert t.extractfile(k).read()==b
receipt={'path':str(target.relative_to(repo)),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'payloadMembers':len(selected),'payloadBytes':sum(len(b) for p,b in selected.values()),'allOriginalBytesEqual':True,'seedNotDuplicated':True,'storeDeltaMembers':{k:sum(v['source']=='new run delta' for v in d.values()) for k,d in deltas.items()}}
(r/'preservation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
