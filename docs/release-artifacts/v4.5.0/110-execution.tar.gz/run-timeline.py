import pathlib,sys,shutil,subprocess,time,hashlib,json
p=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');sys.path.insert(0,str(repo/'scripts/internal'))
from recording_native_isolation import environment
root=p/'timeline-after-run';root.mkdir(mode=0o700);env=environment(root);shutil.copytree(p/'seed106',root/'recording',dirs_exist_ok=True)
a={str(f.relative_to(root/'recording')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'recording').rglob('*') if f.is_file()};expected=json.loads((p/'before-http/input-binding.json').read_text())['files'];assert a==expected
env.update(MEDIA_SERVER_VERIFY_RECORDING_LATENCY_TRACE='1',MEDIA_SERVER_VERIFY_CATALOG_HOLDER_TRACE='1',MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS='1',MEDIA_SERVER_VERIFY_RECORDING_LATENCY_SLOW_ONLY='1')
command=[str(p/'timeline-after'),str(root)];t=time.monotonic();r=subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
assert len(r.stdout)<=4*1024*1024
(root/'output.log').write_bytes(r.stdout);(root/'execution.json').write_text(json.dumps({'command':command,'exit':r.returncode,'elapsedSeconds':time.monotonic()-t,'bytes':len(r.stdout),'binarySha256':hashlib.sha256((p/'timeline-after').read_bytes()).hexdigest(),'inputMatchesSeed':True,'historicalOracle':'109 after selected field digests; not new before performance'},indent=2));print(r.returncode)
