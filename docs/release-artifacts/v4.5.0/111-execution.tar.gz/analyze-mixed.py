import json,pathlib,collections,sys,math,re
p=pathlib.Path(sys.argv[1]);text=(p/'server-1.private.log').read_text();rows=lambda s:[json.loads(x[len(s):]) for x in text.splitlines() if x.startswith(s)]
h=rows('[catalog-holder] ');requests=rows('[visual-request] ');result={}
for req in requests:
 rid=req['id'];own=[x for x in h if x['r']==rid];groups={};gaps=[]
 for w in own:
  intervals=[]
  for e in h:
   if e['m']!=w['m']:continue
   a,b=max(w['b'],e['a']),min(w['a'],e['e'])
   if b<=a:continue
   key=f"{e['work']}:{e['site']}:{e['l']}:peer{e['r']}:thread{e['t']}"
   g=groups.setdefault(key,{'overlapNs':0,'count':0,'maxHoldNs':0,'heldNs':0,'ids':set(),'counts':[0]*4});g['overlapNs']+=b-a
   if e['id'] not in g['ids']:
    g['ids'].add(e['id']);g['count']+=1;g['heldNs']+=e['e']-e['a'];g['maxHoldNs']=max(g['maxHoldNs'],e['e']-e['a']);g['counts']=[x+y for x,y in zip(g['counts'],e['counts'])]
   intervals.append((a,b))
  cursor=w['b']
  for a,b in sorted(intervals):
   if a>cursor:gaps.append({'ns':a-cursor,'begin':cursor,'end':a,'waitSite':w['site']})
   cursor=max(cursor,b)
  if cursor<w['a']:gaps.append({'ns':w['a']-cursor,'begin':cursor,'end':w['a'],'waitSite':w['site']})
 owncost={}
 for x in own:
  g=owncost.setdefault(x['site'],{'n':0,'waitNs':0,'heldNs':0,'counts':[0]*4});g['n']+=1;g['waitNs']+=x['a']-x['b'];g['heldNs']+=x['e']-x['a'];g['counts']=[a+b for a,b in zip(g['counts'],x['counts'])]
 for g in groups.values():del g['ids']
 result[rid]={'summary':req,'capturedLocks':len(own),'own':owncost,'overlap':dict(sorted(groups.items(),key=lambda v:-v[1]['overlapNs'])),'observedWindowUnattributedNs':sum(x['ns'] for x in gaps) if own else None,'wholeRequestHolderCaptured':len(own)==req['locks'][0][0],'unattributedNs':sum(x['ns'] for x in gaps) if len(own)==req['locks'][0][0] else None,'largestGaps':sorted(gaps,key=lambda x:-x['ns'])[:10]}
http=[]
for l in text.splitlines():
 m=re.match(r'\[R107-http\] round=(\d+) client=(\d+) ms=([0-9.e+-]+)',l)
 if m:http.append({'round':int(m[1]),'client':int(m[2]),'ms':float(m[3])})
out={'requests':result,'holderEnd':rows('[catalog-holder-end] '),'http':http,'result':[l for l in text.splitlines() if l.startswith(('[R107-result]','[R107-background]','[R107-fail]'))]}
(p/'request-analysis-v2.json').write_text(json.dumps(out,indent=2)+'\n')
for rid,r in result.items():
 print('request',rid,'ms',r['summary']['elapsedNs']/1e6,'catalog',r['summary']['locks'][0],'captured',r['capturedLocks'],'unattributedMs',r['unattributedNs']/1e6 if r['unattributedNs'] is not None else 'unobserved-or-partial')
 if r['capturedLocks']:
  for k,v in list(r['overlap'].items())[:8]:print(k,'overlapMs',round(v['overlapNs']/1e6,3),'n',v['count'],'maxMs',round(v['maxHoldNs']/1e6,3),'subcosts',v['counts'])
print(out['result'],out['holderEnd'])
