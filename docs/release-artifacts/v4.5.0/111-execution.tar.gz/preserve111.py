import pathlib,json,hashlib,tarfile,io,re
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');dest=repo/'docs/release-artifacts/v4.5.0';selected={};trans=[];excluded=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def add(p,member=None):
 assert p.is_file() and not p.is_symlink();k=member or str(p.relative_to(r));assert k not in selected;selected[k]=(p,None)
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.mjs','.patch','.sh','.txt') and p.name not in ('semantic-candidate.json','preservation-receipt.json','preserve.log'):add(p)
labels=['before-build','before-B','before-A','before-C','detail-build','detail-C','after-build','after-finalbuild','after-B','after-A','after-C','after2-build','after2-B','after2p-B','after2-B-authorized','after2-A-authorized','after2-C-authorized']
deltas={}
for label in labels:
 folder=r/label
 if not folder.is_dir():continue
 for p in folder.iterdir():
  if p.is_file() and p.suffix in ('.json','.log'):add(p)
 store={}
 for p in sorted((folder/'recording').rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink();rel=p.relative_to(folder/'recording');b=p.read_bytes();base=r/'seed106'/rel;same=base.is_file() and b==base.read_bytes();store[str(rel)]={'bytes':len(b),'sha256':sha(b),'source':'106 original seed reused' if same else 'new run delta'}
  if not same:add(p)
 if store:deltas[label]=store
for p in (r/'after900').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r/'after900');parts=rel.parts
 if any(x in ('state','gst-cache') for x in parts) or p.name in ('normalize','process-metrics','review-seed','registry.bin'):
  excluded.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'reason':'generated settings/credentials or tool/cache binary; not source evidence'});continue
 if p.name.endswith('.private.log'):
  raw=p.read_bytes();clean,n=re.subn(rb'\b(?:https?|rtsp|rtsps|udp|tcp)://[^\s"<>]+',b'[REDACTED-URL]',raw);member=str(p.relative_to(r)).replace('.private.log','.sanitized.log');selected[member]=(None,clean);trans.append({'originalPath':str(p.relative_to(r)),'archivedPath':member,'originalBytes':len(raw),'originalSha256':sha(raw),'transformedBytes':len(clean),'transformedSha256':sha(clean),'rule':'URL tokens only; retain all other lines/values','replacements':n});continue
 add(p)
# Prior scripts are reused references, not copied old execution archives. Preserve
# the two analysis/qualification sources actually consumed by this run.
for name in ['analyze-v2.py'] :add(r/'prior'/name)
b=json.dumps({'seed':'106 archive parts / after900/media-server-current-observer-VJTJaz/recordings; original911 files reused byte-for-byte','stores':deltas},indent=2).encode();selected['store-delta-bindings.json']=(None,b)
b=json.dumps({'transformations':trans,'excluded':excluded,'semanticCandidate':'full JSON equal existing approved audit; see semantic-comparison.json; unchanged7.7MB candidate omitted'},indent=2).encode();selected['preservation-scope.json']=(None,b)
manifest={}
archive=r/'111-execution.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for k,(p,raw) in selected.items():
  b=raw if p is None else p.read_bytes();manifest[k]={'bytes':len(b),'sha256':sha(b)};i=tarfile.TarInfo(k);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 for k,(p,raw) in selected.items():
  b=t.extractfile(k).read();assert b==(raw if p is None else p.read_bytes());assert sha(b)==manifest[k]['sha256']
blob=archive.read_bytes();parts=[];limit=50*1024*1024
for n,at in enumerate(range(0,len(blob),limit),1):
 name='111-execution.tar.gz'+(f'.part{n:03}' if len(blob)>limit else '');p=dest/name;assert not p.exists();b=blob[at:at+limit];p.write_bytes(b);assert p.read_bytes()==b;parts.append({'path':str(p.relative_to(repo)),'bytes':len(b),'sha256':sha(b)})
receipt={'archive':'111-execution.tar.gz; ordered parts if split','bytes':len(blob),'sha256':sha(blob),'parts':parts,'payloadMembers':len(manifest),'payloadBytes':sum(x['bytes'] for x in manifest.values()),'allSelectedOriginalBytesEqual':True,'transformations':trans,'excludedFileCount':len(excluded),'seedNotDuplicated':True};(r/'preservation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
