import json,pathlib,re,sys,math
r=pathlib.Path(__file__).parent;label=sys.argv[1];p=r/label;t=(p/'output.log').read_text()
def rows(prefix):return [json.loads(l[len(prefix):]) for l in t.splitlines() if l.startswith(prefix)]
http=[]
for l in t.splitlines():
 m=re.fullmatch(r'\[R107-http\] round=(\d+) client=(\d+) ms=([0-9.e+-]+) response=(.*)',l)
 if m:http.append({'round':int(m[1]),'client':int(m[2]),'ms':float(m[3]),'body':json.loads(m[4])})
v=rows('[visual-request] ');o=rows('[recording-resource] ');s=rows('[R101-space] ');x=json.loads((p/'execution.json').read_text())
times=sorted(h['ms'] for h in http)
result={'label':label,'exit':x['exit'],'requests':len(http),'p95Ms':times[math.ceil(.95*len(times))-1] if times else None,'maxMs':max(times) if times else None,'http':http,'visual':v,'samples':len(s),'allSamplesComplete':bool(s) and all(a['metrics']['valid'] and a['metrics']['fdObservation']['complete'] for a in s),'processSampleMax':{k:max(a['metrics'][k] for a in s) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']} if s else {},'ownerSampleMax':{k:max(a[k] for a in o) for k in ['ram','ramPeak','scratchDisk','scratchDiskPeak','scratchFd','scratchFdPeak']} if o else {},'finalOwner':[a for a in o if a['phase']=='after-storage-destruction'],'background':[l for l in t.splitlines() if l.startswith(('[R107-background]','[R107-result]','[R107-fail]'))],'elapsedSeconds':x['elapsedSeconds']}
result['spaceByPhase']={phase:{'samples':sum(a['phase']==phase for a in s),'anonymousLogicalMax':max(a['metrics']['anonymousFileBytes'] for a in s if a['phase']==phase),'anonymousAllocatedMax':max(a['metrics']['anonymousAllocatedBytes'] for a in s if a['phase']==phase),'fdMax':max(a['metrics']['fdCount'] for a in s if a['phase']==phase)} for phase in sorted({a['phase'] for a in s})}
(p/'summary111.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['label','exit','requests','p95Ms','maxMs','samples','allSamplesComplete','processSampleMax','ownerSampleMax','elapsedSeconds']}))
