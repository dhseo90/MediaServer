#!/bin/bash
set -euo pipefail
r=/tmp/media-server-r112-linux
mkdir -m 700 "$r" "$r/work" "$r/output"
trap 'prior=$?; for log in "$r"/output/*.log; do [ -f "$log" ] || continue; printf "[linux-log] %s\n" "$log"; cat "$log"; done; printf "[linux-exit] %s\n" "$prior"; exit "$prior"' EXIT
export TMPDIR="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
id
cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" --target media_server -j 2 > "$r/output/build.log" 2>&1
python3 - <<'PY'
import pathlib,shlex,subprocess,sys
sys.path.insert(0,'/source/scripts/internal');from recording_native_isolation import environment
r=pathlib.Path('/tmp/media-server-r112-linux');b=r/'build';root=r/'fixture';root.mkdir(mode=0o700);env=environment(root);env['LD_LIBRARY_PATH']='/opt/onnxruntime-linux-aarch64-1.23.2/lib'
f={}
for line in (b/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);f[k]=shlex.split(v)
l=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());libs=l[l.index('libmedia_server_runtime.a')+1:]
for name in ['recording_preserved_frame_smoke','visual_frame_decoder_smoke','evidence_package_smoke']:
 cmd=[l[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I/source/scripts/internal','/source/scripts/internal/'+name+'.cpp',str(b/'libmedia_server_runtime.a')]+libs+['-o',str(r/name)]
 with (r/'output'/(name+'-build.log')).open('w') as out:subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90,check=True)
for label,name,args in [('preserved','recording_preserved_frame_smoke',['/input/repro.mp4']),('software','visual_frame_decoder_smoke',[str(root/'software.mp4'),'--software-only']),('automatic','visual_frame_decoder_smoke',[str(root/'automatic.mp4')]),('package','evidence_package_smoke',[str(root)])]:
 with (r/'output'/(label+'.log')).open('w') as out:subprocess.run([str(r/name)]+args,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=90,check=True)
PY
