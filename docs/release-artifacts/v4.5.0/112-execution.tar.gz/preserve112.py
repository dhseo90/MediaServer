import pathlib,json,hashlib,tarfile,subprocess,io,os
r=pathlib.Path('/private/tmp/media-server-r112-qkx3cxrv');repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');out=repo/'docs/release-artifacts/v4.5.0';target=out/'112-execution.tar.gz'
assert not target.exists()
(r/'implementation.patch').write_bytes(subprocess.check_output(['git','diff','623832a599f86ef5a96f141a03363e6b9c7f82da','a2fda4029ac1fa1b5dcd6c0701e6db0999860d8f','--','src','include','scripts/internal','docs/project-feature-test-inventory.md']))
(r/'binary-binding.json').write_text(json.dumps({'mac':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.iterdir() if p.is_file() and (p.name.startswith('probe-') and p.suffix=='' or p.name in ['recording_preserved_frame_smoke','visual_frame_decoder_smoke','evidence_package_smoke'])},'runtime':json.loads((r/'final-source-freeze.json').read_text())['runtimeSha256'],'linux':'source/runtime/build logs retained; per-binary hash not separately captured'},indent=2)+'\n')
allowed={'.json','.log','.txt','.cpp','.sh','.py','.stdout','.stderr','.exit','.patch'}
items=[]
for p in sorted(r.iterdir()):
 if not p.is_file() or p.suffix not in allowed or p.name=='candidate.json' or p.name.startswith('prior-'):continue
 assert not p.is_symlink();items.append((p.name,p))
for name in ['preserved-packages','concurrent-packages']:
 for p in sorted((r/'package4'/name).iterdir()):
  assert p.is_file() and not p.is_symlink();items.append(('package4/'+name+'/'+p.name,p))
rows=[]
for name,p in items:
 b=p.read_bytes();assert len(b)<=4*1024*1024,(name,len(b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema':'media-server.v450.r112.execution-manifest.v1','files':rows,'sourceCommit':'a2fda4029ac1fa1b5dcd6c0701e6db0999860d8f','excluded':'old111 archive/MP4/full store copies, models, SDK, settings/private backup, executables and GST cache','originalBindings':'selected-originals.json/package-source-original-map.json reference existing111 archive','classes':{'originalNew':'direct logs and generated package bytes','analysis':'decode-comparison/search-handoff/segment-records/file-evidence','source':'implementation.patch and final-source-freeze; diagnostic local copies distinct'},'candidateOmitted':'candidate-delta proves exact semantic equality with existing committed source audit; legacy digest is not new behavior approval'}
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
with tarfile.open(target,'x:gz') as t:
 for name,p in items:t.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('manifest.json');info.size=len(mb);info.mode=0o600;t.addfile(info,io.BytesIO(mb))
with tarfile.open(target) as t:
 for row in rows:
  m=t.getmember(row['path']);assert m.isfile();b=t.extractfile(m).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
summary={'archiveBytes':target.stat().st_size,'archiveSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'payloadFiles':len(rows),'uncompressedBytes':sum(x['bytes'] for x in rows),'readbackMismatches':0}
(out/'112-preservation.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
