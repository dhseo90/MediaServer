#include "recording/visual_frame_decoder.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <iostream>
int main(int argc,char**argv){if(argc!=3)return 2;int fd=open(argv[1],O_RDONLY|O_NOFOLLOW);struct stat s{};if(fd<0||fstat(fd,&s))return 2;lseek(fd,37,SEEK_SET);recording::VisualRgbFrame frame;std::string error;bool ok=recording::DecodeVisualFrame(fd,s.st_size,std::stoll(argv[2]),&frame,&error,{},5000,recording::VisualDecodePolicy::SoftwareOnly);std::cout<<"result="<<ok<<" error="<<error<<" ns="<<frame.presentation_ns<<" rgb="<<frame.rgb.size()<<" offset="<<lseek(fd,0,SEEK_CUR)<<"\n";close(fd);return ok?0:1;}
