#!/bin/bash
set -eu
cd /Users/dhseo/Workspace/mediaServer
r=/private/tmp/media-server-r112-qkx3cxrv
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
python3 - "$r" <<'PY'
import subprocess,sys,pathlib,shutil,os,json
r=pathlib.Path(sys.argv[1]);records=[]
with (r/'avdec-authorized.txt').open('xb') as o:
 p=subprocess.run(['gst-inspect-1.0','avdec_h264'],stdout=o,stderr=subprocess.STDOUT,timeout=20);records.append({'tool':'gst-inspect','exit':p.returncode})
shutil.copyfile(r/'prior/after900/media-server-current-observer-K5sGlB/recordings/9101/59dfb25c-a7eb-4333-bb29-3d7ae4b42fa6.mp4',r/'repro.mp4')
with (r/'before.stdout').open('xb') as o,(r/'before.stderr').open('xb') as e:
 p=subprocess.run([str(r/'probe-before'),str(r/'repro.mp4'),'1966666667'],env=dict(os.environ,MEDIA_SERVER_VERIFY_FRAME_TRACE='1'),stdout=o,stderr=e,timeout=15);records.append({'tool':'productdecode','exit':p.returncode})
(r/'before-execution.json').write_text(json.dumps(records,indent=2)+'\n')
PY
