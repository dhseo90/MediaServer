#!/bin/bash
set -eu
cd /Users/dhseo/Workspace/mediaServer
r=/private/tmp/media-server-r112-qkx3cxrv
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
c++ -std=c++17 -Wall -Wextra -Werror -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=1 $(pkg-config --cflags gstreamer-app-1.0 gstreamer-video-1.0) "$r/probe.cpp" src/recording/visual_frame_decoder.cpp $(pkg-config --libs gstreamer-app-1.0 gstreamer-video-1.0) -o "$r/probe-before"
gst-inspect-1.0 avdec_h264 > "$r/avdec-properties.txt"
cp "$r/prior/after900/media-server-current-observer-K5sGlB/recordings/9101/59dfb25c-a7eb-4333-bb29-3d7ae4b42fa6.mp4" "$r/repro.mp4"
set +e
MEDIA_SERVER_VERIFY_FRAME_TRACE=1 "$r/probe-before" "$r/repro.mp4" 1966666667 > "$r/before.stdout" 2> "$r/before.stderr"
echo $? > "$r/before.exit"
