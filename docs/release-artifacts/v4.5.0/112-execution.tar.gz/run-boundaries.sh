#!/bin/bash
set -eu
cd /Users/dhseo/Workspace/mediaServer
r=/private/tmp/media-server-r112-qkx3cxrv
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
python3 - "$r" <<'PY'
import pathlib,json,sys
r=pathlib.Path(sys.argv[1]);(r/'boundary-plan.json').write_text(json.dumps({'calls':{'traceTarget':1,'actualDeadline':1,'GSToff':1},'target':1966666667,'file':'repro.mp4','ordinaryBudgetMs':5000,'deadlineInjectionMs':1,'cancelCallbackDelayMs':2,'limitsUnchanged':True})+'\n')
s=(r/'probe.cpp').read_text().replace('#include <iostream>','#include <iostream>\n#include <thread>\n#include <chrono>');s=s.replace('{},5000,','[]{std::this_thread::sleep_for(std::chrono::milliseconds(2));return false;},1,');(r/'probe-deadline.cpp').write_text(s)
PY
c++ -std=c++17 -Wall -Wextra -Werror -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=1 $(pkg-config --cflags gstreamer-app-1.0 gstreamer-video-1.0) "$r/probe.cpp" src/recording/visual_frame_decoder.cpp $(pkg-config --libs gstreamer-app-1.0 gstreamer-video-1.0) -o "$r/probe-after"
c++ -std=c++17 -Wall -Wextra -Werror -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=1 $(pkg-config --cflags gstreamer-app-1.0 gstreamer-video-1.0) "$r/probe-deadline.cpp" src/recording/visual_frame_decoder.cpp $(pkg-config --libs gstreamer-app-1.0 gstreamer-video-1.0) -o "$r/probe-deadline"
c++ -std=c++17 -Wall -Wextra -Werror -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=0 "$r/probe.cpp" src/recording/visual_frame_decoder.cpp -o "$r/probe-disabled"
python3 - "$r" <<'PY'
import subprocess,pathlib,sys,json,os
r=pathlib.Path(sys.argv[1]);out=[]
for name,expected in [('after',0),('deadline',1),('disabled',1)]:
 with (r/('boundary-'+name+'.log')).open('xb') as f:p=subprocess.run([str(r/('probe-'+name)),str(r/'repro.mp4'),'1966666667'],env=dict(os.environ,MEDIA_SERVER_VERIFY_FRAME_TRACE='1'),stdout=f,stderr=subprocess.STDOUT,timeout=15)
 out.append({'name':name,'exit':p.returncode,'expected':expected})
 assert p.returncode==expected
(r/'boundary-results.json').write_text(json.dumps(out,indent=2)+'\n')
PY
