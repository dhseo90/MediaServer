#!/bin/bash
set -eu
cd /Users/dhseo/Workspace/mediaServer
r=/private/tmp/media-server-r112-qkx3cxrv
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
python3 - "$r" <<'PY'
import subprocess,sys,pathlib,os,json
r=pathlib.Path(sys.argv[1]);plan={'calls':1,'scope':'same sequential diagnostic; bounded libav/videodecoder detail to locate first dropped sample; no performance trial','deadlineSeconds':15,'logCapBytes':1048576};(r/'decoder-edges-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
p=subprocess.Popen([str(r/'probe-sequential'),str(r/'repro.mp4'),'1966666667'],env=dict(os.environ,MEDIA_SERVER_VERIFY_FRAME_TRACE='1',GST_DEBUG='libav:6,videodecoder:5,h264parse:4',GST_DEBUG_NO_COLOR='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
try:b,_=p.communicate(timeout=15)
except subprocess.TimeoutExpired:p.kill();b,_=p.communicate();(r/'decoder-edges.log').write_bytes(b);raise
(r/'decoder-edges.log').write_bytes(b);assert len(b)<=1048576
(r/'decoder-edges-execution.json').write_text(json.dumps({'exit':p.returncode,'bytes':len(b)})+'\n')
PY
