#!/bin/bash
set -eu
cd /Users/dhseo/Workspace/mediaServer
r=/private/tmp/media-server-r112-qkx3cxrv
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
c++ -std=c++17 -Wall -Wextra -Werror -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=1 $(pkg-config --cflags gstreamer-app-1.0 gstreamer-video-1.0) "$r/probe.cpp" "$r/decoder-owned-output.cpp" $(pkg-config --libs gstreamer-app-1.0 gstreamer-video-1.0) -o "$r/probe-owned-output"
python3 - "$r" <<'PY'
import pathlib,subprocess,os,sys,json
r=pathlib.Path(sys.argv[1])
with (r/'owned-output.stdout').open('xb') as o,(r/'owned-output.stderr').open('xb') as e:
 p=subprocess.run([str(r/'probe-owned-output'),str(r/'repro.mp4'),'1966666667'],env=dict(os.environ,MEDIA_SERVER_VERIFY_FRAME_TRACE='1'),stdout=o,stderr=e,timeout=15)
(r/'owned-output-execution.json').write_text(json.dumps({'exit':p.returncode})+'\n')
PY
