from pathlib import Path
import json,hashlib,tarfile,io,re
r=Path(__file__).parent;dest=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0');selected={};trans=[];excluded=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for p in r.rglob('*'):
 rel=p.relative_to(r);parts=rel.parts
 if p.is_dir():continue
 if any(x in ['state','gst-cache'] for x in parts) or p.name in ['normalize','process-metrics','review-seed','registry.bin']:
  excluded.append({'path':str(rel),'reason':'isolated settings/credentials, cache or binary; not archived'});continue
 assert not p.is_symlink(),str(p)
 if len(parts)==1 and p.name not in ['entry.json','analysis.json','analyze113.py','failure-segment-binding.json','preserve113.py','independent-result.json','preparation.json']:continue
 b=p.read_bytes();name=str(rel)
 if p.name.endswith('.private.log'):
  clean,n=re.subn(rb'\b(?:https?|rtsp|rtsps|udp|tcp)://[^\s"<>]+',b'[REDACTED-URL]',b);name=name.replace('.private.log','.sanitized.log');trans.append({'originalPath':str(rel),'archivedPath':name,'originalBytes':len(b),'originalSha256':sha(b),'transformedBytes':len(clean),'transformedSha256':sha(clean),'rule':'URL tokens only; other bytes retained','replacements':n});b=clean
 selected[name]=b
selected['preservation-scope.json']=json.dumps({'transforms':trans,'excluded':excluded,'note':'Only new R113 synthetic owned run; no prior archive/config/private95backup/model/SDK; decoder trace covers3 representative successes, not every extraction'},indent=2).encode()
manifest={k:{'bytes':len(b),'sha256':sha(b)} for k,b in selected.items()};archive=r/'113-execution.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for k,b in selected.items():
  i=tarfile.TarInfo(k);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 for k,b in selected.items():assert t.extractfile(k).read()==b
blob=archive.read_bytes();parts=[];limit=50*1024*1024
for n,at in enumerate(range(0,len(blob),limit),1):
 name='113-execution.tar.gz'+(f'.part{n:03}' if len(blob)>limit else '');p=dest/name;assert not p.exists();b=blob[at:at+limit];p.write_bytes(b);assert p.read_bytes()==b;parts.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
receipt={'archiveSha256':sha(blob),'archiveBytes':len(blob),'payloadMembers':len(selected),'payloadBytes':sum(len(x) for x in selected.values()),'byteReadbackMismatches':0,'parts':parts,'sanitizedPrivateLogs':trans,'excludedFiles':len(excluded)}
(r/'preservation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='sanitizedPrivateLogs'},indent=2))
