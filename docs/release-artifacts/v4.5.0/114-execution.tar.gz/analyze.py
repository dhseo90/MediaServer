import pathlib,json,zlib,base64,hashlib,tarfile,subprocess,struct
r=pathlib.Path('/private/tmp/media-server-r114-vgfn95ff');arc=pathlib.Path('docs/release-artifacts/v4.5.0/113-execution.tar.gz');prefix='after900/media-server-current-observer-yqaE8x/recordings/'
rows=[]
for n,line in enumerate((r/'original'/prefix/'active-9.jsonl').read_text().splitlines(),1):
 x=json.loads(line)
 if x.get('codec')=='zlib-base64':
  raw=zlib.decompress(base64.b64decode(x['data']));assert len(raw)==x['length'] and zlib.crc32(raw)==x['crc32'];x=json.loads(raw)
 if x.get('mutationType')=='segment_v2_bound_finalized' and x['payload']['segment']['channel_id']=='9201':rows.append({'line':n,**x['payload']})
print([(x['segment']['order_sequence'],x['segment']['segment_id'],list(x)) for x in rows])
# Only directly adjacent finalized channel9201 rows in the retained active journal.
target=next(i for i,x in enumerate(rows) if x['segment']['order_sequence']==734);selected=rows[max(0,target-1):target+2]
with tarfile.open(arc) as t:
 for x in selected:
  name=prefix+'9201/'+x['segment']['segment_id']+'.mp4';m=t.getmember(name);assert m.isfile() and not m.issym() and not m.islnk() and not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
  p=r/'original'/name
  if not p.exists():
   p.parent.mkdir(parents=True,exist_ok=True);p.open('xb').write(t.extractfile(m).read())
  b=p.read_bytes();assert len(b)==x['segment']['size_bytes'] and hashlib.sha256(b).hexdigest()==x['segment']['checksum_sha256']
(r/'neighbor-boundings.json').write_text(json.dumps(selected,indent=2)+'\n')
# Independent packet oracle: no product RAM is included in this offline parser.
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_packets','-show_streams','-show_data_hash','sha256','-of','json',str(p)],stderr=subprocess.DEVNULL))
input=probe(r/'original/after900/media-server-current-observer-yqaE8x/input/retention-9201.mp4');lookup={p['data_hash']:i+1 for i,p in enumerate(input['packets'])};assert len(lookup)==120
result=[]
for x in selected:
 s=x['segment'];p=r/'original'/prefix/'9201'/(s['segment_id']+'.mp4');v=probe(p);(r/(s['segment_id']+'-packets.json')).write_text(json.dumps(v,indent=2)+'\n')
 result.append({'order':s['order_sequence'],'id':s['segment_id'],'bytes':s['size_bytes'],'sha256':s['checksum_sha256'],'ordinalsByExactAUHash':[lookup[q['data_hash']] for q in v['packets']],'payloadBytes':sum(int(q['size']) for q in v['packets']), 'sourceBinding':{k:v for k,v in x.get('sourceBinding',x.get('binding',{})).items() if k in ['source_generation','generation_order','media_epoch_id']}})
(r/'neighbor-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
# Bound on dynamic sample tables. Other boxes are fixed by this one-track AVC fixture and mux profile.
def boxes(b,start,end,path='',out=None):
 if out is None:out=[]
 while start<end:
  size,kind=struct.unpack_from('>I4s',b,start);kind=kind.decode('ascii');assert size>=8 and start+size<=end
  item={'path':path+'/'+kind,'bytes':size,'offset':start};out.append(item)
  if kind in ['moov','trak','mdia','minf','stbl','edts','udta']:boxes(b,start+8,start+size,item['path'],out)
  start+=size
 assert start==end
 return out
out=[]
for p in sorted((r/'transitions').glob('transition-*/channel-1/*.mp4')):
 b=p.read_bytes();bs=boxes(b,0,len(b));v=probe(p);N=len(v['packets']);payload=sum(int(x['size']) for x in v['packets']);entries=0
 for x in bs:
  kind=x['path'].split('/')[-1]
  if kind in ['stts','stss','stsc','stco','co64']:entries+=x['bytes']-16
  if kind=='stsz':entries+=x['bytes']-20
 assert not any(x['path'].endswith('/ctts') for x in bs)
 fixed=len(b)-payload-entries;assert fixed==877 and N<=120 and payload<=66504
 out.append({'case':p.parts[-3],'bytes':len(b),'sampleCount':N,'payload':payload,'tableEntriesBytes':entries,'fixedBytes':fixed,'limit':71237,'within':len(b)<=71237})
(r/'transition-box-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
