#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-r114-linux
mkdir -p "$r/output" "$r/work"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" --exclude='prefix' --exclude='protection' --exclude='focused' --exclude='transitions' --exclude='generation/live' --exclude='generation/copy' --exclude='writer' --exclude='metrics' -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib TASK_REPO=/source TASK_BUILD="$r/build"
cd /source
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0; } > "$r/output/environment.log"
timeout 600 cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" --target media_server_runtime -j2 > "$r/output/build.log" 2>&1
sha256sum "$r/build/libmedia_server_runtime.a" > "$r/output/runtime.sha256"
python3 /input/compile.py "$r/output" > "$r/output/compiler.log" 2>&1
c++ -std=c++17 -Wall -Wextra -Werror scripts/internal/recording_process_metrics.cpp -o "$r/output/metrics"
mkdir -m700 "$r/output/transitions"
python3 /input/run.py "$r/output" transitions 90 python3 scripts/internal/recording_native_isolation.py "$r/output/transitions" -- "$r/output/writer" "$r/output/transitions" --mixed-transitions /input/original/after900/media-server-current-observer-yqaE8x/input/retention-9201.mp4 > "$r/output/transitions-parent.log"
for mode in prefix protection focused; do
 mkdir -m700 "$r/output/$mode"
 if [[ $mode == prefix ]]; then args=(--mixed-fixture-bound); elif [[ $mode == protection ]]; then args=(--mixed-profile-direct); else args=(); fi
 python3 /input/run.py "$r/output" "$mode" 180 python3 scripts/internal/recording_native_isolation.py "$r/output/$mode" -- "$r/output/writer" "$r/output/$mode" "${args[@]}" > "$r/output/$mode-parent.log"
done
mkdir -m700 "$r/output/generation"
python3 /input/run.py "$r/output" generation-parent 210 node scripts/internal/recording_mixed_generation_check.mjs "$r/output/generation" "$r/output/writer" "$r/output/metrics" > "$r/output/generation-parent-wrapper.log"
node scripts/internal/recording_longrun_progress.test.mjs /input/original/after900/media-server-current-observer-yqaE8x/input/retention-9201.mp4 > "$r/output/progress.log" 2>&1
node scripts/internal/recording_mixed_generation_check.test.mjs > "$r/output/parent-contract.log" 2>&1
sha256sum "$r/output/writer" "$r/output/generation/live/mixed-input.mp4" > "$r/output/binary-input.sha256"
