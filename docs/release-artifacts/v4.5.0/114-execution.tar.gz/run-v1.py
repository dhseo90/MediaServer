import sys,os,json,pathlib,subprocess,time,signal
r=pathlib.Path(sys.argv[1]);label=sys.argv[2];limit=float(sys.argv[3]);cmd=sys.argv[4:];t=time.monotonic();why=None
with (r/(label+'.log')).open('xb') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if time.monotonic()-t>limit:why='deadline'
  if os.fstat(f.fileno()).st_size>4*1024*1024:why='log-cap'
  if why:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   break
  time.sleep(.1)
rec={'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-t,'failure':why,'logBytes':(r/(label+'.log')).stat().st_size};(r/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec));sys.exit(0 if p.returncode==0 and why is None else 1)
