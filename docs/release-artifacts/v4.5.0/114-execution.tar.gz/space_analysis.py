import json,pathlib,sys
r=pathlib.Path(sys.argv[1]);rows=[json.loads(l) for l in (r/'space.jsonl').read_text().splitlines()];out={}
keys=['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']
for phase in sorted({x['phase'] for x in rows}):
 a=[x for x in rows if x['phase']==phase];out[phase]={'samples':len(a),'decisionMaximaAtSeparateSamples':{k:max(x['decision'][k] for x in a) for k in ['variableBytes','copyBytes','combinedBytes']},'processSampleMaxima':{k:max([x['metrics'][k] for x in a if x['metrics'].get(k) is not None],default=None) for k in keys}}
result={'scope':'sequential/phase samples, not instantaneous peak; metric maxima need not occur in the same sample; unavailable null','phases':out,'allSampleMaxima':{k:max([x['metrics'][k] for x in rows if x['metrics'].get(k) is not None],default=None) for k in keys},'decisionMaxima':{k:max(x['decision'][k] for x in rows) for k in ['variableBytes','copyBytes','combinedBytes']}}
pathlib.Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['allSampleMaxima']));print(result['decisionMaxima'])
