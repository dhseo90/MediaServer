from pathlib import Path
import json,hashlib,tarfile,io,re,stat
r=Path(__file__).parent;dest=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0');selected={};trans=[];excluded=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r);parts=rel.parts
 if any(x in ['state','gst-cache'] for x in parts) or p.name in ['normalize','process-metrics','review-seed','registry.bin']:
  excluded.append({'path':str(rel),'reason':'isolated settings/credentials, runtime cache or binary; no content read/archive'});continue
 assert not p.is_symlink(),str(rel)
 if p.is_dir():continue
 assert stat.S_ISREG(p.stat().st_mode)
 if len(parts)==1 and (p.suffix not in ['.json','.py'] or p.name.startswith(('preservation-receipt','remote-','cleanup'))):continue
 b=p.read_bytes();name=str(rel)
 if p.name.endswith('.private.log'):
  clean,n=re.subn(rb'\b(?:https?|rtsp|rtsps|udp|tcp)://[^\s"<>]+',b'[REDACTED-URL]',b);name=name.replace('.private.log','.sanitized.log');trans.append({'originalPath':str(rel),'archivedPath':name,'originalBytes':len(b),'originalSha256':sha(b),'transformedBytes':len(clean),'transformedSha256':sha(clean),'rule':'URL tokens only; other bytes retained','replacements':n});b=clean
 selected[name]=b
# Runtime inputs are bound by executable hashes; never archive user settings, models or SDK.
selected['preservation-scope.json']=json.dumps({'transforms':trans,'excluded':excluded,'note':'Only new synthetic R115 run. Raw logs selectively URL-redacted; original hash retained, not same-byte claim. No prior archive/config/private95backup/model/SDK. Representative decoder trace4, not all calls. Failed MP4 and closed source store retained.'},indent=2).encode()
manifest={k:{'bytes':len(b),'sha256':sha(b)} for k,b in selected.items()};archive=dest/'115-execution.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as t:
 for k,b in selected.items():
  i=tarfile.TarInfo(k);i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
 b=json.dumps(manifest,indent=2).encode();i=tarfile.TarInfo('MANIFEST.json');i.size=len(b);i.mode=0o600;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(selected)+1
 for k,b in selected.items():assert t.extractfile(k).read()==b
receipt={'archive':'115-execution.tar.gz','sha256':sha(archive.read_bytes()),'archiveBytes':archive.stat().st_size,'payloadFiles':len(selected),'payloadBytes':sum(len(x) for x in selected.values()),'allMembersVerified':True,'manifestSha256':sha(json.dumps(manifest,indent=2).encode()),'sanitizedPrivateLogs':trans,'excludedFiles':len(excluded),'status':'local bytes verified; remote/cleanup pending'}
(r/'preservation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
