#include "recording/visual_frame_decoder.h"
#include <gst/app/gstappsink.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <iostream>
int main(int argc,char** argv){if(argc!=3)return 2;gst_init(nullptr,nullptr);
 for(int i=1;i<3;++i){int fd=open(argv[i],O_RDONLY|O_NOFOLLOW|O_CLOEXEC);struct stat s{};if(fd<0||fstat(fd,&s))return 2;recording::VisualRgbFrame f;std::string e;auto t=i==1?1800000000LL:2800000000LL;bool ok=recording::DecodeVisualFrame(fd,s.st_size,t,&f,&e,{},5000,recording::VisualDecodePolicy::SoftwareOnly);std::cout<<"seek file="<<i<<" target="<<t<<" ok="<<ok<<" actual="<<f.presentation_ns<<" error="<<e<<'\n';close(fd);if((i==1&&ok)||(i==2&&!ok))return 1;}
 gchar* escaped=g_strescape(argv[1],nullptr);std::string launch=std::string("filesrc location=\"")+escaped+"\" ! qtdemux ! h264parse ! avdec_h264 max-threads=1 ! videoconvert ! appsink name=out sync=false";g_free(escaped);GError* e=nullptr;auto* p=gst_parse_launch(launch.c_str(),&e);if(!p||e)return 2;auto* sink=gst_bin_get_by_name(GST_BIN(p),"out");gst_element_set_state(p,GST_STATE_PLAYING);bool found=false;unsigned count=0;
 while(auto* s=gst_app_sink_try_pull_sample(GST_APP_SINK(sink),5*GST_SECOND)){auto* b=gst_sample_get_buffer(s);auto* seg=gst_sample_get_segment(s);auto stream=gst_segment_to_stream_time(seg,GST_FORMAT_TIME,GST_BUFFER_PTS(b));std::cout<<"sequential pts="<<GST_BUFFER_PTS(b)<<" stream="<<stream<<'\n';found=found||stream==1800000000;gst_sample_unref(s);if(++count>120)return 2;}
 bool eos=gst_app_sink_is_eos(GST_APP_SINK(sink));gst_element_set_state(p,GST_STATE_NULL);gst_object_unref(sink);gst_object_unref(p);std::cout<<"sequential count="<<count<<" target="<<found<<" eos="<<eos<<'\n';return eos&&!found?0:1;}
