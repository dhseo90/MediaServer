from pathlib import Path
import sys,os,subprocess,time,signal,json,hashlib,selectors
repo=Path(os.environ.get('TASK_REPO','/Users/dhseo/Workspace/mediaServer'));r=Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
binary=r;out=r;native=r
if len(sys.argv)>1:out=Path(sys.argv[1]);out.mkdir(mode=0o700,exist_ok=True)
results=[]
plan=[('source-final2','recording_recorder_continuity_smoke',['@root',str(r/'input.mp4'),'--after'],60),('source-readback','recording_recorder_continuity_smoke',[str(out/'source-final2'),str(r/'input.mp4'),'--readback'],30),('transitions','recording_managed_writer_smoke',['@root','--mixed-transitions',str(r/'input.mp4')],90),('writer','recording_managed_writer_smoke',['@root'],180),('preserved112','recording_preserved_frame_smoke',[str(r/'r112.mp4')],45),('input-observation','recording_input_observation_smoke',[],60),('legacy-writer','recording_segment_writer_smoke',['@root'],90),('source-runtime','recording_default_composition_smoke',['@root','source-runtime'],90),('package','evidence_package_smoke',['@root'],90),('damaged-package','evidence_package_smoke',[str(r/'failed-package'),'--damaged-preserved'],90)]
plan=plan[:2]
plan[0]=('source-owner-final','continuity-owners',['@root',str(r/'input.mp4'),'--after'],60)
plan[1]=('source-owner-readback','continuity-owners',[str(out/'source-owner-final'),str(r/'input.mp4'),'--readback'],30)
for label,name,args,limit in plan:
 root=out/label;root.mkdir(mode=0o700);env=environment(root)
 if label=='source-runtime':
  nested=root/'source-runtime';nested.mkdir(mode=0o700);env=environment(nested);env['MEDIA_SERVER_DEFAULT_FILE']=str(nested/'input/identity.mp4');env.update(MEDIA_SERVER_IDLE_GRACE_MS='0',MEDIA_SERVER_AUTH_MODE='off',MEDIA_SERVER_ANALYSIS_EVENT_STORAGE_ENABLED='0',MEDIA_SERVER_ANALYSIS_EVENT_SNAPSHOT_HOOK_ENABLED='0',MEDIA_SERVER_ANALYSIS_EVENT_CLIP_HOOK_ENABLED='0',MEDIA_SERVER_ANALYSIS_EVENT_POST_ENABLED='0')
 cmd=[str(binary/name),*[str(root) if x=='@root' else x for x in args]]
 t=time.monotonic();p=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);size=0;reason=None
 with (out/(label+'.log')).open('xb') as log:
  while sel.get_map():
   if reason is None and time.monotonic()-t>limit:reason='deadline'
   if reason is not None and p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
   for key,_ in sel.select(.1):
    b=os.read(key.fileobj.fileno(),65536)
    if not b:sel.unregister(key.fileobj);continue
    allowed=min(len(b),4194304-size);log.write(b[:allowed]);size+=allowed
    if len(b)>allowed:reason='log-cap'
   if reason is not None and time.monotonic()-t>limit+5 and p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
  code=p.wait()
 record={'label':label,'command':cmd,'exit':code,'elapsedSeconds':time.monotonic()-t,'failure':reason,'logBytes':size,'deadlineSeconds':limit,'binarySha256':hashlib.sha256((binary/name).read_bytes()).hexdigest()};results.append(record);(out/'direct-results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
 if code or reason:raise SystemExit(1)
