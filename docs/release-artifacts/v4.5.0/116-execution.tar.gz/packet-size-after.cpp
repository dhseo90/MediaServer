#include "/Users/dhseo/Workspace/mediaServer/include/media_types.h"
#include <iostream>
int main(){std::cout<<sizeof(media::Packet)<<"\n";}
