import pathlib,json,hashlib,subprocess,tarfile,os
r=pathlib.Path('/Users/dhseo/Workspace/mediaServer'); w=pathlib.Path('/private/tmp/media-server-r116-g4x5490c')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(['git','diff','--name-only'],cwd=r,text=True).splitlines()+['scripts/internal/recording_recorder_continuity_smoke.cpp']
freeze={'baseHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'files':{p:sha(r/p) for p in files},'runtimeSha256':sha(r/'build-gst-onnx/libmedia_server_runtime.a'),'productSha256':sha(r/'build-gst-onnx/media_server'),'scope':'Final product and tests; producer-generated binding metadata finalized after execution. Backlog/release status text is separate.'}
(w/'final-source-freeze2.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n')
(w/'final-product.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=r))
(w/'final-recorder-continuity.cpp').write_bytes((r/'scripts/internal/recording_recorder_continuity_smoke.cpp').read_bytes())
# Only new bounded artifacts and final/first-reproducer media. Never traverse old copied stores or environment homes.
selected=[]
exclude={'failure-frame-binding.json','server-1.sanitized.log','candidate-r116.json'}
for p in w.iterdir():
 if p.is_file() and not p.is_symlink() and p.name not in exclude and not p.name.startswith(('r112-','r114-')) and p.suffix in ('.json','.log','.stderr','.cpp','.h','.py','.sh','.mp4','.patch'):
  selected.append(p)
for d in ('remaining','remaining2','owners','linux-output','linux-b-output','linux-c-output'):
 for p in (w/d).iterdir():
  if p.is_file() and not p.is_symlink() and p.suffix in ('.json','.log','.txt','.sh'):selected.append(p)
for d in ('source-before','owners/source-owner-final'):
 for p in (w/d).rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(w/d)
  if any(x in ('home','cache','tmp','state','auth') for x in rel.parts):continue
  if p.name.endswith(('.registry','.bin')):continue
  # Generated source evidence / journals / packages; all owned synthetic data.
  selected.append(p)
selected=sorted(set(selected))
for p in selected:
 if p.stat().st_size>4*1024*1024:raise RuntimeError(('unexpected large file',p))
manifest={'schema':'media-server.r116.artifact-members.v1','files':[{'path':str(p.relative_to(w)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in selected], 'historicalReferences':{'115':'docs/release-artifacts/v4.5.0/115-execution.tar.gz','112':'docs/release-artifacts/v4.5.0/112-execution.tar.gz'},'beforeProbeLimit':'Product baseline is 0966e97 and before binary hash/commands are preserved. The early probe source was edited during focused test development and not snapshotted at its first compile; final source is preserved. Before is an unsafe-continuity reproducer, not a precise performance benchmark.'}
(w/'artifact-members.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
selected.append(w/'artifact-members.json')
out=r/'docs/release-artifacts/v4.5.0/116-execution.tar.gz'
with tarfile.open(out,'x:gz') as t:
 for p in selected:t.add(p,arcname=str(p.relative_to(w)),recursive=False)
with tarfile.open(out) as t:
 for row in manifest['files']:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'archive':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'members':len(selected),'rawBytes':sum(p.stat().st_size for p in selected)}))
