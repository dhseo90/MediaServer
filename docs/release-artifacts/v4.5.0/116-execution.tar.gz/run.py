from pathlib import Path
import sys,subprocess,json,time,os,signal
sys.path.insert(0,'/Users/dhseo/Workspace/mediaServer/scripts/internal');from recording_native_isolation import environment
r=Path(__file__).parent;label=sys.argv[1];root=r/label;root.mkdir(mode=0o700);env=environment(root);env['MEDIA_SERVER_VERIFY_RECORDING_RESOURCE_TRACE']='1';env['MEDIA_SERVER_VERIFY_VISUAL_FRAME_TRACE']='1'
cmd=[str(r/'continuity-before2'),str(root),str(r/'input.mp4'),'--before'];t=time.monotonic();p=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
try:b=p.communicate(timeout=60)[0]
except subprocess.TimeoutExpired:
 os.killpg(p.pid,signal.SIGTERM)
 try:b=p.communicate(timeout=5)[0]
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);b=p.communicate()[0]
 raise
finally:pass
with (r/(label+'.log')).open('xb') as f:f.write(b)
record={'command':cmd,'exit':p.returncode,'elapsedSeconds':time.monotonic()-t,'logBytes':len(b),'logLimit':4194304,'isolation':str(root)};(r/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(record);assert len(b)<=4194304
