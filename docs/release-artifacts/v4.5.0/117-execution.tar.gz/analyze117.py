from pathlib import Path
import json,math,hashlib,collections,zlib,base64,re
r=Path(__file__).parent;p=r/'mixed900';app=next(p.glob('media-server-current-observer-*'));lines=(p/'run.log').read_text().splitlines();server=(app/'server-1.private.log').read_text().splitlines()
def rows(tag):return [json.loads(x.split('] ',1)[1]) for x in lines if x.startswith('['+tag+'] ')]
def put(n,v):(r/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def stats(a):
 s=sorted(a);return {'count':len(s),'p95Ms':s[math.ceil(len(s)*.95)-1] if s else None,'maxMs':max(s) if s else None}
f=json.loads((p/'artifacts/report.json').read_text());ex=json.loads((p/'execution.json').read_text());s=rows('current-observation');roots=rows('root-storage');load=f['evidenceLoad'];lat=load['searchLatencyMs'];assert len(lat)==240 and load['searchUnavailable']==0
segments={};rowsChecked=0
for q in sorted((app/'recordings').glob('*.jsonl')):
 if not q.is_file():continue
 with q.open() as stream:
  for n,line in enumerate(stream,1):
   v=json.loads(line);rowsChecked+=1
   if v.get('codec')=='zlib-base64':
    b=zlib.decompress(base64.b64decode(v['data']));assert len(b)==v['length'] and zlib.crc32(b)==v['crc32'];v=json.loads(b)
   if v.get('mutationType')!='segment_v2_bound_finalized':continue
   pay=v['payload'];seg=pay['segment'];bind=pay['sourceBinding'];sid=seg['segment_id']
   if seg['channel_id'] not in ['9101','9201']:continue
   record={'segment':sid,'channel':seg['channel_id'],'order':seg['order_sequence'],'occurredAtMs':v['occurredAtMs'],'generation':bind['source_generation'],'generationOrder':bind['generation_order'],'samples':bind['samples'],'fileEvidence':bind['file_evidence'],'path':pay['mediaRelpath']}
   if sid in segments:assert segments[sid]['record']==record;segments[sid]['locations'].append([q.name,n])
   else:segments[sid]={'record':record,'locations':[[q.name,n]]}
closed=[];groups=collections.defaultdict(list);sampleGaps=[]
for sid,wrapped in segments.items():
 row=wrapped['record'];b=row['fileEvidence'];q=app/'recordings'/row['path'];data=q.read_bytes();assert len(data)==b['bytes'] and sha(data)==b['sha256'];sample=row['samples'];ordinals=[x['ordinal'] for x in sample]
 assert [x[0] for x in b['samples']]==ordinals
 if any(y!=x+1 for x,y in zip(ordinals,ordinals[1:])):sampleGaps.append(sid)
 groups[(row['channel'],row['generation'],row['generationOrder'])].append(row)
 closed.append({'path':str(q.relative_to(r)),'bytes':len(data),'sha256':sha(data),'segment':sid,'channel':row['channel'],'generationOrder':row['generationOrder'],'firstOrdinal':ordinals[0],'lastOrdinal':ordinals[-1],'sampleCount':len(sample),'occurredAtMs':row['occurredAtMs']})
gaps=[]
for (channel,generation,order),items in groups.items():
 items.sort(key=lambda x:x['samples'][0]['ordinal'])
 for a,b in zip(items,items[1:]):
  last=a['samples'][-1];first=b['samples'][0]
  if first['ordinal']>last['ordinal']+1:gaps.append({'channel':channel,'generation':generation,'generationOrder':order,'beforeSegment':a['segment'],'afterSegment':b['segment'],'lastAccepted':last,'nextAccepted':first,'absentAcceptedOrdinals':first['ordinal']-last['ordinal']-1,'ptsSeparationNs':first['pts_ns']-last['pts_ns'],'beforeFinalizedAtMs':a['occurredAtMs'],'afterFinalizedAtMs':b['occurredAtMs']})
notices=[]
pat=re.compile(r'input discontinuity generationOrder=(\d+) previousOrdinal=(\d+) nextOrdinal=(\d+) deliveryLoss=(\d+) sourceDiscont=(\d+)')
for n,line in enumerate(server,1):
 m=pat.search(line)
 if m:notices.append(dict(zip(['generationOrder','previousOrdinal','nextOrdinal','deliveryLoss','sourceDiscont'],map(int,m.groups())),serverLine=n,eventTimestamp=None))
byOrder={order:channel for channel,g,order in groups}
for row in notices:row['channelFromCommittedGeneration']=byOrder.get(row['generationOrder'])
packages=[]
for q in sorted((app/'recordings/evidence-packages').glob('*.evp')):
 data=q.read_bytes();assert data[:8]==b'MSEVP01\n';length=int.from_bytes(data[8:16],'little');assert 0<length<=1048576;v=json.loads(data[16:16+length]);offset=16+length
 for a in v['assets']:
  size=a['sizeBytes'];asset=data[offset:offset+size];assert sha(asset)==a['sha256'];offset+=size
 assert offset==len(data)
 packages.append({'id':q.stem,'sha256':sha(data),'bytes':len(data),'createdAtMs':v['createdAtMs'],'queryKind':v['queryKind'],'status':v['status'],'frames':v['frames']})
put('closed-media-hashes.json',closed);put('recording-continuity.json',{'scope':'post-stop authenticated format/hash checks and committed sample ranges; not source/dequeue enumeration or new decoder execution','uniqueBoundFinalizations':len(segments),'rawJournalRowsChecked':rowsChecked,'withinSegmentOrdinalGaps':sampleGaps,'segmentFirstOrdinalNotInputKeyframe':[x['segment'] for x in closed if x['firstOrdinal'] not in [1,31,61,91]],'inputKeyframeScope':'fixed normalized120AU input from unchanged R114; no new keyframe creation','betweenCommittedSegmentGaps':gaps,'boundedDiscontinuityNotices':notices,'totalQueueDrops':None,'totalWriterSkippedForKeyframe':None,'totalRecoveries':None,'eventTimeLimit':'Discontinuity lines have no per-event timestamp/channel. Channel joined only when generation exists in committed source. File finalize timestamps are not queue drop times. Log buffer arrival is not event time.','saturation':'128 notices equal two writer64 caps; counts are bounded samples, not complete totals','packages':packages})
for tag in ['root-storage','current-observation','recording-status-judgment','visual-query-observation','evidence-create-responses','mixed-http-timing']:put(tag+'.json',rows(tag))
rootSamples=[x for x in roots if x['reason']=='sample'];assert len(rootSamples)==len(s)
operands=[{'sample':i+1,'phaseAt':a['phaseAt'],'measurementStartedAt':b['measurementStartedAt'],'measurementCompletedAt':b['measurementCompletedAt'],'fixedBytes':b['fixedBytes'],'namedAndParentBytes':b['totalBytes'],'anonymousLogical':a['anonymousFileBytes'],'anonymousAllocated':a['anonymousAllocatedBytes'],'variableUsed':b['totalBytes']-b['fixedBytes']+max(a['anonymousFileBytes'],a['anonymousAllocatedBytes']),'limit':448*1024*1024} for i,(a,b) in enumerate(zip(s,rootSamples))]
put('workspace-operands.json',{'scope':'recomputed same ordered sample/root operands; sequential/non-atomic, not instantaneous peak','rows':operands})
http=rows('mixed-http-timing');pairs=rows('evidence-create-responses')
analysis={'status':'FAIL','failureClass':'final-search-latency','attempts':1,'execution':ex,'firstFailure':next(x for x in lines if x.startswith('[fail]')),'duration':{'mainLoopReached900Seconds':True,'basis':'A.finish and actual mixed work assertions after while(duration) passed before final latency failure','lastSampleProgressMs':s[-1]['progress']['elapsedMs'],'sampleSpanMs':s[-1]['phaseAt']-s[0]['phaseAt'],'verifiedDurationMs':f['verifiedDurationMs'],'nodeElapsedMs':f['elapsedMs'],'totalSeconds':ex['totalWithFinalBindingSeconds']},'search':{'population':'original mixed successful HTTP array; visual2 then structured2 per cycle; A/retrieval excluded; no trimming','overall':stats(lat),'visual':stats([x for i,x in enumerate(lat) if i%4<2]),'structured':stats([x for i,x in enumerate(lat) if i%4>=2]),'thirds':[stats(lat[i*80:(i+1)*80]) for i in range(3)],'clientCounts':load['searchSuccessByClient'],'unavailable':load['searchUnavailable'],'timingOutcomes':dict(collections.Counter(str(x.get('outcome'))+':'+str(x.get('status')) for x in http)),'gate':'FAIL_p95_over2000; maxunder5000; no request timeout'},'evidence':{'structured':load['createSuccess'],'complete':load['createComplete'],'partial':load['createPartial'],'visual':load['visualCreated'],'structuredPairs':dict(collections.Counter(str(x['status'])+':'+str(x.get('body',{}).get('error','created')) for pair in pairs for x in pair)),'retainedChecks':load['retainedChecks'],'storedPackages':len(packages),'postStopManifestAssetHashes':'all checked read-only; not new decode or independent live recovery','aCompleted':len(f['aLoad']['completed']),'aScheduled':len(f['aLoad']['schedule']),'detectorEvaluated':f['aLoad']['detectorEvaluated']},'progress':{'windows':load['windows'],'lastDrained':s[-1]['progress'],'firstIndex':load['visualIndexObservations'][0],'lastIndex':load['visualIndexObservations'][-1],'closedTargetFiles':len(closed),'maxClosedTargetBytes':max(x['bytes'] for x in closed),'bound':71237,'allFilesWithinBound':all(x['bytes']<=71237 for x in closed)},'loss':{'notices':len(notices),'deliveryLossNotices':sum(x['deliveryLoss'] for x in notices),'sourceDiscontNotices':sum(x['sourceDiscont'] for x in notices),'sampledChannels':dict(collections.Counter(x['channelFromCommittedGeneration'] for x in notices)),'firstNotice':notices[0],'betweenCommittedSegmentGaps':len(gaps),'withinSegmentOrdinalGaps':len(sampleGaps),'scope':'repeated actual Recorder loss and recording gaps observed; safe recovery does not excuse normal-load service quality; no complete queue-drop or skipped-frame total','details':'recording-continuity.json'},'resources':{'samples':len(s),'summarySamples':f['resources']['sampleCount'],'pids':sorted(set(x['pid'] for x in s)),'startIdentities':sorted(set(x['startIdentity'] for x in s)),'maxSampleGapMs':max(b['phaseAt']-a['phaseAt'] for a,b in zip(s,s[1:])),'allFDComplete':all(x['fdObservation']['complete'] for x in s),'separateMaxima':{k:max(x[k] for x in s) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'largestRecomputedWorkspace':max(operands,key=lambda x:x['variableUsed']),'workspaceFailure':f['workspaceFailure'],'owner':rows('resource-trace-summary')[0],'trend':f['resources'],'postStopStorage':roots[-1],'scope':'individual sampled maxima, not simultaneous peaks; owner logical not totalheap; RSS increase not assigned to leak'},'collection':{tag:rows(tag)[0] for tag in ['server-diagnostic','frame-trace-summary','search-failure-summary','recording-state-summary']},'termination':{'finally':rows('process-cleanup')[0],'lastAAssertion':'PASS','actualMixedWork':'PASS','finalLatency':'FAIL','finalSampleContinuityGate':'not-run','finalProgressGate':'not-run','explicitDisable':'not-run','closedJournalGate':'not-run','processesClosed':f['processesClosed'],'udpClosed':f['udpClosed']},'notRun':['retry','45 minutes','120 minutes','product/fixture/collector change','new direct decoder test','release procedures'],'next45':'ineligible: final latency fail and repeated input loss/service quality residual','analysisCorrections':['Initial exploratory EVP read used big-endian length and failed before any mutation; source Length() is little-endian; corrected read-only parser. Not a product/test failure.']}
put('analysis.json',analysis)
print(json.dumps({k:analysis[k] for k in ['duration','search','loss']},ensure_ascii=False,indent=2))
