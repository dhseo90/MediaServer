import pathlib,json,re,math,hashlib,subprocess
p=pathlib.Path('/private/tmp/media-server-r118-mnl4w209');r=pathlib.Path('/Users/dhseo/Workspace/mediaServer');result={}
for label in ['aligned-small','bound-large','reservation-small','reservation-large','shared-small','shared-large']:
 root=p/label;lines=(root/'output.log').read_text(errors='replace').splitlines();times=[];queues=[];stages=[];owners=[];space=[];holders=[]
 for l in lines:
  if l.startswith('[R107-http] '):
   m=re.match(r'\[R107-http\] round=(\d+) client=(\d+) ms=([^ ]+) response=(.*)',l);body=json.loads(m[4]);times.append({'round':int(m[1]),'client':int(m[2]),'ms':float(m[3]),'shape':'items' in body,'bodySha256':hashlib.sha256(m[4].encode()).hexdigest()})
  if l.startswith('[recorder-cost] '):queues.append({k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',l)})
  if l.startswith('[writer-cost] '):stages.append({k:v if k=='stage' else int(v) for k,v in re.findall(r'(\w+)=([^ ]+)',l)})
  for prefix,out in [('[recording-resource] ',owners),('[R101-space] ',space),('[catalog-holder] ',holders)]:
   if l.startswith(prefix):out.append(json.loads(l[len(prefix):]))
 vals=sorted(t['ms'] for t in times);sites={}
 for h in holders:
  v=sites.setdefault(h['site'],{'calls':0,'holdNs':0,'maxHoldNs':0,'waitNs':0});v['calls']+=1;v['holdNs']+=h['e']-h['a'];v['maxHoldNs']=max(v['maxHoldNs'],h['e']-h['a']);v['waitNs']+=h['a']-h['b']
 result[label]={'execution':json.loads((root/'execution.json').read_text()),'originalHttp':{'requests':times,'p95Ms':vals[math.ceil(len(vals)*.95)-1] if vals else None,'maxMs':max(vals) if vals else None},'recorder':queues,'writer':stages,'source':[l for l in lines if l.startswith('[R118-source]')],'failure':[l for l in lines if l.startswith('[R107-fail]')],'explicitFinish':any('"phase":"finished"' in l for l in lines),'resourceOwners':owners,'sampleMaxima':{k:max(s['metrics'][k] for s in space) for k in ['rssBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes','footprintBytes']},'workspaceMax':max(s['bounds']['variableBytes'] for s in space),'completeSamples':sum(s['metrics']['valid'] and s['metrics']['fdObservation']['complete'] for s in space),'samples':len(space),'selectedHolderSiteTotals':sites,'holderLimit':'selected requests only; sum waits is not mutex occupancy or one request; nested phases not added'}
(root.parent/'direct-analysis.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:{'p95':v['originalHttp']['p95Ms'],'exit':v['execution']['exit'],'finish':v['explicitFinish'],'rss':v['sampleMaxima']['rssBytes'],'workspace':v['workspaceMax']} for k,v in result.items()},indent=2))
