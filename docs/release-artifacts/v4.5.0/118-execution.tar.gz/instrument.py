from pathlib import Path
p=Path('include/core/shared_stream.h');s=p.read_text();s=s.replace('std::deque<media::Packet> queue;','''struct QueuedPacket { media::Packet packet; std::uint64_t enqueued_ns{0}; };
        std::deque<QueuedPacket> queue;
        // Opt-in Recorder counters; fixed size, no payload history or extra lock.
        std::uint64_t enqueued{0}, dequeued{0}, payload_bytes{0}, queued_bytes{0};
        std::uint64_t max_depth{0}, max_bytes{0}, first_input_ns{0}, last_input_ns{0};
        std::uint64_t min_input_gap_ns{UINT64_MAX}, max_input_gap_ns{0};
        std::uint64_t queue_wait_ns{0}, max_queue_wait_ns{0}, callback_ns{0}, max_callback_ns{0};''');s=s.replace('static void WorkerLoop(', 'static void ReportRecorder(const std::shared_ptr<SubscriberState>& state);\n    static void WorkerLoop(');p.write_text(s)
p=Path('src/core/shared_stream.cpp');s=p.read_text();s='#include "recording/recording_latency_trace.h"\n'+s
s=s.replace('state->worker.join();','state->worker.join();\n        ReportRecorder(state);')
s=s.replace('packet = std::move(state->queue.front());','''const auto now=recording::latency::SubcostEnabled()&&state->role==SubscriberRole::Recorder?recording::latency::Now():0;
            if(now){const auto wait=now-state->queue.front().enqueued_ns;++state->dequeued;
                state->queue_wait_ns+=wait;state->max_queue_wait_ns=std::max(state->max_queue_wait_ns,wait);
                state->queued_bytes-=state->queue.front().packet.payload.size();}
            packet = std::move(state->queue.front().packet);''')
s=s.replace('        try {\n            state->callback(packet);','''        const auto begin=recording::latency::SubcostEnabled()&&state->role==SubscriberRole::Recorder?recording::latency::Now():0;
        try {
            state->callback(packet);''')
s=s.replace('        } catch (...) {\n            // 비표준 예외도 worker thread를 죽이지 않는다.\n        }','''        } catch (...) {
            // 비표준 예외도 worker thread를 죽이지 않는다.
        }
        if(begin){const auto cost=recording::latency::Now()-begin;
            // Only this worker writes callback counters; final report follows join.
            state->callback_ns+=cost;state->max_callback_ns=std::max(state->max_callback_ns,cost);}''')
s=s.replace('state->queue.front().kind','state->queue.front().packet.kind')
s=s.replace('            state->queue.pop_front();\n            ++state->dropped_packets;', '''            if(recording::latency::SubcostEnabled()&&state->role==SubscriberRole::Recorder)
                state->queued_bytes-=state->queue.front().packet.payload.size();
            state->queue.pop_front();
            ++state->dropped_packets;''')
s=s.replace('        state->queue.push_back(packet);','''        const auto now=recording::latency::SubcostEnabled()&&state->role==SubscriberRole::Recorder?recording::latency::Now():0;
        state->queue.push_back({packet,now});
        if(now){++state->enqueued;state->payload_bytes+=packet.payload.size();state->queued_bytes+=packet.payload.size();
            state->max_depth=std::max(state->max_depth,std::uint64_t(state->queue.size()));state->max_bytes=std::max(state->max_bytes,state->queued_bytes);
            if(state->last_input_ns){const auto gap=now-state->last_input_ns;state->min_input_gap_ns=std::min(state->min_input_gap_ns,gap);state->max_input_gap_ns=std::max(state->max_input_gap_ns,gap);}
            else state->first_input_ns=now;
            state->last_input_ns=now;}''')
pos=s.index('void SharedStream::WorkerLoop')
s=s[:pos]+'''void SharedStream::ReportRecorder(const std::shared_ptr<SubscriberState>& state) {
    if(!recording::latency::SubcostEnabled()||state->role!=SubscriberRole::Recorder)return;
    // Called only after join, outside queue/map locks; all counter writers stopped.
    std::fprintf(stderr,"[recorder-cost] enqueued=%llu dequeued=%llu dropped=%zu payloadBytes=%llu maxDepth=%llu maxBytes=%llu firstNs=%llu lastNs=%llu minInputGapNs=%llu maxInputGapNs=%llu queueWaitNs=%llu maxQueueWaitNs=%llu callbackNs=%llu maxCallbackNs=%llu\\n",
        (unsigned long long)state->enqueued,(unsigned long long)state->dequeued,state->dropped_packets,
        (unsigned long long)state->payload_bytes,(unsigned long long)state->max_depth,(unsigned long long)state->max_bytes,
        (unsigned long long)state->first_input_ns,(unsigned long long)state->last_input_ns,
        (unsigned long long)state->min_input_gap_ns,(unsigned long long)state->max_input_gap_ns,
        (unsigned long long)state->queue_wait_ns,(unsigned long long)state->max_queue_wait_ns,
        (unsigned long long)state->callback_ns,(unsigned long long)state->max_callback_ns);
}

'''+s[pos:];p.write_text(s)
p=Path('src/recording/gstreamer_segment_writer.cpp');s=p.read_text();pos=s.index('    void Stop() {');end=s.index('\n    std::shared_ptr<const RecordingTimeSnapshot>',pos)
s=s[:pos]+'''    void Stop() {
        std::unique_lock lock(mu);
        time_snapshot.Invalidate();
#if MEDIA_SERVER_USE_GSTREAMER
        FinalizeLocked();
#endif
        started = false;
        const auto costs=writer_costs;const bool report=latency::SubcostEnabled()&&!costs_reported;costs_reported=true;
        lock.unlock();
        if(report){const char* names[]={"push","open","writer-binding","admission","finalize","eos","fsync","hash","file-evidence","ready-ticket","durable-commit","release"};
            for(unsigned i=0;i<costs.size();++i)std::fprintf(stderr,"[writer-cost] stage=%s calls=%llu totalNs=%llu maxNs=%llu\\n",names[i],
                (unsigned long long)costs[i][0],(unsigned long long)costs[i][1],(unsigned long long)costs[i][2]);}
    }
''' + s[end:]
# no logging/allocation in timed stages, nested elapsed scopes explicitly identified
pos=s.index('private:\n');s=s[:pos]+s[pos:].replace('private:\n','''private:
    std::array<std::array<std::uint64_t,3>,12> writer_costs{};
    bool costs_reported{false};
    struct Cost {
        std::array<std::uint64_t,3>& row;std::uint64_t begin;
        Cost(Impl& owner,unsigned stage):row(owner.writer_costs[stage]),begin(latency::SubcostEnabled()?latency::Now():0){}
        void End(){if(begin){const auto ns=latency::Now()-begin;++row[0];row[1]+=ns;row[2]=std::max(row[2],ns);begin=0;}}
        ~Cost(){End();}
    };
''',1)
# class name check: Impl is nested GStreamerSegmentWriter::Impl
s=s.replace('    void PushV2Locked(const media::Packet& packet) {','    void PushV2Locked(const media::Packet& packet) {\n        Cost cost(*this,0);')
s=s.replace('    bool OpenLocked(const media::Packet& first, std::int64_t utc_ms) {','    bool OpenLocked(const media::Packet& first, std::int64_t utc_ms) {\n        Cost cost(*this,1);')
s=s.replace('        if(v2_mode) {\n            std::string error;managed_id=NewId();','        if(v2_mode) {\n            Cost cost(*this,2);\n            std::string error;managed_id=NewId();')
s=s.replace('        if (options.admit_segment) {','        if (options.admit_segment) {\n            Cost cost(*this,3);')
s=s.replace('        if (!segment_open) return;\n        if (appsrc', '        if (!segment_open) return;\n        Cost total(*this,4);Cost eos_cost(*this,5);\n        if (appsrc')
s=s.replace('        struct stat output_status {};','        eos_cost.End();Cost fsync_cost(*this,6);\n        struct stat output_status {};')
s=s.replace('        ResetPipelineLocked();\n        if (!output_binding_ok)', '        ResetPipelineLocked();fsync_cost.End();\n        if (!output_binding_ok)')
s=s.replace('        current.checksum_sha256 = FileSha256(partial_path);','        {Cost cost(*this,7);current.checksum_sha256 = FileSha256(partial_path);}')
s=s.replace('            if(evidence_capture) {','            if(evidence_capture) {\n                Cost cost(*this,8);')
a='''            if(!WriteFinalizeReadyTicket(options.storage_root,ready,&error) ||
               !CommitFinalizeReadyV2(*options.managed_catalog,options.storage_root,ready,&error)) {'''
b='''            const bool ticket_ok=[&]{Cost cost(*this,9);return WriteFinalizeReadyTicket(options.storage_root,ready,&error);}();
            if(!ticket_ok || ![&]{Cost cost(*this,10);return CommitFinalizeReadyV2(*options.managed_catalog,options.storage_root,ready,&error);}()) {'''
assert a in s;s=s.replace(a,b);s=s.replace('            ReleaseReservationLocked(current_v2.size_bytes);segment_open=false;return;','            {Cost cost(*this,11);ReleaseReservationLocked(current_v2.size_bytes);}segment_open=false;return;');p.write_text(s)
