from pathlib import Path
import tarfile,json,hashlib
root=Path('/private/tmp/media-server-r118-mnl4w209');repo=Path('/Users/dhseo/Workspace/mediaServer')
with tarfile.open(repo/'docs/release-artifacts/v4.5.0/117-execution.tar.gz') as t:
    prefix='mixed900/media-server-current-observer-fGKmwE/recordings/'
    items=[]
    for m in t:
        if m.name.startswith(prefix) and m.isfile():dst=root/'seed117'/m.name[len(prefix):]
        elif m.name=='mixed900/media-server-current-observer-fGKmwE/input/retention-9101.mp4':dst=root/'input.mp4'
        else:continue
        assert not m.issym() and not m.islnk() and '..' not in Path(m.name).parts
        dst.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        data=t.extractfile(m).read()
        with dst.open('xb') as f:f.write(data)
        dst.chmod(0o600);items.append({'member':m.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(root/'seed-binding.json').write_text(json.dumps(items,indent=2))
with tarfile.open(repo/'docs/release-artifacts/v4.5.0/111-execution.tar.gz') as t:
    matches=[m for m in t if m.name.endswith('/http_qualification.py') or m.name=='http_qualification.py']
    assert len(matches)==1
    (root/'http_qualification.py').write_bytes(t.extractfile(matches[0]).read())
p=repo/'src/core/shared_stream.cpp';s=p.read_text().replace('            state->worker.join();\n        ReportRecorder(state);','            state->worker.join();\n            ReportRecorder(state);');p.write_text(s)
