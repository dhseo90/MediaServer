import pathlib,json,hashlib,tarfile,io,re,stat
p=pathlib.Path('/private/tmp/media-server-r118-mnl4w209'); out=pathlib.Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0/118-execution.tar.gz')
H=lambda b:hashlib.sha256(b).hexdigest()
fail=json.loads((p/'preparation-failures.json').read_text());fail['additional']=[
 {'label':'baseline-large','failure':'wrong persistent cache path forced cold rebuild; index-ready timeout then Stop join blocked; outer 630s TERM','classification':'fixture connection failure; stack retained; no decoder diagnosis'},
 {'label':'aligned-build','failure':'undefined NowNs','correction':'use existing clock helper; first compiler output retained'},
 {'label':'aligned-large','failure':'cache-origin generation null rejected by fixture','correction':'null allowed only cache origin; newly published generation remains numeric'},
 {'label':'focused-reservation','failure':'old RetentionSnapshot aggregate initializer no longer matches reservations-first layout','correction':'explicit candidates helper; original assertions preserved'},
 {'label':'independent-derived-order','failure':'draft free-space before durable snapshot could undercount completed durable reservations','correction':'durable snapshot before fresh physical-free capture; corrected before final comparisons'},
 {'label':'independent-derived-oracle','failure':'draft test forbade mandatory Apply authority snapshot after free reading','correction':'verify first two snapshots before first free, permit mandatory authority recheck'},
 {'label':'reservation-red','failure':'two latch progress assertions failed','classification':'predeclared expected RED, 62 pass/2 fail'},
 {'label':'bound-large/reservation-large/shared-large','failure':'original12 p95 exceeds2000ms; separate auxiliary live publication receive failure','classification':'actual direct FAIL, explicit Finish not-run; no retry of unchanged performance candidate'}]
(p/'preparation-failures.json').write_text(json.dumps(fail,ensure_ascii=False,indent=2)+'\n')
# Reuse unchanged original bytes from R117 by digest; do not copy that archive.
seed={}
for f in (p/'seed117').rglob('*'):
 if f.is_file() and not f.is_symlink():seed[H(f.read_bytes())]=str(f.relative_to(p/'seed117'))
allowed={'before-build','before-small','before-small-permitted','baseline-build','baseline-small','baseline-large','aligned-build','aligned-build-fixed','aligned-small','aligned-large','bound-build','bound-large','reservation-red','reservation-green','reservation-build','reservation-small','reservation-large','focused-reservation','focused-shared','focused-final','shared-build','shared-small','shared-large','linux-input','linux-output','prior117'}
records=[]; reused=[]; redactions=[]; excluded=0
with tarfile.open(out,'x:gz') as t:
 for f in sorted(p.rglob('*')):
  rel=f.relative_to(p); parts=rel.parts
  if f.is_symlink() or not f.is_file():continue
  if len(parts)>1 and parts[0] not in allowed:continue
  if parts[0]=='prior117' and f.name not in {'analysis.json','holder-callsite-analysis.json'}:continue
  if any(x in {'home','cache','auth','state','visual-cache','__pycache__'} for x in parts):continue
  if f.suffix not in {'.json','.jsonl','.log','.txt','.py','.sh','.cpp','.h','.patch','.mp4','.png','.evp'}:continue
  # JSON generation files and newly generated MP4 are retained; SQLite is derived and excluded.
  b=f.read_bytes(); original=H(b)
  if len(parts)>1 and 'recording' in parts and original in seed:
   reused.append({'runPath':str(rel),'sha256':original,'bytes':len(b),'r117SeedPath':seed[original]});continue
  if f.suffix in {'.log','.txt','.json','.jsonl','.py','.sh','.cpp','.h','.patch'}:
   try:s=b.decode('utf-8')
   except UnicodeDecodeError:s=None
   if s is not None:
    # Only runtime logs contain source URL tokens; source-code strings stay intact.
    if f.suffix in {'.log','.txt'}:
     s,n=re.subn(r'(?:file|rtsp|rtsps|http|https)://[^\s\"\'<>]+','[URL-REDACTED]',s)
     if n:
      b=s.encode();redactions.append({'path':str(rel),'originalBytes':f.stat().st_size,'originalSha256':original,'replacements':n,'archivedSha256':H(b)})
  info=tarfile.TarInfo(str(rel)); info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b));records.append({'path':str(rel),'bytes':len(b),'sha256':H(b)})
 manifest={'schema':'r118-selective-preservation-v1','files':records,'unchangedR117Reused':reused,'sanitizedLogs':redactions,'excludes':'user settings/private backup/models/SDK/binaries/auth/state/cache/SQLite; unchanged R117 source bytes referenced by hash','originalR117ArchiveSha256':'8e7fe70e4e0c1fdaa8c7ec9538ba4b4fb13e9a8b28ecca29bf2ab02280fea9c6'}
 b=json.dumps(manifest,ensure_ascii=False,indent=2).encode();info=tarfile.TarInfo('preservation-manifest.json');info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 for r in records:
  assert H(t.extractfile(r['path']).read())==r['sha256']
receipt={'archive':out.name,'bytes':out.stat().st_size,'sha256':H(out.read_bytes()),'files':len(records),'payloadBytes':sum(r['bytes'] for r in records),'reusedFiles':len(reused),'redactedLogs':len(redactions),'allMemberBytesVerified':True,'manifestSha256':H(b)}
(p/'preservation-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
