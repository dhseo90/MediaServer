from pathlib import Path
p=Path('scripts/internal/recording_generation_request_proof_smoke.cpp');s=p.read_text();pos=s.index('void RetentionPathCases(');s=s[:pos]+'''// R119: a real private Catalog cut is held before admission serialization.
void AdmissionPreparedCases(const std::filesystem::path& root){
    for(const std::string mode:{"increase","decrease","remove","hold","completion","parallel","exception"}){
        const auto path=root/mode;std::filesystem::create_directories(path);CompleteFixture(path);
        RecordingJournal journal(Options(path));Need(journal.Open(&error));auto opts=ReadOptions(path);opts.enable_generation_writes=true;
        RecordingCatalog catalog(journal,opts);Need(catalog.Open(&error));
        RetentionCoordinator coordinator(catalog,[](auto* bytes,auto*){*bytes=1024ULL*1024*1024;return true;},
            [](const auto&,auto*){return false;},{0,1,path});
        RetentionPolicy policy{mode=="increase"?1ULL:1024ULL*1024*1024,0,1024ULL*1024*1024,0};
        Need(coordinator.UpdateChannelPolicy("channel",policy,&error));
        Need(coordinator.UpdateChannelPolicy("other",{1024ULL*1024*1024,0,1024ULL*1024*1024,0},&error));
        if(mode=="completion")Need(coordinator.AdmitContinuousWrite("channel",128,1).allowed);
        const auto fds=OpenDescriptors();
        std::promise<void> entered,resume;auto ready=entered.get_future();auto release=resume.get_future().share();
        RetentionAdmissionResult result;std::exception_ptr failure;
        std::thread reader([&]{try{ProofProbe::RetentionHook([&]{ProofProbe::RetentionHook({});entered.set_value();release.wait();
                if(mode=="exception")throw std::runtime_error("admission preparation injection");});
            result=coordinator.AdmitContinuousWrite("channel",128,2);
        }catch(...){failure=std::current_exception();}ProofProbe::RetentionHook({});});
        struct Guard{std::promise<void>& resume;std::thread& thread;bool done=false;void Release(){if(!done){resume.set_value();done=true;}}
            ~Guard(){Release();if(thread.joinable())thread.join();}}guard{resume,reader};
        Need(ready.wait_for(std::chrono::seconds(3))==std::future_status::ready);
        auto change=std::async(std::launch::async,[&]{std::string detail;
            if(mode=="remove"){coordinator.RemoveChannelPolicy("channel");return true;}
            if(mode=="increase"||mode=="decrease"){auto current=policy;current.continuous_max_bytes=mode=="increase"?1024ULL*1024*1024:1;
                return coordinator.UpdateChannelPolicy("channel",current,&detail);}
            if(mode=="hold")return catalog.AdjustHoldCount("segment",1,&detail);
            if(mode=="completion"){coordinator.CompleteContinuousWrite("channel",128);return true;}
            const auto other=coordinator.AdmitContinuousWrite("other",128,3);if(other.allowed)coordinator.CompleteContinuousWrite("other",128);return other.allowed;
        });
        const bool progressed=change.wait_for(std::chrono::seconds(3))==std::future_status::ready;
        if(!progressed)guard.Release();const bool changed=change.get();
        guard.Release();reader.join();if(failure)std::rethrow_exception(failure);
        const bool denied=mode=="decrease"||mode=="remove"||mode=="exception";
        Check("R119-P01",progressed&&changed&&result.allowed!=denied,(mode+": current policy/reservation read after independent preparation; no stale admission").c_str());
        if(result.allowed)coordinator.CompleteContinuousWrite("channel",128);
        if(mode=="hold")Need(catalog.AdjustHoldCount("segment",-1,&error));
        Check("R119-P01",OpenDescriptors()==fds&&catalog.RetentionSnapshot().authoritative,"all private readers release FD; transient rejection preserves authority");
        Need(journal.Finish(&error));
    }
}
''' +s[pos:];s=s.replace('        RetentionPreparedCases(root/"retention-prepared");','        RetentionPreparedCases(root/"retention-prepared");\n        AdmissionPreparedCases(root/"admission-prepared");');p.write_text(s)
p=Path('scripts/internal/recording_retention_smoke.cpp');s=p.read_text().replace('coordinator.AdmitContinuousWrite("b",50,2)','coordinator.AdmitContinuousWrite("b",70,2)').replace('"R118 old free not paired with later reduced reservation"','"R119 current free/reservation rejects real remaining-capacity shortage"');p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');s=p.read_text();s+='\n- **R119-P01**: native generation admission private 준비 중 quota 증가/감소·정책 제거·hold·예약 완료·다른 채널 admission과 예외를 latch로 겹친다. 현재 정책/공간 판단, no stale reservation, FD 회수·authority 유지. 기존 R108 변경-ID/원본 손상/재Open 경계 재사용. custom provider 실제 부족(70>60) 거부와 fresh50 수용을 대조한다. UI 없음; focused macOS/Linux, 장시간은 직접 목표 후 별도900초1회만.\n';p.write_text(s)
