from pathlib import Path
import json,re,math
r=Path(__file__).parent
out={}
for name in ['diagnostic-large','prepared-small','prepared-large','indexdiag-large','control-large','fused-large','hotread-large']:
 p=r/name
 if not(p/'execution.json').exists():continue
 ex=json.loads((p/'execution.json').read_text())
 if 'exit' not in ex:continue
 text=(p/'output.log').read_text()
 def rows(tag):
  return [json.loads(m) for m in re.findall(r'^\['+re.escape(tag)+r'\] (\{[^\n]*\})$',text,re.M)]
 def lines(tag):return re.findall(r'^\['+re.escape(tag)+r'\] ([^\n]*)$',text,re.M)
 wires=rows('R119-http-wire');visual=rows('visual-request');space=rows('R101-space');resource=rows('recording-resource');ad=rows('R119-admission')
 original=[x for x in wires if x['scope']=='original12'];ms=sorted((x['endNs']-x['beginNs'])/1e6 for x in original)
 out[name]={'execution':ex,'wireOriginal':{'count':len(ms),'statuses':[x['status'] for x in original],'p95Ms':ms[math.ceil(.95*len(ms))-1] if ms else None,'maxMs':max(ms) if ms else None},'originalPrinted':lines('R119-original-result'),'auxiliary':[x for x in wires if x['scope']!='original12'],'membership':lines('R119-membership'),'source':lines('R118-source'),'recorder':lines('recorder-cost'),'writer':lines('writer-cost'),'explicitFinish':lines('R119-finish'),'firstFailure':lines('R107-fail'),'indexFailure':lines('R119-index-failure'),'visual':visual,'admission':{'calls':len(ad),'totalElapsedMs':sum(x['endNs']-x['beginNs'] for x in ad)/1e6,'slotSumMs':[sum(x['costNs'][i] for x in ad)/1e6 for i in range(7)],'slotMaxMs':[max([x['costNs'][i] for x in ad]+[0])/1e6 for i in range(7)],'basis':'elapsed inclusive; prepared snapshot slot3 includes callback slot0 wait/slot1 recovery, do not add'},'resource':resource,'sampledMax':{k:max([x['metrics'][k] for x in space if x['metrics'].get(k) is not None]+[0]) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'spaceSamples':len(space),'spaceVariableMax':max([x['bounds']['variableBytes'] for x in space]+[0]),'holderEnd':rows('catalog-holder-end')}
(r/'run-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for n,x in out.items():print(n,x['wireOriginal']['p95Ms'],x['membership'],x['explicitFinish'],x['firstFailure'])
