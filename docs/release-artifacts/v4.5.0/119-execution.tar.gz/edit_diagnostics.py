from pathlib import Path
p=Path('include/ingress/visual_search_application_service.h');s=p.read_text().replace('private:\n    Options options_;','private:\n    friend struct VisualSearchPublicationTestProbe;\n    Options options_;');p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_smoke.cpp');s=p.read_text().replace('namespace ingress {struct RecordingHttpOwnershipProbe {','namespace ingress {struct VisualSearchPublicationTestProbe {\n static recording::VisualIndexReadView View(const VisualSearchApplicationService& s){return s.worker_?s.worker_->ReadView():recording::VisualIndexReadView{};}\n};struct RecordingHttpOwnershipProbe {')
a=s.index('std::string Drain(');b=s.index('\n}',a)
s=s[:a]+'''struct HttpObservation {
 unsigned id;const char* scope;const std::string& route;Clock::time_point begin{Clock::now()};
 std::size_t bytes=0;int status=0,error=0;bool headers=false;const char* failure="none";
 ~HttpObservation(){std::ostringstream o;o<<"[R119-http-wire] {\\"id\\":"<<id<<",\\"scope\\":\\""<<scope<<"\\",\\"route\\":\\""<<route<<"\\",\\"beginNs\\":"<<std::chrono::duration_cast<std::chrono::nanoseconds>(begin.time_since_epoch()).count()<<",\\"endNs\\":"<<SourceHttpSteadyNs()<<",\\"bytes\\":"<<bytes<<",\\"headers\\":"<<(headers?"true":"false")<<",\\"status\\":"<<status<<",\\"errno\\":"<<error<<",\\"failure\\":\\""<<failure<<"\\"}\\n";const auto row=o.str();std::fwrite(row.data(),1,row.size(),stderr);}
};
std::string Drain(int fd,Clock::time_point deadline,HttpObservation& observation){std::string result;char b[4096];for(;;){
 const auto remaining=std::chrono::duration_cast<std::chrono::microseconds>(deadline-Clock::now()).count();
 if(remaining<=0){observation.failure="total-deadline";throw std::runtime_error("HTTP total deadline");}
 timeval timeout{static_cast<time_t>(remaining/1000000),static_cast<suseconds_t>(remaining%1000000)};
 if(setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout))){observation.error=errno;observation.failure="setsockopt";throw std::runtime_error("receive deadline");}
 const auto n=recv(fd,b,sizeof(b),0);const int saved_errno=n<0?errno:0;
 if(n==0){if(!observation.headers)observation.failure="eof-before-headers";break;}
 if(n<0){observation.error=saved_errno;observation.failure="recv";throw std::runtime_error("client receive failed");}
 observation.bytes+=static_cast<std::size_t>(n);
 if(result.size()+static_cast<std::size_t>(n)>4*1024*1024+8192){observation.failure="result-bound";throw std::runtime_error("HTTP fixture result bound");}
 result.append(b,n);observation.headers=result.find("\\r\\n\\r\\n")!=std::string::npos;
 if(result.find("\\r\\n")!=std::string::npos&&result.rfind("HTTP/1.1 ",0)==0)observation.status=std::atoi(result.c_str()+9);
 }return result;}
struct ExplicitFinish {
 WebRtcHttpServer& server;VisualSearchApplicationService& visual;recording::RecordingRuntimeStorage& runtime;recording::RecordingResourceTrace& trace;bool done=false;
 bool Run() noexcept {if(done)return true;done=true;bool good=true;std::string error;
  try{WaitIdle(server);}catch(const std::exception& e){std::cerr<<"[R119-cleanup-error] idle "<<e.what()<<std::endl;good=false;}
  try{server.Stop();std::cout<<"[R119-stop] server=1"<<std::endl;}catch(...){good=false;}
  try{visual.Stop();std::cout<<"[R119-stop] visual=1"<<std::endl;}catch(...){good=false;}
  try{const bool ok=runtime.Finish(&error);std::cout<<"[R119-finish] ok="<<ok<<" error="<<error<<std::endl;good=ok&&good;good=trace.Emit("finished")&&good;}catch(...){good=false;}
  return good;}
 ~ExplicitFinish(){if(!done)(void)Run();}
};
''' + s[b:]
s=s.replace(' std::set<std::string> original_segments;',' ExplicitFinish finish{server,visual,runtime,trace};\n std::set<std::string> original_segments;')
s=s.replace('const auto begin=Clock::now();Socket socket;socket.fd=Request(port,route);auto wire=Drain(socket.fd,begin+std::chrono::seconds(5));','const auto begin=Clock::now();HttpObservation observation{round*clients+client,"original12",route,begin};Socket socket;socket.fd=Request(port,route);auto wire=Drain(socket.fd,begin+std::chrono::seconds(5),observation);')
s=s.replace(' background.join();if(bgerror)std::rethrow_exception(bgerror);',' background.join();if(bgerror)std::rethrow_exception(bgerror);\n {auto times=elapsed;std::sort(times.begin(),times.end());std::cout<<"[R119-original-result] failures="<<failures<<" count="<<times.size()<<" p95="<<times[std::size_t(std::ceil(times.size()*.95))-1]<<" max="<<times.back()<<std::endl;}')
s=s.replace(' if(source_mode){const auto begin=Clock::now();Socket socket;socket.fd=Request(port,"/ops/api/recordings/visual-search?channelIds=9101,9201&text=ball&limit=200&threshold=-1");const auto wire=Drain(socket.fd,begin+std::chrono::seconds(5));',''' if(source_mode){
 {const auto view=VisualSearchPublicationTestProbe::View(visual);NeedHttp(view.index&&view.publication,"current publication");std::size_t fresh=0;for(const auto& d:view.index->documents())if(!original_segments.count(d.segment_id)){NeedHttp(catalog.FindSourceBinding(d.segment_id).has_value(),"published current binding");++fresh;}
 std::cout<<"[R119-membership] generation="<<view.publication->generation.value_or(0)<<" documents="<<view.index->documents().size()<<" newDocuments="<<fresh<<" instance="<<view.publication->instance_id<<std::endl;NeedHttp(fresh>0,"published new document membership");}
 const auto begin=Clock::now();const std::string route="/ops/api/recordings/visual-search?channelIds=9101,9201&text=ball&limit=200&threshold=-1";HttpObservation observation{100,"auxiliary200",route,begin};Socket socket;socket.fd=Request(port,route);const auto wire=Drain(socket.fd,begin+std::chrono::seconds(5),observation);''')
s=s.replace(' WaitIdle(server);server.Stop();visual.Stop();\n NeedHttp(runtime.Finish(&error),error.c_str());NeedHttp(trace.Emit("finished"),"trace-finish");',' NeedHttp(finish.Run(),"explicit finish failed");')
p.write_text(s)
