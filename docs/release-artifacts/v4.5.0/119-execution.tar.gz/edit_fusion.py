from pathlib import Path
r=Path('/Users/dhseo/Workspace/mediaServer')
def edit(p,a,b):
 p=r/p;s=p.read_text();assert a in s,p;s=s.replace(a,b,1);p.write_text(s)
edit('include/recording/recording_search_reader.h','    bool SourceSeekPrepared(','''    // 최초 준비의 최종 현재성 검사와 같은 호출에서 정확한 frame seek를 만든다.
    // 이후 사용은 SourceSeekPrepared로 다시 현재성을 확인한다.
    std::unique_ptr<PreparedSource> PrepareSourceAndSeek(const std::string& channel,const std::string& segment,
        const std::string& media_sha256,std::int64_t original_ns,const std::string& frame_sha256,
        SearchSeekTarget*,std::string*,const std::function<bool()>&,
        std::chrono::steady_clock::time_point) const;
    bool SourceSeekPrepared(''')
edit('include/recording/recording_search_reader.h','private:\n    RecordingCatalog& catalog_;','''private:
    std::unique_ptr<PreparedSource> PrepareSourceImpl(const std::string&,const std::string&,std::string*,
        const std::function<bool()>&,std::chrono::steady_clock::time_point,
        const std::string*,std::int64_t,const std::string*,SearchSeekTarget*) const;
    RecordingCatalog& catalog_;''')
edit('src/recording/recording_search_reader.cpp','''    const auto expired=[&]{return std::chrono::steady_clock::now()>=deadline||(cancelled&&cancelled());};
    const auto fail=[&](const char* reason)->std::unique_ptr<PreparedSource>''','''    return PrepareSourceImpl(channel,id,error,cancelled,deadline,nullptr,0,nullptr,nullptr);
}
std::unique_ptr<RecordingSearchReader::PreparedSource> RecordingSearchReader::PrepareSourceAndSeek(
    const std::string& channel,const std::string& id,const std::string& media_sha,std::int64_t original_ns,
    const std::string& frame_sha,SearchSeekTarget* target,std::string* error,const std::function<bool()>& cancelled,
    std::chrono::steady_clock::time_point deadline) const {
    if(!target||original_ns<0){if(error)*error="visual-invalid-frame-reference";return {};}
    return PrepareSourceImpl(channel,id,error,cancelled,deadline,&media_sha,original_ns,&frame_sha,target);
}
std::unique_ptr<RecordingSearchReader::PreparedSource> RecordingSearchReader::PrepareSourceImpl(
    const std::string& channel,const std::string& id,std::string* error,const std::function<bool()>& cancelled,
    std::chrono::steady_clock::time_point deadline,const std::string* media_sha,std::int64_t original_ns,
    const std::string* frame_sha,SearchSeekTarget* target) const {
    const auto expired=[&]{return std::chrono::steady_clock::now()>=deadline||(cancelled&&cancelled());};
    const auto fail=[&](const char* reason)->std::unique_ptr<PreparedSource>''')
edit('src/recording/recording_search_reader.cpp','''    if(expired())return fail("seek-cancelled");
    if(error)error->clear();
    return std::unique_ptr<PreparedSource>(new PreparedSource(std::move(proof)));''','''    if(expired())return fail("seek-cancelled");
    SearchSeekTarget initial;
    if(target){
        // 동일 호출의 마지막 현재성 검사 직후 파일 상태도 확인한다. NativeSeek의
        // 구간 포함 fallback만으로 다른 sample을 선택하지 않도록 원래 PTS/hash를 먼저 확인한다.
        struct stat now{};
        if(!media_sha||!frame_sha||proof->segment.checksum_sha256!=*media_sha||
            ::fstat(proof->media->fd(),&now)!=0||!SameFileState(proof->verified,now))
            return fail("visual-invalid-frame-reference");
        unsigned matches=0;
        for(const auto& sample:proof->binding->file_evidence->samples)
            if(sample.original_pts_ns==original_ns&&sample.sample_sha256==*frame_sha)++matches;
        if(matches!=1)return fail("visual-source-unavailable");
        if(!NativeSeek(*proof->binding->file_evidence,original_ns,&initial,error,expired))return {};
    }
    auto result=std::unique_ptr<PreparedSource>(new PreparedSource(std::move(proof)));
    if(target)*target=std::move(initial);
    if(error)error->clear();
    return result;''')
edit('include/recording/recording_visual_source.h','    bool ResolvePrepared(','''    std::unique_ptr<PreparedSource> PrepareResolved(const VisualSearchDocument&,SearchSeekTarget*,std::string*,
        const std::function<bool()>&,std::chrono::steady_clock::time_point) const;
    bool ResolvePrepared(''')
edit('src/recording/recording_visual_source.cpp','bool RecordingVisualSource::ResolvePrepared(','''std::unique_ptr<RecordingVisualSource::PreparedSource> RecordingVisualSource::PrepareResolved(
    const VisualSearchDocument& doc,SearchSeekTarget* target,std::string* error,
    const std::function<bool()>& cancelled,std::chrono::steady_clock::time_point deadline) const {
    if(!doc.event_id.empty()||!target||doc.time_base_num!=1||doc.time_base_den!=1000000000){
        Fail(error,"visual-invalid-frame-reference");return {};
    }
    RecordingSearchReader search(catalog_,reader_);
    return search.PrepareSourceAndSeek(doc.channel_id,doc.segment_id,doc.media_sha256,doc.media_pts,
        doc.frame_sha256,target,error,cancelled,deadline);
}
bool RecordingVisualSource::ResolvePrepared(''')
edit('src/ingress/visual_search_application_service.cpp','Prepared* Acquire(const recording::VisualSearchDocument& doc,std::unique_ptr<Prepared>& temporary,std::string* error){','''Prepared* Acquire(const recording::VisualSearchDocument& doc,std::unique_ptr<Prepared>& temporary,std::string* error,
        recording::SearchSeekTarget* initial=nullptr,bool* resolved=nullptr){
        if(resolved)*resolved=false;''')
edit('src/ingress/visual_search_application_service.cpp','''recording::latency::VisualPhase phase("source-prepare");temporary=source_.Prepare(doc,error,cancelled_,deadline_);if(!temporary)return nullptr;''','''recording::latency::VisualPhase phase("source-prepare");
            const bool combined=initial&&resolved&&doc.event_id.empty();
            temporary=combined?source_.PrepareResolved(doc,initial,error,cancelled_,deadline_):source_.Prepare(doc,error,cancelled_,deadline_);
            if(!temporary)return nullptr;
            if(combined)*resolved=true;''')
edit('src/ingress/visual_search_application_service.cpp','''std::unique_ptr<Prepared> temporary;const auto* proof=Acquire(doc,temporary,error);if(!proof)return false;
        recording::latency::VisualPhase phase("source-resolve");
        if(!source_.ResolvePrepared(doc,*proof,target,error,cancelled_,deadline_))return false;''','''std::unique_ptr<Prepared> temporary;bool resolved=false;
        const auto* proof=Acquire(doc,temporary,error,target,&resolved);if(!proof)return false;
        recording::latency::VisualPhase phase("source-resolve");
        if(!resolved&&!source_.ResolvePrepared(doc,*proof,target,error,cancelled_,deadline_))return false;''')
