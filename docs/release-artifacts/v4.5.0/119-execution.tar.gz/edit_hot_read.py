from pathlib import Path
p=Path('src/recording/recording_catalog.cpp');s=p.read_text()
a='''        if(reusable){
            // The hit remains in one Catalog cut, with current physical raw
            // authentication. This is not a revision-only cached answer.
            acquired=acquire();
        }else{'''
b='''        {
            // The context owns immutable parsed/envelope values. Even a hit must
            // authenticate current physical raw, but need not hold Catalog during I/O.
            // No same-cut promise survives this unlock; current membership follows.'''
assert a in s;s=s.replace(a,b,1)
a='''        link_phase.End();
        if(context->binding&&context->envelope&&context->binding->segment_id==id&&context->segment_json==segment_json){'''
b='''        link_phase.End();
        if(reusable){
            if(!opened_||!derived_job_state_authoritative_||!CanReadLocked(error)||!journal_.OwnsCatalog(this))return {};
            const auto now=segments_v2_.find(id);
            if(now==segments_v2_.end()||EffectiveLifecycleV2Locked(id,true)!=RecordingLifecycle::Finalized||
                SerializeRecordingSegmentV2(now->second)!=segment_json){Fail(error,"source binding current source changed");return {};}
            const auto current_entry=SourceEntryLocked(id);
            if(!current_entry||current_entry->latest_mutation_id!=entry.latest_mutation_id||current_entry->id!=entry.id||
               current_entry->channel!=entry.channel||current_entry->source!=entry.source||current_entry->generation!=entry.generation||
               current_entry->track!=entry.track||current_entry->order!=entry.order||current_entry->sample_count!=entry.sample_count){
                Fail(error,"source binding current source changed");return {};}
        }
        if(context->binding&&context->envelope&&context->binding->segment_id==id&&context->segment_json==segment_json){'''
assert a in s;s=s.replace(a,b,1);s=s.replace('                if(continuous_cut)*continuous_cut=reusable;','                // continuous_cut remains false: caller rechecks media/path after this unlocked read.',1)
s=s.replace('''    // A cache hit that never released mu_ already passed ValidateMediaLocked in
    // this exact cut. A miss/parser unlock still requires the original recheck.''','''    // Source authentication can release mu_ even on a parsed cache hit.
    // Preserve the post-I/O media/path check in the reacquired current cut.''',1);p.write_text(s)
p=Path('scripts/internal/recording_generation_request_proof_smoke.cpp');s=p.read_text();s=s.replace('''for(const std::string mode:{"progress","delete","resource"}){
        const auto path=root/mode;''','''for(const std::string scenario:{"progress","delete","resource","hot-progress","hot-delete","hot-resource"}){
        const bool hot=scenario.rfind("hot-",0)==0;const auto mode=hot?scenario.substr(4):scenario;
        const auto path=root/scenario;''',1)
a='''        std::string result;std::exception_ptr failure;
        std::thread reader([&]{try{ProofProbe::AcquireHook''';b='''        ProofProbe::SourceContext hot_context;bool continuous=false;
        if(hot)Need(ProofProbe::SourceCached(catalog,&hot_context,&continuous)==expected);
        std::string result;std::exception_ptr failure;
        std::thread reader([&]{try{ProofProbe::AcquireHook''';assert a in s;s=s.replace(a,b,1)
s=s.replace('''            result=ProofProbe::Source(catalog);
        }catch(...){failure=std::current_exception();}ProofProbe::AcquireHook({});});''','''            result=hot?ProofProbe::SourceCached(catalog,&hot_context,&continuous):ProofProbe::Source(catalog);
        }catch(...){failure=std::current_exception();}ProofProbe::AcquireHook({});});''',1)
s=s.replace('''        Check("R106-P01",moved,"source cold acquisition latch permits real search timeline and durable writer reservation");''','''        Check(hot?"R119-P03":"R106-P01",moved,"source authentication latch permits real search timeline and durable writer reservation");''',1)
s=s.replace('''Check("R106-P01",ProofProbe::SourceCached(catalog,&context,&same)==expected&&same,"authenticated same-cut hit reports continuous lock without a new raw bypass");''','''Check("R119-P03",ProofProbe::SourceCached(catalog,&context,&same)==expected&&!same,"authenticated hit reports released cut and current membership revalidation");''',1);p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');s=p.read_text();s+='''\n- R119-P03: parsed source context hit도 현재 raw 인증 I/O 동안 Catalog를 해제하고 reacquire 뒤 authority/정확한 segment·lifecycle·source entry와 caller media/path를 재검증한다. hot hit latch에서 실제 timeline/내구 reservation/Checkpoint 진행, 삭제·자원 거부, 원본 손상 회귀. 기존 continuous-cut=true 자기선언은 더 이상 사용하지 않음. 교정된 fused-large(12 p95/aux 수신 FAIL) 보존 뒤 hotread 후보 누적1회. 먼저 focused/matrix, 빌드 종료 후 동일 입력/권한/부하/한도에서만 실행.\n''';p.write_text(s)
