#!/bin/bash
set -eu
root=/tmp/media-server-r119-linux
mkdir -m700 "$root"
export TMPDIR="$root"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
finish(){ code=$?; cp -a "$root"/*.log /output/ 2>/dev/null || true; if [ -d "$root/focused" ]; then python3 - <<'END'
import pathlib,shutil
r=pathlib.Path('/tmp/media-server-r119-linux/focused');o=pathlib.Path('/output')
for p in r.iterdir():
 if p.is_file() and p.suffix in ('.log','.json'):shutil.copyfile(p,o/p.name)
END
fi; echo "$code" > /output/exit.txt; }
trap finish EXIT
id > "$root/environment.log"
uname -a >> "$root/environment.log"
pkg-config --modversion gstreamer-1.0 >> "$root/environment.log"
cp /input/input.mp4 "$root/input.mp4"
cmake -S /source -B "$root/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$root/configure.log" 2>&1
cmake --build "$root/build" --target media_server -j2 > "$root/build.log" 2>&1
python3 /input/focused.py /source "$root/focused" "$root/build" > "$root/focused.log" 2>&1

python3 /source/scripts/internal/verify_visual_request_media_cache.py --build "$root/build" --output /output/request-cache.json > /output/request-cache-command.log 2>&1

bash /source/scripts/internal/verify_recording_generation_request_proof.sh > /output/generation-proof.log 2>&1
