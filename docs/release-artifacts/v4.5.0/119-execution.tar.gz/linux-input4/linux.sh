#!/bin/bash
set -eu
mkdir -m700 /tmp/media-server-r119-linux
export TMPDIR=/tmp/media-server-r119-linux
trap 'echo $? > /output/exit.txt' EXIT
cd /source
bash scripts/internal/verify_recording_generation_request_proof.sh > /output/generation-proof.log 2>&1
