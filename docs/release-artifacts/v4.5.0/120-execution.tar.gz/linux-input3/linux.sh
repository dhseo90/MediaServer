#!/bin/bash
set -eu
root=/tmp/media-server-r120-linux
mkdir -m700 "$root"
export TMPDIR="$root"
trap 'code=$?; echo "$code" > /output/exit.txt' EXIT
bash /source/scripts/internal/verify_recording_generation_request_proof.sh > /output/generation-proof.log 2>&1
