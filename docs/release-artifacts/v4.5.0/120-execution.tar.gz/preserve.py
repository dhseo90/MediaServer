from pathlib import Path
import os,stat,json,hashlib,tarfile,io,re
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');out=repo/'docs/release-artifacts/v4.5.0/120-execution.tar.gz'
assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
selected={};reused=[];dedup={}
def add(p):
 st=p.lstat();assert stat.S_ISREG(st.st_mode) and not p.is_symlink()
 rel=p.relative_to(r).as_posix();data=p.read_bytes()
 if p.suffix in ('.log','.json','.jsonl','.py','.sh','.patch'):
  text=data.decode('utf8',errors='replace')
  assert not re.search(r'(?:rtsp|https?)://[^/\s]+:[^/@\s]+@',text,re.I),rel
  if p.suffix not in ('.patch','.py','.sh'):
   assert not re.search(r'authorization:\s*Bearer\s+\S+',text,re.I),rel
 selected[rel]=(p,data,stat.S_IMODE(st.st_mode))
for p in r.iterdir():
 if p.is_file() and not p.is_symlink() and p.suffix in ('.log','.json','.jsonl','.patch','.py','.cpp') and p.name not in ('candidate.json',):add(p)
for folder in sorted(r.iterdir()):
 if not folder.is_dir() or folder.is_symlink() or not (folder.name.endswith('-build') or folder.name.endswith('-source') or folder.name.endswith('-focused') or folder.name.startswith('linux-input') or folder.name.startswith('linux-output') or folder.name=='new-source'):continue
 for p in folder.iterdir():
  if p.is_file() and not p.is_symlink() and p.suffix in ('.log','.json','.sh','.py','.cpp','.txt'):add(p)
for run in sorted(r.glob('*-large')):
 for p in run.iterdir():
  if p.is_file() and not p.is_symlink() and p.suffix in ('.log','.json'):add(p)
 seed=json.loads((run/'input-binding.json').read_text()).get('files',{}) if (run/'input-binding.json').exists() else {}
 recording=run/'recording'
 for p in recording.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(recording).as_posix()
  if any(part.startswith('.visual') for part in p.relative_to(recording).parts) or '.sqlite3' in p.name:continue
  data=p.read_bytes();digest=sha(data)
  if seed.get(rel)==digest:
   reused.append({'path':p.relative_to(r).as_posix(),'bytes':len(data),'sha256':digest,'original':'117-execution.tar.gz:mixed900/media-server-current-observer-fGKmwE/recordings/'+rel});continue
  if digest in dedup:
   reused.append({'path':p.relative_to(r).as_posix(),'bytes':len(data),'sha256':digest,'original':'120:'+dedup[digest]});continue
  add(p);dedup[digest]=p.relative_to(r).as_posix()
# actual input already preserved in117, refer rather than rearchive every copy
reused.append({'path':'input.mp4','bytes':(r/'input.mp4').stat().st_size,'sha256':sha((r/'input.mp4').read_bytes()),'original':'117-execution.tar.gz:mixed900/media-server-current-observer-fGKmwE/input/retention-9101.mp4'})
# Verify referenced original bytes, not just a prior manifest assertion.
needed={v['original'].split(':',1)[1].strip():v['sha256'] for v in reused if v['original'].startswith('117-execution.tar.gz:')}
with tarfile.open(repo/'docs/release-artifacts/v4.5.0/117-execution.tar.gz') as old:
 for member in old:
  if member.name not in needed:continue
  assert member.isfile() and not member.issym() and not member.islnk()
  assert sha(old.extractfile(member).read())==needed.pop(member.name)
assert not needed,needed
c=json.loads((r/'candidate.json').read_text());binding={'items':len(c['items']),'candidateDigest':c.get('candidateDigest'),'scope':'unchanged986 independently reviewed mapping; not new product approval'}
manifest={'schema':'media-server.r120.archive.v1','files':[{'path':n,'bytes':len(v[1]),'sha256':sha(v[1]),'mode':v[2]}for n,v in sorted(selected.items())],'reuse':reused,'candidate':binding,'exclusions':'user config/private95backup/models/SDK/auth/home/cache/binaries and duplicated117seed excluded; old evidence unchanged; no redaction needed in selected logs'}
mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
with tarfile.open(out,'x:gz') as t:
 for n,(p,data,mode) in sorted(selected.items()):
  info=tarfile.TarInfo(n);info.size=len(data);info.mode=mode;info.mtime=int(p.stat().st_mtime);t.addfile(info,io.BytesIO(data))
 info=tarfile.TarInfo('manifest.json');info.size=len(mb);info.mode=0o600;t.addfile(info,io.BytesIO(mb))
with tarfile.open(out) as t:
 for f in manifest['files']:
  m=t.getmember(f['path']);assert m.isfile() and not m.issym();b=t.extractfile(m).read();assert len(b)==f['bytes'] and sha(b)==f['sha256']
 assert t.extractfile('manifest.json').read()==mb
result={'archive':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'files':len(selected),'payloadBytes':sum(len(v[1])for v in selected.values()),'reuseReferences':len(reused),'allMemberBytesVerified':True,'manifestSha256':sha(mb),'scope':manifest['exclusions']}
(r/'archive-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
p=repo/'docs/release-artifacts/v4.5.0/120-validation.json';x=json.loads(p.read_text());x['archive']=result;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False))
