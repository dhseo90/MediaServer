from pathlib import Path
import json,re,math
r=Path(__file__).parent
out={}
for run in sorted(r.glob('*-large')):
 if not (run/'output.log').exists():continue
 lines=(run/'output.log').read_text().splitlines()
 def objs(prefix):
  return [json.loads(s[len(prefix):]) for s in lines if s.startswith(prefix)]
 def texts(prefix):return [s[len(prefix):] for s in lines if s.startswith(prefix)]
 wires=objs('[R119-http-wire] ');normal=[v for v in wires if v['scope']!='auxiliary200'];aux=[v for v in wires if v['scope']=='auxiliary200']
 for v in aux:
  v['clientMs']=(v['endNs']-v['beginNs'])/1e6;v['fiveSecondComplete200']=v['status']==200 and v['failure']=='none' and v['clientMs']<=5000
 times=sorted((v['endNs']-v['beginNs'])/1e6 for v in normal)
 spaces=objs('[R101-space] ');live=[v for v in spaces if v.get('phase')=='live' and v.get('completedPhase')=='live']
 obj={'execution':json.loads((run/'execution.json').read_text()),'originalPrinted':texts('[R119-original-result] '),'wireOriginal':{'count':len(normal),'status':[v['status'] for v in normal],'p95Ms':times[math.ceil(len(times)*.95)-1] if times else None,'maxMs':max(times) if times else None},'auxiliary':aux,'requests':objs('[visual-request] '),'preparation':objs('[visual-preparation] '),'membership':texts('[R119-membership] '),'publicationNewDocuments':[re.match(r'newDocuments=(\d+)',s).group(1) for s in texts('[R118-publication] ')],'source':texts('[R118-source] '),'finish':texts('[R119-finish] '),'stop':texts('[R119-stop] '),'resource':objs('[recording-resource] '),'spaceSamples':len(spaces),'liveSampledMax':{k:max((v['metrics'][k] for v in live if v['metrics'].get(k) is not None),default=None) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'variableBytesMax':max((v['bounds']['variableBytes'] for v in live),default=None),'spaceEnd':objs('[R101-space-end] ')}
 # Prefixes are read from the original fixture output, never synthesized.
 out[run.name]=obj
(r/'final-comparison-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for name,o in out.items():print(name,o['originalPrinted'],[(a['status'],round(a['clientMs'],3))for a in o['auxiliary']],o['source'],o['finish'])
