import json,sys,collections,pathlib
p=pathlib.Path(sys.argv[1]);rows=[json.loads(s.split('] ',1)[1]) for s in p.read_text().splitlines() if s.startswith('[catalog-holder] ')]
def union(v):
 out=[]
 for a,b in sorted(v):
  if not out or a>out[-1][1]:out.append([a,b])
  else:out[-1][1]=max(b,out[-1][1])
 return out
out={}
for r in (1,2,3):
 own=[e for e in rows if e['r']==r];by=collections.defaultdict(float);gaps=[]
 for e in own:
  intervals=[]
  for h in rows:
   a,b=max(e['b'],h['a']),min(e['a'],h['e'])
   if h['m']==e['m'] and h['t']!=e['t'] and a<b:
    intervals.append((a,b));by[h['site']]+=(b-a)/1e6
  coverage=sum(b-a for a,b in union(intervals));gaps.append({'event':e,'coveredMs':coverage/1e6,'unattributedMs':(e['a']-e['b']-coverage)/1e6})
 out[r]={'count':len(own),'waitMs':sum(e['a']-e['b']for e in own)/1e6,'holdMs':sum(e['e']-e['a']for e in own)/1e6,'unattributedMs':sum(g['unattributedMs']for g in gaps),'sameMutexOtherHoldOverlapMs':dict(sorted(by.items(),key=lambda x:-x[1])),'largestGaps':sorted(gaps,key=lambda x:-x['unattributedMs'])[:5]}
print(json.dumps(out,indent=2))
