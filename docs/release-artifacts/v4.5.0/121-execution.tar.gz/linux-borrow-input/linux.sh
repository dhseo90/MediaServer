#!/bin/bash
set -eu
root=/tmp/media-server-r121-borrow-linux
mkdir -m700 "$root"
export TMPDIR="$root"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
finish(){ code=$?; python3 - "$root" "$code" <<'END'
import pathlib,shutil,sys,json
r=pathlib.Path(sys.argv[1]);o=pathlib.Path('/output')
for p in r.rglob('*'):
 if p.is_file() and p.suffix in ('.log','.json') and ('build' not in p.relative_to(r).parts):
  q=o/p.relative_to(r);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
(o/'exit.json').write_text(json.dumps({'exit':int(sys.argv[2]),'collection':'complete'}))
END
}
trap finish EXIT
id > "$root/environment.log"
uname -a >> "$root/environment.log"
pkg-config --modversion gstreamer-1.0 >> "$root/environment.log"

cmake -S /source -B "$root/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$root/configure.log" 2>&1
cmake --build "$root/build" --target media_server -j2 > "$root/build.log" 2>&1
python3 /input/focused.py /source "$root/focused" "$root/build" > "$root/focused.log" 2>&1

bash /source/scripts/internal/verify_recording_generation_request_proof.sh > "$root/proof-matrix.log" 2>&1

python3 /source/scripts/internal/verify_visual_request_media_cache.py --build "$root/build" --output "$root/cache.json" > "$root/cache-driver.log" 2>&1
