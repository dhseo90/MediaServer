#include "recording/recording_contracts.h"
#include <fstream>
#include <iostream>
#include <chrono>
#include <vector>
int main(int argc,char** argv){if(argc!=2)return 2;std::ifstream in(argv[1]);std::string line,error;std::vector<recording::RecordingSegmentV2> rows;while(std::getline(in,line)){recording::RecordingSegmentV2 row;if(!recording::ParseRecordingSegmentV2(line,&row,&error)){std::cerr<<error;return 3;}rows.push_back(std::move(row));}for(int pass=0;pass<3;++pass){long long ns=0;size_t bytes=0;for(const auto& row:rows){const auto begin=std::chrono::steady_clock::now();const auto s=recording::SerializeRecordingSegmentV2(row);ns+=std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now()-begin).count();bytes+=s.size();}std::cout<<"pass="<<pass<<" rows="<<rows.size()<<" bytes="<<bytes<<" serializeNs="<<ns<<'\n';}return 0;}
