import json,pathlib,re,math,sys
root=pathlib.Path(sys.argv[1]); out=root/'direct-analysis.json';assert not out.exists()
s=(root/'output.log').read_text()
def rows(prefix):return [json.loads(l[len(prefix):]) for l in s.splitlines() if l.startswith(prefix)]
w=rows('[R119-http-wire] ');original=[x for x in w if x['scope']=='original12'];aux=[x for x in w if x['scope']=='auxiliary200'];assert len(original)==12 and len(aux)==1
assert all(x['status']==200 and x['headers'] and x['errno']==0 and x['failure']=='none' for x in w)
a=aux[0];times=sorted((x['endNs']-x['beginNs'])/1e6 for x in original)
pub=[l for l in s.splitlines() if l.startswith('[R118-publication] ')];assert len(pub)==1
m=re.fullmatch(r'\[R118-publication\] newDocuments=(\d+) response=(.*)',pub[0]);fresh=int(m[1]);b=json.loads(m[2]);items=b['items'];assert len(items)==200 and len({x['id'] for x in items})==200
assert b['appliedQuery']['limit']==200 and b['appliedQuery']['threshold']==-1 and b['appliedQuery']['text']=='ball'
keys=[]
for x in items:
 assert math.isfinite(x['score']) and -1<=x['score']<=1 and x['playable'] and x['seekAvailable'] and x['timeBasis']=='verified-native-file-presentation'
 assert x['channelId'] in ('9101','9201') and math.isfinite(x['targetSeconds']) and x['targetSeconds']>=0
 keys.append((-x['score'],x['id']))
assert keys==sorted(keys) and fresh>0
metrics=rows('[R101-space] ');resource=rows('[recording-resource] ')
result={'original12':{'status':[x['status'] for x in original],'p95Ms':times[math.ceil(.95*len(times))-1],'maxMs':max(times)},'auxiliary':a,'auxStagesFromStartMs':{k:(a[k]-a['beginNs'])/1e6 if a[k] else None for k in ('headerNs','receiveEndNs','validationEndNs','bindingEndNs','outputEndNs','endNs')},'bindingInclusiveMs':a['bindingNs']/1e6,'auxItems':len(items),'publicFresh':fresh,'auxShapeOrderSeekMetadata':True,'publicFreshMeaning':'actual source-binding checked fresh result; membership separate; not exhaustive top-k independent oracle','markers':[l for l in s.splitlines() if l.startswith(('[R119-membership]','[R118-source','[R119-source','[R118-finish','[R119-finish','[R118-stop','[R119-stop','[R107-background]','[R107-result]'))],'sampleMaximaNotSimultaneous':{k:max(x['metrics'][k] for x in metrics if x['metrics'].get(k) is not None) for k in ('rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes')},'workspaceMax':max(x['bounds']['variableBytes'] for x in metrics),'spaceSamples':len(metrics),'resourceFinal':[x for x in resource if x['phase']=='after-storage-destruction'],'execution':json.loads((root/'execution.json').read_text())}
result['originalGate']=max(times)<=2000
result['auxiliaryGate']=(a['endNs']-a['beginNs'])<=5_000_000_000
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('original12','auxStagesFromStartMs','bindingInclusiveMs','auxItems','publicFresh','markers','sampleMaximaNotSimultaneous','workspaceMax','originalGate','auxiliaryGate')},ensure_ascii=False,indent=2))
