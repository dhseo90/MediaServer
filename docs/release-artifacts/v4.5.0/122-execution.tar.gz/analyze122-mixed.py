from pathlib import Path
import json,math,hashlib,collections,zlib,base64,re
r=Path(__file__).parent;p=r/'mixed900';app=next(p.glob('media-server-current-observer-*'));lines=(p/'run.log').read_text().splitlines();server=(app/'server-1.private.log').read_text().splitlines()
def rows(tag):return [json.loads(x.split('] ',1)[1]) for x in lines if x.startswith('['+tag+'] ')]
def put(n,v):(r/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def stats(a):
 s=sorted(a);return {'count':len(s),'p95Ms':s[math.ceil(len(s)*.95)-1] if s else None,'maxMs':max(s) if s else None}
f=json.loads((p/'artifacts/report.json').read_text());ex=json.loads((p/'execution.json').read_text());s=rows('current-observation');roots=rows('root-storage');load=f['evidenceLoad'];lat=load['searchLatencyMs'];assert len(lat)==load['searchSuccess']
segments={};rowsChecked=0
for q in sorted((app/'recordings').glob('*.jsonl')):
 if not q.is_file():continue
 with q.open() as stream:
  for n,line in enumerate(stream,1):
   v=json.loads(line);rowsChecked+=1
   if v.get('codec')=='zlib-base64':
    b=zlib.decompress(base64.b64decode(v['data']));assert len(b)==v['length'] and zlib.crc32(b)==v['crc32'];v=json.loads(b)
   if v.get('mutationType')!='segment_v2_bound_finalized':continue
   pay=v['payload'];seg=pay['segment'];bind=pay['sourceBinding'];sid=seg['segment_id']
   if seg['channel_id'] not in ['9101','9201']:continue
   record={'segment':sid,'channel':seg['channel_id'],'order':seg['order_sequence'],'occurredAtMs':v['occurredAtMs'],'generation':bind['source_generation'],'generationOrder':bind['generation_order'],'samples':bind['samples'],'fileEvidence':bind['file_evidence'],'path':pay['mediaRelpath']}
   if sid in segments:assert segments[sid]['record']==record;segments[sid]['locations'].append([q.name,n])
   else:segments[sid]={'record':record,'locations':[[q.name,n]]}
closed=[];groups=collections.defaultdict(list);sampleGaps=[]
for sid,wrapped in segments.items():
 row=wrapped['record'];b=row['fileEvidence'];q=app/'recordings'/row['path'];data=q.read_bytes();assert len(data)==b['bytes'] and sha(data)==b['sha256'];sample=row['samples'];ordinals=[x['ordinal'] for x in sample]
 assert [x[0] for x in b['samples']]==ordinals
 if any(y!=x+1 for x,y in zip(ordinals,ordinals[1:])):sampleGaps.append(sid)
 groups[(row['channel'],row['generation'],row['generationOrder'])].append(row)
 closed.append({'path':str(q.relative_to(r)),'bytes':len(data),'sha256':sha(data),'segment':sid,'channel':row['channel'],'generationOrder':row['generationOrder'],'firstOrdinal':ordinals[0],'lastOrdinal':ordinals[-1],'sampleCount':len(sample),'occurredAtMs':row['occurredAtMs']})
gaps=[]
for (channel,generation,order),items in groups.items():
 items.sort(key=lambda x:x['samples'][0]['ordinal'])
 for a,b in zip(items,items[1:]):
  last=a['samples'][-1];first=b['samples'][0]
  if first['ordinal']>last['ordinal']+1:gaps.append({'channel':channel,'generation':generation,'generationOrder':order,'beforeSegment':a['segment'],'afterSegment':b['segment'],'lastAccepted':last,'nextAccepted':first,'absentAcceptedOrdinals':first['ordinal']-last['ordinal']-1,'ptsSeparationNs':first['pts_ns']-last['pts_ns'],'beforeFinalizedAtMs':a['occurredAtMs'],'afterFinalizedAtMs':b['occurredAtMs']})
notices=[]
pat=re.compile(r'input discontinuity generationOrder=(\d+) previousOrdinal=(\d+) nextOrdinal=(\d+) deliveryLoss=(\d+) sourceDiscont=(\d+)')
for n,line in enumerate(server,1):
 m=pat.search(line)
 if m:notices.append(dict(zip(['generationOrder','previousOrdinal','nextOrdinal','deliveryLoss','sourceDiscont'],map(int,m.groups())),serverLine=n,eventTimestamp=None))
byOrder={order:channel for channel,g,order in groups}
for row in notices:row['channelFromCommittedGeneration']=byOrder.get(row['generationOrder'])
packages=[]
for q in sorted((app/'recordings/evidence-packages').glob('*.evp')):
 data=q.read_bytes();assert data[:8]==b'MSEVP01\n';length=int.from_bytes(data[8:16],'little');assert 0<length<=1048576;v=json.loads(data[16:16+length]);offset=16+length
 for a in v['assets']:
  size=a['sizeBytes'];asset=data[offset:offset+size];assert sha(asset)==a['sha256'];offset+=size
 assert offset==len(data)
 packages.append({'id':q.stem,'sha256':sha(data),'bytes':len(data),'createdAtMs':v['createdAtMs'],'queryKind':v['queryKind'],'status':v['status'],'frames':v['frames']})
put('closed-media-hashes.json',closed);put('recording-continuity.json',{'scope':'post-crash offline format/CRC/file-hash checks and committed sample ranges; not new product authentication/current-state, source/dequeue enumeration, or decoder execution','uniqueBoundFinalizations':len(segments),'rawJournalRowsChecked':rowsChecked,'withinSegmentOrdinalGaps':sampleGaps,'segmentFirstOrdinalNotInputKeyframe':[x['segment'] for x in closed if x['firstOrdinal'] not in [1,31,61,91]],'inputKeyframeScope':'fixed normalized120AU input from unchanged R114; no new keyframe creation','betweenCommittedSegmentGaps':gaps,'boundedDiscontinuityNotices':notices,'totalQueueDrops':None,'totalWriterSkippedForKeyframe':None,'totalRecoveries':None,'eventTimeLimit':'Discontinuity lines have no per-event timestamp/channel. Channel joined only when generation exists in committed source. File finalize timestamps are not queue drop times. Log buffer arrival is not event time.','saturation':'up to64 notices perwriter; counts are bounded samples, not complete totals','packages':packages})
for tag in ['root-storage','current-observation','recording-status-judgment','visual-query-observation','evidence-create-responses','mixed-http-timing']:put(tag+'.json',rows(tag))
rootSamples=[x for x in roots if x['reason']=='sample'];assert len(rootSamples)==len(s)
operands=[{'sample':i+1,'phaseAt':a['phaseAt'],'measurementStartedAt':b['measurementStartedAt'],'measurementCompletedAt':b['measurementCompletedAt'],'fixedBytes':b['fixedBytes'],'namedAndParentBytes':b['totalBytes'],'anonymousLogical':a['anonymousFileBytes'],'anonymousAllocated':a['anonymousAllocatedBytes'],'variableUsed':b['totalBytes']-b['fixedBytes']+max(a['anonymousFileBytes'],a['anonymousAllocatedBytes']),'limit':448*1024*1024} for i,(a,b) in enumerate(zip(s,rootSamples))]
put('workspace-operands.json',{'scope':'recomputed same ordered sample/root operands; sequential/non-atomic, not instantaneous peak','rows':operands})
http=rows('mixed-http-timing');pairs=rows('evidence-create-responses')

rawResource=[json.loads(x.split('] ',1)[1]) for x in server if x.startswith('[recording-resource] ')]
failures=[x for x in lines if x.startswith('[fail]')]
analysis={'status':'FAIL','attempts':1,'firstFailure':failures[0],'failures':failures,'execution':ex,'duration':{'verifiedMainMs':f['verifiedDurationMs'],'nodeElapsedMs':f['elapsedMs'],'totalSeconds':ex['totalWithFinalBindingSeconds']},'search':{'population':'unchanged original successful mixed HTTP array; allowed unavailable retained separately; A/retrieval excluded','overall':stats(lat),'gate':'PASS','unavailable':load['searchUnavailable'],'clientCounts':load['searchSuccessByClient'],'timeoutCount':sum(x.get('outcome')=='timeout' for x in http),'orderedSuccessThirds':[stats(lat[i*78:(i+1)*78]) for i in range(3)],'thirdsMeaning':'recorded successful array order (batch/client order), not time windows or arrival order'},'evidence':{'structured':load['createSuccess'],'complete':load['createComplete'],'partial':load['createPartial'],'visual':load['visualCreated'],'busy':load['createBusy'],'retainedChecks':load['retainedChecks'],'aCompleted':len(f['aLoad']['completed']),'storedPackages':len(packages),'offlineAssetHashes':'all stored manifest assets matched bytes; not new independent decoder execution'},'progress':{'phase':f['phase'],'windows':load['windows'],'lastIndex':load['visualIndexObservations'][-1],'closedFiles':len(closed),'maxClosedBytes':max(x['bytes'] for x in closed),'bound':71237},'loss':{'boundedNotices':len(notices),'deliveryLossNotices':sum(x['deliveryLoss'] for x in notices),'betweenCommittedGaps':len(gaps),'withinSegmentGaps':len(sampleGaps),'totalDrops':None,'totalKeyframeSkipped':None,'scope':'committed ranges only; no universal source/dequeue enumeration; post-crash finalization may be incomplete'},'resources':{'samples':len(s),'allFDComplete':all(x['fdObservation']['complete'] for x in s),'pidIdentity':list({str(x['pid'])+':'+x['startIdentity'] for x in s}),'separateSampleMaxima':{k:max(x[k] for x in s) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'largestWorkspaceOperands':max(operands,key=lambda x:x['variableUsed']),'workspaceFailure':f['workspaceFailure'],'lastObservedOwner':rawResource[-1],'afterDestructionOwners':[x for x in rawResource if x['phase']=='after-storage-destruction'],'limits':'sample maxima not simultaneous peaks; logical owner not totalheap; crash OS cleanup not normal Finish/owner0'},'termination':{'cleanup':rows('process-cleanup')[0],'lastA':'PASS','latencyGate':'PASS','sampleCoverage':'PASS','retainedProgress':'PASS','disable9101':'PASS','disable9201':'FAIL http-header-error; server stop-channel log is not HTTP confirmation','closedJournal':'not-run','normalStopFinish':'not-confirmed; SIGBUS','ownerFinal':'not-observed','diagnosticCollection':'FAIL recording-state-capture-incomplete; subsequent summaries not-run','sourceUnchanged':ex['source']==ex['sourceEnd']},'cause':'SIGBUS root cause unconfirmed; no retry/product change after final run','next45':'not eligible; abnormal termination and incomplete diagnostic collection','notRun':['retry','45minutes','120minutes','public procedures']}
put('mixed-analysis.json',analysis)
print(json.dumps({k:analysis[k] for k in ['duration','search','evidence','loss','termination']},ensure_ascii=False,indent=2))
