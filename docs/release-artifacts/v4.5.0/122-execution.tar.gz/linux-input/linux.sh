#!/bin/bash
set -eu
root=/tmp/media-server-r122-linux
mkdir -m700 "$root"
export TMPDIR="$root"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
finish(){ code=$?; python3 - "$root" "$code" <<'END'
import pathlib,shutil,sys,json
r=pathlib.Path(sys.argv[1]);o=pathlib.Path('/output')
for p in r.rglob('*'):
 if p.is_file() and p.suffix in ('.log','.json') and ('build' not in p.relative_to(r).parts):
  q=o/p.relative_to(r);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
(o/'exit.json').write_text(json.dumps({'exit':int(sys.argv[2]),'collection':'complete'}))
END
}
trap finish EXIT
id > "$root/environment.log"
uname -a >> "$root/environment.log"
pkg-config --modversion gstreamer-1.0 >> "$root/environment.log"

cmake -S /source -B "$root/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$root/configure.log" 2>&1
cmake --build "$root/build" --target media_server -j2 > "$root/build.log" 2>&1
python3 /input/focused.py /source "$root/focused" "$root/build" > "$root/focused.log" 2>&1

c++ -std=c++17 -Wall -Wextra -Werror -pthread /source/scripts/internal/recording_http_observation_smoke.cpp -o "$root/observation"
"$root/observation" > "$root/observation.log" 2>&1
c++ -std=c++17 -Wall -Wextra -Werror -I/source/include /source/scripts/internal/recording_binding_prepare_smoke.cpp /source/src/recording/recording_contracts.cpp /source/src/domain/strict_json.cpp -o "$root/binding"
"$root/binding" /input/corpus.jsonl > "$root/binding.log" 2>&1
MEDIA_SERVER_VERIFY_V410_RECORDING_CONTRACTS_BUILD_DIR="$root/contracts" bash /source/scripts/internal/verify_v410_recording_contracts.sh > "$root/contracts.log" 2>&1

python3 /source/scripts/internal/verify_visual_request_media_cache.py --build "$root/build" --output "$root/cache.json" > "$root/cache-driver.log" 2>&1
