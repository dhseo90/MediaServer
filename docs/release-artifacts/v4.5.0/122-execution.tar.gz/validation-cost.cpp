#include "recording/recording_contracts.h"
#include <fstream>
#include <chrono>
#include <iostream>
int main(int argc,char**argv){if(argc!=2)return 2;using C=std::chrono::steady_clock;for(int run=0;run<3;++run){std::ifstream f(argv[1]);std::string b,s,e;long long parse=0,repeat=0;unsigned n=0;while(std::getline(f,b)&&std::getline(f,s)){recording::RecordingSourceBindingV1 binding;recording::RecordingSegmentV2 segment;auto t=C::now();if(!recording::ParseRecordingSourceBindingV1(b,&binding,&e)||!recording::ParseRecordingSegmentV2(s,&segment,&e)){std::cerr<<e;return 1;}parse+=std::chrono::duration_cast<std::chrono::nanoseconds>(C::now()-t).count();t=C::now();if(!recording::ValidateRecordingSourceBindingV1(binding,&e))return 1;repeat+=std::chrono::duration_cast<std::chrono::nanoseconds>(C::now()-t).count();++n;}std::cout<<"run="<<run<<" rows="<<n<<" parseMs="<<parse/1e6<<" repeatedBindingValidationMs="<<repeat/1e6<<'\n';} }
