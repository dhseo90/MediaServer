from pathlib import Path
import json,hashlib,zlib,base64,re
r=Path('/private/tmp/media-server-r123-s_nu6tzo')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,x): (r/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
raw=(r/'crash-original.ips').read_text();x=json.loads(raw[raw.index('\n')+1:]);t=x['threads'][x['faultingThread']]
crash={k:x[k] for k in ['pid','procName','captureTime','cpuType','osVersion','exception','termination','vmRegionInfo','faultingThread']}
crash.update(originalSha256=sha(r/'crash-original.ips'),thread=t,images=[{k:i[k] for k in ['name','uuid','base','size','arch'] if k in i} for i in x['usedImages']])
save('crash-sanitized.json',crash)
def rows(root):
 for f in sorted(root.glob('active-*.jsonl')):
  for i,line in enumerate(f.read_bytes().splitlines()):
   x=json.loads(line)
   if x.get('codec')=='zlib-base64':
    b=zlib.decompress(base64.b64decode(x['data']));assert len(b)==x['length'] and zlib.crc32(b)==x['crc32'];x=json.loads(b)
   if x.get('mutationType')=='segment_v2_bound_finalized':yield f.name,i,x
seed=json.loads((r/'after-http/input-binding.json').read_text())
out={}
for run in ['after-http','final-http']:
 p=r/run;record=p/'recordings';result=json.loads((p/'result.json').read_text());new=[]
 for filename,line,x in rows(record):
  data=x['payload'];s=data['segment'];rel=data['mediaRelpath'];f=record/rel
  if rel in seed:continue
  assert f.is_file() and len(f.read_bytes())==s['size_bytes'] and sha(f)==s['checksum_sha256']
  new.append({'journal':filename,'line':line+1,'channel':s['channel_id'],'id':s['segment_id'],'order':s['order_sequence'],'occurredAtMs':x['occurredAtMs'],'bytes':s['size_bytes'],'sha256':s['checksum_sha256'],'bindingSha256':hashlib.sha256(json.dumps(data['sourceBinding'],sort_keys=True,separators=(',',':')).encode()).hexdigest()})
 oldmp4=[k for k in seed if k.endswith('.mp4')];assert all(sha(record/k)==seed[k] for k in oldmp4)
 a=next(c for c in result['disabled9101']['channels'] if c['channelId']=='9201');b=next(c for c in result['otherProgress']['channels'] if c['channelId']=='9201');delta=b['continuousBytes']-a['continuousBytes'];assert a['active'] and b['active'] and delta>0
 resources=[json.loads(l.split('[recording-resource] ',1)[1]) for l in (p/'server.private.log').read_text().splitlines() if '[recording-resource] ' in l]
 assert resources[-1]['phase']=='after-storage-destruction' and all(resources[-1][k]==0 for k in ['ram','scratchDisk','scratchFd'])
 assert result['closed']=={'code':0,'signal':None} and result['firstError'] is None
 assert all(not c['active'] and not c['enabled'] for c in result['disabled9201']['channels'] if c['channelId'] in ['9101','9201'])
 out[run]={'newFinalized':new,'newFiles':len(new),'seedMP4Unchanged':len(oldmp4),'otherChannelProgressBytes':delta,'otherChannelProof':'actual active status with increasing confirmed continuous bytes; new durable files independently match journal/hash; exact per-packet progress not enumerated','disable':[q for q in result['requests'] if q['method']=='PUT'],'exit':result['closed'],'elapsedMs':result['elapsedMs'],'resources':resources,'limits':'logical reservation observations, not total heap/OS-FD/RSS or instantaneous full-process peaks; short run not sustained load'}
save('analysis.json',out)
print(json.dumps({k:{'newFiles':v['newFiles'],'otherProgressBytes':v['otherChannelProgressBytes'],'seedMP4Unchanged':v['seedMP4Unchanged']} for k,v in out.items()}))
