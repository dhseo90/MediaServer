import fs from 'node:fs';
import {CurrentRecordingObserver,closedJournalComplete} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs';
const base='/private/tmp/media-server-r123-s_nu6tzo';
const observer=new CurrentRecordingObserver(base+'/final-http/recordings',base+'/normalize-final');
let result,close,polls=0;const start=performance.now();
try {do{result=await observer.pollAsync();polls++;if(polls>1000||performance.now()-start>60000)throw Error('bounded-readback-budget');}while(result.backlog||result.busy);if(!closedJournalComplete(result))throw Error('closed-journal-incomplete');}
finally{close=await observer.closeAsync();fs.writeFileSync(base+'/closed-journal-final.json',JSON.stringify({result,close,polls,elapsedMs:performance.now()-start},null,2),{flag:'wx'});}
console.log(JSON.stringify({pass:true,polls,mutations:result.mutationCount,partialBytes:result.partialBytes,backlog:result.backlog,close}));
