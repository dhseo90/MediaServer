from pathlib import Path
import json,hashlib,shutil,subprocess,time,sys
sys.path.insert(0,'/Users/dhseo/Workspace/mediaServer/scripts/internal')
from recording_native_isolation import environment
r=Path('/private/tmp/media-server-r123-s_nu6tzo');p=r/'media-server-current-observer-final-readback';p.mkdir(mode=0o700)
def hashes(root):return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in root.rglob('*') if f.is_file() and not f.is_symlink()}
source=r/'final-http/recordings';before=hashes(source);shutil.copytree(source,p/'recordings')
build=json.loads((r/'native-build.json').read_text());cmd=build['command'] if 'command' in build else build['cmd'];cmd[-1]=str(r/'normalize-final')
with (r/'native-final-build.log').open('xb') as log:x=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
assert x.returncode==0
start=time.monotonic()
with (p/'readback.log').open('xb') as log:x=subprocess.run([str(r/'normalize-final'),'--snapshot',str(p/'recordings')],env=environment(p),stdout=log,stderr=subprocess.STDOUT,timeout=60)
after=hashes(p/'recordings');result={'exit':x.returncode,'seconds':time.monotonic()-start,'before':before,'after':after,'changed':[k for k,v in before.items() if after.get(k)!=v],'added':[k for k in after if k not in before],'sourceUnchanged':hashes(source)==before,'command':[str(r/'normalize-final'),'--snapshot',str(p/'recordings')]};(p/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['before','after']}));assert x.returncode==0 and result['sourceUnchanged']
