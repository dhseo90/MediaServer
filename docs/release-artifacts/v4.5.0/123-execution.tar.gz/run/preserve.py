from pathlib import Path,PurePosixPath
import json,tarfile,hashlib,io,re,subprocess
r=Path('/private/tmp/media-server-r123-s_nu6tzo');repo=Path('/Users/dhseo/Workspace/mediaServer');dest=repo/'docs/release-artifacts/v4.5.0/123-execution.tar.gz'
assert not dest.exists()
def sha(b):return hashlib.sha256(b).hexdigest()
entries={};references=[];redactions=[]
def add(name,b):
 assert name not in entries and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
 entries[name]=b
for p in sorted(r.iterdir()):
 if p.is_file() and p.name!='crash-original.ips' and (p.suffix in ['.json','.log','.py','.mjs','.lldb','.patch']):add('run/'+p.name,p.read_bytes())
# Preserve the exact crashed binary/symbol table; current binary/runtime remain in build and have hashes.
add('symbols/media_server-r122', (r/'media_server-r122').read_bytes())
prior=r/'prior/mixed900/media-server-current-observer-lSFepa/recordings'
priorhash={str(p.relative_to(prior)):sha(p.read_bytes()) for p in prior.rglob('*') if p.is_file() and not p.is_symlink()}
for label in ['before-http','after-http','final-http']:
 root=r/label
 for name in ['result.json','input-binding.json']:add(label+'/'+name,(root/name).read_bytes())
 p=root/'server.private.log';raw=p.read_bytes();txt=raw.decode();clean=re.sub(r'(?:rtsp|rtsps|https?|file|stun)://[^\s"\x27<>]+','<redacted-url>',txt).encode();add(label+'/server.sanitized.log',clean);redactions.append({'path':label+'/server.private.log','originalBytes':len(raw),'originalSha256':sha(raw),'sanitizedSha256':sha(clean),'sameBytes':raw==clean})
 files={}
 for p in sorted((root/'recordings').rglob('*')):
  assert not p.is_symlink()
  if not p.is_file():continue
  rel=str(p.relative_to(root/'recordings'));b=p.read_bytes();h=sha(b);files[rel]={'bytes':len(b),'sha256':h,'mode':oct(p.stat().st_mode&0o777)}
  if priorhash.get(rel)==h:references.append({'run':label,'path':'recordings/'+rel,'sha256':h,'archive':'122-execution.tar.gz','member':'mixed900/media-server-current-observer-lSFepa/recordings/'+rel})
  else:add(label+'/recordings/'+rel,b)
 add(label+'/output-hashes.json',json.dumps(files,indent=2).encode())
for label in ['media-server-current-observer-closed-readback','media-server-current-observer-crash-recovery','media-server-current-observer-final-readback']:
 for name in ['result.json','readback.log']:add('readback/'+label+'/'+name,(r/label/name).read_bytes())
for name in ['src/recording/recording_history_index.h','include/core/session_manager.h','scripts/internal/recording_history_stack_smoke.cpp']:
 add('source/'+name,(repo/name).read_bytes())
manifest={'schema':'media-server.v450.r123.archive.v1','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in entries.items()],'references':references,'redactions':redactions,'exclusions':'user settings/private95backup/auth files/home/cache/models/SDK/raw system crash/core dumps; original system crash remains local with SHA linked to selected sanitized fields','priorArchiveSha256':sha((repo/'docs/release-artifacts/v4.5.0/122-execution.tar.gz').read_bytes())}
add('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode())
with dest.open('xb') as output:
 with tarfile.open(fileobj=output,mode='w:gz') as t:
  for name,b in entries.items():
   item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o600;t.addfile(item,io.BytesIO(b))
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(entries)
 for m in t:
  assert m.isfile() and sha(t.extractfile(m).read())==sha(entries[m.name])
# Verify referenced bytes in the already committed archive, without re-extracting.
with tarfile.open(repo/'docs/release-artifacts/v4.5.0/122-execution.tar.gz') as t:
 expected={x['member']:x['sha256'] for x in references}
 for name,h in expected.items():assert sha(t.extractfile(name).read())==h
receipt={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest.read_bytes()),'files':len(entries),'payloadBytes':sum(map(len,entries.values())),'references':len(references),'allMemberBytesVerified':True,'allReferenceBytesVerified':True,'manifestSha256':sha(entries['manifest.json'])};(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
