import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';
import {reservePort,stopServer,assertPortClosed,bootstrapRecordingUiAuth,createUiAuthPasswords} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/verify_v410_recording_ui_contract.mjs';
import {mixedRecordingSettings,nextRecordingSettings} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_longrun_progress.mjs';
const [root,binary]=process.argv.slice(2),repo='/Users/dhseo/Workspace/mediaServer',diagnose=true,stateDiagnose=false,short=false,contentionDiagnose=false,frameTraceMode='bounded';
const pause=ms=>new Promise(r=>setTimeout(r,ms));let child,cookie='',closed=null,logFd,firstError=null;const start=performance.now();let bytes=0;
const result={root,binary,attempts:1,kind:'short closed-store copy; not historical live cache',requests:[],stop:null};
async function request(base,method,route,body){const begin=performance.now();const r=await fetch(base+route,{method,signal:AbortSignal.timeout(5000),redirect:'error',headers:{Cookie:cookie,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined});const text=await r.text();result.requests.push({method,route,status:r.status,bytes:Buffer.byteLength(text),elapsedMs:performance.now()-begin});if(r.status!==200&&r.status!==201)throw Error('http-status-'+r.status+':'+text.slice(0,300));return JSON.parse(text);}
async function until(f,ms=15000){const end=performance.now()+ms;while(performance.now()<end){if(closed)throw Error('server-exited:'+JSON.stringify(closed));if(await f())return;await pause(100);}throw Error('readiness-timeout');}
function environment(http,rtsp,stun){const env={PATH:process.env.PATH,HOME:path.join(root,"home"),XDG_CACHE_HOME:path.join(root,"cache"),TMPDIR:path.join(root,'tmp')};
  const values={SKIP_LOCAL_ENV:1,SKIP_BUILD:1,SKIP_ENV_CHECK:1,BUILD_DIR:path.join(repo,'build-gst-onnx'),BIN_PATH:binary,AUTH_MODE:'auto',ENABLE_AI:0,ENABLE_LAB:0,ENABLE_OPS:1,ENABLE_CLIENT:0,ENABLE_YOUTUBE_SOURCE:0,
    LISTEN_ADDRESS:'127.0.0.1',HTTP_LISTEN_ADDRESS:'127.0.0.1',LISTEN_PORT:rtsp,HTTP_LISTEN_PORT:http,FORCE_RTSP_TCP:1,
    FILE_ROOT:path.join(root,'input'),DEFAULT_FILE:path.join(root,'input/retention-9101.mp4'),STATE_DIR:path.join(root,'state'),AUTH_USERS_FILE:path.join(root,'state/users.json'),
    SOURCE_REGISTRY:path.join(root,'state/sources.json'),PUBLISHED_VIEWS:path.join(root,'state/views.json'),ANALYSIS_REGISTRY:path.join(root,'state/analysis.json'),
    ANALYSIS_EVENT_STORAGE_ENABLED:0,ANALYSIS_EVENT_STORAGE_PATH:path.join(root,'events/events.jsonl'),ANALYSIS_EVENT_POST_ENABLED:0,
    ANALYSIS_EVENT_CLIP_HOOK_ENABLED:0,ANALYSIS_EVENT_CLIP_DIR:path.join(root,'events/clips'),ANALYSIS_EVENT_SNAPSHOT_HOOK_ENABLED:0,ANALYSIS_EVENT_SNAPSHOT_DIR:path.join(root,'events/snapshots'),
    VA_REVIEW_ENABLED:1,VA_REVIEW_LOCAL_ENDPOINT:'http://127.0.0.1:1',VISUAL_SEARCH_ENABLED:1,VISUAL_SEARCH_MODEL_DIRECTORY:path.join(repo,'models/v430-siglip2'),VISUAL_SEARCH_SCAN_SECONDS:1,VISUAL_SEARCH_SAMPLE_SECONDS:1,EVIDENCE_ENABLED:1,RECORDING_ENABLED:1,RECORDING_STORAGE_ROOT:path.join(root,'recordings'),RECORDING_SEGMENT_DURATION_SECONDS:2,RECORDING_RESERVED_FREE_BYTES:0,RECORDING_RETENTION_INTERVAL_MS:1000,
    VERIFY_RECORDING_STATE_TRACE:1,VERIFY_CATALOG_HOLDER_TRACE:diagnose&&!stateDiagnose?1:0,VERIFY_VISUAL_REQUEST_TRACE:1,VERIFY_RECORDING_SEARCH_TRACE:1,VERIFY_VISUAL_LATENCY_TRACE:short?1:0,VERIFY_RECORDING_RESOURCE_TRACE:1,VERIFY_FRAME_TRACE:frameTraceMode,VERIFY_RECORDING_LATENCY_TRACE:1,VERIFY_RECORDING_LATENCY_SLOW_ONLY:1,
    GST_CACHE_DIR:path.join(root,'gst-cache'),GST_PLUGIN_PROFILE:'headless',WEBRTC_STUN_SERVER:`stun://127.0.0.1:${stun}`,WEBRTC_TURN_SERVER:''};
  if(contentionDiagnose)values.VERIFY_CATALOG_HOLDER_WHOLE_REQUESTS='slow-first';
  for(const [k,v] of Object.entries(values))env['MEDIA_SERVER_'+k]=String(v);return env;
}

const http=await reservePort(),rtsp=await reservePort(),stun=await reservePort();result.ports={http,rtsp};const base=`http://127.0.0.1:${http}`;
try{
 const env=environment(http,rtsp,stun);fs.writeFileSync(path.join(root,'environment.json'),JSON.stringify(env,null,2),{flag:'wx',mode:0o600});
 child=spawn(path.join(repo,'server.sh'),['foreground'],{cwd:repo,env,stdio:['ignore','pipe','pipe']});result.pid=child.pid;
 logFd=fs.openSync(path.join(root,'server.private.log'),'wx',0o600);for(const stream of [child.stdout,child.stderr])stream.on('data',b=>{bytes+=b.length;if(bytes>4*1024*1024){firstError??='log-cap';child.kill('SIGTERM');return;}fs.writeSync(logFd,b);});child.on('exit',(code,signal)=>{closed={code,signal};});
 await until(async()=>{try{return Boolean(await request(base,'GET','/health'));}catch{return false;}},30000);
 const auth=await bootstrapRecordingUiAuth(base,createUiAuthPasswords());cookie=auth.cookies[0];
 for(const id of ['9101','9201'])await request(base,'POST','/ops/api/sources',{sourceId:id,displayName:'Owned shutdown '+id,kind:'file',file:'retention-'+id+'.mp4',enabled:true,recording:mixedRecordingSettings('continuous-r114',1,true)});
 await until(async()=>{const s=await request(base,'GET','/ops/api/recordings/status');return ['9101','9201'].every(id=>s.channels?.some(c=>c.channelId===id&&c.active));});
 await pause(7000);result.before=await request(base,'GET','/ops/api/recordings/status');
 for(const id of ['9101','9201']){const registry=await request(base,'GET','/ops/api/sources');const source=registry.sources.find(s=>s.sourceId===id);if(!source)throw Error('source-missing');
  const body={sourceId:id,displayName:'Owned shutdown '+id,kind:'file',file:'retention-'+id+'.mp4',enabled:true,recording:nextRecordingSettings(registry,id,false,'continuous-r114')};
  const response=await request(base,'PUT','/ops/api/sources/'+id,body);if(response.source?.recording?.enabled!==false)throw Error('disable-response');
  const state=await request(base,'GET','/ops/api/recordings/status');result['disabled'+id]=state;if(state.channels.some(c=>c.channelId===id&&(c.active||c.enabled)))throw Error('disable-state');
  if(id==='9101'){if(!state.channels.some(c=>c.channelId==='9201'&&c.active))throw Error('other-channel-stopped');await pause(2300);result.otherProgress=await request(base,'GET','/ops/api/recordings/status');}
 }
}catch(e){firstError??=String(e);}
finally{
 if(child){try{await stopServer(child);result.stop=closed;}catch(e){result.stopError=String(e);}for(const port of [http,rtsp])try{await assertPortClosed(port);}catch(e){result.portError=String(e);}}
 if(logFd!==undefined)fs.closeSync(logFd);result.firstError=firstError;result.closed=closed;result.logBytes=bytes;result.elapsedMs=performance.now()-start;fs.writeFileSync(path.join(root,'result.json'),JSON.stringify(result,null,2),{flag:'wx'});console.log(JSON.stringify(result));
}
process.exitCode=firstError||closed?.code!==0||result.portError?1:0;
