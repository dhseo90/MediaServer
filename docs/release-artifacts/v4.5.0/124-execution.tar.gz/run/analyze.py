import json,pathlib,math,zlib,base64,hashlib,collections
R=pathlib.Path(__file__).parent;M=R/'mixed900';O=M/'media-server-current-observer-ObhUeB';F=json.loads((R/'result.json').read_text());L=(M/'run.log').read_text().splitlines();S=(O/'server-1.private.log').read_text().splitlines()
def tagged(lines,t):return [json.loads(x[len(t)+1:]) for x in lines if x.startswith(t+' ')]
def stats(v):
 s=sorted(v);return {'count':len(v),'p95Ms':s[math.ceil(len(s)*.95)-1] if s else None,'maxMs':max(s) if s else None}
obs=tagged(L,'[current-observation]');roots=tagged(L,'[root-storage]');resources=tagged(S,'[recording-resource]');lat=F['evidenceLoad']['searchLatencyMs'];tim=tagged(L,'[mixed-http-timing]')
mutations={};compressed=0
for p in sorted((O/'recordings').glob('*.jsonl')):
 if not p.is_file():continue
 for line in p.read_text().splitlines():
  d=json.loads(line)
  if d.get('codec')=='zlib-base64':
   b=zlib.decompress(base64.b64decode(d['data']));assert len(b)==d['length'] and zlib.crc32(b)==d['crc32'];d=json.loads(b);compressed+=1
  if d.get('schema')!='media-server.recording-mutation.v1':continue
  mid=d['mutationId']
  if mid in mutations:assert mutations[mid]==d
  mutations[mid]=d
segments=[];groups=collections.defaultdict(list);inside=[];file_errors=[]
for d in mutations.values():
 if d['mutationType']!='segment_v2_bound_finalized':continue
 p=d['payload'];b=p['sourceBinding'];s=p['segment'];media=O/'recordings'/p['mediaRelpath'];raw=media.read_bytes();assert len(raw)==s['size_bytes'];assert hashlib.sha256(raw).hexdigest()==s['checksum_sha256']
 if s['channel_id'] not in ['9101','9201']:continue
 ords=[x['ordinal'] for x in b['samples']];gaps=[(x,y) for x,y in zip(ords,ords[1:]) if y!=x+1];inside.extend(gaps)
 row={'segment':s['segment_id'],'channel':s['channel_id'],'generation':b['source_generation'],'generationOrder':b['generation_order'],'order':s['order_sequence'],'first':ords[0],'last':ords[-1],'samples':len(ords),'bytes':len(raw),'sha256':s['checksum_sha256'],'indexComplete':b['index_complete']};segments.append(row);groups[(row['channel'],row['generation'])].append(row)
between=[];pairs=0
for key,v in groups.items():
 v.sort(key=lambda r:r['order'])
 for a,b in zip(v,v[1:]):
  pairs+=1
  if b['first']!=a['last']+1:between.append({'channel':key[0],'generation':key[1],'before':a['segment'],'after':b['segment'],'last':a['last'],'first':b['first']})
frame=tagged(S,'[visual-frame]')
D={'schema':'media-server.v450.r124.analysis.v1','derivedFrom':['mixed900/run.log','mixed900/media-server-current-observer-ObhUeB/server-1.private.log','closed recording journal bytes'],
 'search':{'originalSuccess':stats(lat),'byClient':F['evidenceLoad']['searchSuccessByClient'],'unavailable':F['evidenceLoad']['searchUnavailable'],'timeoutOrTransportFailures':[v for v in tim if v.get('outcome')!='ok'],'orderedSuccessThirds':[stats(lat[i:i+80]) for i in range(0,len(lat),80)],'thirdsMeaning':'success array order groups, not exact five-minute periods; no auxiliary requests added'},
 'evidence':{k:F['evidenceLoad'][k] for k in ['cycles','createSuccess','createComplete','createPartial','createBusy','visualCreated','visualExpired','retainedChecks','windows']},
 'A':{'scheduled':len(F['aLoad']['schedule']),'completed':sum(x['state']=='completed' for x in F['aLoad']['schedule']),'detectorEvaluated':F['aLoad']['detectorEvaluated']},
 'shutdown':{'puts':[x for x in tagged(L,'[http-timing]') if x['method']=='PUT'],'settingPassLines':[x for x in L if 'setting ' in x and ' false' in x],'closedJournalPass':'[pass] LP26-O02 closed journal no partial tail' in L,'cleanup':tagged(L,'[process-cleanup]'),'state':tagged(L,'[recording-state-summary]'),'ownersAtShutdown':[x for x in resources if x['phase']!='sample']},
 'resources':{'sampleCount':len(obs),'identities':sorted({(x['pid'],x['startIdentity']) for x in obs}),'allFdComplete':all(x['fdObservation']['complete'] for x in obs),'sampleMax':{k:max(x[k] for x in obs) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'rootVariableMax':max(x['variableBytes'] for x in roots if 'variableBytes' in x),'note':'maxima are different-time sequential samples; not additive simultaneous peak; reservations not actual disk or RSS','summary':F['resources'],'ownerFinal':resources[-1]},
 'recording':{'finalizedPerChannel':dict(collections.Counter(x['channel'] for x in segments)),'newSegments':len(segments),'originalSeedSegments':sum(d['mutationType']=='segment_v2_bound_finalized' for d in mutations.values())-len(segments),'sampleCount':sum(x['samples'] for x in segments),'allIndexComplete':all(x['indexComplete'] for x in segments),'sourceGenerationGroups':len(groups),'sameGenerationAdjacentPairs':pairs,'internalOrdinalGaps':inside,'betweenSegmentOrdinalGaps':between,'deliveryLossLogCount':sum('deliveryLoss' in s for s in S),'allFinalizedMediaBytesAndHashVerified':True,'totalQueueDrop':None,'sourceInputTotal':None,'note':'0 logs/gaps does not prove all input delivered; source generation boundaries and incomplete final input excluded; no full queue counter'},
 'diagnostics':{tag:tagged(L,tag)[-1] for tag in ['[frame-trace-summary]','[search-failure-summary]','[server-diagnostic]','[resource-trace-summary]']},
 'frameRepresentatives':[{'policy':x['policy'],'target':x['target'],'lastPts':x['lastPts'],'lastStream':x['lastStream'],'succeeded':x['succeeded'],'factoryEvents':[e for e in x['events'] if e['kind'] in ['factory','codec-threads']]} for x in frame],
 'journal':{'uniqueMutations':len(mutations),'compressedEnvelopesCheckedIncludingDuplicates':compressed,'types':dict(collections.Counter(d['mutationType'] for d in mutations.values()))},
 'analysisPreparationFailure':{'kind':'read-only Python analysis assumed every journal line had mutationType; compressed envelope caused KeyError','result':'no product/run changed; subsequent parser validates envelope length/crc32 and then deduplicates mutation IDs; not a product regression'}}
(R/'analysis.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n');(R/'segment-analysis.json').write_text(json.dumps(segments,indent=2)+'\n')
print(json.dumps({k:D[k] for k in ['search','A','recording','journal']},ensure_ascii=False,indent=2))
