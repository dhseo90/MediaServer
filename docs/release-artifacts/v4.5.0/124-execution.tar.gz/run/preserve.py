from pathlib import Path
import json,hashlib,tarfile,io,stat,re
R=Path(__file__).parent;O=R/'mixed900/media-server-current-observer-ObhUeB';repo=Path('/Users/dhseo/Workspace/mediaServer');dest=repo/'docs/release-artifacts/v4.5.0/124-execution.tar.gz'
assert not dest.exists();files=[]
for p in R.iterdir():
 if p.is_file() and p.name not in ['archive-result.json']:files.append((p,'run/'+p.name))
for p in (R/'mixed900').iterdir():
 if p.is_file():files.append((p,'mixed900/'+p.name))
for folder in ['artifacts','receipts']:
 for p in (R/'mixed900'/folder).rglob('*'):
  if p.is_file() and not p.is_symlink():files.append((p,'mixed900/'+str(p.relative_to(R/'mixed900'))))
for folder in ['recordings','input','record-input']:
 for p in (O/folder).rglob('*'):
  if p.is_symlink():continue
  if p.is_file() and 'visual-cache' not in p.relative_to(O).parts and p.name not in ['.recording-store-lease','writer.lock','read.lock']:
   files.append((p,'observer/'+str(p.relative_to(O))))
for name in ['seed.json','catalog-holders-65855.json']:
 p=O/name
 if p.exists():files.append((p,'observer/'+name))
manifest={'schema':'media-server.v450.r124.archive.v1','sourceHead':'4954d1d6c8be2b365bb894e8cf4881e3a9d2fbb4','files':[], 'excluded':['private raw server log URL text (sanitized copy + original hash retained)','auth/state/user settings and private95backup','GStreamer registry/cache','visual derived cache','executables/runtime, retained in build with hash/UUID binding','models/SDK','old archives','symlinks'],'meaning':'new single run original bytes plus labeled derived analysis; sanitized server log is distinct from original'}
with tarfile.open(dest,'w:gz',compresslevel=6) as t:
 for p,name in sorted(files,key=lambda x:x[1]):
  st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==501
  b=p.read_bytes()
  if p.suffix in ['.json','.log','.mjs','.py']:
   assert not re.search(rb'(?:rtsp|https?)://',b),name
   assert not re.search(rb'"(?:passwordHash|tokenHash|passwordHistory)"',b),name
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b));manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 b=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest['files'])+1
 for f in manifest['files']:
  b=t.extractfile(f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
out={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files),'payloadBytes':sum(x['bytes'] for x in manifest['files']),'allMemberBytesVerified':True}
(R/'archive-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
