import json,pathlib,math,zlib,base64,hashlib,collections
R=pathlib.Path(__file__).parent;M=R/'mixed45';O=M/'media-server-current-observer-ELNlWP';F=json.loads((M/'artifacts/report.json').read_text());L=(M/'run.log').read_text().splitlines();S=(O/'server-1.private.log').read_text().splitlines()
def tagged(lines,t):return [json.loads(x[len(t)+1:]) for x in lines if x.startswith(t+' ')]
def stats(v):
 s=sorted(v);return {'count':len(v),'p95Ms':s[math.ceil(len(s)*.95)-1] if s else None,'maxMs':max(s) if s else None}
obs=tagged(L,'[current-observation]');roots=tagged(L,'[root-storage]');resources=tagged(S,'[recording-resource]');lat=F['evidenceLoad']['searchLatencyMs'];tim=tagged(L,'[mixed-http-timing]')
mutations={};compressed=0
for p in sorted((O/'recordings').glob('*.jsonl')):
 if not p.is_file():continue
 for line in p.read_text().splitlines():
  d=json.loads(line)
  if d.get('codec')=='zlib-base64':
   b=zlib.decompress(base64.b64decode(d['data']));assert len(b)==d['length'] and zlib.crc32(b)==d['crc32'];d=json.loads(b);compressed+=1
  if d.get('schema')!='media-server.recording-mutation.v1':continue
  mid=d['mutationId']
  if mid in mutations:assert mutations[mid]==d
  mutations[mid]=d
segments=[];groups=collections.defaultdict(list);inside=[];file_errors=[]
for d in mutations.values():
 if d['mutationType']!='segment_v2_bound_finalized':continue
 p=d['payload'];b=p['sourceBinding'];s=p['segment'];media=O/'recordings'/p['mediaRelpath'];raw=media.read_bytes();assert len(raw)==s['size_bytes'];assert hashlib.sha256(raw).hexdigest()==s['checksum_sha256']
 if s['channel_id'] not in ['9101','9201']:continue
 ords=[x['ordinal'] for x in b['samples']];gaps=[(x,y) for x,y in zip(ords,ords[1:]) if y!=x+1];inside.extend(gaps)
 row={'segment':s['segment_id'],'channel':s['channel_id'],'generation':b['source_generation'],'generationOrder':b['generation_order'],'order':s['order_sequence'],'first':ords[0],'last':ords[-1],'samples':len(ords),'bytes':len(raw),'sha256':s['checksum_sha256'],'indexComplete':b['index_complete']};segments.append(row);groups[(row['channel'],row['generation'])].append(row)
between=[];pairs=0
for key,v in groups.items():
 v.sort(key=lambda r:r['order'])
 for a,b in zip(v,v[1:]):
  pairs+=1
  if b['first']!=a['last']+1:between.append({'channel':key[0],'generation':key[1],'before':a['segment'],'after':b['segment'],'last':a['last'],'first':b['first']})
frame=tagged(S,'[visual-frame]')
D={'schema':'media-server.v450.r125.analysis.v1','derivedFrom':['mixed45/run.log','mixed45/media-server-current-observer-ELNlWP/server-1.private.log','closed recording journal bytes'],
 'search':{'originalSuccess':stats(lat),'byClient':F['evidenceLoad']['searchSuccessByClient'],'unavailable':F['evidenceLoad']['searchUnavailable'],'timeoutOrTransportFailures':[v for v in tim if v.get('outcome')!='ok'],'orderedSuccessThirds':[stats(lat[i:i+80]) for i in range(0,len(lat),80)],'thirdsMeaning':'success array order groups, not exact five-minute periods; no auxiliary requests added'},
 'evidence':{k:F['evidenceLoad'][k] for k in ['cycles','createSuccess','createComplete','createPartial','createBusy','visualCreated','visualExpired','retainedChecks','windows']},
 'A':{'scheduled':len(F['aLoad']['schedule']),'completed':sum(x['state']=='completed' for x in F['aLoad']['schedule']),'detectorEvaluated':F['aLoad']['detectorEvaluated']},
 'shutdown':{'puts':[x for x in tagged(L,'[http-timing]') if x['method']=='PUT'],'settingPassLines':[x for x in L if 'setting ' in x and ' false' in x],'closedJournalPass':'[pass] LP26-O02 closed journal no partial tail' in L,'cleanup':tagged(L,'[process-cleanup]'),'state':tagged(L,'[recording-state-summary]'),'ownersAtShutdown':[x for x in resources if x['phase']!='sample']},
 'resources':{'sampleCount':len(obs),'identities':sorted({(x['pid'],x['startIdentity']) for x in obs}),'allFdComplete':all(x['fdObservation']['complete'] for x in obs),'sampleMax':{k:max(x[k] for x in obs) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'rootVariableMax':max(x['variableBytes'] for x in roots if 'variableBytes' in x),'note':'maxima are different-time sequential samples; not additive simultaneous peak; reservations not actual disk or RSS','summary':F['resources'],'ownerFinal':resources[-1]},
 'recording':{'finalizedPerChannel':dict(collections.Counter(x['channel'] for x in segments)),'newSegments':len(segments),'originalSeedSegments':sum(d['mutationType']=='segment_v2_bound_finalized' for d in mutations.values())-len(segments),'sampleCount':sum(x['samples'] for x in segments),'allIndexComplete':all(x['indexComplete'] for x in segments),'sourceGenerationGroups':len(groups),'sameGenerationAdjacentPairs':pairs,'internalOrdinalGaps':inside,'betweenSegmentOrdinalGaps':between,'deliveryLossLogCount':sum('deliveryLoss' in s for s in S),'allFinalizedMediaBytesAndHashVerified':True,'totalQueueDrop':None,'sourceInputTotal':None,'note':'0 logs/gaps does not prove all input delivered; source generation boundaries and incomplete final input excluded; no full queue counter'},
 'diagnostics':{tag:tagged(L,tag)[-1] for tag in ['[frame-trace-summary]','[search-failure-summary]','[server-diagnostic]','[resource-trace-summary]']},
 'frameRepresentatives':[{'policy':x['policy'],'target':x['target'],'lastPts':x['lastPts'],'lastStream':x['lastStream'],'succeeded':x['succeeded'],'factoryEvents':[e for e in x['events'] if e['kind'] in ['factory','codec-threads']]} for x in frame],
 'journal':{'uniqueMutations':len(mutations),'compressedEnvelopesCheckedIncludingDuplicates':compressed,'types':dict(collections.Counter(d['mutationType'] for d in mutations.values()))},
 'analysisPreparationFailure':{'kind':'read-only Python analysis assumed every journal line had mutationType; compressed envelope caused KeyError','result':'no product/run changed; subsequent parser validates envelope length/crc32 and then deduplicates mutation IDs; not a product regression'}}

D.pop('analysisPreparationFailure',None)
D['search'].pop('orderedSuccessThirds',None);D['search'].pop('thirdsMeaning',None)
D['search']['officialLatencyGate']='not-run: first failure requireMixedWindows; recomputed original-success p95 exceeds2000ms, not a completed official gate'
D['gate']={'firstFailure':'mixed early middle late work missing','observationLastMs':obs[-1]['progress']['elapsedMs'],'verifiedDurationMs':F['verifiedDurationMs'],'notRun':['successful-search-latency','final-sample-continuity','cyclic-deletion-gate','two-channel-disable','closed-journal'],'normalFinallyExit':True}
begin=obs[0]['phaseAt']-obs[0]['progress']['elapsedMs']
assert max(abs((x['phaseAt']-x['progress']['elapsedMs'])-begin) for x in obs)<.001
D['timeBasis']={'beginPhaseAt':begin,'fixedBinsMs':300000,'selection':'pre-run analysis-plan.json','rootMeasurements':'own monotonic measurementCompletedAt; sequential non-atomic; not instant combined peak','requestTiming':'mixed HTTP timing has duration but no monotonic timestamp; ordered log position bounded by adjacent monotonic samples; only same-bin bracketed waves assigned; boundary waves separate; cycle-progress stops when structured pages unavailable so not used for late attribution'}
def spread(vals):
 return {'count':len(vals),'first':vals[0] if vals else None,'last':vals[-1] if vals else None,'min':min(vals) if vals else None,'max':max(vals) if vals else None,'delta':vals[-1]-vals[0] if vals else None}
queries=tagged(L,'[visual-query-observation]')
# HTTP log-position brackets against immediately surrounding resource samples.
positions=[(i,json.loads(s.split(' ',1)[1])['progress']['elapsedMs']) for i,s in enumerate(L) if s.startswith('[current-observation] ')]
requests=[];wave=[]
for i,s in enumerate(L):
 if not s.startswith('[mixed-http-timing] '):continue
 q=json.loads(s.split(' ',1)[1])
 if i+1<len(L) and L[i+1].startswith('[A-http] '):continue
 if q.get('method')!='GET' or q.get('routeKind') not in ['/ops/api/recordings/search','/ops/api/recordings/visual-search']:continue
 lo=next((v for n,v in reversed(positions) if n<i),None);hi=next((v for n,v in positions if n>i),None)
 b=int(lo//300000) if lo is not None and hi is not None and int(lo//300000)==int(hi//300000) and hi<2700000 else None
 requests.append({'route':q['routeKind'],'status':q['status'],'elapsedMs':q['totalElapsedMs'],'bin':b,'beforeSampleMs':lo,'afterSampleMs':hi,'timingPrecision':'HTTP milliseconds; official array retains higher precision'})
D['search']['httpOriginalRouteCounts']=dict(collections.Counter((x['route']+' '+str(x['status'])) for x in requests))
assert len(requests)==F['evidenceLoad']['searchSuccess']+F['evidenceLoad']['searchUnavailable']
D['search']['excludedASupplementaryQueries']=45
D['search']['unassignedBoundaryHttp']=len([x for x in requests if x['bin'] is None])
D['bins']=[]
for i in range(9):
 low=i*300000;high=(i+1)*300000;v=[x for x in obs if low<=x['progress']['elapsedMs']<high];rs=[x for x in roots if low<=x.get('measurementCompletedAt',-1)-begin<high]
 q=[x for x in requests if x['bin']==i];end=v[-1] if v else None
 row={'rangeMs':[low,high],'observedRangeMs':[v[0]['progress']['elapsedMs'],v[-1]['progress']['elapsedMs']] if v else None,'resources':{k:spread([x[k] for x in v]) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes','mutationCount']},'logicalOwner':{k:spread([x['productOwner'][k] for x in v if x.get('productOwner')]) for k in ['ram','scratchDisk','scratchFd']},'finalized':{c:spread([x['progress']['channels'][c]['finalized'] for x in v]) for c in ['9101','9201']},'deleted':{c:spread([x['progress']['channels'][c]['deleted'] for x in v]) for c in ['9101','9201']},'namedBytes':{k:spread([x['categories'][k]['bytes'] for x in rs]) for k in ['media','journal','generationSnapshot','generationEvidence','sqlite','recordingsOther']},'search':{'success':stats([x['elapsedMs'] for x in q if x['status']==200]),'unavailable':sum(x['status']==503 for x in q),'byRoute':{route:stats([x['elapsedMs'] for x in q if x['status']==200 and x['route']=='/ops/api/recordings/'+route]) for route in ['search','visual-search']}},'ACompleted':sum(low<=x.get('completedAt',-1)-begin<high for x in F['aLoad']['schedule'])}
 row['indexObserved']={}
 iq=[]
 for n,line in enumerate(L):
  if not line.startswith('[visual-query-observation] '):continue
  lo=next((v for m,v in reversed(positions) if m<n),None);hi=next((v for m,v in positions if m>n),None)
  if lo is not None and hi is not None and low<=lo and hi<high:iq.append(json.loads(line.split(' ',1)[1]))
 if iq:
  row['indexObserved']={'queryCount':len(iq),'first':iq[0]['usedIndex'],'last':iq[-1]['usedIndex'],'documents':spread([sum(c['indexedFrames'] for c in x['usedIndex']['channels']) for x in iq])}
 row['retainedProgress']={}
 for tag in ['[visual-preserved]','[evidence-create-responses]']:
  total=0
  for n,line in enumerate(L):
   if not line.startswith(tag+' '):continue
   lo=next((v for m,v in reversed(positions) if m<n),None);hi=next((v for m,v in positions if m>n),None)
   if lo is not None and hi is not None and low<=lo and hi<high:total+=1
  row['retainedProgress'][tag]=total
 D['bins'].append(row)
D['memoryInterpretation']={'firstDeletion':None,'allSamplesDeletedZero':all(all(c['deleted']==0 for c in x['progress']['channels'].values()) for x in obs),'limits':['No actual deletion interval, so pre/post deletion memory comparison unavailable','recordingsOther contains more than evidence/A; retained package exact final bytes reported separately','No full heap/allocator/mapping inventory; RSS-owner subtraction not performed','After structured capacity failure visual search/preservation and A continue, structured search/preservation do not; lower memory is not stability under unchanged successful work mix','Reservations and OS samples have separate timestamps; maxima not summed'],'nextBoundary':['structured model-build/capture-source capacity ceilings and emitted documents versus logical owner; preserve authentication and absence semantics','per-owner retained source/read context/index generations and contemporaneous actual allocations needed to attribute residual RSS; no new profiler implemented','Recorder sustained deliveryLoss and same-generation gaps remain separate service-quality blocker']}
D['shutdown']['explicitDisablePass']=False
D['recording']['note']='Observed bounded deliveryLoss and ledger gaps; no complete input/drop totals; generation boundaries and unfinished inputs excluded'
D['diagnostics']['[search-failure-summary]']={k:v for k,v in D['diagnostics']['[search-failure-summary]'].items() if k!='failures'}
failures=tagged(L,'[search-failure-summary]')[-1]['failures'];D['structuredCapacity']={'totalRecorded':len(failures),'attempts':dict(collections.Counter(a['stage']+':'+a['reason'] for f in failures for a in f['attempts'])),'first':failures[0],'last':failures[-1]}
D['decoderFailures']=[x for x in frame if not x['succeeded']]
D['frameFailureFileBinding']=[]
for f in D['decoderFailures']:
 for p in (O/'recordings').rglob('*.mp4'):
  st=p.stat()
  if st.st_ino==f['inoBefore'] and st.st_dev==f['devBefore']:
   D['frameFailureFileBinding'].append({'path':str(p.relative_to(O)),'bytes':st.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identityScope':'post-stop stat identity; not proof of all earlier byte stability','target':f['target'],'policy':f['policy']})
paired=[];lastRoot=None
for line in L:
 if line.startswith('[root-storage] '):lastRoot=json.loads(line.split(' ',1)[1])
 if line.startswith('[current-observation] ') and lastRoot:
  x=json.loads(line.split(' ',1)[1]);paired.append({'phaseAt':x['phaseAt'],'rootMeasuredStart':lastRoot['measurementStartedAt'],'rootMeasuredEnd':lastRoot['measurementCompletedAt'],'nativeMeasuredAt':x['sampledAt'],'namedVariableBytes':lastRoot['variableBytes'],'anonymousMaxBytes':max(x['anonymousFileBytes'],x['anonymousAllocatedBytes']),'variableCombinedBytes':lastRoot['variableBytes']+max(x['anonymousFileBytes'],x['anonymousAllocatedBytes'])})
D['resources']['pairedSequentialVariableMax']=max(paired,key=lambda x:x['variableCombinedBytes'])
D['resources']['pairedScope']='same sample decision inputs reconstructed from adjacent logged named root and native sample; sequential not atomic; no instantaneous peak claim'
D['resources']['lastSample']=obs[-1]
D['resources']['lastNamedRoot']=roots[-1]
D['finalRetainedPackages']={}
for name in ['evidence-packages','va-reviews']:
 fs=[p for p in (O/'recordings'/name).rglob('*') if p.is_file() and not p.is_symlink()]
 D['finalRetainedPackages'][name]={'files':len(fs),'bytes':sum(p.stat().st_size for p in fs)}
(R/'analysis.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
(R/'segment-analysis.json').write_text(json.dumps(segments,indent=2)+'\n')
(R/'http-brackets.json').write_text(json.dumps(requests,indent=2)+'\n')
print(json.dumps({'search':D['search'],'recording':{k:v for k,v in D['recording'].items() if k not in ['betweenSegmentOrdinalGaps','internalOrdinalGaps']},'gaps':len(between),'internal':len(inside),'memoryBins':[(b['rangeMs'],b['resources']['rssBytes']['first'],b['resources']['rssBytes']['last'],b['logicalOwner']['ram']['first'],b['logicalOwner']['ram']['last']) for b in D['bins']],'frameFile':D['frameFailureFileBinding']},ensure_ascii=False))
