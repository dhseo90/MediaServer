import pathlib,json,zlib,base64,collections,hashlib
r=pathlib.Path(__file__).parent;store=r/'baseline/observer/recordings';seen={};compressed=0
for path in sorted(store.glob('*.jsonl')):
 if not path.name.startswith(('active-','evidence-')):continue
 for line in path.read_bytes().splitlines():
  if not line:continue
  v=json.loads(line)
  if v.get('schema')=='media-server.recording-compressed-mutation.v1':
   raw=zlib.decompress(base64.b64decode(v['data'],validate=True));assert len(raw)==v['length'] and zlib.crc32(raw)==v['crc32'];v=json.loads(raw);compressed+=1
  if v.get('schema')!='media-server.recording-mutation.v1':continue
  mid=v['mutationId']
  if mid in seen:assert seen[mid]==v
  seen[mid]=v
channels={};segments=[];last_ms=max(x['occurredAtMs'] for x in seen.values());cutoff=last_ms-10800000
for m in seen.values():
 if m['mutationType']!='segment_v2_bound_finalized':continue
 s=m['payload']['segment'];segments.append(s);ch=s['channel_id'];a=channels.setdefault(ch,{'segments':0,'mediaBytes':0,'mappings':0,'known':0,'unknown':0,'allMappingsKnownSegments':0,'unknownAgeSegments':0,'ageEligibleBeforeProtection':0})
 a['segments']+=1;a['mediaBytes']+=s['size_bytes'];maps=s['mappings'];a['mappings']+=len(maps)
 known=[x for x in maps if x.get('utc_start_ns') is not None and x.get('utc_end_ns') is not None];a['known']+=len(known);a['unknown']+=len(maps)-len(known)
 complete=all(x.get('utc_end_ns') is not None and x.get('uncertainty_ns') is not None and x.get('end_pts') is not None and x.get('provenance')!='unknown' for x in maps)
 if complete and maps:
  a['allMappingsKnownSegments']+=1
  latest=max(int(x['utc_end_ns'])+int(x['uncertainty_ns']) for x in maps);a['ageEligibleBeforeProtection']+=int((latest+999999)//1000000<=cutoff)
 else:a['unknownAgeSegments']+=1
for ch,a in channels.items():
 if ch in ['9101','9201']:
  a.update(quotaBytes=108*1024**2,nextReservationBytes=64*1024**2,bytesPlusOneReservation=a['mediaBytes']+64*1024**2,additionalBytesToReachQuota=44*1024**2-a['mediaBytes'],minimumAdditionalBytesToExceedQuota=44*1024**2-a['mediaBytes']+1)
result={'uniqueMutations':len(seen),'compressedEnvelopesCRCCheckedIncludingDuplicates':compressed,'lastMutationAtMs':last_ms,'ageCutoffAtMs':cutoff,'channels':channels,'deletionMutationCount':sum(x['mutationType']=='segment_v2_deleted' for x in seen.values()),'limits':'closed-original analysis; not historical live hold/pending/free reconstruction; byte+one-reservation is necessary arithmetic, not entire admission replay; unknown age is intentionally not fabricated'}
(r/'input-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
