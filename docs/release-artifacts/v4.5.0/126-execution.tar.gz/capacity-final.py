import pathlib,shlex,subprocess,sys,shutil,json,os
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');root=pathlib.Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
flags={}
for l in (repo/'build-gst-onnx/CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);flags[k]=shlex.split(v)
link=shlex.split((repo/'build-gst-onnx/CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
cmd=[link[0]]+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(repo/'scripts/internal/recording_search_capacity_http_smoke.cpp'),str(repo/'build-gst-onnx/libmedia_server_runtime.a')]+libs+['-o',str(root/'capacity-final')]
(root/'capacity-final-command.json').write_text(json.dumps(cmd));subprocess.run(cmd,cwd=repo,check=True)
case=root/'capacity-run';case.mkdir(mode=0o700);env=environment(case);shutil.copytree(root/'baseline/observer/recordings',case/'recording',dirs_exist_ok=True)
shutil.copyfile(root/'expected-ids.txt',case/'expected-ids.txt')
shutil.copyfile(root/'input.mp4',case/'input/r118.mp4')
env['MEDIA_SERVER_VERIFY_RECORDING_SEARCH_TRACE']='1'
with (root/'capacity-final.log').open('x') as f:r=subprocess.run([str(root/'capacity-final'),str(case)],cwd=case,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(r.returncode);print((root/'capacity-final.log').read_text()[-6000:])

if r.returncode==0:
 with (root/'capacity-final-readback.log').open('x') as f:rr=subprocess.run([str(root/'capacity-final'),str(case),'--readback'],cwd=case,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=30)
 print('readback',rr.returncode)
