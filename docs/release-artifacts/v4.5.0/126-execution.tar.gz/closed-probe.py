import pathlib,subprocess,shlex,json,sys
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');r=pathlib.Path(__file__).parent;b=repo/'build-gst-onnx';f={}
for l in (b/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);f[k]=shlex.split(v)
l=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());libs=l[l.index('libmedia_server_runtime.a')+1:]
c=[l[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(repo/'scripts/internal/recording_current_observer_native.cpp'),str(b/'libmedia_server_runtime.a')]+libs+['-o',str(r/'normalize')]
(r/'closed-build-command.json').write_text(json.dumps(c));subprocess.run(c,check=True,cwd=r)
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
js='''import {CurrentRecordingObserver,closedJournalComplete} from './scripts/internal/recording_current_observer.mjs';const observer=new CurrentRecordingObserver(process.argv[1],process.argv[2]);let result;let count=0,polls=0;try{do{result=await observer.pollAsync();count+=result.rows.length;polls++;if(polls>128)throw Error('bounded-drain');}while(result.backlog);console.log(JSON.stringify({count,polls,partialBytes:result.partialBytes,backlog:result.backlog,busy:result.busy,pass:closedJournalComplete(result)}));if(!closedJournalComplete(result))process.exitCode=1;}finally{console.log(JSON.stringify({close:await observer.closeAsync()}));}'''
for name in ['final-source','capacity-run']:
 with (r/(name+'-closed.log')).open('x') as log:
  p=subprocess.run(['node','--input-type=module','-e',js,str(r/name/'recording'),str(r/'normalize')],env=environment(r/name),cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 print(name,p.returncode);print((r/(name+'-closed.log')).read_text()[-1000:]);assert p.returncode==0
