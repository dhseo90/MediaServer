import pathlib,json,hashlib,subprocess
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
rows=[];http=[]
for l in (r/'final-source/output.log').read_text().splitlines():
 if l.startswith('[R101-space] '):rows.append(json.loads(l.split('] ',1)[1]))
 if l.startswith('[R119-http-wire] '):
  d=json.loads(l.split('] ',1)[1]);d['clientElapsedMs']=(d['endNs']-d['beginNs'])/1e6;http.append(d)
resource={'samples':len(rows),'allValid':all(x['metrics']['valid'] for x in rows),'allFdComplete':all(x['metrics']['fdObservation']['complete'] for x in rows),'startIdentities':sorted(set(x['metrics']['startIdentity'] for x in rows)),'metrics':{k:{'first':rows[0]['metrics'][k],'last':rows[-1]['metrics'][k],'max':max(x['metrics'][k] for x in rows)} for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'maxPairedVariableBytes':max(x['bounds']['variableBytes'] for x in rows),'maxLogicalFilesBytes':max(x['storage']['totalBytes'] for x in rows),'limits':'sequential process/FD and nonatomic file sums; categories mostly other, not complete product-owner classification; unrelated maxima never added; holder loss:true; no heap attribution'}
save(r/'resource-analysis.json',resource);save(r/'http-analysis.json',{'requests':http,'plannedOriginal':12,'completedOriginal':sum(x['status']==200 for x in http),'auxLimit200':'not-run','firstFailure':'id2 recv errno35 no headers/bytes; not a received503','scope':'different from final capacity fixture; not merged to claim full direct PASS'})
files=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()+['scripts/internal/recording_search_capacity_http_smoke.cpp']
save(r/'final-source-binding.json',{'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':{x:h(repo/x) for x in files},'runtime':h(repo/'build-gst-onnx/libmedia_server_runtime.a'),'capacityHelper':h(r/'capacity-final'),'parallelHelper':h(r/'http-final'),'note':'runtime immutable since final-source freeze; final capacity helper added refresh before its execution; Linux-only test line formatting after macOS execution; no changed product between final direct executions'})
print(json.dumps(resource,indent=2))
