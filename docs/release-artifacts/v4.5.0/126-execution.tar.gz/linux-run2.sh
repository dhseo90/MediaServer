#!/bin/sh
set -eu
umask 077
preserve() {
 python3 - <<'PY3'
import pathlib,shutil,hashlib,json
r=pathlib.Path('/tmp/media-server-r126-linux2');o=pathlib.Path('/task/linux-output2');o.mkdir(exist_ok=True)
for p in r.rglob('*'):
 if p.is_file() and (p.suffix in ('.log','.json') or p.name in ('flags.make','link.txt')) and 'env.json'!=p.name:
  d=o/p.relative_to(r);d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
binaries={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'regress').glob('*') if p.is_file() and not p.suffix}
(o/'binaries.json').write_text(json.dumps(binaries,indent=2))
PY3
}
trap preserve EXIT
mkdir /tmp/media-server-r126-linux2
python3 - <<'PY2'
import sys,pathlib,os,json
sys.path.insert(0,'/repo/scripts/internal')
from recording_native_isolation import environment
r=pathlib.Path('/tmp/media-server-r126-linux2');e=environment(r)
(r/'env.json').write_text(json.dumps(e))
PY2
python3 - <<'PY2'
import json,subprocess,pathlib
r=pathlib.Path('/tmp/media-server-r126-linux2');e=json.loads((r/'env.json').read_text())
c=['cmake','-S','/repo','-B',str(r/'build'),'-DMEDIA_SERVER_USE_GSTREAMER=ON','-DMEDIA_SERVER_USE_ONNXRUNTIME=OFF','-DMEDIA_SERVER_USE_SIGLIP2=OFF','-DCMAKE_BUILD_TYPE=Release']
with (r/'configure.log').open('x') as f:subprocess.run(c,env=e,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=120)
with (r/'build.log').open('x') as f:subprocess.run(['cmake','--build',str(r/'build'),'-j','4'],env=e,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=900)
subprocess.run(['python3','/task/linux-regress2.py'],env=e,check=True,timeout=1200)
PY2
