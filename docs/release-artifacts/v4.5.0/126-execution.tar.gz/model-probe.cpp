#include "recording/recording_runtime_composition.h"
#include "recording/recording_search_reader.h"
#include "recording/recording_search_diagnostic.h"
#include "recording_writer_test_isolation.h"
#include <iostream>
#include <chrono>
using namespace recording;
void Report(const char* label,bool ok,const std::string& error){const auto& d=search_capacity_diagnostic;std::cout<<label<<" ok="<<ok<<" error="<<error<<" condition="<<d.condition<<" docs="<<d.documents<<" capacity="<<d.capacity<<" index="<<d.index<<" before="<<d.before<<" addition="<<d.addition<<std::endl;}
int main(int argc,char**argv){if(argc!=2||!RecordingWriterTestIsolation(argv[1]))return 2;std::string error;std::shared_ptr<SearchModelResidency> owner;
 {RecordingRuntimeStorage runtime(std::filesystem::path(argv[1])/"recording");if(!runtime.Open(&error))return 3;owner=runtime.catalog().SearchResidency();
 {SearchSourceBatch batch;if(!runtime.catalog().CaptureSearchSource({"9101"},nullptr,&batch,&error,{},false))return 4;
 std::shared_ptr<const RecordingSearchModel> old;
 {auto prefix=batch.delta.upserts;prefix.resize(16651);prefix.reserve(32768);Report("old16651",RecordingSearchModel::Build(prefix,batch.delta.source_instance,1,&old,&error),error);}
 const auto* data=batch.delta.upserts.data();std::size_t bytes=0;for(const auto&d:batch.delta.upserts)if(!AccountOwnedSearchDocument(d,&bytes,SIZE_MAX))return 5;
 std::shared_ptr<const RecordingSearchModel> model;bool ok=RecordingSearchModel::BuildOwned(std::move(batch.delta.upserts),batch.delta.source_instance,batch.delta.revision,&model,&error,{100000,64*1024*1024,owner});Report("owned",ok,error);if(!ok)return 6;
 std::cout<<"moved="<<(data==model->documents().data())<<" docs="<<model->documents().size()<<" capacity="<<model->documents().capacity()<<" singleDocumentBytes="<<bytes<<" modelBytes="<<model->accounted_bytes()<<" owner="<<owner->used()<<std::endl;
 RecordingReadService read(runtime.catalog());RecordingSearchReader reader(runtime.catalog(),read);RecordingSearchQuery q;q.channels={"9101"};q.start_time_ms=1792000000000;q.end_time_ms=1792200000000;q.include_unplaced=true;q.limit=20;
 RecordingSearchMatches matches;if(!model->Query(q,&matches,&error))return 7;std::cout<<"known="<<matches.known_count<<" unknown="<<matches.unplaced_count<<std::endl;
 std::shared_ptr<const RecordingSearchModel> playback;const auto start=std::chrono::steady_clock::now();ok=reader.WithPlayback(*model,q,&playback,&error);Report("playback",ok,error);std::cout<<"elapsedMs="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count()<<" docs="<<(playback?playback->documents().size():0)<<" owner="<<owner->used()<<" peak="<<owner->peak()<<std::endl;if(!ok)return 8;
 }
 std::cout<<"finish="<<runtime.Finish(&error)<<" owner="<<owner->used()<<std::endl;
 }std::cout<<"destroyed="<<owner->used()<<std::endl;return owner->used()?9:0;}
