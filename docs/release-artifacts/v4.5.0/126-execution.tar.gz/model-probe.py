import pathlib,shlex,subprocess,sys,shutil,json,os
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');root=pathlib.Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
flags={}
for l in (repo/'build-gst-onnx/CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);flags[k]=shlex.split(v)
link=shlex.split((repo/'build-gst-onnx/CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
cmd=[link[0]]+flags['CXX_DEFINES']+flags['CXX_INCLUDES']+flags['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(root/'model-probe.cpp'),str(repo/'src/recording/recording_search_model.cpp'),str(repo/'src/recording/recording_search_source.cpp'),str(repo/'src/recording/recording_search_reader.cpp'),str(repo/'build-gst-onnx/libmedia_server_runtime.a')]+libs+['-o',str(root/'probe')]
(root/'probe-command.json').write_text(json.dumps(cmd));subprocess.run(cmd,cwd=repo,check=True)
case=root/'owned-model';case.mkdir(mode=0o700);env=environment(case);shutil.copytree(root/'baseline/observer/recordings',case/'recording',dirs_exist_ok=True)
env['MEDIA_SERVER_VERIFY_RECORDING_SEARCH_TRACE']='1'
with (root/'owned-model.log').open('x') as f:r=subprocess.run([str(root/'probe'),str(case)],cwd=case,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(r.returncode);print((root/'owned-model.log').read_text()[-6000:])
