#include "recording/recording_runtime_composition.h"
#include "recording/recording_search_diagnostic.h"
#include "recording_writer_test_isolation.h"
#include <iostream>
using namespace recording;
int main(int argc,char** argv){
 if(argc!=2||!RecordingWriterTestIsolation(argv[1]))return 2;
 std::string error;RecordingRuntimeStorage runtime(std::filesystem::path(argv[1])/"recording");
 if(!runtime.Open(&error)){std::cerr<<"open "<<error<<'\n';return 3;}
 auto owner=runtime.catalog().SearchResidency();
 {SearchSourceBatch batch;SearchDiagnostic diagnostic(owner.get());
 const bool ok=runtime.catalog().CaptureSearchSource({"9101"},nullptr,&batch,&error,{},false);
 const auto& d=search_capacity_diagnostic;
 std::cout<<"capture="<<ok<<" error="<<error<<" sizeofDocument="<<sizeof(SearchDocument)<<" stage="<<d.stage<<" condition="<<d.condition<<" max="<<d.max_bytes<<" docs="<<d.documents<<" capacity="<<d.capacity<<" index="<<d.index<<" before="<<d.before<<" addition="<<d.addition<<" owner="<<owner->used()<<" peak="<<owner->peak()<<" rejected="<<owner->rejected()<<std::endl;
 if(ok){std::shared_ptr<const RecordingSearchModel> model;const bool built=RecordingSearchModel::Build(batch.delta.upserts,batch.delta.source_instance,batch.delta.revision,&model,&error,{100000,64*1024*1024,owner});std::cout<<"build="<<built<<" error="<<error<<" docs="<<batch.delta.upserts.size()<<" capacity="<<batch.delta.upserts.capacity()<<" charge="<<(model?model->accounted_bytes():0)<<std::endl;}
 }
 std::cout<<"finish="<<runtime.Finish(&error)<<" error="<<error<<" owner="<<owner->used()<<std::endl;
 return 0;
}
