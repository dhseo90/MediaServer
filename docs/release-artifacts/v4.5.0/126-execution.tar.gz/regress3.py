import pathlib,subprocess,json,shlex,sys,time,hashlib
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');root=pathlib.Path(__file__).parent
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
build=repo/'build-gst-onnx';dest=root/'regress3';dest.mkdir(mode=0o700);env=environment(dest);f={}
for l in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);f[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
results=[]
for name in ['recording_search_model_smoke','recording_search_source_smoke','recording_search_generation_smoke','recording_search_cursor_smoke','recording_search_filter_smoke','recording_search_events_smoke','recording_search_playback_smoke','recording_search_precedence_smoke','recording_search_application_smoke','recording_search_concurrent_smoke']:
 binary=dest/name;case=dest/(name+'-data');case.mkdir(mode=0o700)
 commands=[[link[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(binary)],[str(binary),str(case)]]
 for i,c in enumerate(commands):
  started=time.monotonic()
  with (dest/f'{name}-{i}.log').open('xb') as log:p=subprocess.run(c,cwd=case if i else dest,env=environment(case) if i else env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  results.append({'command':c,'exit':p.returncode,'seconds':time.monotonic()-started,'runtimeSha256':hashlib.sha256((build/'libmedia_server_runtime.a').read_bytes()).hexdigest()});(dest/'results.json').write_text(json.dumps(results,indent=2))
  print(name,i,p.returncode,flush=True)
  if p.returncode:sys.exit(p.returncode)
