import pathlib,subprocess,sys,shlex,json,shutil,os,time
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
b=repo/'build-gst-onnx';f={}
for l in (b/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);f[k]=shlex.split(v)
l=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());libs=l[l.index('libmedia_server_runtime.a')+1:]
a=sys.argv[1]
if a=='build':
 for name,src in [('pair',r/'pair.cpp'),('observer',repo/'scripts/internal/recording_current_observer_native.cpp')]:
  cmd=[l[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(src),str(b/'libmedia_server_runtime.a')]+libs+['-o',str(r/name)]
  (r/(name+'-command.json')).write_text(json.dumps(cmd));subprocess.run(cmd,check=True)
else:
 case=r/a;case.mkdir(mode=0o700);env=environment(case);env.update(MEDIA_SERVER_VERIFY_RECORDING_SEARCH_TRACE='1',MEDIA_SERVER_VERIFY_RECORDING_LATENCY_TRACE='1',MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS='1')
 shutil.copytree(r/'r125/observer/recordings',case/'recording',dirs_exist_ok=True)
 with (r/(a+'.log')).open('x') as log:
  t=time.monotonic();p=subprocess.run([str(r/'pair'),str(case)],env=env,cwd=case,stdout=log,stderr=subprocess.STDOUT,timeout=45)
 (r/(a+'-execution.json')).write_text(json.dumps({'exit':p.returncode,'seconds':time.monotonic()-t,'scope':'two fixed rounds of two structured HTTP; no writer/visual causal control, not target load'}));print(p.returncode)
