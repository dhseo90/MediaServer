from pathlib import Path
p=Path('include/recording/recording_search_diagnostic.h');s=p.read_text().replace('#include <array>','#include <array>\n#include <chrono>\n#include "recording/recording_latency_trace.h"')
s=s.replace('unsigned attempt=0,channels=0;int status=503;', '''struct Cost {const char* name;std::uint64_t begin,end;};
    std::array<Cost,40> costs{};unsigned cost_count=0;bool cost_loss=false;
    static inline std::atomic<unsigned> sequence{0};
    unsigned id=0;std::uint64_t entered=0;
    static std::uint64_t Tick() noexcept {return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
    static void CostRow(const char* name,std::uint64_t begin,std::uint64_t end) noexcept {
        if(!active||!active->id)return;
        if(active->cost_count==active->costs.size()){active->cost_loss=true;return;}
        active->costs[active->cost_count++]={name,begin,end};
    }
    struct Phase {const char* name;std::uint64_t begin;explicit Phase(const char* value):name(value),begin(active&&active->id?Tick():0){}~Phase(){if(begin)CostRow(name,begin,Tick());}};
    unsigned attempt=0,channels=0;int status=503;''')
s=s.replace('previous=active;active=this;search_capacity_diagnostic={};','previous=active;active=this;search_capacity_diagnostic={};\n        if(Enabled()){id=++sequence;entered=Tick();if(id>128)id=0;}')
s=s.replace('active=previous;\n        if(!Enabled()||status<500)return;', '''active=previous;
        if(id) {
            char line[6144];int n=std::snprintf(line,sizeof(line),"[search-request-cost] {\\\"id\\\":%u,\\\"thread\\\":%u,\\\"startNs\\\":%llu,\\\"endNs\\\":%llu,\\\"status\\\":%d,\\\"loss\\\":%s,\\\"phases\\\":[",id,latency::local.thread,(unsigned long long)entered,(unsigned long long)Tick(),status,cost_loss?"true":"false");
            for(unsigned i=0;i<cost_count&&n>0&&n<int(sizeof(line));++i){const auto& c=costs[i];n+=std::snprintf(line+n,sizeof(line)-n,"%s[\\\"%s\\\",%llu,%llu]",i?",":"",c.name,(unsigned long long)c.begin,(unsigned long long)c.end);}
            if(n>0&&n+4<int(sizeof(line))){std::memcpy(line+n,"]}\\n",3);n+=3;Write(line,static_cast<std::size_t>(n));}else Write("[search-cost-loss]\\n",19);
        }
        if(!Enabled()||status<500)return;''')
p.write_text(s)
p=Path('src/ingress/recording_search_application_service.cpp');s=p.read_text();s=s.replace('namespace {\nusing Query=', '''namespace {
// Record only fixed timestamps under the service mutex; emit at request exit after unlock.
struct SearchLock {
    const char* name;std::uint64_t before,acquired;std::unique_lock<std::mutex> lock;
    SearchLock(std::mutex& mutex,const char* value):name(value),before(recording::SearchDiagnostic::Tick()),lock(mutex){acquired=recording::SearchDiagnostic::Tick();}
    ~SearchLock(){const auto end=recording::SearchDiagnostic::Tick();lock.unlock();recording::SearchDiagnostic::CostRow(name,before,acquired);recording::SearchDiagnostic::CostRow("service-hold",acquired,end);}
};
using Query=''')
s=s.replace('std::lock_guard<std::mutex> lock(search_mutex_);','SearchLock lock(search_mutex_,"service-wait");')
s=s.replace('if(!search.Refresh(query.channels,state->source,&state->source,&error,{},observations)){','bool refreshed=false;{recording::SearchDiagnostic::Phase cost("Refresh");refreshed=search.Refresh(query.channels,state->source,&state->source,&error,{},observations);}\n                if(!refreshed){')
s=s.replace('if(!search.WithPlayback(*model,query,&model,&error)){','bool playback=false;{recording::SearchDiagnostic::Phase cost("WithPlayback");playback=search.WithPlayback(*model,query,&model,&error);}\n                if(!playback){')
s=s.replace('if(!state->snapshots.Begin(model,query,principal,scope,&page,&error))return Failure(error);','{recording::SearchDiagnostic::Phase cost("SnapshotBegin");if(!state->snapshots.Begin(model,query,principal,scope,&page,&error))return Failure(error);}')
s=s.replace('auto response_memory=catalog_.SearchResidency()', 'recording::SearchDiagnostic::Phase response_cost("CurrentnessJson");\n        auto response_memory=catalog_.SearchResidency()')
p.write_text(s)
p=Path('src/recording/recording_search_reader.cpp');s=p.read_text().replace('if (!catalog_.CaptureSearchSource(channels, previous.get(), &batch, error, limits, include_observations)) return false;', '{SearchDiagnostic::Phase cost("Capture");if (!catalog_.CaptureSearchSource(channels, previous.get(), &batch, error, limits, include_observations)) return false;}')
s=s.replace('*output = previous;if(error)error->clear();return true;', 'SearchDiagnostic::CostRow("RefreshReuse",SearchDiagnostic::Tick(),SearchDiagnostic::Tick());*output = previous;if(error)error->clear();return true;')
s=s.replace('const bool built = batch.rebuild ?', 'SearchDiagnostic::Phase build_cost(batch.rebuild?"BuildOwned":"ApplyDelta");\n    const bool built = batch.rebuild ?')
s=s.replace('std::vector<SearchPlaybackCandidate> candidates;if(!PlaybackCandidates(model,query,&candidates,error,&proof))return false;', 'std::vector<SearchPlaybackCandidate> candidates;{SearchDiagnostic::Phase cost("PlaybackCandidates");if(!PlaybackCandidates(model,query,&candidates,error,&proof))return false;}\n    SearchDiagnostic::Phase preparation_cost("PlaybackDocuments");')
s=s.replace('if(!RecordingSearchModel::BuildOwned(std::move(documents),model.source_instance()', 'SearchDiagnostic::Phase cost("PlaybackBuildOwned");\n        if(!RecordingSearchModel::BuildOwned(std::move(documents),model.source_instance()')
p.write_text(s)
# Test-only milestones, no input data, no product locks; existing timeout remains3s.
p=Path('scripts/internal/recording_generation_observation.h');s=p.read_text().replace('#include <unordered_set>','#include <unordered_set>\n#include <cstdio>\n#include <cstdlib>')
s=s.replace('using namespace recording;','''using namespace recording;
inline void Phase(const char* name) {if(std::getenv("MEDIA_SERVER_VERIFY_OBSERVER_PHASE")){std::fprintf(stderr,"[observer-phase] %s %lld\\n",name,(long long)std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count());std::fflush(stderr);}}''')
s=s.replace('Reader files(root,cache);','Phase("entry");Reader files(root,cache);')
s=s.replace('RecordingGenerationFile identity_head;','Phase("snapshot");RecordingGenerationFile identity_head;')
s=s.replace('const auto snapshot_done=', 'Phase("active");const auto snapshot_done=')
s=s.replace('const auto active_done=', 'Phase("chain");const auto active_done=')
s=s.replace('const auto chain_done=', 'Phase("output");const auto chain_done=')
s=s.replace('return result;\n    }catch(const Busy&)', 'Phase("complete");return result;\n    }catch(const Busy&)')
p.write_text(s)
