#define RECORDING_DEGRADED_HTTP_NO_MAIN
#include "recording_degraded_http_smoke.cpp"
int main(int argc,char**argv){if(argc!=2||!RecordingWriterTestIsolation(argv[1]))return 2;
 try {const std::filesystem::path root(argv[1]);std::string error;recording::RecordingRuntimeStorage runtime(root/"recording");NeedHttp(runtime.Open(&error),error.c_str());auto& catalog=runtime.catalog();recording::RecordingReadService reader(catalog);ingress::RecordingApplicationService app(reader,catalog,true,{});
 Media media;Lifecycle lifecycle;Reads reads;WebRtcHttpRuntimeConfig config;config.auth_mode=HttpAuthMode::Token;config.auth_admin_token="owned-http85-admin-token";config.enable_ops=true;
 config.auth_users_file=(root/"users.json").string();config.source_registry_path=(root/"sources.json").string();config.analysis_registry_path=(root/"analysis.json").string();config.file_root_path=(root/"input").string();
 WebRtcHttpServer server(media,lifecycle,reads,config,&app);NeedHttp(server.Start("127.0.0.1",0,&error),error.c_str());const auto port=RecordingHttpOwnershipProbe::Port(server);std::exception_ptr first;
 try {for(unsigned round=0;round<2;++round){std::vector<std::future<bool>> requests;
 for(unsigned i=0;i<2;++i)requests.push_back(std::async(std::launch::async,[&,i,round]{const std::string route="/ops/api/recordings/search?channelIds=9101&startTimeMs=1792000000000&endTimeMs=1792100000000&limit=20&includeUnplaced=true";const auto begin=Clock::now();HttpObservation observation{round*2+i,"causal-structured-pair",route,begin};Socket socket;socket.fd=Request(port,route);const auto wire=Drain(socket.fd,begin+std::chrono::seconds(5),observation);NeedHttp(wire.rfind("HTTP/1.1 200",0)==0,"status200");std::cout<<"[R127-pair] round="<<round<<" client="<<i<<" ms="<<std::chrono::duration<double,std::milli>(Clock::now()-begin).count()<<" bytes="<<wire.size()<<std::endl;return true;}));
 for(auto& f:requests){try{NeedHttp(f.get(),"pair");}catch(...){if(!first)first=std::current_exception();}}if(first)break;}}
 catch(...){first=std::current_exception();}
 WaitIdle(server);server.Stop();NeedHttp(runtime.Finish(&error),error.c_str());std::cout<<"[R127-pair-finish] true\n";if(first)std::rethrow_exception(first);return 0;
 }catch(const std::exception& e){std::cerr<<"[R127-pair-fail] "<<e.what()<<std::endl;return 1;}}
