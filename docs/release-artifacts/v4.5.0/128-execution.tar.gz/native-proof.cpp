#include "/Users/dhseo/Workspace/mediaServer/src/recording/recording_file_evidence.cpp"
#include <fstream>
#include <iostream>
int main(int argc,char**argv){try{
 if(argc!=3)return 2;std::ifstream in(argv[2]);std::string raw((std::istreambuf_iterator<char>(in)),{}),error;recording::RecordingSourceBindingV1 binding;
 if(!recording::ParseRecordingSourceBindingV1(raw,&binding,&error))throw std::runtime_error(error);
 int fd=::open(argv[1],O_RDONLY|O_NOFOLLOW);if(fd<0)throw std::runtime_error("open");const bool ok=recording::VerifyRecordingFileEvidenceFd(fd,binding,&error);
 const auto data=recording::ReadFile(fd,binding.file_evidence->file_size_bytes,binding.file_evidence->file_sha256);::close(fd);const auto n=recording::Mp4(data).Read();
 std::cout<<"{\"verified\":"<<ok<<",\"timescale\":"<<n.timescale<<",\"movieTimescale\":"<<n.movie_timescale<<",\"editDuration\":"<<n.edit_duration<<",\"editTime\":"<<n.edit_time<<",\"samples\":[";
 bool comma=false;for(const auto& s:n.samples){if(comma)std::cout<<',';comma=true;std::cout<<"{\"pts\":"<<s.pts<<",\"dts\":"<<s.dts<<",\"duration\":"<<s.duration<<",\"raw\":\""<<s.raw<<"\",\"vcl\":\""<<s.vcl<<"\"}";}std::cout<<"]}\n";return ok?0:1;
 }catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
