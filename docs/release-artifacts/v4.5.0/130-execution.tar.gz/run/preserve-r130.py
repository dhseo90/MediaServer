import pathlib,json,hashlib,tarfile,io,stat,subprocess
root=pathlib.Path('/private/tmp/media-server-r130-pkw7n4z1');repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer')
archive=repo/'docs/release-artifacts/v4.5.0/130-execution.tar.gz'
entries={}
def add(p,name):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink(),p
 assert name not in entries and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 entries[name]=p
# Only task-owned regular summaries, scripts and build logs. No home/model/SDK/registry tree.
for p in root.iterdir():
 if p.is_file() and p.suffix in ('.json','.log','.py','.txt'):
  add(p,'run/'+p.name)
for directory in ['r130-run','r130-build','r130-finalbuild','comparison','comparison-cwd-fixed','bus-unit','recording_frame_bus_detail_smoke-case','recording_visual_source_smoke-case','visual_frame_decoder_smoke-case','visual_index_worker_smoke-case','visual_index_store_smoke-case','linux-first-results','linux-final-results']:
 for p in (root/directory).iterdir():
  if p.is_file() and p.suffix in ('.json','.jsonl','.log') and p.name not in ('private.jsonl','private-bus.jsonl'):
   add(p,'run/'+str(p.relative_to(root)))
for n in ['http-r130','recording_index_policy_smoke','process-metrics','input.mp4']:
 add(root/n,'run/'+n)
delta=json.loads((root/'recording-delta.json').read_text())
for row in delta:
 p=root/'r130-run/recording'/row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 add(p,'run/r130-run/recording/'+row['path'])
b=json.loads((root/'http-r130.binding.json').read_text());e=json.loads((root/'r130-run/execution.json').read_text())
sources=set(b['sourceFiles'])|set(e['dependencies'])|{'scripts/internal/recording_degraded_http_smoke.cpp','scripts/internal/recording_source_http_fixture.h','src/recording/visual_index_worker.cpp','scripts/internal/recording_visual_source_smoke.cpp','scripts/internal/visual_frame_decoder_smoke.cpp','scripts/internal/visual_index_worker_smoke.cpp'}
for n in sources:add(repo/n,'source/'+n)
manifest={'schema':'media-server.r130.archive.v1','executionCommit':e['head'],'unchangedOriginals':{'archive':'docs/release-artifacts/v4.5.0/125-execution.tar.gz','sha256':'39eeb7708486378f919c10c82e4a3ba059d0c82f7874a1617559e7beb95eb83b','inputMap':'run/input-map.json','changedFiles':'run/recording-delta.json'},'categories':{'original':'run/*/output.log and execution/binding records; task-owned synthetic media delta','derived':'run/final-analysis.json, comparison-cwd-fixed/rows-derived.json and analyses','source':'source/ plus task scripts','binary':'run/http-r130 final; run/recording_index_policy_smoke comparison'},'exclusions':['user settings/backups/models/SDK','private raw diagnostics (real executions zero bytes)','GStreamer registry cache','unchanged125 media duplicate'],'limitations':['workspace-first-failure.json is reserved preallocation, not actual failure','invalid premature readback preserved separately; final readback after producer used','post-run cache is not immutable fresh membership assertion'],'members':[]}
for n,p in sorted(entries.items()):manifest['members'].append({'path':n,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
with archive.open('xb') as out:
 with tarfile.open(fileobj=out,mode='w:gz') as tf:
  for n,p in sorted(entries.items()):
   ti=tf.gettarinfo(str(p),arcname=n);ti.uid=ti.gid=0;ti.uname=ti.gname='';ti.mode=0o755 if p.name in ['http-r130','recording_index_policy_smoke','process-metrics'] else 0o644
   with p.open('rb') as f:tf.addfile(ti,f)
  data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();ti=tarfile.TarInfo('manifest.json');ti.size=len(data);tf.addfile(ti,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tf:
 assert len(tf.getmembers())==len(entries)+1
 for row in manifest['members']:
  v=tf.extractfile(row['path']).read();assert len(v)==row['bytes'] and hashlib.sha256(v).hexdigest()==row['sha256']
result={'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries)+1,'allMemberReadback':'PASS','recordingDeltaFiles':len(delta),'unchangedOriginalsReference':manifest['unchangedOriginals'],'privateRawIncluded':False}
p=repo/'docs/release-artifacts/v4.5.0/130-validation.json';d=json.loads(p.read_text());d['archive']=result;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
