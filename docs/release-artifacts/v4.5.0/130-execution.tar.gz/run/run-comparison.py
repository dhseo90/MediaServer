import pathlib,sys,os,subprocess,json,time
r=pathlib.Path(__file__).parent;sys.path.insert(0,'/Users/dhseo/Workspace/mediaServer/scripts/internal');from recording_native_isolation import environment
c=r/'comparison-cwd-fixed';env=environment(c);env['MEDIA_SERVER_VERIFY_FRAME_TRACE']='bounded'
fd=os.open(c/'private.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_APPEND,0o600);env['MEDIA_SERVER_VERIFY_FRAME_PRIVATE_FD']=str(fd);t=time.monotonic()
try:
 with (c/'output.log').open('xb') as out:q=subprocess.run([str(r/'recording_index_policy_smoke'),str(c)],cwd=c,env=env,pass_fds=(fd,),stdout=out,stderr=subprocess.STDOUT,timeout=200)
 (c/'execution.json').write_text(json.dumps({'exit':q.returncode,'elapsed':time.monotonic()-t,'externalRuns':1}));print(q.returncode,flush=True)
finally:os.close(fd)
