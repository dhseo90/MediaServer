import sys,pathlib,os,subprocess,json,time
r=pathlib.Path(__file__).parent;repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
results=[]
for name in ['recording_frame_bus_detail_smoke','visual_index_store_smoke','visual_index_worker_smoke','recording_visual_source_smoke','visual_frame_decoder_smoke']:
 c=r/(name+'-case');c.mkdir(mode=0o700);env=environment(c);env['MEDIA_SERVER_VERIFY_FRAME_TRACE']='bounded';fds=()
 if name=='recording_frame_bus_detail_smoke':
  fd=os.open(c/'private.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_APPEND,0o600);fds=(fd,);env['MEDIA_SERVER_VERIFY_FRAME_PRIVATE_FD']=str(fd)
 arg=[str(c/'fixture.mp4'),'--software-only'] if name=='visual_frame_decoder_smoke' else [str(c)]
 if name=='recording_frame_bus_detail_smoke':arg=[]
 if name=='recording_visual_source_smoke':arg+=[str(repo/'models/v430-siglip2')]
 t=time.monotonic()
 with (c/'output.log').open('xb') as out:q=subprocess.run([str(r/name)]+arg,cwd=c,env=env,pass_fds=fds,stdout=out,stderr=subprocess.STDOUT,timeout=180)
 for fd in fds:os.close(fd)
 results.append({'name':name,'exit':q.returncode,'seconds':time.monotonic()-t});(r/'focused-results.json').write_text(json.dumps(results,indent=2));print(name,q.returncode,flush=True)
 if q.returncode:sys.exit(q.returncode)
