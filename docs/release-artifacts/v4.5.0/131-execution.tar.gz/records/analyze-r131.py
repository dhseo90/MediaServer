from pathlib import Path
import json,re,math,hashlib
root=Path('<OWNED_ROOT>');out=root/'analysis';out.mkdir(exist_ok=False)
names=['r131before-run','r131after-run','r131identity-run','r131retryverified-run'];allruns=[]
for name in names:
 p=root/'warm'/name;t=(p/'output.log').read_text();lines=t.splitlines()
 def rows(tag):
  result=[]
  for l in lines:
   if l.startswith('['+tag+'] '):
    raw=l.split('] ',1)[1]
    if raw.startswith('{'):result.append(json.loads(raw))
  return result
 def kv(tag):return [{k:(int(v) if v.isdigit() else v) for k,v in re.findall(r'(\w+)=([^ ]+)',l.split('] ',1)[1])} for l in lines if l.startswith('['+tag+'] ')]
 http=[]
 for l in lines:
  if l.startswith('[R107-http] '):
   m=re.match(r'\[R107-http\] round=(\d+) client=(\d+) ms=([\d.e+-]+) response=(.*)',l)
   r,c,ms,body=m.groups();b=json.loads(body);http.append({'round':int(r),'client':int(c),'ms':float(ms),'items':len(b.get('items',[]))})
 execution=json.loads((p/'execution.json').read_text());space=rows('R101-space');owners=rows('recording-resource');holders=rows('catalog-holder');cap=rows('search-capture-cost');vis=rows('visual-request');search=rows('search-request-cost')
 times=sorted(x['ms'] for x in http)
 stats={key:{'min':min(s['metrics'][key] for s in space),'max':max(s['metrics'][key] for s in space),'last':space[-1]['metrics'][key]} for key in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']}
 r={'name':name,'execution':execution,'http':http,'httpWire':rows('R119-http-wire'),'p95Ms':times[math.ceil(len(times)*.95)-1],'maxMs':max(times),'recorder':kv('recorder-cost'),'source':kv('R118-source'),'writer':kv('writer-cost'),'admission':rows('R119-admission'),'periodic':rows('R131-periodic'),'initial':rows('R107-ready'),'membership':kv('R119-membership'),'explicitFinish':kv('R119-finish'),'stops':kv('R119-stop'),'sourceCapture':cap,'structured':search,'visual':vis,'visualPreparation':rows('visual-preparation'),'owners':owners,'resourceStatistics':stats,'resourceSamples':len(space),'spaceEnd':rows('R101-space-end'),'holderEnd':rows('catalog-holder-end'),'largestCapturedHolds':sorted(holders,key=lambda h:h['e']-h['a'],reverse=True)[:12],'largestCapturedWaits':sorted(holders,key=lambda h:h['a']-h['b'],reverse=True)[:12],'failure':[l for l in lines if l.startswith('[R107-fail]')],'initialOutputSha256':hashlib.sha256((p/'output.log').read_bytes()).hexdigest(),'limits':'nested phases are not additive; holder selected request windows only; maxima not simultaneous; raw HTTP vs rounded original qualifier latency separately retained'}
 (out/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');allruns.append({k:r[k] for k in ['name','p95Ms','maxMs','source','recorder','membership','explicitFinish','failure','resourceSamples']})
(out/'runs-summary.json').write_text(json.dumps(allruns,indent=2)+'\n')
print(json.dumps([{'name':r['name'],'p95':r['p95Ms'],'source':r['source'],'membership':r['membership'],'failure':r['failure']} for r in allruns],indent=2))
