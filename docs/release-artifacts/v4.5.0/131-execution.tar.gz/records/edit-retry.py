from pathlib import Path
r=Path('<REPO>')
def edit(p,a,b):
 f=r/p;s=f.read_text();assert a in s,p;f.write_text(s.replace(a,b,1))
edit('include/recording/recording_search_source.h','#include "recording/recording_search_model.h"','#include "recording/recording_search_model.h"\n#include <array>\n#include <map>')
edit('include/recording/recording_search_source.h','    SearchSourceBatch()=default;','''private:
    friend class RecordingCatalog;
    friend class RecordingSearchReader;
    struct SegmentSpan {
        std::array<unsigned char,32> digest{};
        std::size_t raw_bytes=0,begin=0,count=0;
        RecordingLifecycle lifecycle{RecordingLifecycle::Pending};
    };
    // A single HTTP retry owns this evidence, never a published/cache model.
    std::map<std::string,SegmentSpan> segment_spans_;
    const SearchModelResidency* residency_=nullptr;
    std::size_t max_documents_=0,max_bytes_=0;
public:
    SearchSourceBatch()=default;''')
edit('include/recording/recording_search_source.h','std::swap(pending,other.pending);return *this;','std::swap(pending,other.pending);segment_spans_.swap(other.segment_spans_);std::swap(residency_,other.residency_);std::swap(max_documents_,other.max_documents_);std::swap(max_bytes_,other.max_bytes_);return *this;')
for p in ['include/recording/recording_catalog.h','include/recording/recording_search_reader.h']:
 edit(p,'bool include_observations = true) const;','bool include_observations = true, SearchSourceBatch* retry_capture = nullptr) const;')
edit('include/recording/recording_retained_rows.h','''    template<class F,class E> bool ForEachChannelEntry(const std::vector<std::string>& channels,F&& visitor,E&& excluded,
                                                     std::uint64_t* memo_excluded=nullptr)const {''','''    template<class F,class E> bool ForEachChannelEntry(const std::vector<std::string>& channels,F&& visitor,E&& excluded,
                                                     std::uint64_t* memo_excluded=nullptr)const {
        return ForEachChannelEntry(channels,std::forward<F>(visitor),std::forward<E>(excluded),memo_excluded,
            [](const std::string&,const std::string&)->std::optional<bool>{return {};});
    }
    // The private consumer may reuse a derived row only after this current raw
    // namespace read. nullopt requests the unchanged strict typed decode path.
    template<class F,class E,class R> bool ForEachChannelEntry(const std::vector<std::string>& channels,F&& visitor,E&& excluded,
                                                     std::uint64_t* memo_excluded,R&& raw_consumer)const {''')
# Match channel method only.
f=r/'include/recording/recording_retained_rows.h';s=f.read_text();start=s.index('template<class F,class E,class R>');tail=s[start:];a='''            const auto row=Decode(id,std::move(bytes));
            if(!consume(row->first,row->second)){refused=true;return false;}return true;''';b='''            if(const auto used=raw_consumer(id,bytes.bytes)){
                if(!*used)refused=true;return *used;
            }
            const auto row=Decode(id,std::move(bytes));
            if(!consume(row->first,row->second)){refused=true;return false;}return true;''';assert a in tail;f.write_text(s[:start]+tail.replace(a,b,1))
edit('include/recording/recording_retained_rows.h','sibling supplies only exact-byte parsed memoization','sibling supplies only current-raw SHA-256-bound parsed memoization')
edit('src/recording/recording_search_reader.cpp','SearchModelLimits limits, bool include_observations) const {','SearchModelLimits limits, bool include_observations, SearchSourceBatch* retry_capture) const {')
edit('src/recording/recording_search_reader.cpp','&batch, error, limits, include_observations)) return false;','&batch, error, limits, include_observations, retry_capture)) {if(retry_capture)*retry_capture=SearchSourceBatch{};return false;}}\n    if(retry_capture)*retry_capture=SearchSourceBatch{};\n    {')
edit('src/recording/recording_search_reader.cpp','    if (!catalog_.ValidateSearchSource(batch, error)) return false;','''    if (!catalog_.ValidateSearchSource(batch, error)) {
        if(retry_capture&&!include_observations&&batch.rebuild&&error&&*error=="search-source-changed")
            *retry_capture=std::move(batch);
        return false;
    }''')
edit('src/ingress/recording_search_application_service.cpp','            bool prepared=false;','            recording::SearchSourceBatch retry_capture;\n            bool prepared=false;')
edit('src/ingress/recording_search_application_service.cpp','&error,{},observations);','&error,{},observations,&retry_capture);')
edit('src/recording/recording_search_source.cpp','SearchModelLimits limits, bool include_observations) const {','SearchModelLimits limits, bool include_observations, SearchSourceBatch* retry_capture) const {')
edit('src/recording/recording_search_source.cpp','        std::size_t bytes = sizeof(batch);','''        batch.residency_=limits.residency.get();batch.max_documents_=limits.max_documents;batch.max_bytes_=limits.max_bytes;
        const bool remember=retry_capture&&!include_observations&&batch.rebuild;
        const bool reuse=remember&&retry_capture->rebuild&&retry_capture->pending.empty()&&
            retry_capture->catalog_instance==batch.catalog_instance&&
            retry_capture->delta.source_instance==batch.delta.source_instance&&
            retry_capture->resolution_revision<=batch.resolution_revision&&
            retry_capture->residency_==batch.residency_&&retry_capture->max_documents_==limits.max_documents&&
            retry_capture->max_bytes_==limits.max_bytes;
        std::array<unsigned char,32> raw_digest{};std::size_t raw_size=0;
        bool raw_valid=false;
        std::size_t bytes = sizeof(batch);
        const auto remember_span=[&](const std::string& id,RecordingLifecycle lifecycle,std::size_t begin) {
            if(!remember||!raw_valid)return true;
            const auto charge=sizeof(std::pair<const std::string,SearchSourceBatch::SegmentSpan>)+4*sizeof(void*)+2*(id.size()+1);
            if(charge>limits.max_bytes||bytes>limits.max_bytes-charge)return false;
            bytes+=charge;
            batch.segment_spans_.emplace(id,SearchSourceBatch::SegmentSpan{raw_digest,raw_size,begin,batch.delta.upserts.size()-begin,lifecycle});
            return true;
        };''')
edit('src/recording/recording_search_source.cpp','''                if (lifecycle==RecordingLifecycle::Deleted) return true;
                const auto segment''','''                const auto begin=batch.delta.upserts.size();
                if (lifecycle==RecordingLifecycle::Deleted) return remember_span(id,lifecycle,begin);
                const auto segment''')
edit('src/recording/recording_search_source.cpp','''                if (s.mappings.empty()) return segment(nullptr);
                for(const auto& mapping:s.mappings)if(!segment(&mapping))return false;
                return true;''','''                if (s.mappings.empty()) {if(!segment(nullptr))return false;}
                else for(const auto& mapping:s.mappings)if(!segment(&mapping))return false;
                return remember_span(id,lifecycle,begin);''')
edit('src/recording/recording_search_source.cpp','''            },&costs.memo);''','''            },&costs.memo,[&](const std::string& id,const std::string& raw)->std::optional<bool>{
                raw_valid=false;
                if(!remember)return {};
#if MEDIA_SERVER_USE_OPENSSL
                unsigned digest_size=0;
                raw_valid=EVP_Digest(raw.data(),raw.size(),raw_digest.data(),&digest_size,EVP_sha256(),nullptr)==1&&digest_size==raw_digest.size();
#endif
                raw_size=raw.size();
                if(!raw_valid||!reuse)return {};
                const auto prior=retry_capture->segment_spans_.find(id);
                if(prior==retry_capture->segment_spans_.end())return {};
                const auto span=prior->second;
                if(span.raw_bytes!=raw_size||span.digest!=raw_digest)return {};
                const auto lifecycle=EffectiveLifecycleV2Locked(id,true);
                // State is separate from segment raw. A changed lifecycle takes
                // the strict path; deleted rows are never moved into the result.
                if(lifecycle!=span.lifecycle)return {};
                if(span.begin>retry_capture->delta.upserts.size()||span.count>retry_capture->delta.upserts.size()-span.begin)return {};
                const auto begin=batch.delta.upserts.size();
                for(std::size_t i=span.begin;i<span.begin+span.count;++i){
                    const auto& d=retry_capture->delta.upserts[i];
                    if(d.segment_id!=id||d.kind!=SearchDocumentKind::Recording||!selected(d.channel_id))return {};
                }
                for(std::size_t i=span.begin;i<span.begin+span.count;++i)
                    if(!add(std::move(retry_capture->delta.upserts[i])))return false;
                retry_capture->segment_spans_.erase(prior);++costs.rows;
                return remember_span(id,lifecycle,begin);
            });''')
# Included explicitly rather than depending on retained row include.
edit('src/recording/recording_search_source.cpp','#include <stdexcept>','#include <stdexcept>\n#if MEDIA_SERVER_USE_OPENSSL\n#include <openssl/evp.h>\n#endif')
