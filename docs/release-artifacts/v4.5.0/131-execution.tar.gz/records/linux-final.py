import pathlib,subprocess,json,shlex,sys,time,hashlib
repo=pathlib.Path('/repo');root=pathlib.Path('/tmp/media-server-r128-linux')
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
build=root/'build';dest=root/'regress-final';dest.mkdir(mode=0o700);env=environment(dest);f={}
for l in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);f[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
results=[]
for name in ['recording_search_scope_smoke','visual_frame_decoder_smoke']:
 binary=dest/name;case=dest/(name+'-data');case.mkdir(mode=0o700)
 extra=['-DRECORDING_SEARCH_TESTING=1',str(repo/'src/recording/recording_search_reader.cpp')] if name=='recording_search_scope_smoke' else []
 commands=[[link[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+extra+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(binary)],[str(binary),str(case/'fixture.mp4') if name=='visual_frame_decoder_smoke' else str(case)]]
 for i,c in enumerate(commands):
  started=time.monotonic()
  with (dest/f'{name}-{i}.log').open('xb') as log:p=subprocess.run(c,cwd=case if i else dest,env=environment(case) if i else env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
  results.append({'command':c,'exit':p.returncode,'seconds':time.monotonic()-started,'runtimeSha256':hashlib.sha256((build/'libmedia_server_runtime.a').read_bytes()).hexdigest()});(dest/'results.json').write_text(json.dumps(results,indent=2))
  print(name,i,p.returncode,flush=True)
  if p.returncode:sys.exit(p.returncode)
