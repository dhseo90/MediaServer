import pathlib,sys,subprocess,shlex,json,os,time
repo=pathlib.Path('/repo');r=pathlib.Path('/tmp/media-server-r130-linux');out=r/'results-fixed';out.mkdir(mode=0o700)
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
env=environment(r);build=r/'build';results=[]
def run(label,cmd,cwd=r,environment_=env,fd=()):
 t=time.monotonic()
 with (out/(label+'.log')).open('xb') as f:q=subprocess.run(cmd,cwd=cwd,env=environment_,pass_fds=fd,stdout=f,stderr=subprocess.STDOUT,timeout=480)
 results.append({'label':label,'command':cmd,'exit':q.returncode,'seconds':time.monotonic()-t});(out/'results.json').write_text(json.dumps(results,indent=2));print(label,q.returncode,flush=True)
 if q.returncode:sys.exit(q.returncode)
#run('configure',['cmake','-S',str(repo),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DMEDIA_SERVER_USE_GSTREAMER=ON','-DMEDIA_SERVER_USE_ONNXRUNTIME=OFF','-DMEDIA_SERVER_USE_SIGLIP2=OFF'])
run('build',['cmake','--build',str(build),'-j4'])
f={}
for l in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in l:k,v=l.split(' = ',1);f[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
for name in ['recording_frame_bus_detail_smoke','recording_visual_source_smoke','visual_frame_decoder_smoke']:
 binary=r/name;case=r/(name+'-fixed-case');case.mkdir(mode=0o700)
 run(name+'-build',[link[0]]+f['CXX_DEFINES']+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(binary)])
 e=environment(case);e['MEDIA_SERVER_VERIFY_FRAME_TRACE']='bounded';fds=()
 if name=='recording_frame_bus_detail_smoke':
  fd=os.open(case/'private.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_APPEND,0o600);fds=(fd,);e['MEDIA_SERVER_VERIFY_FRAME_PRIVATE_FD']=str(fd)
 args=[] if name=='recording_frame_bus_detail_smoke' else [str(case/'fixture.mp4') if name=='visual_frame_decoder_smoke' else str(case)]
 run(name,[str(binary)]+args,case,e,fds)
 for fd in fds:os.close(fd)
