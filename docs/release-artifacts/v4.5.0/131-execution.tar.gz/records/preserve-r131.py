from pathlib import Path
import hashlib,json,tarfile,io,stat,subprocess
root=Path('<OWNED_ROOT>');repo=Path('<REPO>');out=repo/'docs/release-artifacts/v4.5.0/131-execution.tar.gz'
assert not out.exists()
entries={}; manifest=[]
def add(p,name,kind='record',sanitize=True):
 assert p.is_file() and not p.is_symlink(),str(p)
 assert name not in entries and not name.startswith('/') and '..' not in Path(name).parts
 b=p.read_bytes();rawsha=hashlib.sha256(b).hexdigest();rawsize=len(b)
 if sanitize:
  try:
   text=b.decode('utf-8');text=text.replace(str(root),'<OWNED_ROOT>').replace(str(repo),'<REPO>');b=text.encode()
  except UnicodeDecodeError:pass
 entries[name]=(b,0o700 if p.stat().st_mode&0o111 else 0o600)
 manifest.append({'path':name,'kind':kind,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sourceBytes':rawsize,'sourceSha256':rawsha,'sanitized':rawsha!=hashlib.sha256(b).hexdigest()})
# Executed helpers, actual linked final runtime, and source snapshots. No model/SDK.
for stem in ['r131before','r131after','r131identity','r131retryverified']:
 add(root/'warm'/('http-'+stem),'binary/http-'+stem,'executed-helper',False)
 b=root/'warm'/('http-'+stem+'.binding.json')
 if b.exists():add(b,'binary/'+b.name,'build-binding')
add(repo/'build-gst-onnx/libmedia_server_runtime.a','binary/final-libmedia_server_runtime.a','linked-runtime',False)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()
changed+=['scripts/internal/recording_search_retry_smoke.cpp']
for rel in changed:
 if rel.startswith(('src/','include/','scripts/','docs/project-feature-test-inventory')):add(repo/rel,'source/final/'+rel,'final-source',False)
# Retain every owned root build/plan/failure record and script, not temporary binaries.
for p in sorted(root.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log','.py','.patch','.cpp','.txt'] and p.name not in ['preserve-r131.py']:
  add(p,'records/'+p.name,'analysis' if p.name.startswith(('analyze-','write-validation')) else 'record')
add(root/'preserve-r131.py','records/preserve-r131.py','preservation-source')
for p in sorted((root/'analysis').glob('*')):add(p,'analysis/'+p.name,'derived-analysis')
for name in ['r131before-run','r131after-run','r131identity-run','r131retryverified-run']:
 run=root/'warm'/name
 for p in sorted(run.iterdir()):
  if p.is_file():add(p,'warm/'+name+'/'+p.name,'execution-output' if p.name=='output.log' else 'execution-record')
 delta=json.loads((root/'analysis'/(name+'-delta.json')).read_text())
 for x in delta['changed']:add(run/'recording'/x['path'],'warm/'+name+'/recording-delta/'+x['path'],'changed-owned-recording',False)
# Build/wrapper records; no unexecuted helper binaries or seed copy.
for d in sorted((root/'warm').iterdir()):
 if d.is_dir() and 'build' in d.name:
  for p in d.rglob('*'):
   if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log']:add(p,'warm/'+str(p.relative_to(root/'warm')),'build-record')
for name in ['search-retry-scope','search-retry-final-scope','search-retry-verified-scope','retry-cold-case']:
 d=root/name
 if d.exists():
  for p in sorted(d.rglob('*')):
   if p.is_file() and not p.is_symlink() and (name=='retry-cold-case' or p.suffix in ['.json','.log','.txt']):add(p,'focused/'+str(p.relative_to(root)),'focused-evidence',name!='retry-cold-case')
for name in ['results','results-final','results-verified','native-results']:
 d=root/'linux'/name
 if d.exists():
  for p in sorted(d.rglob('*')):
   if p.is_file() and not p.is_symlink():
    if p.stat().st_size>15*1024*1024:raise RuntimeError('unexpected large Linux evidence '+str(p))
    add(p,'linux/'+str(p.relative_to(root/'linux')),'linux-evidence',p.suffix in ['.log','.txt'] or p.name=='results.json')
# Final source hash check against actual performance binding, independent of later docs.
binding=json.loads((root/'warm/http-r131retryverified.binding.json').read_text())
for rel,h in binding['sourceFiles'].items():assert hashlib.sha256((repo/rel).read_bytes()).hexdigest()==h,rel
refs={str(p.relative_to(repo)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [repo/'docs/release-artifacts/v4.5.0/125-execution.tar.gz',repo/'docs/release-artifacts/v4.5.0/130-execution.tar.gz',repo/'docs/release-artifacts/v4.5.0/130-preservation-supplement.json']}
m={'schema':'media-server.r131.preservation.v1','baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'references':refs,'sanitization':'Only owned absolute root and repository prefix replaced in UTF8 records. sourceSha256 identifies local original; saved sha is different when sanitized. No private config/backup/model/SDK. Recording deltas and binary bytes unchanged.','reconstruction':'Each warm final recording = input-binding maps.warm (125+130delta-snapshot16) + its changed-owned-recording delta - analysis deleted list. Input original modes from archive include0644 lock; correction record applies only identity/retryverified seeds.','limits':'r131after buildBinding originally null, not backfilled. Selected holder windows only. No cold/longrun.','members':manifest}
mb=(json.dumps(m,ensure_ascii=False,indent=2)+'\n').encode();entries['manifest.json']=(mb,0o600)
with tarfile.open(out,'x:gz',compresslevel=6) as t:
 for name,(b,mode) in entries.items():
  ti=tarfile.TarInfo(name);ti.size=len(b);ti.mode=mode;ti.mtime=0;t.addfile(ti,io.BytesIO(b))
# Full payload verification, reject unexpected names/types.
with tarfile.open(out,'r:gz') as t:
 by={x['path']:x for x in manifest}
 for member in t:
  assert member.isfile() and member.name in entries
  b=t.extractfile(member).read()
  if member.name!='manifest.json':assert hashlib.sha256(b).hexdigest()==by[member.name]['sha256']
  else:assert b==mb
record={'path':str(out.relative_to(repo)),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'members':len(entries),'payloadReadback':'PASS','references':refs}
(root/'archive-readback.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
