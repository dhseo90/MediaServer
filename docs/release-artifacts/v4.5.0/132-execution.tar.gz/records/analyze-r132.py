import pathlib,json,re,math
r=pathlib.Path(__file__).parent.parent;out=r/'analysis';out.mkdir(exist_ok=True)
for run in sorted((r/'warm').glob('*-run')):
 p=run/'output.log'
 if not p.exists():continue
 text=p.read_text();lines=text.splitlines()
 def rows(prefix):
  result=[]
  for l in lines:
   if l.startswith(prefix):
    try:result.append(json.loads(l[len(prefix):]))
    except ValueError:pass
  return result
 req=[]
 for l in lines:
  m=re.match(r'\[R107-http\] round=(\d+) client=(\d+) ms=([0-9.e+-]+) response=(.*)',l)
  if m:
   a,b,t,body=m.groups();d=json.loads(body);req.append({'round':int(a),'client':int(b),'ms':float(t),'items':len(d.get('items',[])),'known':d.get('knownCount'),'unplaced':d.get('unplacedCount')})
 wires=rows('[R119-http-wire] ')
 for w in wires:w['elapsedMs']=(w['endNs']-w['beginNs'])/1e6;w['wireMs']=((w['receiveEndNs']-w['beginNs'])/1e6) if w.get('receiveEndNs') else None
 source=[]
 for l in lines:
  if l.startswith('[R118-source] '):source.append({k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',l)})
 selected=[l for l in lines if any(l.startswith(p) for p in ['[R119-membership]','[R118-queue','[R118-recorder','[R119-fresh','[R119-stop]','[R119-finish]','[R107-fail]','[R107-result]','[R119-original-result]'])]
 times=sorted(x['ms'] for x in req)
 result={'run':run.name,'execution':json.loads((run/'execution.json').read_text()),'requests':req,'originalCount':len(req),'p95Ms':times[math.ceil(len(times)*.95)-1] if times else None,'maxMs':max(times) if times else None,'wires':wires,'source':source,'selectedRaw':selected,'captureCosts':rows('[search-capture-cost] '),'requestCosts':rows('[search-request-cost] '),'logicalResources':rows('[recording-resource] '),'space':rows('[R101-space] '),'closedJournal':'not-run until same full warm eligibility; independent observer not implied by Finish'}
 (out/(run.name+'.json')).write_text(json.dumps(result,indent=2))
 print(run.name,len(req),result['p95Ms'],source,[(w['status'],w['elapsedMs']) for w in wires if w['scope']=='auxiliary200'])
