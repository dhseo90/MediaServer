import pathlib,subprocess,shlex,json,time,hashlib
repo=pathlib.Path('<HOME>/Workspace/mediaServer');root=pathlib.Path('<RUN_ROOT>')
script=(repo/'scripts/internal/verify_recording_generation_request_proof.sh').read_text();sources=shlex.split(script.split('task_sources=(')[1].split(')')[0])
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','--libs','openssl','sqlite3'],text=True))
cmd=['c++','-std=c++17','-O1','-Wall','-Wextra','-Werror','-pthread','-I'+str(repo/'include'),'-DMEDIA_SERVER_USE_OPENSSL=1','-DMEDIA_SERVER_USE_SQLITE3=1','-DMEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND=1','-DMEDIA_SERVER_RECORDING_GENERATION_TESTING=1']+[str(repo/x) for x in sources]+flags+['-lz','-o',str(root/'request-proof')]
t=time.monotonic()
with (root/'records/request-proof-build-4.log').open('xb') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=repo)
(root/'records/request-proof-build-4.json').write_text(json.dumps({'command':cmd,'exit':result.returncode,'elapsedSeconds':time.monotonic()-t,'sources':{x:hashlib.sha256((repo/x).read_bytes()).hexdigest() for x in sources}}))
raise SystemExit(result.returncode)
