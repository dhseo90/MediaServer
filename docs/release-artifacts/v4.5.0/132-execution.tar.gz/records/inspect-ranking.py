import pathlib,json,struct,hashlib,collections
r=pathlib.Path(__file__).parent.parent;run=r/'warm/r132visualfinal-run';files=list((run/'recording/visual-cache').glob('visual-software-v1-*.v1'));assert len(files)==1
p=files[0];raw=p.read_bytes();assert hashlib.sha256(raw[:-32]).digest()==raw[-32:];pos=0
def u():
 global pos
 x=struct.unpack_from('<Q',raw,pos)[0];pos+=8;return x
def text():
 global pos
 n=u();assert n<=1024;x=raw[pos:pos+n].decode();pos+=n;return x
assert u()==0x324958564d534d
contract=[text(),text(),text(),u()];count=u();docs=[]
for _ in range(count):
 d=dict(zip(['id','channel','segment','event','mediaHash','frameHash'],[text() for i in range(6)]));d['pts']=u();d['num']=u();d['den']=u();d['hasUtc']=u();d['utc']=u();n=u();assert n==768;d['embeddingHash']=hashlib.sha256(raw[pos:pos+4*n]).hexdigest();pos+=4*n;docs.append(d)
assert pos==len(raw)-32
seed=json.loads((run/'input-binding.json').read_text())['files'];old={pathlib.Path(k).stem for k in seed if k.endswith('.mp4')}
aux=[l for l in (run/'output.log').read_text().splitlines() if l.startswith('[R118-publication]')];assert len(aux)==1
body=json.loads(aux[0].split(' response=',1)[1]);returned=body['items'];byid={d['id']:d for d in docs};fresh=[d for d in docs if d['segment'] not in old]
groups={}
for item in returned:
 d=byid[item['id']];group=groups.setdefault(d['embeddingHash'],{'score':item['score'],'returned':0,'minId':item['id'],'maxId':item['id']});assert group['score']==item['score'];group['returned']+=1;group['minId']=min(group['minId'],item['id']);group['maxId']=max(group['maxId'],item['id'])
summary={'kind':'read-only final persisted cache analysis; not substituted for observed immutable publication','cachePath':str(p.relative_to(r)),'cacheSha256':hashlib.sha256(raw).hexdigest(),'cacheDigestVerified':True,'documents':count,'observedPublicationDocuments':3794,'returned':len(returned),'freshDocuments':len(fresh),'freshReturned':sum(x['id'] in {d['id'] for d in fresh} for x in returned),'returnedEmbeddingGroups':groups,'freshEmbeddingGroups':dict(collections.Counter(d['embeddingHash'] for d in fresh)),'lastReturned':returned[-1],'freshRows':fresh}
(r/'analysis/fresh-ranking.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='freshRows'},indent=2))
