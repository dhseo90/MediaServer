import pathlib,json,hashlib,tarfile,io,stat
r=pathlib.Path(__file__).parent.parent;repo=pathlib.Path('<HOME>/Workspace/mediaServer');out=repo/'docs/release-artifacts/v4.5.0/132-execution.tar.gz'
assert not out.exists()
entries={};manifest=[]
def add(name,data,origin=None,sanitize=False):
 assert name not in entries and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
 raw=data
 if sanitize:
  s=data.decode('utf-8');s=s.replace(str(r),'<RUN_ROOT>').replace('<HOME>','<HOME>');data=s.encode()
 entries[name]=data;manifest.append({'path':name,'source':origin,'sourceBytes':len(raw),'sourceSha256':hashlib.sha256(raw).hexdigest(),'savedBytes':len(data),'savedSha256':hashlib.sha256(data).hexdigest(),'transform':'owned-root/home prefix redaction' if data!=raw else 'none'})
def file(p,name=None,sanitize=True):
 assert p.is_file() and not p.is_symlink();add(name or str(p.relative_to(r)),p.read_bytes(),str(p.relative_to(r)),sanitize)
for folder in ['records','analysis','sources-cut-recovered','sources-compact','sources-single','sources-visual','sources-visual-final']:
 for p in sorted((r/folder).rglob('*')):
  if p.is_file() and not p.name.startswith('prior-') and p.name!='approval-candidate.json':file(p,sanitize=not folder.startswith('sources-'))
for folder in ['focused-single','focused-vector','linux/results','linux/native-results','linux/native-final-results']:
 for p in sorted((r/folder).rglob('*')):
  if p.is_file() and p.suffix in ['.json','.log']:file(p)
for p in sorted(r.iterdir()):
 if p.is_file() and p.suffix in ['.json','.log']:file(p)
for p in sorted((r/'warm').iterdir()):
 if p.is_file() and p.name.endswith('.binding.json'):file(p)
 if p.is_dir() and p.name.endswith('-build'):
  for q in sorted(p.iterdir()):
   if q.is_file() and q.suffix in ['.json','.log','.txt']:file(q)
for name in ['r132cut-run','r132compact-run','r132single-run','r132visualfinal-run']:
 run=r/'warm'/name;seed=json.loads((run/'input-binding.json').read_text())['files'];actual={};changed=[]
 for p in sorted(run.iterdir()):
  if p.is_file() and (p.suffix in ['.json','.jsonl','.log'] or p.name=='resource-phase'):file(p)
 for p in sorted((run/'recording').rglob('*')):
  if p.is_symlink():raise RuntimeError('symlink')
  if not p.is_file():continue
  rel=str(p.relative_to(run/'recording'));data=p.read_bytes();h=hashlib.sha256(data).hexdigest();actual[rel]=h
  if seed.get(rel)!=h:
   add(f'warm/{name}/recording-delta/{rel}',data,str(p.relative_to(r)),False);changed.append(rel)
 delta={'baseInputBinding':'input-binding.json','changedOrNew':{k:actual[k] for k in changed},'deleted':[k for k in seed if k not in actual],'finalFiles':actual,'meaning':'apply changed/new bytes and deleted paths to exact seed; no entire old archive duplication'}
 add(f'warm/{name}/recording-delta.json',json.dumps(delta,indent=2).encode(),None,False)
refs={}
for n in ['125-execution.tar.gz','130-execution.tar.gz','130-preservation-supplement.json','131-execution.tar.gz']:
 p=repo/'docs/release-artifacts/v4.5.0'/n;b=p.read_bytes();refs[n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
add('references.json',json.dumps({'existingBytes':refs,'seed':'125 +130 supplement; exact input maps included','noIncluded':'user config/private95/models/SDK/runtime binaries; build commands and binary hashes separately recorded','cold':'not-run'},indent=2).encode())
add('final-reviewed.patch',__import__('subprocess').check_output(['git','diff','--', 'include','src','scripts/internal/recording_search_retry_smoke.cpp','scripts/internal/recording_generation_request_proof_smoke.cpp','docs/project-feature-test-inventory.md'],cwd=repo))
m={'schema':'r132-preservation-v1','entries':manifest,'rawOriginals':'owned execution originals; sanitized outputs are distinct bytes; necessary fixture deltas retained exact','fullRawOriginalsLocalOnlyUntilCleanup':str(r).replace('<HOME>','<HOME>')}
entries['manifest.json']=json.dumps(m,indent=2).encode()
with tarfile.open(out,'x:gz') as t:
 for n,b in sorted(entries.items()):
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(out) as t:
 assert len(t.getmembers())==len(entries)
 for member in t.getmembers():
  assert member.isfile() and t.extractfile(member).read()==entries[member.name]
b=out.read_bytes();receipt={'file':out.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'members':len(entries),'payloads':len(manifest),'readback':'all bytes equal in-memory selected source/sanitizer transformation; regularmembers only; no duplicate/path traversal','references':refs};(r/'records/archive-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
