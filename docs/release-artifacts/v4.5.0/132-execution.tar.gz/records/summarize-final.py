import pathlib,json,re,hashlib
r=pathlib.Path(__file__).parent.parent
runs=[]
for name in ['r132cut-run','r132compact-run','r132single-run','r132visualfinal-run']:
 d=json.loads((r/'analysis'/f'{name}.json').read_text());log=(r/'warm'/name/'output.log').read_text();e=d['execution'];aux=next((x for x in d['wires'] if x['scope']=='auxiliary200'),None)
 recorder=[]
 for line in log.splitlines():
  if line.startswith('[recorder-cost]'):recorder.append({k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)})
 run={'name':name,'exit':e['exit'],'elapsedSeconds':e['elapsedSeconds'],'originalCount':d['originalCount'],'p95Ms':d['p95Ms'],'maxMs':d['maxMs'],'originalWireStatuses':[x['status'] for x in d['wires'] if x['scope']=='original12'],'source':d['source'],'recorder':recorder,'aux':aux,'stageLines':d['selectedRaw'],'captureCosts':d['captureCosts'],'runtimeSha256':e['buildBinding']['runtimeSha256'],'binarySha256':e['binarySha256'],'logicalResources':d['logicalResources'],'collection':{k:e.get(k) for k in ['timeout','overflow','collectionError','runnerError','qualificationError','cleanupError','groupAbsent','monitorExit']},'closedJournal':'not-run'}
 metrics=[s['metrics'] for s in d['space'] if s.get('metrics',{}).get('valid')];run['osSamples']={'count':len(metrics),'first':metrics[0] if metrics else None,'last':metrics[-1] if metrics else None,'separateMaxima':{k:max((m.get(k,0) or 0) for m in metrics) for k in ['rssBytes','footprintBytes','fdCount','anonymousFileBytes','anonymousAllocatedBytes']},'limits':'sequential samples, not whole heap or simultaneous maxima; storage category other contains fixture recording subtree; no zero-media inference'}
 run['liveSpaceMax']=max((s['bounds']['totalBytes'] for s in d['space'] if s.get('phase')=='live'),default=None)
 runs.append(run)
(r/'analysis/execution-summary.json').write_text(json.dumps(runs,indent=2));print(json.dumps([{k:x[k] for k in ['name','p95Ms','source','liveSpaceMax']} for x in runs],indent=2))
