from pathlib import Path
p=Path('scripts/internal/recording_degraded_http_qualification.py');s=p.read_text();at=s.index('\ndef qualify(')
code='''
def visual_response(body, channels, start=None, end=None, exact_count=None):
 q=body['appliedQuery'];items=body['items']
 assert body['kind']=='visual-frame' and body['scoreMeaning']=='similarity-not-evidence'
 assert q['text']=='ball' and q['limit']==200 and q['threshold']==-1
 assert q['channelIds']==channels and q['startTimeMs']==start and q['endTimeMs']==end
 assert body['returnedItems']==len(items) and 0<len(items)<=200
 if exact_count is not None:assert len(items)==exact_count,'aux200 count'
 assert len({x['id'] for x in items})==len(items)
 previous=None
 for x in items:
  score=x['score'];assert math.isfinite(score) and -1<=score<=1
  key=(-score,x['id']);assert previous is None or previous<=key,'visual order';previous=key
  assert x['channelId'] in channels and x['playable'] is True and x['seekAvailable'] is True
  assert x['timeBasis']=='verified-native-file-presentation' and math.isfinite(x['targetSeconds']) and x['targetSeconds']>=0
  assert x['playbackUrl'].startswith('/ops/api/recordings/media/')
  if start is not None:assert x['timeNs'] is not None and start*1000000<=int(x['timeNs'])<end*1000000
 return items

def public_fresh(body,target):
 assert 1<=target['bucketCount']<=200 and target['freshCount']>0
 assert target['startMs']==int(target['utcNs'])//1000000 and target['endMs']==target['startMs']+1
 items=visual_response(body,[target['channel']],target['startMs'],target['endMs'])
 assert len(items)<=target['bucketCount']
 index=body['index'];assert index['instanceId']==target['instanceId'] and index['generation']==target['generation'],'public-fresh generation'
 found=[x for x in items if x['id']==target['id']];assert len(found)==1,'public-fresh target missing'
 x=found[0];assert x['channelId']==target['channel'] and x['timeNs']==target['utcNs'] and x['playbackUrl']=='/ops/api/recordings/media/'+target['segment']
 return True
'''
s=s[:at]+code+s[at:]
s=s.replace(" owners=rows('[recording-resource] ')",""" if mode.startswith('source-'):
  broad=[json.loads(x.split(' response=',1)[1]) for x in text.splitlines() if x.startswith('[R118-publication] ')];assert len(broad)==1
  visual_response(broad[0],['9101','9201'],exact_count=200)
  targets=rows('[R133-target] ');fresh=[json.loads(x.split('response=',1)[1]) for x in text.splitlines() if x.startswith('[R133-public-fresh] ')];assert len(targets)==len(fresh)==1
  public_fresh(fresh[0],targets[0])
  wires=rows('[R119-http-wire] ')
  for scope,count in [('original12',3*clients),('auxiliary200',1),('publicFresh',1)]:
   selected=[x for x in wires if x['scope']==scope];assert len(selected)==count
   assert all(x['status']==200 and x['headers'] and x['bytes']>0 and x['failure']=='none' and x['errno']==0 and 0<=x['endNs']-x['beginNs']<=5000000000 for x in selected),'actual wire/deadline'
  assert '[R133-finish-success]' in text and '[R119-stop] server=1' in text and '[R119-stop] visual=1' in text and '[R119-finish] ok=1 error=' in text
 owners=rows('[recording-resource] ')""")
s=s.replace('(1 if mode.startswith("source-") else 0)','(2 if mode.startswith("source-") else 0)')
p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_smoke.cpp');s=p.read_text().replace('NeedHttp(finish.Run(),"explicit finish failed");','NeedHttp(finish.Run(),"explicit finish failed");std::cout<<"[R133-finish-success]"<<std::endl;');p.write_text(s)
