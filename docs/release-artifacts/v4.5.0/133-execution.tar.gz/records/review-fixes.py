from pathlib import Path
p=Path('scripts/internal/recording_public_fresh_oracle.h');s=p.read_text();pos=s.index('template<class CurrentBinding>');s=s[:pos]+'''// Only exact sample/file evidence, independently of the public Resolve path.
template<class Binding>
std::optional<std::pair<std::int64_t,std::uint32_t>> ExpectedSeek(
 const recording::VisualSearchDocument& d,const Binding& b) {
 if(b.channel_id!=d.channel_id||b.segment_id!=d.segment_id||!b.file_evidence||
    d.time_base_num!=1||d.time_base_den!=1000000000)return {};
 const auto& e=*b.file_evidence;if(e.file_sha256!=d.media_sha256||!e.timescale)return {};
 std::size_t count=0;std::int64_t ticks=0;
 for(const auto& x:e.samples)if(x.original_pts_ns==d.media_pts){
  ++count;const __int128 delta=static_cast<__int128>(x.native_pts)-e.edit_media_time;
  if(x.sample_sha256!=d.frame_sha256||delta<0||delta>std::numeric_limits<std::int64_t>::max())return {};
  ticks=static_cast<std::int64_t>(delta);
 }
 if(count!=1)return {};return std::make_pair(ticks,e.timescale);
}
''' +s[pos:];p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_smoke.cpp');s=p.read_text();s=s.replace('return b&&b->channel_id==d.channel_id&&b->segment_id==d.segment_id&&b->file_evidence&&b->file_evidence->file_sha256==d.media_sha256;','return b&&recording_public_fresh_oracle::ExpectedSeek(d,*b).has_value();');s=s.replace(' const auto& d=view.index->documents()[target.index];',' const auto& d=view.index->documents()[target.index];\n const auto target_binding=catalog.FindSourceBinding(d.segment_id);NeedHttp(target_binding.has_value(),"public-fresh target binding");const auto expected_seek=recording_public_fresh_oracle::ExpectedSeek(d,*target_binding);NeedHttp(expected_seek.has_value(),"public-fresh target sample");')
s=s.replace('<<",\\\"bucketCount\\\":"<<target.bucket_count', '<<",\\\"seekTicks\\\":"<<quote(std::to_string(expected_seek->first))<<",\\\"seekTimescale\\\":"<<expected_seek->second<<",\\\"bucketCount\\\":"<<target.bucket_count');p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_qualification.py');s=p.read_text();s=s.replace(" return True\n\ndef qualify", " assert target['seekTimescale']>0 and int(target['seekTicks'])>=0\n assert abs(x['targetSeconds']-int(target['seekTicks'])/target['seekTimescale'])<=1e-9,'public-fresh exact seek'\n return True\n\ndef qualify");p.write_text(s)
p=Path('scripts/internal/test_recording_public_fresh_oracle.py');s=p.read_text().replace("generation=2)\n  self.item", "generation=2,seekTicks='0',seekTimescale=3000)\n  self.item");s=s.replace("'instance','time','source')", "'instance','time','seek','source')").replace("   else:b['items'][0]['playbackUrl']", "   elif change=='seek':b['items'][0]['targetSeconds']=.1\n   else:b['items'][0]['playbackUrl']");p.write_text(s)
p=Path('scripts/internal/recording_public_fresh_oracle_smoke.cpp');s=p.read_text().replace(' std::cout<<"pass="', ''' struct Sample {std::int64_t original_pts_ns=0,native_pts=0;std::string sample_sha256="frame";};
 struct Evidence {std::string file_sha256="file";std::uint32_t timescale=3000;std::int64_t edit_media_time=0;std::vector<Sample> samples{Sample{}};};
 struct Binding {std::string channel_id="9101",segment_id="new";std::optional<Evidence> file_evidence=Evidence{};} binding;
 auto frame=Doc("frame","new",1000000);frame.media_sha256="file";frame.frame_sha256="frame";
 using recording_public_fresh_oracle::ExpectedSeek;
 check(ExpectedSeek(frame,binding)==std::make_optional(std::make_pair(std::int64_t{0},std::uint32_t{3000})),"independent exact sample seek");
 frame.media_pts=1;check(!ExpectedSeek(frame,binding),"stale fresh PTS rejected");frame.media_pts=0;frame.frame_sha256="changed";check(!ExpectedSeek(frame,binding),"stale fresh AU hash rejected");frame.frame_sha256="frame";binding.file_evidence->samples.push_back(Sample{});check(!ExpectedSeek(frame,binding),"ambiguous sample rejected");binding.file_evidence.reset();check(!ExpectedSeek(frame,binding),"missing evidence rejected");
 std::cout<<"pass="''');p.write_text(s)
