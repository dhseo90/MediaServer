import {CurrentRecordingObserver,closedJournalComplete} from '<HOME>/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs';
import {spawn} from 'node:child_process';
import fs from 'node:fs';
const [root,binary,label]=process.argv.slice(2);let diagnostics=0;
const spawnChild=(bin,args,options)=>{const child=spawn(bin,args,{...options,env:{...options.env,MEDIA_SERVER_VERIFY_OBSERVER_PHASE:'1'}});child.stderr.on('data',bytes=>{diagnostics+=bytes.length;if(diagnostics<=65536)fs.appendFileSync(label+'.phases',bytes)});return child};
const observer=new CurrentRecordingObserver(root,binary,undefined,{spawnChild});let result,count=0,polls=0;const start=performance.now();
try{do{const b=performance.now();result=await observer.pollAsync();count+=result.rows.length;polls++;console.log(JSON.stringify({poll:polls,ms:performance.now()-b,count,backlog:result.backlog}));if(polls>128)throw Error('bounded-drain');}while(result.backlog);console.log(JSON.stringify({count,polls,partialBytes:result.partialBytes,backlog:result.backlog,busy:result.busy,pass:closedJournalComplete(result),ms:performance.now()-start}));if(!closedJournalComplete(result))process.exitCode=1;}
catch(error){console.log(JSON.stringify({error:error.message,count,polls,ms:performance.now()-start}));process.exitCode=1;}
finally{try{console.log(JSON.stringify({close:await observer.closeAsync()}));}catch(error){console.log(JSON.stringify({closeError:error.message}));process.exitCode=1;}}
