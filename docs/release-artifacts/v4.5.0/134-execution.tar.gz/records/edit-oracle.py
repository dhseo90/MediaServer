from pathlib import Path
p=Path('scripts/internal/recording_public_fresh_oracle.h');s=p.read_text();i=s.index('template<class CurrentBinding>');s=s[:i]+'''// Exact public accessibility is independent of UTC and text ranking.
struct ExactTarget {std::size_t index,fresh_count;};
template<class CurrentBinding>
ExactTarget SelectExact(const std::vector<recording::VisualSearchDocument>& docs,
 const std::set<std::string>& original,CurrentBinding current_binding) {
 std::optional<std::size_t> first;std::size_t fresh=0;
 for(std::size_t i=0;i<docs.size();++i){const auto& d=docs[i];if(original.count(d.segment_id))continue;
  ++fresh;if(!current_binding(d))throw std::runtime_error("public-fresh current binding");
  if(!d.event_id.empty()||d.channel_id.empty()||d.id.empty())continue;
  if(!first||std::tie(d.channel_id,d.id)<std::tie(docs[*first].channel_id,docs[*first].id))first=i;
 }
 if(!fresh)throw std::runtime_error("public-fresh publication empty");
 if(!first)throw std::runtime_error("public-fresh exact target not constructible");
 return {*first,fresh};
}
inline std::string QueryEscape(const std::string& value){
 const char* hex="0123456789ABCDEF";std::string out;
 for(unsigned char c:value){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')out+=char(c);else{out+='%';out+=hex[c>>4];out+=hex[c&15];}}return out;
}
''' +s[i:];p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_smoke.cpp');s=p.read_text();pos=s.index(' const auto target=recording_public_fresh_oracle::Select(');s=s[:pos]+''' const auto quote=[](const auto& value){return recording::EvidenceJsonQuote(value);};
 {
 const auto exact=recording_public_fresh_oracle::SelectExact(view.index->documents(),original_segments,bound);
 const auto& d=view.index->documents()[exact.index];const auto binding=catalog.FindSourceBinding(d.segment_id);NeedHttp(binding.has_value(),"exact-public binding");const auto seek=recording_public_fresh_oracle::ExpectedSeek(d,*binding);NeedHttp(seek.has_value(),"exact-public sample");
 std::cout<<"[R134-target] {\\"id\\":"<<quote(d.id)<<",\\"channel\\":"<<quote(d.channel_id)<<",\\"segment\\":"<<quote(d.segment_id)<<",\\"utcNs\\":"<<(d.utc_ns?quote(std::to_string(*d.utc_ns)):"null")<<",\\"seekTicks\\":"<<quote(std::to_string(seek->ticks))<<",\\"durationTicks\\":"<<quote(std::to_string(seek->duration))<<",\\"seekTimescale\\":"<<seek->timescale<<",\\"freshCount\\":"<<exact.fresh_count<<",\\"instanceId\\":"<<quote(view.publication->instance_id)<<",\\"generation\\":"<<view.publication->generation.value_or(0)<<"}"<<std::endl;
 const auto before=VisualSearchPublicationTestProbe::View(visual);NeedHttp(before.index==view.index&&before.publication==view.publication,"exact-public publication before changed");
 const auto begin=Clock::now();const std::string route="/ops/api/recordings/visual-search/seek?channelId="+recording_public_fresh_oracle::QueryEscape(d.channel_id)+"&hitId="+recording_public_fresh_oracle::QueryEscape(d.id);
 HttpObservation observation{102,"publicExact",route,begin};Socket socket;socket.fd=Request(port,route);const auto wire=Drain(socket.fd,begin+std::chrono::seconds(5),observation);
 const auto body=wire.substr(wire.find("\\r\\n\\r\\n")+4);std::cout<<"[R134-public-exact] response="<<body<<std::endl;
 NeedHttp(wire.rfind("HTTP/1.1 200",0)==0,"exact-public HTTP status");StrictJsonObjectDocument doc;NeedHttp(ParseStrictJsonObjectDocument(body,&doc,&error),"exact-public JSON");
 NeedHttp(StrictJsonStringField(doc,"hitId")==std::optional<std::string>(d.id)&&StrictJsonBoolField(doc,"playable")==std::optional<bool>(true)&&StrictJsonBoolField(doc,"seekAvailable")==std::optional<bool>(true)&&StrictJsonStringField(doc,"playbackUrl")==std::optional<std::string>("/ops/api/recordings/media/"+d.segment_id)&&StrictJsonStringField(doc,"timeBasis")==std::optional<std::string>("verified-native-file-presentation"),"exact-public shape");
 const auto number=[&](const char* key){const auto* v=doc.Find(key);NeedHttp(v&&v->type==StrictJsonType::Number,"exact-public numeric shape");const double n=std::stod(v->raw);NeedHttp(std::isfinite(n)&&n>=0,"exact-public numeric range");return n;};
 NeedHttp(std::abs(number("targetSeconds")-double(seek->ticks)/seek->timescale)<=1e-9&&std::abs(number("frameDurationSeconds")-double(seek->duration)/seek->timescale)<=1e-9,"exact-public independent seek");NeedHttp(bound(d),"exact-public final binding");
 const auto after=VisualSearchPublicationTestProbe::View(visual);
 std::cout<<"[R134-exact-publication] {\\"beforeInstance\\":"<<quote(before.publication->instance_id)<<",\\"beforeGeneration\\":"<<before.publication->generation.value_or(0)<<",\\"afterInstance\\":"<<(after.publication?quote(after.publication->instance_id):"null")<<",\\"afterGeneration\\":"<<(after.publication?after.publication->generation.value_or(0):0)<<",\\"sameIndex\\":"<<(after.index==view.index?"true":"false")<<",\\"samePublication\\":"<<(after.publication==view.publication?"true":"false")<<"}"<<std::endl;
 NeedHttp(after.index==view.index&&after.publication==view.publication,"exact-public publication after changed");HttpObservation::Mark(observation.validationEndNs);HttpObservation::Mark(observation.outputEndNs);
 }
 if(fresh_representative){
''' +s[pos:];s=s.replace(' const auto quote=[](const auto& value){return recording::EvidenceJsonQuote(value);};\n std::cout<<"[R133-target]', ' std::cout<<"[R133-target]');s=s.replace('HttpObservation observation{101,"publicFresh",route,begin}', 'HttpObservation observation{101,"bucketFresh",route,begin}')
s=s.replace(' }\n }\n\n NeedHttp(finish.Run()', ' }\n }else std::cout<<"[R134-bucket] not-applicable no-known-UTC-representative-fresh"<<std::endl;\n }\n\n NeedHttp(finish.Run()');s=s.replace('[R133-finish-success]','[R134-finish-success]');p.write_text(s)
p=Path('scripts/internal/recording_degraded_http_qualification.py');s=p.read_text().replace('import json,math,re,subprocess','import json,math,re,subprocess\nfrom urllib.parse import parse_qs,urlsplit');i=s.index('\ndef qualify');s=s[:i]+'''
def exact_public_fresh(body,target,publication,wire):
 assert target['id'] and target['channel'] and target['freshCount']>0
 q=parse_qs(urlsplit(wire['route']).query)
 assert urlsplit(wire['route']).path=='/ops/api/recordings/visual-search/seek'
 assert q=={'channelId':[target['channel']],'hitId':[target['id']]},'exact request binding'
 assert wire['status']==200,'exact HTTP status'
 assert body['hitId']==target['id'] and body['playable'] is True and body['seekAvailable'] is True
 assert body['playbackUrl']=='/ops/api/recordings/media/'+target['segment']
 assert body['timeBasis']=='verified-native-file-presentation'
 assert math.isfinite(body['targetSeconds']) and body['targetSeconds']>=0
 assert math.isfinite(body['frameDurationSeconds']) and body['frameDurationSeconds']>0
 assert target['seekTimescale']>0 and int(target['seekTicks'])>=0 and int(target['durationTicks'])>0
 assert abs(body['targetSeconds']-int(target['seekTicks'])/target['seekTimescale'])<=1e-9
 assert abs(body['frameDurationSeconds']-int(target['durationTicks'])/target['seekTimescale'])<=1e-9
 assert publication['sameIndex'] is True and publication['samePublication'] is True
 for phase in ('before','after'):
  assert publication[phase+'Instance']==target['instanceId'] and publication[phase+'Generation']==target['generation'],'exact publication changed'
 return True
''' +s[i:];s=s.replace("  targets=rows('[R133-target] ');fresh=", "  targets=rows('[R133-target] ');fresh=")
s=s.replace('  public_fresh(fresh[0],targets[0])\n  wires=', '''  bucket=len(targets)==1
  if bucket:public_fresh(fresh[0],targets[0])
  else:assert not fresh and '[R134-bucket] not-applicable no-known-UTC-representative-fresh' in text
  wires=''')
s=s.replace(';assert len(targets)==len(fresh)==1', ';assert len(targets)==len(fresh) and len(targets)<=1')
s=s.replace("  for scope,count in [('original12',3*clients),('auxiliary200',1),('publicFresh',1)]:", "  target=rows('[R134-target] ');publication=rows('[R134-exact-publication] ');exact=[json.loads(x.split('response=',1)[1]) for x in text.splitlines() if x.startswith('[R134-public-exact] ')];exactwire=[x for x in wires if x['scope']=='publicExact'];assert len(target)==len(publication)==len(exact)==len(exactwire)==1\n  exact_public_fresh(exact[0],target[0],publication[0],exactwire[0])\n  for scope,count in [('original12',3*clients),('auxiliary200',1),('publicExact',1),('bucketFresh',int(bucket))]:")
s=s.replace('[R133-finish-success]','[R134-finish-success]').replace('str(3*min(clients,2)+(2 if mode.startswith("source-") else 0))','str(3*min(clients,2)+(1+int(bucket) if mode.startswith("source-") else 0))');p.write_text(s)
