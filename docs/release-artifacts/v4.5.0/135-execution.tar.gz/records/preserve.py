import pathlib,json,hashlib,tarfile,io,subprocess,stat,os
repo=pathlib.Path.cwd();root=pathlib.Path(__file__).parent.parent;records=root/'records';out=repo/'docs/release-artifacts/v4.5.0';h=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def sanitize(b):
 try:return b.decode().replace(str(root),'<RUN_ROOT>').replace(str(pathlib.Path.home()),'<HOME>').replace(os.environ.get('TMPDIR','/nonexistent-temp-prefix').rstrip('/'),'<TMPDIR>').encode()
 except UnicodeDecodeError:
  assert str(root).encode() not in b and str(pathlib.Path.home()).encode() not in b
  return b
selected=[];reconstruction={}
for mode in ['warm','cold']:
 run=root/mode/('r135'+mode+'-run')
 if not (run/'execution.json').exists():continue
 seed=json.loads((root/'input-binding.json').read_text())['maps'][mode]
 current={str(p.relative_to(run/'recording')):h(p.read_bytes()) for p in (run/'recording').rglob('*') if p.is_file() and not p.is_symlink()}
 delta=[{'path':p,'sha256':v,'bytes':(run/'recording'/p).stat().st_size} for p,v in current.items() if seed.get(p)!=v]
 reconstruction[mode]={'seedReference':'125-execution.tar.gz observer/recordings'+(' +130 delta minus supplement deletedPaths' if mode=='warm' else ''),'changed':delta,'deleted':sorted(set(seed)-set(current)),'seedMapSha256':h(json.dumps(seed,sort_keys=True).encode()),'currentMap':current}
 for row in delta:selected.append((run/'recording'/row['path'],mode+'/recording-delta/'+row['path']))
 for p in run.iterdir():
  if p.is_file() and p.name in ['execution.json','output.log','input-binding.json','preparation-budget.json','workspace-first-failure.json','resource-phase']:selected.append((p,mode+'/run/'+p.name))
 selected.append((root/mode/('http-r135'+mode+'.binding.json'),mode+'/build-binding.json'))
dump(records/'recording-reconstruction.json',reconstruction)
for p in (root/'warm/r135warm-build').iterdir():
 if p.is_file() and p.name in ['execution.json','output.log']:selected.append((p,'warm/build/'+p.name))
for attempt in ['writer-before','writer-before-corrected','writer-after']:
 d=root/attempt
 for name in ['writer-output.log','workspace-first-failure.json']:
  if (d/name).exists():selected.append((d/name,'direct/'+attempt+'/'+name))
 media=list((d/'recording').glob('*/*.mp4'));assert len(media)==1
 selected.append((media[0],'direct/'+attempt+'/media.mp4'))
for p in records.iterdir():
 if p.is_file() and not p.name.startswith('prior-'):selected.append((p,'records/'+p.name))
selected.append((root/'input-binding.json','input-binding.json'))
source=['recording_current_observer.mjs','recording_visual_contention_observer.mjs','recording_current_root_storage.test.mjs','recording_visual_contention_contract_test.py','recording_publication_observer_smoke.cpp','recording_publication_observer_smoke.mjs','recording_degraded_http_smoke.cpp','recording_degraded_http_qualification.py','recording_public_fresh_oracle.h','recording_degraded_http_run.py','recording_source_http_fixture.h','recording_http_observation.h','recording_native_isolation.py','recording_current_observer_native.cpp']
for name in source:selected.append((repo/'scripts/internal'/name,'source/scripts/internal/'+name))
archive=out/'135-execution.tar.gz';assert not archive.exists();manifest=[];seen=set()
with tarfile.open(archive,'w:gz') as t:
 for p,name in sorted(selected,key=lambda x:x[1]):
  st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and name not in seen;seen.add(name)
  raw=p.read_bytes();saved=sanitize(raw);info=tarfile.TarInfo(name);info.size=len(saved);info.mode=0o600;t.addfile(info,io.BytesIO(saved));manifest.append({'path':name,'sourceBytes':len(raw),'sourceSha256':h(raw),'savedBytes':len(saved),'savedSha256':h(saved),'sanitized':raw!=saved})
 b=(json.dumps({'files':manifest,'rawVsSanitized':'owned root/home path replacement only, separate hashes; diagnostics already redacted enums','references':['125-execution.tar.gz','130-execution.tar.gz','130-preservation-supplement.json','134-execution.tar.gz'],'excluded':'user settings/private95/auth/env/models/SDK; no duplicate seed/runtime/binaries; binary/source/link hashes retained'},indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.mode=0o600;info.size=len(b);t.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as t:
 for row in manifest:
  m=t.getmember(row['path']);assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts;assert h(t.extractfile(m).read())==row['savedSha256']
info={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h(archive.read_bytes()),'payloadMembers':len(manifest),'totalMembers':len(manifest)+1,'localReadback':'every payload saved hash checked; manifest parsed; entire gzip hash bound','deltaFiles':{k:len(v['changed']) for k,v in reconstruction.items()}}
dump(records/'archive-result.json',info);print(json.dumps(info))
