from pathlib import Path
import json,math,zlib,base64,hashlib,collections
R=Path(__file__).parent; M=R/'mixed900'; O=next(M.glob('media-server-current-observer-*')); lines=(M/'run.log').read_text().splitlines()
def tagged(tag):return [json.loads(x[len(tag)+1:]) for x in lines if x.startswith(tag+' ')]
def save(name,j):(R/name).write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def dist(a):
 a=sorted(a);return {'count':len(a),'p95Ms':a[math.ceil(len(a)*.95)-1] if a else None,'maxMs':a[-1] if a else None}
def stats(a):return {'count':len(a),'first':a[0] if a else None,'last':a[-1] if a else None,'min':min(a) if a else None,'max':max(a) if a else None,'delta':a[-1]-a[0] if a else None}
f=json.loads((R/'final-result.json').read_text()); points=tagged('[current-observation]'); roots=tagged('[root-storage]'); obs0=points[0]['phaseAt']-points[0]['progress']['elapsedMs']; assert all(abs(p['phaseAt']-p['progress']['elapsedMs']-obs0)<.001 for p in points)
assert len({(p['pid'],p['startIdentity']) for p in points})==1
fields=['rssBytes','footprintBytes','anonymousFileBytes','anonymousAllocatedBytes','fdCount'];own=['ram','scratchDisk','scratchFd','scratchRam'];resource=[]
for lo,hi in [(0,300),(300,600),(600,900),(0,900)]:
 ps=[p for p in points if lo*1000<=p['progress']['elapsedMs']<(hi*1000)]; rs=[r for r in roots if r['reason']=='sample' and lo*1000<=r['measurementStartedAt']-obs0<hi*1000]
 row={'rangeSeconds':[lo,hi],'sampleCount':len(ps),'firstTimeSeconds':ps[0]['progress']['elapsedMs']/1000 if ps else None,'lastTimeSeconds':ps[-1]['progress']['elapsedMs']/1000 if ps else None,'metrics':{k:stats([p[k] for p in ps if isinstance(p.get(k),(int,float))]) for k in fields},'logical':{k:stats([p['productOwner'][k] for p in ps]) for k in own},'workspace':{k:stats([r[k] for r in rs]) for k in ['variableBytes','totalBytes']},'fileCategories':{k:stats([r['categories'][k]['bytes'] for r in rs]) for k in ['media','journal','generationEvidence','cache','recordingsOther']},'mutation':stats([p['mutationCount'] for p in ps]),'finalized':{ch:stats([p['progress']['channels'][ch]['finalized'] for p in ps]) for ch in ['9101','9201']},'ACompleted':sum(lo*1000<=a['completedAt']-obs0<hi*1000 for a in f['aLoad']['schedule'])}
 resource.append(row)
save('memory-intervals.json',{'clock':'actual phaseAt minus progress.elapsedMs; fixed half-open bins; final >900s sample separately','observationStartMonotonicMs':obs0,'pid':points[0]['pid'],'startIdentity':points[0]['startIdentity'],'intervals':resource,'allSamplesIncludingFinal':{k:stats([p[k] for p in points]) for k in fields},'finalSample':points[-1],'logicalScope':'latest sequential resource counter sample carried into process measurement; not simultaneous heap measurement','maxSampleGapMs':max(b['phaseAt']-a['phaseAt'] for a,b in zip(points,points[1:]))})
# Search start timestamps are absent. Exact official latency stays separate from rounded transport diagnostics.
http=tagged('[mixed-http-timing]'); original=[h for h in http if h['routeKind'] in ['/ops/api/recordings/search','/ops/api/recordings/visual-search'] and h['method']=='GET']
# A uses the structured route too, so identify original four-request batches immediately before index-status.
batches=[]; pending=[]
for h in http:
 if h['routeKind'] in ['/ops/api/recordings/search','/ops/api/recordings/visual-search'] and h['method']=='GET':pending.append(h)
 elif h['routeKind']=='/ops/api/recordings/visual-search/status':
  q=pending[-4:];assert len(q)==4 and sum(x['routeKind'].endswith('/search') for x in q)==2; batches.extend(q);pending=[]
save('search-analysis.json',{'officialPopulation':dist(f['evidenceLoad']['searchLatencyMs']),'successByClient':f['evidenceLoad']['searchSuccessByClient'],'unavailable':f['evidenceLoad']['searchUnavailable'],'transportFailureCount':sum(h['outcome']!='ok' for h in http),'routeDiagnosticsRoundedMs':{k:dist([h['totalElapsedMs'] for h in batches if h['routeKind']==k and h['status']==200]) for k in ['/ops/api/recordings/search','/ops/api/recordings/visual-search']},'wallTimeRequestBins':None,'wallTimeReason':'mixed-http-timing has elapsed durations but no request start/end absolute monotonic timestamp; no array thirds substituted','existingEvidenceWindows':f['evidenceLoad']['windows'],'evidenceWindowsScope':'helper selects window at evidenceLoad entry; item counts and created packages, not request-time latency bins','ACompletedByActualTime':[x['ACompleted'] for x in resource[:3]],'retainedAndBusyWallTime':None})
seen={};segments=[];intra=[];checked=0
for p in sorted((O/'recordings').glob('*.jsonl')):
 if not (p.name.startswith('active-') or p.name.startswith('evidence-') or p.name=='recording-v2-mutations.jsonl'):continue
 for line in p.read_bytes().splitlines():
  if not line:continue
  j=json.loads(line)
  if j.get('schema')=='media-server.recording-compressed-mutation.v1':
   b=zlib.decompress(base64.b64decode(j['data']));assert len(b)==j['length'] and zlib.crc32(b)==j['crc32'];j=json.loads(b);checked+=1
  mid=j.get('mutationId');
  if mid in seen:assert seen[mid]==j;continue
  if mid:seen[mid]=j
  if j.get('mutationType')!='segment_v2_bound_finalized':continue
  q=j['payload'];s=q['segment'];b=q['sourceBinding'];c=s['channel_id']
  if c not in ['9101','9201']:continue
  ords=[x['ordinal'] for x in b['samples']]; mp=O/'recordings'/q['mediaRelpath'];data=mp.read_bytes();assert len(data)==s['size_bytes'] and hashlib.sha256(data).hexdigest()==s['checksum_sha256']==b['file_evidence']['sha256']
  for x,y in zip(ords,ords[1:]):
   if y!=x+1:intra.append({'segment':s['segment_id'],'before':x,'after':y})
  segments.append({'segment':s['segment_id'],'channel':c,'generation':b['source_generation'],'generationOrder':b['generation_order'],'order':s['order_sequence'],'first':ords[0],'last':ords[-1],'samples':len(ords),'bytes':len(data),'sha256':s['checksum_sha256'],'indexComplete':b['index_complete'],'createdAtMs':s['created_at_ms'],'finalizedAtMs':s['finalized_at_ms']})
segments.sort(key=lambda s:s['order']);between=[];groups=collections.defaultdict(list)
for s in segments:groups[(s['channel'],s['generation'])].append(s)
comparisons=0
for key,ss in groups.items():
 for a,b in zip(ss,ss[1:]):
  comparisons+=1
  if b['first']!=a['last']+1:between.append({'channel':key[0],'generation':key[1],'before':a['segment'],'after':b['segment'],'last':a['last'],'first':b['first']})
log=(O/'server-1.private.log').read_text();save('segment-analysis.json',segments)
rec={'finalizedFiles':len(segments),'channels':{c:{'files':sum(s['channel']==c for s in segments),'samples':sum(s['samples'] for s in segments if s['channel']==c),'bytes':sum(s['bytes'] for s in segments if s['channel']==c)} for c in ['9101','9201']},'intraSegmentGaps':intra,'betweenSameGenerationGaps':between,'sameGenerationComparisons':comparisons,'channelGenerationGroups':len(groups),'allFileHashesMatchBinding':True,'compressedRowsCRCChecked':checked,'deliveryLossLogLines':sum('deliveryLoss' in l for l in log.splitlines()),'sourceExpected':None,'queueEnqueued':None,'queueDequeued':None,'queueDrops':None,'writerAcceptedTotal':None,'maxCallback':None,'maxDepth':None,'maxQueueWait':None,'firstDrop':None,'firstDepth64':None,'unavailableReason':'full product mixed mode does not emit direct-fixture queue/callback counters; no instrumentation added','scope':'closed finalized samples and within-generation continuity only; generation transition/Stop tail/source completeness not proven'}
save('recording-analysis.json',rec)
save('shutdown-analysis.json',{'cleanup':tagged('[process-cleanup]'),'state':tagged('[recording-state-summary]'),'resource':tagged('[resource-trace-summary]'),'finishPhases':[json.loads(l.split(' ',1)[1]) for l in log.splitlines() if l.startswith('[recording-resource]') and any(x in l for x in ['before-Finish','after-Finish','after-storage-destruction'])],'closedJournalGate':'[pass] LP26-O02 closed journal no partial tail' in lines,'disableHttp':[h for h in tagged('[http-timing]') if h['method']=='PUT' and h['routeClass']=='source-item'],'failureLines':[l for l in lines if l.startswith('[fail]')]})
print(json.dumps({'search':dist(f['evidenceLoad']['searchLatencyMs']),'recording':rec,'intervalRSS':[r['metrics']['rssBytes'] for r in resource],'observationStart':obs0},indent=2))
