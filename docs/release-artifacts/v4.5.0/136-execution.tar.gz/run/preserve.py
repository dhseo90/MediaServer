from pathlib import Path
import json,hashlib,tarfile,io,stat,re
R=Path(__file__).parent;M=R/'mixed900';O=next(M.glob('media-server-current-observer-*'));repo=Path('<REPO>');dest=repo/'docs/release-artifacts/v4.5.0/136-execution.tar.gz'
assert not dest.exists(); files=[]
for p in R.iterdir():
 if p.is_file() and p.name not in ['archive-result.json','preservation-attempt1.incomplete.tar.gz']:files.append((p,'run/'+p.name))
for p in M.iterdir():
 if p.is_file():files.append((p,'mixed900/'+p.name))
for folder in ['artifacts','receipts']:
 for p in (M/folder).rglob('*'):
  if p.is_file() and not p.is_symlink():files.append((p,'mixed900/'+str(p.relative_to(M))))
for folder in ['recordings','input']:
 for p in (O/folder).rglob('*'):
  if p.is_symlink():continue
  if p.is_file() and 'visual-cache' not in p.relative_to(O).parts and not p.name.startswith('.') and p.name not in ['writer.lock','read.lock']:
   files.append((p,'observer/'+str(p.relative_to(O))))
for p in O.iterdir():
 if p.is_file() and (p.suffix in ['.log','.json','.cpp']):files.append((p,'observer/'+p.name.replace('.private.log','.sanitized.log')))
for name in ['run_v450_recording_a_mixed.py','verify_v450_recording_a_mixed.sh','v450_recording_a_mixed.mjs','v450_recording_a_load.mjs','recording_current_observer.mjs','recording_longrun_progress.mjs','recording_current_app_helpers.mjs','recording_resource_trace.mjs','recording_process_metrics.cpp']:
 files.append((repo/'scripts/internal'/name,'source/'+name))
for name in ['CMakeFiles/media_server.dir/link.txt','CMakeFiles/media_server_runtime.dir/flags.make']:
 files.append((repo/'build-gst-onnx'/name,'source/build/'+Path(name).name))
manifest={'schema':'media-server.v450.r136.archive.v1','sourceHead':'720fec41a5a2822ed441b48e71c9c2a5b2a57691','files':[],'excluded':['auth/state/user settings/private backups','GStreamer registry/plugin cache','visual derived cache','executables/runtime (hash bound)','models/SDK','symlinks/lease/locks'],'sanitization':'text paths/URIs redacted, original and retained hashes separate; binary recording/input/package bytes unchanged','meaning':'one external900 execution; no historical archives replaced'}
with tarfile.open(dest,'w:gz',compresslevel=6) as t:
 for p,name in sorted(files,key=lambda x:x[1]):
  st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==501
  original=p.read_bytes(); b=original;redacted=False
  # Binary evidence/media and compressed journal envelopes retain exact bytes.
  if p.suffix in ['.json','.jsonl','.log','.stdout','.cpp','.mjs','.py','.sh','.txt','.make'] or p.name=='launcher.stdout':
   s=b.decode();s=s.replace(str(R),'<OWNED_ROOT>').replace(str(repo),'<REPO>').replace('<HOME>','<HOME>')
   s=re.sub(r'<OS_TMP>"\x27]+','<OS_TMP>',s)
   # Preserve scheme marker; no private URI payload on remote.
   s=re.sub(r'((?:https?|rtsp|file|stun)://)[^\s\"\x27<>]+',r'\1<REDACTED>',s)
   b=s.encode();redacted=b!=original
   assert not re.search(rb'"(?:passwordHash|tokenHash|passwordHistory)"\s*:',b),name
   assert b'<HOME>' not in b and str(R).encode() not in b,name
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b));manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),'sanitized':redacted})
 b=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest['files'])+1
 for f in manifest['files']:
  b=t.extractfile(f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
out={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files),'payloadBytes':sum(x['bytes'] for x in manifest['files']),'allMemberBytesVerified':True}
(R/'archive-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
