import sys,pathlib,subprocess,json,time
sys.path.insert(0,'/repo/scripts/internal')
from recording_native_isolation import environment
r=pathlib.Path('/tmp/media-server-r137-linux/worker-stage-diagnostic');r.mkdir(mode=0o700)
e=environment(r);e['MEDIA_SERVER_VERIFY_MEMORY_ATTRIBUTION']='1';e['MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS']='1'
t=time.monotonic()
with (r/'output.log').open('xb') as f:p=subprocess.run(['/tmp/media-server-r137-linux/focused-observed/visual_index_worker_smoke',str(r/'case')],env=e,stdout=f,stderr=subprocess.STDOUT,timeout=30)
(r/'result.json').write_text(json.dumps({'exit':p.returncode,'elapsedSeconds':time.monotonic()-t,'scope':'same binary single stage diagnostic, no PASS reselection'},indent=2));print(p.returncode)
