from pathlib import Path
import json,hashlib,tarfile,io,stat,re,subprocess
R=Path(__file__).parent;M=R/'mixed600';O=next(M.glob('media-server-current-observer-*'));repo=Path('<REPO>');dest=repo/'docs/release-artifacts/v4.5.0/137-execution.tar.gz'
assert not dest.exists();files=[]
# Analysis, plan, complete focused stdout/stderr and build diagnostics; no build objects/binaries or edit scratch scripts.
for p in R.iterdir():
 if p.is_file() and (p.suffix in ['.log','.stdout'] or p.name in ['plan.json','clock-comparison.json','layout-result.json','product-uuid.txt','final-result.json','memory-intervals.json','search-analysis.json','recording-analysis.json','segment-analysis.json','shutdown-analysis.json','owner-analysis.json','owner-events-observed.json','postrun-absence.json','analyze.py','analyze-owners.py','preserve.py','run_focused.py','run_linux_completion.py','linux-worker-diagnostic.py']):files.append((p,'run/'+p.name))
for folder in ['mac-focused','mac-focused-2','mac-focused-current','mac-final','linux-work','linux-native-results']:
 for p in (R/folder).rglob('*'):
  if p.is_file() and p.suffix in ['.log','.json'] and 'build' not in p.relative_to(R/folder).parts:files.append((p,'focused/'+str(p.relative_to(R))))
for p in M.iterdir():
 if p.is_file():files.append((p,'mixed600/'+p.name))
for folder in ['artifacts','receipts']:
 for p in (M/folder).rglob('*'):
  if p.is_file() and not p.is_symlink():files.append((p,'mixed600/'+str(p.relative_to(M))))
for folder in ['recordings','input']:
 for p in (O/folder).rglob('*'):
  if p.is_symlink():raise RuntimeError('unexpected owned evidence symlink')
  if p.is_file() and 'visual-cache' not in p.relative_to(O).parts and not p.name.startswith('.') and p.name not in ['writer.lock','read.lock']:files.append((p,'observer/'+str(p.relative_to(O))))
for p in O.iterdir():
 if p.is_file() and p.suffix in ['.log','.json','.cpp']:files.append((p,'observer/'+p.name.replace('.private.log','.sanitized.log')))
changed=subprocess.check_output(['git','diff','--name-only','7cfea7a9f4e70ed22e8e9cc283b5eed72d787853','ed93102f2d309451cbf2dd49f1ff32dad1241347'],cwd=repo,text=True).splitlines()
extra=['scripts/internal/recording_process_metrics.cpp','scripts/internal/v450_recording_a_load.mjs','scripts/internal/recording_longrun_progress.mjs','scripts/internal/recording_resource_trace.mjs']
for n in sorted(set(changed+extra)):
 if n.startswith(('src/','include/','scripts/')):files.append((repo/n,'source/'+n))
for n in ['CMakeFiles/media_server.dir/link.txt','CMakeFiles/media_server_runtime.dir/flags.make']:files.append((repo/'build-gst-onnx'/n,'source/build/'+Path(n).name))
assert len({n for _,n in files})==len(files)
manifest={'schema':'media-server.v450.r137.archive.v1','sourceHead':'ed93102f2d309451cbf2dd49f1ff32dad1241347','files':[],'excluded':['auth/state/user settings/private backups','GStreamer registry/plugin cache','visual derived cache','executables/runtime: hash-bound, not copied','models/SDK','symlinks/lease/locks','build objects','edit scratch and duplicate binding candidate'],'sanitization':'Text user/owned/OS temporary paths and URI payloads replaced; original and retained hashes separate. Binary media/input/packages unchanged. No memory dump.','meaning':'one600/780 owner attribution diagnostic; baseline archives/history unchanged'}
textExt={'.json','.jsonl','.log','.stdout','.cpp','.h','.mjs','.py','.sh','.txt','.make'}
with tarfile.open(dest,'w:gz',compresslevel=6) as t:
 for p,name in sorted(files,key=lambda x:x[1]):
  st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==501
  assert not p.is_symlink() and all(not q.is_symlink() for q in p.parents if str(q).startswith(str(R)))
  original=p.read_bytes();b=original
  if p.suffix in textExt:
   s=b.decode();s=s.replace(str(R),'<OWNED_ROOT>').replace(str(repo),'<REPO>').replace('<HOME>','<HOME>')
   s=re.sub(r'<OS_TMP>"\x27<>]+','<OS_TMP>',s)
   s=re.sub(r'((?:https?|rtsp|file|stun)://)[^\s\"\x27<>]+',r'\1<REDACTED>',s)
   b=s.encode()
   assert not re.search(rb'"(?:passwordHash|tokenHash|passwordHistory)"\s*:',b),name
   assert b'<HOME>' not in b and str(R).encode() not in b,name
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b));manifest['files'].append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),'sanitized':b!=original})
 b=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(b);info.mode=0o600;t.addfile(info,io.BytesIO(b))
with tarfile.open(dest) as t:
 assert len(t.getmembers())==len(manifest['files'])+1
 for f in manifest['files']:
  b=t.extractfile(f['path']).read();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
out={'archive':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'files':len(files),'payloadBytes':sum(x['bytes'] for x in manifest['files']),'allMemberBytesVerified':True}
(R/'archive-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
