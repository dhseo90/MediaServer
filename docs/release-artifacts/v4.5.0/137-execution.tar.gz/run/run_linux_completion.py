import pathlib,sys,subprocess,shlex,json,time,os
repo=pathlib.Path(sys.argv[1]);root=pathlib.Path(sys.argv[2]);build=pathlib.Path(sys.argv[3]);root.mkdir(mode=0o700,exist_ok=True)
sys.path.insert(0,str(repo/'scripts/internal'));from recording_native_isolation import environment
env=environment(root);env['MEDIA_SERVER_VERIFY_MEMORY_ATTRIBUTION']='1'
env['MEDIA_SERVER_VERIFY_CATALOG_SUBCOSTS']='1'
results=[]
def run(name,cmd,args=None):
 t=time.monotonic()
 with (root/(name+'.log')).open('xb') as f:p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 results.append(dict(name=name,command=cmd,exit=p.returncode,seconds=time.monotonic()-t));(root/'results.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
f={}
for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);f[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
for name in ['visual_index_worker_smoke','recording_resource_trace_smoke']:
 binary=root/name
 extra=[str(repo/'src/recording/visual_index_store.cpp')] if sys.platform=='linux' and name=='visual_index_worker_smoke' else []
 defs=[v for v in f['CXX_DEFINES'] if not (extra and v.startswith('-DMEDIA_SERVER_USE_SIGLIP2='))]+(['-DMEDIA_SERVER_USE_SIGLIP2=1'] if extra else [])
 if extra:
  obj=root/'visual-index-store.o'
  run('visual-index-store-build',[link[0]]+defs+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-c',extra[0],'-o',str(obj)])
  extra=[str(obj)]
 run(name+'-build',[link[0]]+defs+f['CXX_INCLUDES']+f['CXX_FLAGS']+['-Wall','-Wextra','-Werror','-I'+str(repo/'scripts/internal'),str(repo/'scripts/internal'/(name+'.cpp')),*extra,str(build/'libmedia_server_runtime.a')]+libs+['-o',str(binary)])
 # Resource trace's existing sink asserts its exact original schema; diagnostic disabled regression.
 if name=='recording_resource_trace_smoke':env.pop('MEDIA_SERVER_VERIFY_MEMORY_ATTRIBUTION',None)
 run(name,[str(binary)]+(['/tmp/media-server-r137-visual-native'] if name=='visual_index_worker_smoke' else []))
