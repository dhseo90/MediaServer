// 파일 용도: 검색 결과의 bounded 불변 페이지와 사용자/권한/질의 결박 cursor.
#pragma once
#include "recording/recording_search_model.h"
#include <array>
#include <chrono>
#include <deque>
#include <mutex>
#include <condition_variable>
#include <thread>

namespace recording {
struct SearchSnapshotLimits {
    std::size_t max_snapshots{8}, max_bytes{128*1024*1024};
    std::chrono::milliseconds lifetime{std::chrono::minutes(5)};
};
struct RecordingSearchPage {
    SearchModelResidency::Reservation memory;
    std::shared_ptr<const RecordingSearchModel> model;
    std::vector<std::size_t> positions;
    std::size_t known_count{0}, unplaced_count{0};
    std::string snapshot_id, next_cursor;
    RecordingSearchPage()=default;
    RecordingSearchPage(const RecordingSearchPage&)=default;
    RecordingSearchPage(RecordingSearchPage&&) noexcept=default;
    RecordingSearchPage& operator=(RecordingSearchPage other) noexcept {
        memory.swap(other.memory);std::swap(model,other.model);std::swap(positions,other.positions);std::swap(known_count,other.known_count);std::swap(unplaced_count,other.unplaced_count);std::swap(snapshot_id,other.snapshot_id);std::swap(next_cursor,other.next_cursor);return *this;
    }
};
class RecordingSearchSnapshots {
public:
    using Clock=std::chrono::steady_clock;
    // 수동 모드는 독립 시계 fixture용이다. 제품은 자동 idle 만료를 명시한다.
    explicit RecordingSearchSnapshots(SearchSnapshotLimits limits = {}, bool automatic_expiry = false);
    ~RecordingSearchSnapshots();
    // caller는 매 호출마다 현재 사용자와 요청 채널 전체 권한을 먼저 검사한다.
    bool Begin(std::shared_ptr<const RecordingSearchModel>, const RecordingSearchQuery&,
        const std::string& principal, const std::string& scope,
        RecordingSearchPage*, std::string* error, Clock::time_point now=Clock::now());
    bool Resume(const std::string& cursor, const RecordingSearchQuery&,
        const std::string& principal, const std::string& scope,
        RecordingSearchPage*, std::string* error, Clock::time_point now=Clock::now());
    bool ResolveHit(const std::string& snapshot_id, const std::string& hit_id,
        const RecordingSearchQuery&, const std::string& principal, const std::string& scope,
        std::shared_ptr<const RecordingSearchModel>*, std::size_t* position,
        std::string* error, Clock::time_point now=Clock::now());
private:
    struct Entry {
        std::shared_ptr<const RecordingSearchModel> model;
        RecordingSearchMatches matches;
        std::string id, query_hash, principal, scope;
        std::size_t limit{0}, bytes{0};
        Clock::time_point expires;
    };
    bool Page(const Entry&, std::size_t offset, RecordingSearchPage*, std::string*) const;
    bool Mac(const std::string&, std::string*) const;
    void Expire(Clock::time_point);
    void RunExpiry();
    void DiagnosticLocked(unsigned reason=0);
    const std::uint64_t diagnostic_key_{memory_diagnostic::NextIdentity()};
    SearchSnapshotLimits limits_;
    std::array<unsigned char,32> secret_{};
    bool ready_{false};
    std::mutex mutex_;
    std::deque<Entry> entries_;
    std::size_t bytes_{0};
    std::condition_variable expiry_changed_;
    bool stopping_{false};
    std::thread expiry_worker_;
};
} // namespace recording
