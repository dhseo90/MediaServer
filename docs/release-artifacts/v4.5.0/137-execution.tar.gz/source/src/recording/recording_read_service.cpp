// 파일 용도: 운영 timeline의 조회 전용 투영.
#include "recording/recording_read_service.h"
#include "recording/recording_latency_trace.h"
#include "recording/recording_completion_trace.h"
#include "recording/recording_timeline_calculations.h"
#include <stdexcept>
#include <unordered_map>
#include "recording/recording_media_inspector.h"
#include <algorithm>
#include <charconv>
#include <cerrno>
#include <limits>
#include <tuple>
#include <set>
#include "domain/strict_json.h"
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace recording {
using detail::timeline::Bytes;
using detail::timeline::Interval;
using detail::timeline::kBytes;
using detail::timeline::Union;

std::optional<ConfirmedMediaInterval> IntersectConfirmedMediaIntervals(
        const ConfirmedMediaInterval& a, const ConfirmedMediaInterval& b) {
    if(a.source_id.empty()||a.store_id.empty()||a.media_epoch_id.empty()||a.segment_id.empty()||
       a.source_id!=b.source_id||a.store_id!=b.store_id||a.media_epoch_id!=b.media_epoch_id||a.segment_id!=b.segment_id||
       a.time_base_num<=0||a.time_base_den<=0||a.time_base_num!=b.time_base_num||a.time_base_den!=b.time_base_den||
       a.start_pts<0||b.start_pts<0||a.start_pts>=a.end_pts||b.start_pts>=b.end_pts)return std::nullopt;
    auto out = a;
    out.start_pts = std::max(a.start_pts, b.start_pts);
    out.end_pts = std::min(a.end_pts, b.end_pts);
    return out.start_pts<out.end_pts?std::optional<ConfirmedMediaInterval>(out):std::nullopt;
}
bool RecordingReadService::ResolveConsumerReference(const RecordingConsumerReferenceV1& reference,
        ConsumerReferenceResolution* output, std::string* error) const {
    if (output) *output = {};
    if (!output || !ValidateRecordingConsumerReferenceV1(reference, error)) return false;
    if (reference.association_quality != "timestamp-match") {
        output->reason = reference.association_quality;
        if (error) error->clear();
        return true;
    }
    const auto& original = *reference.original;
    RecordingOriginalResult candidates;
    if(!catalog_.ResolveOriginalSample(reference.channel_id,reference.source_id,original.source_generation,
        original.generation_order,original.track_id,original.ordinal,original.pts_ns,&candidates,error))return false;
    output->unindexed=candidates.unknown;
    for(const auto& candidate:candidates.exact) {
        const auto& segment=candidate.segment;
        const __int128 numerator=static_cast<__int128>(original.pts_ns)*segment.time_base_den;
        const __int128 denominator=static_cast<__int128>(1000000000)*segment.time_base_num;
        // 정상 binding은 이미 exact 변환을 검증한다. 방어 경계에서도 원본 후보는 숨기지 않는다.
        if (denominator <= 0 || numerator % denominator ||
            numerator / denominator > std::numeric_limits<std::int64_t>::max()) {
            RecordingLocationResult unknown;
            unknown.state = RecordingLocationState::Unknown;
            unknown.has_unknown = true;
            output->exact.push_back({candidate, std::move(unknown), "unrepresentable-media-time"});
            continue;
        }
        RecordingLocationResult location;
        if(!ResolveMediaLocation(reference.channel_id,segment.segment_id,static_cast<std::int64_t>(numerator/denominator),&location,error))return false;
        // catalog 조회 사이 삭제/손상된 후보를 확정 위치로 돌려주지 않는다.
        if(location.state==RecordingLocationState::Deleted||location.state==RecordingLocationState::None)continue;
        output->exact.push_back({candidate,std::move(location),{}});
    }
    if(output->exact.empty())output->reason=output->unindexed.empty()?"none":"sample-index-cap";
    if (error) error->clear();
    return true;
}
namespace {
RecordingRangeCandidate RangeCandidate(const RecordingSegmentV2& segment,
                                       const RecordingUtcMappingV1& mapping) {
    return {segment.store_id, segment.segment_id, segment.media_epoch_id, segment.order_sequence,
            segment.time_base_num, segment.time_base_den, mapping, std::nullopt, std::nullopt, {}};
}
void SortRangeCandidates(std::vector<RecordingRangeCandidate>& candidates) {
    std::sort(candidates.begin(), candidates.end(), [](const auto& a, const auto& b) {
        return std::tie(a.store_id, a.order_sequence, a.segment_id, a.mapping.mapping_id) <
               std::tie(b.store_id, b.order_sequence, b.segment_id, b.mapping.mapping_id);
    });
}
void AddRangeBoundary(std::vector<std::int64_t>& boundaries, std::int64_t point,
                      std::int64_t start, std::int64_t end) {
    if (point > start && point < end) boundaries.push_back(point);
}
void SortRangeBoundaries(std::vector<std::int64_t>& boundaries) {
    std::sort(boundaries.begin(), boundaries.end());
    boundaries.erase(std::unique(boundaries.begin(), boundaries.end()), boundaries.end());
}
bool PlacedUtc(const RecordingUtcMappingV1& mapping) {
    return mapping.provenance != "unknown" && mapping.utc_start_ns &&
           mapping.utc_end_ns && mapping.end_pts;
}
std::optional<std::int64_t> InverseRangeBound(const RecordingSegmentV2& segment,
                                            const RecordingUtcMappingV1& mapping,
                                            std::int64_t utc, bool end, std::string& reason) {
    // 64비트 차이 × 양수 32비트 timebase는 signed int128 안이다.
    const __int128 numerator = (static_cast<__int128>(utc) - *mapping.utc_start_ns) * segment.time_base_den;
    const __int128 denominator = static_cast<__int128>(1000000000) * segment.time_base_num;
    if (denominator <= 0 || numerator % denominator != 0) {
        reason = "non-integral-media-bound";
        return std::nullopt;
    }
    const __int128 pts = static_cast<__int128>(mapping.start_pts) + numerator / denominator;
    if (pts < std::numeric_limits<std::int64_t>::min() ||
        pts > std::numeric_limits<std::int64_t>::max()) {
        reason = "media-bound-overflow";
        return std::nullopt;
    }
    if (pts < mapping.start_pts || (end ? pts > *mapping.end_pts : pts >= *mapping.end_pts)) {
        reason = "outside-mapping-media-bounds";
        return std::nullopt;
    }
    return static_cast<std::int64_t>(pts);
}
bool InvalidRange(std::string* error) {
    if (error) *error = "invalid range input";
    return false;
}
} // namespace

bool RecordingReadService::ResolveMediaRange(const std::string& channel, const std::string& id,
                                             std::int64_t start, std::int64_t end,
                                             RecordingRangeResult* result, std::string* error) const {
    if (result) *result = {};
    if (!result || start >= end || !ValidateRecordingReferenceId(channel, error) || !ValidateOpaqueId(id, error))
        return InvalidRange(error);
    RecordingLocationCatalogSnapshot snapshot;
    if (!catalog_.SnapshotLocationsV2(channel, &snapshot, error)) return false;
    RecordingRangeResult output;
    if (std::binary_search(snapshot.deleted_segment_ids.begin(), snapshot.deleted_segment_ids.end(), id)) {
        output.deleted = true;
    } else {
        const RecordingSegmentV2* selected = nullptr;
        std::vector<std::int64_t> boundaries{start, end};
        for (const auto& segment : snapshot.segments) {
            if (segment.segment_id != id) continue;
            selected = &segment;
            for (const auto& mapping : segment.mappings) {
                AddRangeBoundary(boundaries, mapping.start_pts, start, end);
                if (mapping.end_pts) AddRangeBoundary(boundaries, *mapping.end_pts, start, end);
            }
            break;
        }
        SortRangeBoundaries(boundaries);
        for (std::size_t i = 1; i < boundaries.size(); ++i) {
            RecordingRangeSlice slice{boundaries[i-1], boundaries[i], RecordingRangeCoverage::Gap, {}};
            if (selected) for (const auto& mapping : selected->mappings) {
                if (slice.start < mapping.start_pts || (mapping.end_pts && slice.start >= *mapping.end_pts)) continue;
                auto candidate = RangeCandidate(*selected, mapping);
                candidate.media_start_pts = slice.start;
                if (mapping.end_pts) {
                    candidate.media_end_pts = slice.end;
                    slice.coverage = RecordingRangeCoverage::Confirmed;
                } else {
                    candidate.reason = "open-media-end";
                    slice.coverage = RecordingRangeCoverage::Unknown;
                }
                slice.candidates.push_back(std::move(candidate));
            }
            SortRangeCandidates(slice.candidates);
            output.slices.push_back(std::move(slice));
        }
    }
    *result = std::move(output);
    if (error) error->clear();
    return true;
}

bool RecordingReadService::ResolveUtcRange(const std::string& channel, std::int64_t start, std::int64_t end,
                                           RecordingRangeResult* result, std::string* error) const {
    if (result) *result = {};
    if (!result || start >= end || !ValidateRecordingReferenceId(channel, error)) return InvalidRange(error);
    RecordingLocationCatalogSnapshot snapshot;
    if (!catalog_.SnapshotLocationsV2(channel, &snapshot, error)) return false;
    return ResolveUtcRangeFromSnapshot(snapshot,start,end,result,error);
}

bool ResolveUtcRangeFromSnapshot(const RecordingLocationCatalogSnapshot& snapshot,
    std::int64_t start, std::int64_t end, RecordingRangeResult* result, std::string* error,std::size_t max_candidates) {
    if(result)*result={};
    if(!result||start>=end)return InvalidRange(error);
    RecordingRangeResult output;
    std::size_t candidate_count=0;
    std::vector<std::int64_t> boundaries{start, end};
    struct Overlap {
        const RecordingSegmentV2* segment;
        const RecordingUtcMappingV1* mapping;
    };
    struct BoundaryEvent {
        std::int64_t point;
        std::size_t index;
        bool entering;
    };
    std::vector<Overlap> overlaps;
    std::vector<BoundaryEvent> events;
    for (const auto& segment : snapshot.segments) for (const auto& mapping : segment.mappings) {
        if (!PlacedUtc(mapping)) {
            if(candidate_count++>=max_candidates) {if(error)*error="utc-range-candidate-cap";return false;}
            auto candidate = RangeCandidate(segment, mapping);
            candidate.media_start_pts = mapping.start_pts;
            candidate.media_end_pts = mapping.end_pts;
            candidate.reason = "utc-unplaced";
            output.unplaced.push_back(std::move(candidate));
            continue;
        }
        if (*mapping.utc_end_ns <= start || *mapping.utc_start_ns >= end) continue;
        const auto first = std::max(start, *mapping.utc_start_ns);
        const auto last = std::min(end, *mapping.utc_end_ns);
        const auto index = overlaps.size();
        overlaps.push_back({&segment, &mapping});
        events.push_back({first, index, true});
        events.push_back({last, index, false});
        AddRangeBoundary(boundaries, first, start, end);
        AddRangeBoundary(boundaries, last, start, end);
    }
    SortRangeBoundaries(boundaries);
    std::sort(events.begin(), events.end(), [](const auto& a, const auto& b) {
        return std::tie(a.point, a.entering, a.index) < std::tie(b.point, b.entering, b.index);
    });
    std::set<std::size_t> active;
    std::size_t next_event = 0;
    for (std::size_t i = 1; i < boundaries.size(); ++i) {
        RecordingRangeSlice slice{boundaries[i-1], boundaries[i], RecordingRangeCoverage::Gap, {}};
        // 인접 구간은 전체 mapping을 다시 읽지 않고 변화한 활성 집합만 갱신한다.
        while (next_event < events.size() && events[next_event].point <= slice.start) {
            const auto& event = events[next_event++];
            if (event.entering) active.insert(event.index);
            else active.erase(event.index);
        }
        bool confirmed = false;
        for (const auto index : active) {
            if(candidate_count++>=max_candidates) {if(error)*error="utc-range-candidate-cap";return false;}
            const auto& segment = *overlaps[index].segment;
            const auto& mapping = *overlaps[index].mapping;
            auto candidate = RangeCandidate(segment, mapping);
            candidate.media_start_pts = InverseRangeBound(segment, mapping, slice.start, false, candidate.reason);
            candidate.media_end_pts = InverseRangeBound(segment, mapping, slice.end, true, candidate.reason);
            confirmed = confirmed || (candidate.media_start_pts && candidate.media_end_pts);
            slice.candidates.push_back(std::move(candidate));
        }
        if (!slice.candidates.empty()) {
            slice.coverage = confirmed ? RecordingRangeCoverage::Confirmed : RecordingRangeCoverage::Unknown;
        }
        SortRangeCandidates(slice.candidates);
        output.slices.push_back(std::move(slice));
    }
    SortRangeCandidates(output.unplaced);
    *result = std::move(output);
    if (error) error->clear();
    return true;
}
namespace {
RecordingLocationCandidate LocationCandidate(const RecordingSegmentV2& s,std::int64_t pts,
                                              const RecordingUtcMappingV1& m) {
    return {s.store_id,s.segment_id,s.media_epoch_id,s.order_sequence,pts,s.time_base_num,s.time_base_den,m};
}
bool LocationError(std::string* error){if(error)*error="invalid location input";return false;}
void SortLocations(RecordingLocationResult* result) {
    std::sort(result->candidates.begin(),result->candidates.end(),[](const auto& a,const auto& b){
        // 이 경로의 후보는 닫힌 mapping 검사를 통과한 LocationCandidate에서만 생성된다.
        return std::tie(a.store_id,a.order_sequence,a.segment_id,a.mapping->mapping_id)<
               std::tie(b.store_id,b.order_sequence,b.segment_id,b.mapping->mapping_id);
    });
}
}
bool RecordingReadService::ResolveMediaLocation(const std::string& channel,const std::string& id,std::int64_t pts,
                                                RecordingLocationResult* result,std::string* error) const {
    if(result)*result={};
    if(!result||!ValidateRecordingReferenceId(channel,error)||!ValidateOpaqueId(id,error))return LocationError(error);
    RecordingLocationCatalogSnapshot snapshot;
    if(!catalog_.SnapshotLocationsV2(channel,&snapshot,error))return false;
    RecordingLocationResult output;
    if(std::binary_search(snapshot.deleted_segment_ids.begin(),snapshot.deleted_segment_ids.end(),id))
        output.state=RecordingLocationState::Deleted;
    else for(const auto& segment:snapshot.segments) {
        if(segment.segment_id!=id||pts<segment.media_start_pts||(segment.media_end_pts&&pts>=*segment.media_end_pts))continue;
        for(const auto& mapping:segment.mappings) {
            if(pts<mapping.start_pts||(mapping.end_pts&&pts>=*mapping.end_pts))continue;
            if(!mapping.end_pts) {output.state=RecordingLocationState::Unknown;output.has_unknown=true;break;}
            output.candidates.push_back(LocationCandidate(segment,pts,mapping));
            output.state=RecordingLocationState::Single;output.has_unknown=mapping.provenance=="unknown";break;
        }
    }
    *result=std::move(output);if(error)error->clear();return true;
}
bool RecordingReadService::ResolveUtcLocations(const std::string& channel,std::int64_t utc,
                                               RecordingLocationResult* result,std::string* error) const {
    if(result)*result={};
    if(!result||!ValidateRecordingReferenceId(channel,error))return LocationError(error);
    RecordingLocationCatalogSnapshot snapshot;
    if(!catalog_.SnapshotLocationsV2(channel,&snapshot,error))return false;
    RecordingLocationResult output;
    for(const auto& segment:snapshot.segments)for(const auto& mapping:segment.mappings) {
        if(mapping.provenance=="unknown"||!mapping.utc_start_ns||!mapping.utc_end_ns||!mapping.end_pts) {
            output.has_unknown=true;continue;
        }
        if(utc<*mapping.utc_start_ns||utc>=*mapping.utc_end_ns)continue;
        // 최대 64비트 차이와 양수 32비트 timebase 곱은 int128 안이다. 끝점 간 보간은 하지 않는다.
        const __int128 numerator=(static_cast<__int128>(utc)-*mapping.utc_start_ns)*segment.time_base_den;
        const __int128 denominator=static_cast<__int128>(1000000000)*segment.time_base_num;
        if(denominator<=0||numerator%denominator!=0) {output.has_unknown=true;continue;}
        const __int128 pts=static_cast<__int128>(mapping.start_pts)+numerator/denominator;
        if(pts<std::numeric_limits<std::int64_t>::min()||pts>std::numeric_limits<std::int64_t>::max()||
           pts<mapping.start_pts||pts>=*mapping.end_pts) {output.has_unknown=true;continue;}
        output.candidates.push_back(LocationCandidate(segment,static_cast<std::int64_t>(pts),mapping));
    }
    SortLocations(&output);
    if(output.candidates.size()>1)output.state=RecordingLocationState::Multiple;
    else if(output.has_unknown)output.state=RecordingLocationState::Unknown;
    else if(output.candidates.size()==1)output.state=RecordingLocationState::Single;
    *result=std::move(output);if(error)error->clear();return true;
}
namespace {
// 루트부터 각 구성요소를 fd로 고정한다. FIFO도 block하지 않고 fstat에서 거부한다.
int OpenMedia(const std::filesystem::path& root, const std::filesystem::path& relative) {
    if (relative.empty() || relative.is_absolute()) return -1;
    for (const auto& part : relative) {
        if (part == ".." || part == "." || part.empty()) return -1;
    }
    std::error_code ec;
    const auto absolute_root = std::filesystem::absolute(root, ec);
    if (ec) return -1;
    int current = ::open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (current < 0) return -1;
    auto descend = [&](const std::filesystem::path& part, bool directory) {
        const int next = ::openat(current, part.c_str(), O_RDONLY | O_NOFOLLOW |
                                 O_CLOEXEC | O_NONBLOCK | (directory ? O_DIRECTORY : 0));
        ::close(current);
        current = next;
        return next >= 0;
    };
    for (const auto& part : absolute_root.relative_path()) {
        if (part == "." || part.empty()) continue;
        if (part == "..") { ::close(current); return -1; }
        if (!descend(part, true)) return -1;
    }
    for (auto it = relative.begin(); it != relative.end(); ++it) {
        auto next = it; ++next;
        if (!descend(*it, next != relative.end())) return -1;
    }
    return current;
}

std::vector<EventRecordingLinkV1> AllLinks(RecordingCatalog& catalog) {
    std::vector<EventRecordingLinkV1> result;
    for (const auto status : {EventRecordingLinkStatus::Pending, EventRecordingLinkStatus::Complete,
                              EventRecordingLinkStatus::Partial, EventRecordingLinkStatus::Failed}) {
        for (auto& link : catalog.ListEventLinks(status)) result.push_back(std::move(link));
    }
    return result;
}

std::filesystem::path RelativeLocator(const std::filesystem::path& root,
                                      const std::string& locator) {
    if (root.empty() || locator.empty() || locator.find('\0') != std::string::npos) return {};
    std::error_code ec;
    const auto absolute_root = std::filesystem::absolute(root, ec);
    if (ec) return {};
    const auto absolute_path = std::filesystem::absolute(locator, ec);
    if (ec) return {};
    return absolute_path.lexically_relative(absolute_root);
}
}  // namespace

ResolvedRecordingMedia::~ResolvedRecordingMedia() {
    if (fd_ >= 0) {::close(fd_);memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,-1);}
    if (catalog_) catalog_->AdjustHoldCount(segment_id_, -1, nullptr);
}

RecordingCatalog::SourceBindingHandle RecordingReadService::RevalidatePreparedMedia(const ResolvedRecordingMedia& media,
    const RecordingSegmentV2& segment,const std::pair<std::filesystem::path,std::filesystem::path>& location,
    RecordingCatalog::SourceBindingReadContext* context,std::string* error) const {
    if(media.catalog_!=&catalog_||media.segment_id_!=segment.segment_id||!catalog_.ValidateMediaV2(segment,location))return {};
    const int current=OpenMedia(location.first,location.second);if(current<0)return {};
    struct stat held{},named{};
    const bool same=::fstat(media.fd_,&held)==0&&::fstat(current,&named)==0&&
        S_ISREG(named.st_mode)&&held.st_dev==named.st_dev&&held.st_ino==named.st_ino&&held.st_size==named.st_size;
    ::close(current);
    // 파일 접근 전/후 media 검증을 유지하고 후검증과 원본 binding을 한 cut에서 회수한다.
    return same?catalog_.ReadSourceBindingForMedia(segment,location,context,error):RecordingCatalog::SourceBindingHandle{};
}
bool RecordingReadService::RevalidateCompactPreparedMedia(const ResolvedRecordingMedia& media,
    const RecordingSegmentV2& segment,const std::pair<std::filesystem::path,std::filesystem::path>& location,
    RecordingCatalog::SourceBindingReadContext* context,std::string* error) const {
    if(media.catalog_!=&catalog_||media.segment_id_!=segment.segment_id||!catalog_.ValidateMediaV2(segment,location))return false;
    const int current=OpenMedia(location.first,location.second);if(current<0)return false;
    struct stat held{},named{};
    const bool same=::fstat(media.fd_,&held)==0&&::fstat(current,&named)==0&&S_ISREG(named.st_mode)&&
        held.st_dev==named.st_dev&&held.st_ino==named.st_ino&&held.st_size==named.st_size;
    ::close(current);
    return same&&catalog_.ValidateSourceBindingForMedia(segment,location,context,error);
}
bool RecordingReadService::RevalidateHeldMediaV2(const ResolvedRecordingMedia& media,
    const RecordingSegmentV2& segment,const std::pair<std::filesystem::path,std::filesystem::path>& location) const {
    if(media.catalog_!=&catalog_||media.segment_id_!=segment.segment_id||!catalog_.ValidateMediaV2(segment,location))return false;
    const int current=OpenMedia(location.first,location.second);if(current<0)return false;
    struct stat held{},named{};
    const bool same=::fstat(media.fd_,&held)==0&&::fstat(current,&named)==0&&
        S_ISREG(named.st_mode)&&held.st_dev==named.st_dev&&held.st_ino==named.st_ino&&held.st_size==named.st_size;
    ::close(current);return same&&catalog_.ValidateMediaV2(segment,location);
}
std::unique_ptr<ResolvedRecordingMedia> RecordingReadService::ResolveOriginalMediaV2(
    const std::string& channel,const std::string& id,RecordingSegmentV2* output,
    std::pair<std::filesystem::path,std::filesystem::path>* output_location,std::string* acquisition_error,MediaInspectionOptions options) const try {
    if(acquisition_error)acquisition_error->clear();
    const auto expired=[&]{return std::chrono::steady_clock::now()>=options.deadline||(options.cancelled&&options.cancelled());};
    if(!output||!output_location||expired()||!ValidateOpaqueId(id,nullptr))return {};
    auto media=std::unique_ptr<ResolvedRecordingMedia>(new ResolvedRecordingMedia);
    // Allocate/copy before acquisition: after acquisition ownership installation cannot throw.
    media->segment_id_=id;
    RecordingSegmentV2 current;std::pair<std::filesystem::path,std::filesystem::path> location;
    if(!catalog_.AcquireMediaV2(channel,id,&current,&location,acquisition_error))return {};
    media->catalog_=&catalog_;
    media->fd_=OpenMedia(location.first,location.second);
    if(media->fd_>=0)memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,1);
    const auto inspected=InspectRecordingPhysicalMediaFd(media->fd_,{
        current.container,current.video_codecs,current.size_bytes,current.checksum_sha256,current.retention_class},options);
    if(inspected.state!=MediaInspectionState::Healthy||expired()||!catalog_.ValidateMediaV2(current,location))return {};
    media->size_bytes_=current.size_bytes;
    if(current.container=="mp4")media->content_type_="video/mp4";
    else if(current.container=="webm")media->content_type_="video/webm";
    else if(current.container=="mpegts"||current.container=="ts")media->content_type_="video/mp2t";
    else return {};
    *output=std::move(current);*output_location=std::move(location);
    return media;
} catch(const recording::RecordingRetainedReadError&){return {};}
  catch(const recording::RecordingResourceUnavailable&){return {};}
std::unique_ptr<ResolvedRecordingMedia> RecordingReadService::ResolveMedia(
    const std::string& channel_id, const std::string& segment_id, MediaInspectionOptions options) const {
    return ResolveMediaWithContext(channel_id,segment_id,nullptr,std::move(options));
}
std::unique_ptr<ResolvedRecordingMedia> RecordingReadService::ResolveMediaWithContext(
    const std::string& channel_id,const std::string& segment_id,RecordingCatalog::JobReadContext* context, MediaInspectionOptions options) const try {
    if(std::chrono::steady_clock::now()>=options.deadline||(options.cancelled&&options.cancelled()))return {};
    if (!ValidateOpaqueId(segment_id, nullptr)) return {};
    // 삭제 ID는 어떤 fallback/파생 경로로도 재생 가능해질 수 없다. 누적 삭제 이력에서
    // segment와 event-link 전수를 반복 조회하지 않고, 권위 있는 삭제 상태에서 먼저 닫는다.
    if (catalog_.IsDeletedSegmentId(segment_id)) return {};
    const auto segment = catalog_.FindSegmentById(segment_id);
    const auto segment_v2 = catalog_.FindSegmentV2ById(segment_id);
    const auto links = AllLinks(catalog_);
    const EventRecordingLinkV1* fallback = nullptr;
    const EventRecordingLinkV1* derived = nullptr;
    for (const auto& link : links) {
        if (link.fallback_evidence_id == segment_id) {
            // segment 스냅샷 뒤 tombstone 확인: 두 조회 사이 삭제 완료도 재사용하지 않는다.
            if (fallback || segment || segment_v2 || catalog_.IsDeletedSegmentId(segment_id)) return {};
            fallback = &link;
        }
        if (link.derived_segment_id == segment_id) {
            if (derived) return {};
            derived = &link;
        }
    }
    if(segment_v2) {
        if(segment||derived||fallback||segment_v2->channel_id!=channel_id)return {};
        auto media=std::unique_ptr<ResolvedRecordingMedia>(new ResolvedRecordingMedia);
        std::string error;
        RecordingSegmentV2 current;
        std::pair<std::filesystem::path,std::filesystem::path> location;
        if(!catalog_.AcquireMediaWithContext(channel_id,segment_id,&current,&location,&error,context))return {};
        media->catalog_=&catalog_;media->segment_id_=segment_id;
        media->fd_=OpenMedia(location.first,location.second);
    if(media->fd_>=0)memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,1);
        const auto inspected=InspectRecordingPhysicalMediaFd(media->fd_,{
            current.container,current.video_codecs,current.size_bytes,
            current.checksum_sha256,current.retention_class},options);
        if(inspected.state!=MediaInspectionState::Healthy||std::chrono::steady_clock::now()>=options.deadline||
            (options.cancelled&&options.cancelled())||!catalog_.ValidateMediaWithContext(current,location,context))return {};
        media->size_bytes_=current.size_bytes;
        if(current.container=="mp4")media->content_type_="video/mp4";
        else if(current.container=="webm")media->content_type_="video/webm";
        else if(current.container=="mpegts"||current.container=="ts")media->content_type_="video/mp2t";
        else return {};
        return media;
    }
    if (fallback) {
        if (derived || fallback->channel_id != channel_id || !fallback->fallback_media_locator) return {};
        auto manifest = std::unique_ptr<ResolvedRecordingMedia>(new ResolvedRecordingMedia);
        manifest->fd_ = OpenMedia(event_root_, RelativeLocator(event_root_, *fallback->fallback_media_locator));
    if(manifest->fd_>=0)memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,1);
        struct stat info {};
        if (manifest->fd_ < 0 || ::fstat(manifest->fd_, &info) != 0 || !S_ISREG(info.st_mode) ||
            info.st_size <= 0 || info.st_size > 65536) return {};
        std::string json(static_cast<std::size_t>(info.st_size), '\0');
        std::size_t offset = 0;
        while (offset < json.size()) {
            const auto n = ::pread(manifest->fd_, json.data() + offset, json.size() - offset,
                                   static_cast<off_t>(offset));
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) return {};
            offset += static_cast<std::size_t>(n);
        }
        ingress::StrictJsonObjectDocument doc, encoded;
        if (!ingress::ParseStrictJsonObjectDocument(json, &doc, nullptr) ||
            ingress::StrictJsonStringField(doc, "schema") != "media-server.va.event-clip-hook.v1" ||
            ingress::StrictJsonStringField(doc, "eventId") != fallback->event_id) return {};
        const auto raw_stream = ingress::StrictJsonStringField(doc, "streamId");
        const auto raw_channel = ingress::StrictJsonStringField(doc, "channelId");
        if (!raw_stream || !raw_channel) return {};
        if (IsBoundRecordingFallbackNamespace(*fallback->fallback_evidence_id)) {
            const auto expected = BoundRecordingFallbackId(fallback->event_id, fallback->link_id,
                fallback->source_id, fallback->channel_id, *raw_stream, *raw_channel);
            // 지원하지 않는 version/잘린 prefix/잘못된 hex도 legacy로 강등하지 않는다.
            if (expected.empty() || expected != *fallback->fallback_evidence_id) return {};
        } else if (*raw_stream != fallback->source_id || *raw_channel != channel_id) {
            return {};
        }
        const auto nested = ingress::StrictJsonObjectField(doc, "encodedClip");
        if (!nested || !ingress::ParseStrictJsonObjectDocument(*nested, &encoded, nullptr) ||
            ingress::StrictJsonStringField(encoded, "schema") != "media-server.encoded-event-clip-contract.v1" ||
            ingress::StrictJsonStringField(encoded, "status") != "completed" ||
            ingress::StrictJsonStringField(encoded, "format") != "webm" ||
            ingress::StrictJsonStringField(encoded, "contentType") != "video/webm") return {};
        const auto codec = ingress::StrictJsonStringField(encoded, "codec");
        const auto path = ingress::StrictJsonStringField(encoded, "mediaPath");
        const auto* size = encoded.Find("byteSize");
        if (!path || (codec != "vp8" && codec != "vp9") || !size ||
            size->type != ingress::StrictJsonType::Number) return {};
        std::uint64_t bytes = 0;
        const auto parsed = std::from_chars(size->raw.data(), size->raw.data() + size->raw.size(), bytes);
        if (parsed.ec != std::errc{} || parsed.ptr != size->raw.data() + size->raw.size() || bytes == 0) return {};
        auto media = std::unique_ptr<ResolvedRecordingMedia>(new ResolvedRecordingMedia);
        media->fd_ = OpenMedia(event_root_, RelativeLocator(event_root_, *path));
    if(media->fd_>=0)memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,1);
        if (media->fd_ < 0 || ::fstat(media->fd_, &info) != 0 || !S_ISREG(info.st_mode) ||
            info.st_size <= 0 || static_cast<std::uint64_t>(info.st_size) != bytes) return {};
        media->size_bytes_ = bytes;
        media->content_type_ = "video/webm";
        return media;
    }
    if (!segment || segment->channel_id != channel_id || !IsPlayable(segment->lifecycle)) return {};
    if (segment->retention_class == RecordingRetentionClass::Event &&
        (!derived || derived->channel_id != channel_id || derived->source_id != segment->source_id ||
         !derived->derived_actual_range || derived->derived_actual_range->start_ms != segment->start.utc_ms ||
         derived->derived_actual_range->end_ms != segment->end.utc_ms ||
         (derived->status != EventRecordingLinkStatus::Complete &&
          derived->status != EventRecordingLinkStatus::Partial))) return {};
    auto media = std::unique_ptr<ResolvedRecordingMedia>(new ResolvedRecordingMedia);
    // AdjustHoldCount는 finalized 판정과 증가를 RequestDeletion과 같은 mutex에서 처리한다.
    if (!catalog_.AdjustHoldCount(segment_id, 1, nullptr)) return {};
    media->catalog_ = &catalog_;
    media->segment_id_ = segment_id;
    const auto location = catalog_.FindSegmentMediaLocation(segment_id);
    if (!location) return {};
    media->fd_ = OpenMedia(location->first, location->second);
    if(media->fd_>=0)memory_diagnostic::Add(memory_diagnostic::ResolvedMediaFDs,1);
    struct stat info {};
    if (media->fd_ < 0 || ::fstat(media->fd_, &info) != 0 || !S_ISREG(info.st_mode) ||
        info.st_size <= 0 || static_cast<std::uint64_t>(info.st_size) != segment->size_bytes) return {};
    if (segment->container == "mp4") media->content_type_ = "video/mp4";
    else if (segment->container == "webm") media->content_type_ = "video/webm";
    else if (segment->container == "mpegts" || segment->container == "ts") media->content_type_ = "video/mp2t";
    else return {};
    media->size_bytes_ = segment->size_bytes;
    return media;
} catch(const recording::RecordingRetainedReadError&){return {};}
  catch(const recording::RecordingResourceUnavailable&){return {};}

std::uint64_t RecordingReadService::TracePreparationStarted() noexcept {return completion::Now();}
void RecordingReadService::TracePreparationCompleted(const char* reference,std::uint64_t started,
    std::uint64_t prepared,std::uint64_t reused,std::uint64_t peak_bytes) noexcept {
    completion::Emit(completion::Event::Media,started,completion::Now(),reference,{},prepared,reused,peak_bytes);
}
bool RecordingReadService::QueryTimeline(const RecordingTimelineQuery& query,
                                         RecordingTimelineResult* result,
                                         std::string* error) const {
    return QueryTimelineImpl(query,result,error,1000);
}
bool RecordingReadService::QuerySearchTimeline(const std::string& channel,std::int64_t start,std::int64_t end,
    RecordingTimelineResult* output,std::string* error) const {
    if(!output){if(error)*error="search-invalid-output";return false;}
    RecordingTimelineResult result;
    if(!QueryTimelineImpl({channel,start,end,0,100000,false},&result,error,100000))return false;
    if(result.items.size()!=result.total||result.unplaced_items.size()!=result.unplaced_total) {
        if(error)*error="search-playback-projection-incomplete";
        return false;
    }
    *output=std::move(result);return true;
}
bool RecordingReadService::QuerySearchEventTimeline(const std::string& channel,std::int64_t start,std::int64_t end,
    RecordingTimelineResult* output,std::string* error) const {
    if(!output){if(error)*error="search-invalid-output";return false;}
    RecordingTimelineResult result;
    if(!QueryTimelineImpl({channel,start,end,0,100000,false},&result,error,100000,true))return false;
    if(result.items.size()!=result.total||result.unplaced_items.size()!=result.unplaced_total) {
        if(error)*error="search-playback-projection-incomplete";
        return false;
    }
    *output=std::move(result);return true;
}
bool RecordingReadService::QueryTimelineImpl(const RecordingTimelineQuery& query,
    RecordingTimelineResult* result,std::string* error,std::size_t max_limit,bool event_candidates_only) const {
    recording::latency::WorkScope holder_work_scope(recording::latency::Work::Structured);
    recording::latency::Scope latency_scope(recording::latency::Operation::Query,recording::latency::Source::Read,__LINE__,true);
    if (!result) {
        if (error) *error = "timeline result is required";
        return false;
    }
    *result = {};
    // channel ID는 opaque media ID가 아니다. 기존 숫자형 채널 식별자를 유지한다.
    if (query.channel_id.empty() || query.channel_id.size() > 256 ||
        query.channel_id.find('\0') != std::string::npos || query.start_ms < 0 ||
        query.end_ms <= query.start_ms || query.limit == 0 || query.limit > max_limit) {
        if (error) *error = "invalid timeline query";
        return false;
    }
    RecordingCatalog::JobReadContext context;
    if(!catalog_.SnapshotTimelineWithContext(query,result,error,&context,event_candidates_only))return false;
    if(result->v2_projection)return FinishTimelineWithContext(query,result,error,&context);
    const auto segments = catalog_.QuerySegments(query.channel_id, query.start_ms, query.end_ms);
    std::vector<EventRecordingLinkV1> links;
    for (auto& link : AllLinks(catalog_))
        if (link.channel_id == query.channel_id) links.push_back(std::move(link));
    for (const auto& segment : segments) {
        RecordingTimelineItem item;
        item.segment_id = segment.segment_id;
        item.channel_id = segment.channel_id;
        const bool event = segment.retention_class == RecordingRetentionClass::Event;
        item.kind = event ? "event" : "continuous";
        item.display_priority = event ? 200 : 100;
        item.start_ms = segment.start.utc_ms;
        item.end_ms = segment.end.utc_ms;
        item.actual_range = UtcRangeV1{item.start_ms, item.end_ms};
        item.completeness = IsPlayable(segment.lifecycle) ? "complete" : "missing";
        const auto resolved = ResolveMedia(query.channel_id, segment.segment_id);
        item.playable = static_cast<bool>(resolved);
        if (resolved) item.content_type = resolved->content_type();
        if (event) {
            const EventRecordingLinkV1* binding = nullptr;
            bool ambiguous = false;
            for (const auto& link : links) {
                if (link.derived_segment_id != segment.segment_id) continue;
                if (binding) { ambiguous = true; break; }
                binding = &link;
            }
            if (!binding || ambiguous || binding->source_id != segment.source_id ||
                !binding->derived_actual_range ||
                binding->derived_actual_range->start_ms != segment.start.utc_ms ||
                binding->derived_actual_range->end_ms != segment.end.utc_ms) {
                item.playable = false;
                item.completeness = "missing";
            } else {
                item.event_id = binding->event_id;
                item.requested_range = binding->requested_range;
                item.completeness = binding->status == EventRecordingLinkStatus::Complete ? "complete" :
                    binding->status == EventRecordingLinkStatus::Partial ? "partial" : "missing";
                if (binding->status != EventRecordingLinkStatus::Complete &&
                    binding->status != EventRecordingLinkStatus::Partial) item.playable = false;
            }
        } else {
            for (const auto& link : links) {
                if (!link.requested_range) continue;
                for (const auto& overlap : link.ordered_overlaps) {
                    if (overlap.segment_id == segment.segment_id &&
                        HalfOpenRangesOverlap(overlap.range.start_ms, overlap.range.end_ms,
                                              query.start_ms, query.end_ms)) {
                        item.superseded_by_event_ids.push_back(link.event_id);
                    }
                }
            }
            auto& ids = item.superseded_by_event_ids;
            std::sort(ids.begin(), ids.end());
            ids.erase(std::unique(ids.begin(), ids.end()), ids.end());
        }
        if (item.playable) item.playback_url = "/ops/api/recordings/media/" + item.segment_id;
        result->items.push_back(std::move(item));
    }
    for (const auto& link : links) {
        if (!link.fallback_evidence_id || !link.requested_range ||
            !HalfOpenRangesOverlap(link.requested_range->start_ms, link.requested_range->end_ms,
                                   query.start_ms, query.end_ms)) continue;
        if (link.derived_segment_id && ResolveMedia(query.channel_id, *link.derived_segment_id)) continue;
        RecordingTimelineItem item;
        item.segment_id = *link.fallback_evidence_id;
        item.channel_id = query.channel_id;
        item.kind = "event";
        item.display_priority = 200;
        item.start_ms = link.requested_range->start_ms;
        item.end_ms = link.requested_range->end_ms;
        item.requested_range = link.requested_range;
        item.event_id = link.event_id;
        item.range_basis = "requested-fallback";
        const auto resolved = ResolveMedia(query.channel_id, item.segment_id);
        item.playable = static_cast<bool>(resolved);
        if (resolved) item.content_type = resolved->content_type();
        // fallback frame buffer 영상의 전체 요청 구간 충족 여부는 아직 보장하지 않는다.
        item.completeness = item.playable ? "partial" : "missing";
        if (item.playable) item.playback_url = "/ops/api/recordings/media/" + item.segment_id;
        result->items.push_back(std::move(item));
    }
    std::sort(result->items.begin(), result->items.end(), [](const auto& a, const auto& b) {
        if (a.start_ms != b.start_ms) return a.start_ms > b.start_ms;
        if (a.display_priority != b.display_priority) return a.display_priority > b.display_priority;
        return a.segment_id < b.segment_id;
    });
    result->total = result->items.size();
    const auto begin = std::min(query.offset, result->total);
    const auto count = std::min(query.limit, result->total - begin);
    std::vector<RecordingTimelineItem> page;
    page.reserve(count);
    for (std::size_t i = 0; i < count; ++i) page.push_back(std::move(result->items[begin + i]));
    result->items = std::move(page);
    if (error) error->clear();
    return true;
}
bool RecordingReadService::FinishTimelineV2(const RecordingTimelineQuery& query,RecordingTimelineResult* result,std::string* error) const {
    return FinishTimelineWithContext(query,result,error,nullptr);
}
bool RecordingReadService::FinishTimelineWithContext(const RecordingTimelineQuery& query,RecordingTimelineResult* result,std::string* error,RecordingCatalog::JobReadContext* context) const {
    recording::latency::Scope latency_scope(recording::latency::Operation::Finish,recording::latency::Source::Projection,__LINE__,true);
    try {
        std::unordered_map<std::string,std::pair<bool,std::string>> media;
        auto phase_started=completion::Now();
        const auto input_rows=result->items.size()+result->unplaced_items.size();
        auto available=[&](RecordingTimelineItem& item){
            if(item.segment_id.empty())return;
            if(item.catalog_state!="finalized"||
               (item.kind=="event"&&(item.job_state!="complete"||item.unavailable_reason=="output-binding-unavailable")))return;
            auto found=media.find(item.segment_id);
            if(found==media.end()){
                auto fd=ResolveMediaWithContext(query.channel_id,item.segment_id,context);
                found=media.emplace(item.segment_id,std::make_pair(bool(fd),fd?fd->content_type():"")).first;
            }
            item.playable=found->second.first;item.content_type=found->second.second;
            if(item.playable){item.playback_url="/ops/api/recordings/media/"+item.segment_id;
                if(item.unavailable_reason=="media-not-checked")item.unavailable_reason.clear();}
            else if(item.unavailable_reason=="media-not-checked")item.unavailable_reason="media-unavailable";
        };
        for(auto& row:result->items)available(row);
        for(auto& row:result->unplaced_items)available(row);
        auto phase_ended=completion::Now();
        completion::Emit(completion::Event::Media,phase_started,phase_ended,{},{},input_rows,media.size());
        phase_started=phase_ended;
        std::size_t bytes=0;
        for(const auto& row:result->items)bytes+=Bytes(row);
        for(const auto& row:result->unplaced_items)bytes+=Bytes(row);
        if(bytes>kBytes)throw std::runtime_error("timeline-snapshot-limit");
        for(auto& original:result->items){
            if(original.kind!="continuous")continue;
            bool full=!original.coverage.empty();
            for(const auto& base:original.coverage){std::vector<Interval> covered;
                for(const auto& event:result->items){if(event.kind!="event"||!event.playable)continue;
                    for(const auto& proof:event.coverage){
                        if(base.source_id!=proof.source_id||base.store_id!=proof.store_id||base.epoch_id!=proof.epoch_id||base.segment_id!=proof.segment_id)continue;
                        const auto a=std::max(base.start_ns,proof.start_ns),b=std::min(base.end_ns,proof.end_ns);if(a>=b)continue;
                        covered.emplace_back(a,b);
                        // overlap는 원본 media-ns 축으로 명시한다. UTC 차이를 파일 seek로 오인하지 않는다.
                        original.event_overlaps.push_back({event.item_id,a,b});
                        if(!event.event_id.empty())original.superseded_by_event_ids.push_back(event.event_id);
                        bytes+=2*(sizeof(RecordingTimelineOverlap)+event.item_id.size()+sizeof(std::string)+event.event_id.size()+sizeof(Interval));
                        if(bytes>kBytes)throw std::runtime_error("timeline-overlap-limit");
                    }
                }
                const auto unioned=Union(std::move(covered));full=full&&unioned.size()==1&&unioned.front().first==base.start_ns&&unioned.front().second==base.end_ns;
            }
            original.hide_by_event=full;
            auto& ids=original.superseded_by_event_ids;std::sort(ids.begin(),ids.end());ids.erase(std::unique(ids.begin(),ids.end()),ids.end());
            std::sort(original.event_overlaps.begin(),original.event_overlaps.end(),[](const auto& a,const auto& b){return std::tie(a.item_id,a.start_ns,a.end_ns)<std::tie(b.item_id,b.start_ns,b.end_ns);});
        }
        phase_ended=completion::Now();
        completion::Emit(completion::Event::Overlap,phase_started,phase_ended,{},{},result->items.size());
        phase_started=phase_ended;
        std::sort(result->items.begin(),result->items.end(),[](const auto& a,const auto& b){
            if(a.utc_start_ns!=b.utc_start_ns)return a.utc_start_ns>b.utc_start_ns;
            if(a.display_priority!=b.display_priority)return a.display_priority>b.display_priority;
            return a.item_id<b.item_id;
        });
        phase_ended=completion::Now();
        completion::Emit(completion::Event::Sort,phase_started,phase_ended,{},{},result->items.size());
        phase_started=phase_ended;
        const auto begin=std::min(query.offset,result->items.size());
        const auto count=std::min(query.limit,result->items.size()-begin);
        std::vector<RecordingTimelineItem> page;page.reserve(count);
        for(std::size_t i=0;i<count;++i)page.push_back(std::move(result->items[begin+i]));
        result->items=std::move(page);
        completion::Emit(completion::Event::Page,phase_started,completion::Now(),{},{},result->items.size(),query.offset,query.limit);
        if(error)error->clear();
        return true;
    }catch(const std::exception&){*result={};if(error)*error="timeline-projection-unavailable";return false;}
}
}  // namespace recording
