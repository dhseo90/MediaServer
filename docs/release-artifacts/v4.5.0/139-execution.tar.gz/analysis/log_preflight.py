import tarfile,json,collections,math,pathlib
root=pathlib.Path(__file__).resolve().parent
r137=tarfile.open('docs/release-artifacts/v4.5.0/137-execution.tar.gz');raw=r137.extractfile('observer/server-1.sanitized.log').read();lines=raw.splitlines(keepends=True)
r138=tarfile.open('docs/release-artifacts/v4.5.0/138-execution.tar.gz');data=r138.extractfile('mac-final/recording_memory_ticket_smoke.log').read()
rows=[json.loads(l.split(b' ',1)[1]) for l in lines if l.startswith(b'[memory-attribution] ')]
witness=[json.loads(l.split(b' ',1)[1])['ticketWitness'] for l in data.splitlines() if l.startswith(b'[memory-attribution] ')]
length=lambda r:len(('[memory-attribution] '+json.dumps(r,separators=(',',':'))+'\n').encode())
w=max(witness,key=lambda w:len(json.dumps(w,separators=(',',':'))))
max_augmented=max(length({**r,'ticketWitness':w}) for r in rows)
# This is a sizing scenario, not measured simultaneous owners or an injected workload.
wide=json.loads(json.dumps(w));wide['sites']=[[670000000,1000,1000000,1000000,670000000,2000000000000000,670000000,1000,132808915,2000000000000000,2000000000000000,2000000000000000,1000000] for _ in range(15)]
wide_max=max(length({**r,'ticketWitness':wide}) for r in rows)
# Mode differences proven by source guards: subcost-only timeline/admission/capture + holder.
removed=collections.Counter();kept=collections.defaultdict(list)
for line in lines:
 key=line.split(b' ',1)[0].decode(errors='replace')
 if key=='[memory-attribution]':continue
 exclude=key in ['[R119-admission]','[R131-periodic]','[search-capture-cost]','[catalog-subcost-basis]'] or key.startswith('[catalog-holder')
 if key=='[recording-completion]':exclude=json.loads(line.split(b' ',1)[1])['event']==15
 if exclude:removed[key]+=len(line)
 else:kept[key].append(len(line))
# Overestimates disabled visual subcost fields by retaining their old bytes; bounded first128/64 costs do not scale.
fixed={'[search-request-cost]':128,'[recording-latency]':64}
project={}
for k,sz in kept.items():
 if k in fixed:project[k]=fixed[k]*max(sz)
 else:project[k]=math.ceil(sum(sz)*2880/600)
forecast=sum(project.values())+580*max_augmented
wide_forecast=sum(project.values())+580*wide_max
out={'basis':'R137 actual600 log + actual R138 largest witness, state-only disabled source guards; estimate not45execution or simultaneous vector','observed137Bytes':len(raw),'actual137MemoryRows':len(rows),'actual137OwnerMaxBytes':max(len(l) for l in lines if l.startswith(b'[memory-attribution] ')),'actual138MaxWitnessBytes':len(json.dumps(w,separators=(',',':'))),'combinedRepresentativeMaxBytes':max_augmented,'numericWidthScenarioMaxBytes':wide_max,'maxRowsFor2880Seconds':580,'recordCap':16384,'collectorSampleCap':1600,'projectedOtherLogBytes':sum(project.values()),'projectedByPrefix':project,'disabledByModeObservedBytes':dict(removed),'projectedTotalBytes':forecast,'numericWidthScenarioTotalBytes':wide_forecast,'capBytes':4194304,'representativeMarginBytes':4194304-forecast,'widthScenarioMarginBytes':4194304-wide_forecast,'completionProjectedRows':math.ceil(len(kept['[recording-completion]'])*4.8),'completionCapRows':4095,'notBound':'Future model count/number widths/errors are not bounded by observed size. 580*16KiB exceeds4MiB; existing caps stop/fail, no silent truncation. Safe cap failure is verified;45min collection eligibility remains unconfirmed/HOLD.'}
(root/'log-budget.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
