# Passive bounded read of one existing archived log; writes no source/product data.
import tarfile,json,hashlib,collections
with tarfile.open('docs/release-artifacts/v4.5.0/137-execution.tar.gz') as t:
 m=t.getmember('observer/server-1.sanitized.log')
 assert m.isfile() and m.size<4194304
 raw=t.extractfile(m).read()
rows=[(l,json.loads(l.split(b'] ',1)[1])) for l in raw.splitlines(keepends=True) if l.startswith(b'[memory-attribution] ')]
enc=lambda x:json.dumps(x,separators=(',',':')).encode()
repeat=new=events=arrays=prev=0;deltas=[];gaps=[]
for i,(line,v) in enumerate(rows):
 end=v['totals'][8];start=end-len(v['recentEvents']);deltas.append(end-prev)
 if i and end-prev>32:gaps.append({'row':i,'previous':prev,'end':end,'delta':end-prev})
 for n,e in enumerate(v['recentEvents'],start):
  b=len(enc(e));events+=b
  if i and n<prev:repeat+=b
  else:new+=b
 arrays+=len(enc(v['models']))+len(enc(v['snapshotPools']));prev=end
print(json.dumps({'inputMember':m.name,'inputBytes':len(raw),'inputSHA256':hashlib.sha256(raw).hexdigest(),'rows':len(rows),'wireBytes':sum(len(l) for l,v in rows),'eventValueBytesExcludingArraySeparators':events,'repeatedEventValueBytes':repeat,'newObservedEventValueBytes':new,'modelPoolValueBytes':arrays,'eventDeltas':dict(collections.Counter(deltas)),'gaps':gaps,'maxDelta':max(deltas)},indent=2))
