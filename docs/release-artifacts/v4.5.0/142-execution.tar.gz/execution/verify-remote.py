import subprocess,json,base64,hashlib,pathlib,sys
ref=sys.argv[1];paths=sys.argv[2:];out=[]
actual=subprocess.check_output(['git','ls-remote','origin','refs/heads/v4.5.0'],text=True).split()[0];assert actual==ref,(actual,ref)
for p in paths:
 v=json.loads(subprocess.check_output(['gh','api','repos/dhseo90/MediaServer/contents/'+p+'?ref='+ref],text=True));assert v['encoding']=='base64'
 remote=base64.b64decode(v['content']);local=pathlib.Path(p).read_bytes();assert remote==local,p
 out.append({'path':p,'bytes':len(remote),'sha256':hashlib.sha256(remote).hexdigest(),'remoteByteMatch':True})
print(json.dumps({'sha':actual,'files':out},indent=2))
