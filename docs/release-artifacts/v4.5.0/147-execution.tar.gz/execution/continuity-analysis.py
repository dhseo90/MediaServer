import pathlib,json,zlib,base64,collections
r=pathlib.Path('$RUN_PARENT');o=next((r/'state45').glob('media-server-current-observer-*'));rs={}
for p in (o/'recordings').glob('active-*.jsonl'):
 for l in p.read_text().splitlines():
  x=json.loads(l)
  if x.get('codec')=='zlib-base64':
   b=zlib.decompress(base64.b64decode(x['data']));assert len(b)==x['length'] and zlib.crc32(b)==x['crc32'];x=json.loads(b)
  rs[x['mutationId']]=x
bs=[x['payload'] for x in rs.values() if x.get('mutationType')=='segment_v2_bound_finalized' and x['payload']['segment']['channel_id'] in ['9101','9201']]
groups=collections.defaultdict(list);inside=[]
for p in bs:
 b=p['sourceBinding'];a=b['samples'];inside.extend({'segment':b['segment_id'],'before':x['ordinal'],'after':y['ordinal']} for x,y in zip(a,a[1:]) if y['ordinal']!=x['ordinal']+1);groups[(b['channel_id'],b['source_generation'])].append(p)
between=[];pairs=0
for key,ls in groups.items():
 ls.sort(key=lambda x:x['segment']['order_sequence'])
 for x,y in zip(ls,ls[1:]):
  x=x['sourceBinding'];y=y['sourceBinding'];pairs+=1
  if y['samples'][0]['ordinal']!=x['samples'][-1]['ordinal']+1:between.append({'channel':key[0],'generation':key[1],'before':x['segment_id'],'after':y['segment_id']})
v={'scope':'post-stop read-only CRC/length-checked active journal sourceBinding samples and matched media hashes; not native closed-journal/current authority gate or upstream packet proof','files':len(bs),'perChannel':dict(collections.Counter(x['segment']['channel_id'] for x in bs)),'samples':sum(len(x['sourceBinding']['samples']) for x in bs),'internalOrdinalGaps':inside,'sameGenerationPairs':pairs,'betweenOrdinalGaps':between,'generationGroups':len(groups),'sort':'segment.order_sequence within channel/source_generation; generation_order identifies generation, not segment order','lastStopBoundary':'unrecorded upstream tail unknown','deleted':sum(x.get('mutationType') in ['deletion_completed','segment_v2_deleted'] for x in rs.values()),'draftCorrection':'Initial read-only analysis sorted equal generation_order across journal files, produced reverse-order apparent gap; corrected with actual segment.order_sequence. No product failure or gate changed.'}
(r/'continuity.json').write_text(json.dumps(v,indent=2)+'\n')
for p in [r/'analysis.json',pathlib.Path('docs/release-artifacts/v4.5.0/147-validation.json')]:
 d=json.loads(p.read_text());d['continuity']=v;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(v))
