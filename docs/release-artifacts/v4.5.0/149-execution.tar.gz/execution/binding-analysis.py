import pathlib,json,zlib,base64,collections,hashlib,os
root=pathlib.Path(__file__).parent;obs=next((root/'state45').glob('media-server-current-observer-*'));rs={};files=[]
for p in sorted((obs/'recordings').glob('active-*.jsonl')):
 data=p.read_bytes();assert not data or data.endswith(b'\n');files.append({'path':p.relative_to(obs).as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 for line in data.splitlines():
  x=json.loads(line)
  if x.get('codec')=='zlib-base64':
   b=zlib.decompress(base64.b64decode(x['data'],validate=True));assert len(b)==x['length'] and zlib.crc32(b)==x['crc32'];x=json.loads(b)
  k=x['mutationId'];assert k not in rs or rs[k]==x;rs[k]=x
bounds=[x['payload'] for x in rs.values() if x.get('mutationType')=='segment_v2_bound_finalized'];checks=[];groups=collections.defaultdict(list);inside=[]
for p in bounds:
 s=p['segment'];file=obs/'recordings'/s['channel_id']/(s['segment_id']+'.mp4');data=file.read_bytes();assert len(data)==s['size_bytes'] and hashlib.sha256(data).hexdigest()==s['checksum_sha256']
 checks.append({'channel':s['channel_id'],'segment':s['segment_id'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'source':s['source_id'],'order':s['order_sequence']})
 if s['channel_id'] not in ['9101','9201']:continue
 b=p['sourceBinding'];samples=b['samples'];inside.extend({'segment':b['segment_id'],'before':a['ordinal'],'after':z['ordinal']} for a,z in zip(samples,samples[1:]) if z['ordinal']!=a['ordinal']+1);groups[(b['channel_id'],b['source_generation'])].append(p)
between=[];pairs=0
for key,ls in groups.items():
 ls.sort(key=lambda p:p['segment']['order_sequence'])
 for a,z in zip(ls,ls[1:]):
  a=a['sourceBinding'];z=z['sourceBinding'];pairs+=1
  if z['samples'][0]['ordinal']!=a['samples'][-1]['ordinal']+1:between.append({'channel':key[0],'generation':key[1],'before':a['segment_id'],'after':z['segment_id'],'lastOrdinal':a['samples'][-1]['ordinal'],'nextOrdinal':z['samples'][0]['ordinal']})
summary={'scope':'post-stop read-only CRC/length checked active journals and every bound file hash; not native closed-journal or current catalog reOpen gate','journalFiles':files,'mutationTypes':dict(collections.Counter(x['mutationType'] for x in rs.values())),'filesChecked':len(checks),'allMatched':True,'perChannel':dict(collections.Counter(x['channel'] for x in checks)),'bytesByChannel':{k:sum(x['bytes'] for x in checks if x['channel']==k) for k in set(x['channel'] for x in checks)},'sourceBindingSamples':sum(len(x['sourceBinding']['samples']) for v in groups.values() for x in v),'internalOrdinalGaps':inside,'sameGenerationPairs':pairs,'betweenOrdinalGaps':between,'generationGroups':len(groups),'unknown':'upstream input/queue/callback/drop totals and final source tail not exposed; no lossless claim'}
(root/'file-binding.json').write_text(json.dumps({'summary':summary,'files':checks},indent=2)+'\n')
a=json.loads((root/'analysis.json').read_text());a['fileBinding']=summary
r=[json.loads(l.split('] ',1)[1]) for l in (root/'state45/run.log').read_text().splitlines() if l.startswith('[sample-step] ')]
a['sampleSteps']=r
(root/'analysis.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['journalFiles','betweenOrdinalGaps']},indent=2));print('betweenGaps',len(between))
