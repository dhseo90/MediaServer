import pathlib,json,hashlib,tarfile,io,re,os,socket,stat,subprocess
root=pathlib.Path(__file__).parent;repo=pathlib.Path.cwd();run=root/'state45';obs=next(run.glob('media-server-current-observer-*'))
sha=lambda b:hashlib.sha256(b).hexdigest()
helper=[]
for p in [obs/'normalize',obs/'process-metrics',obs/'review-seed',*sorted((obs/'input').glob('*.mp4'))]:
 b=p.read_bytes();helper.append({'path':p.relative_to(obs).as_posix(),'bytes':len(b),'sha256':sha(b),'archivedBytes':False})
(root/'input-helper-binding.json').write_text(json.dumps(helper,indent=2)+'\n')
sourcepaths=['scripts/internal/run_v450_recording_a_mixed.py','scripts/internal/verify_v450_recording_a_mixed.sh','scripts/internal/recording_process_metrics.cpp','scripts/internal/recording_foundation_observer.mjs','scripts/internal/v450_recording_a_mixed.mjs','scripts/internal/v450_recording_a_load.mjs','scripts/internal/recording_current_observer.mjs','scripts/internal/recording_completion_collection.mjs','scripts/internal/recording_completion_trace.mjs','scripts/internal/recording_memory_attribution.mjs','scripts/internal/recording_resource_trace.mjs','scripts/internal/recording_longrun_progress.mjs','include/recording/recording_memory_reservation.h','include/recording/recording_memory_diagnostic_output.h']
entries=[]
for name in ['preflight.json','analysis.json','file-binding.json','analyze.py','binding-analysis.py','input-helper-binding.json','launcher-output.log','preserve.py']:
 entries.append((root/name,'execution/'+name))
for name in ['execution.json','run.log','owned-recovery-groups.jsonl']:entries.append((run/name,'run/'+name))
for folder in ['artifacts','receipts']:
 for p in sorted((run/folder).rglob('*')):
  if p.is_file() and not p.is_symlink():entries.append((p,folder+'/'+p.relative_to(run/folder).as_posix()))
entries.append((obs/'server-1.private.log','observer/server-1.sanitized.log'))
entries.append((obs/'catalog-instrumented.cpp','source/catalog-instrumented.cpp'))
for p in sorted((obs/'recordings').iterdir()):
 if p.name.startswith('active-') and p.suffix=='.jsonl' or p.name=='recording-generation.json':entries.append((p,'observer/recordings/'+p.name))
for name in sourcepaths:entries.append((repo/name,'source/'+name))
# No credentials/state store, SDK/models, compiled binaries, raw media, SQLite, cache or duplicate generation snapshots.
manifest={'schema':'media-server.r149.archive.v1','baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'needed sanitized outputs, active journal source bindings and analysis/source; not a full reOpen/reproduction store','excluded':['auth/state files','user settings/private backups','models/SDK/libraries','compiled binary bytes (hashes only)','media bytes (file hash map only)','SQLite/persisted cache','duplicate snapshot/identity/evidence history files'],'files':[]}
replacements=[(str(root),'$RUN_PARENT'),(str(repo),'$REPO'),(str(pathlib.Path.home()),'$HOME'),(socket.gethostname(),'$HOST')]
archive=repo/'docs/release-artifacts/v4.5.0/149-execution.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tf:
 for p,name in entries:
  s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid();raw=p.read_bytes();text=raw.decode('utf-8');
  for old,new in replacements:text=text.replace(old,new)
  text=re.sub(r'(?:rtsp|http|https)://127\.0\.0\.1[^\s"<>]*','$LOCAL_URI',text)
  text=re.sub(r'$TMP_PATH"<>]+','$TMP_PATH',text)
  if re.search(r'"(?:passwordHash|tokenHash|password|cookie|authorization)"\s*:',text,re.I):raise RuntimeError('sensitive key in '+name)
  data=text.encode();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0;tf.addfile(info,io.BytesIO(data))
  manifest['files'].append({'path':name,'originalBytes':len(raw),'originalSha256':sha(raw),'storedBytes':len(data),'storedSha256':sha(data),'sanitized':data!=raw})
 data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);info.mode=0o600;tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tf:
 for row in manifest['files']:
  b=tf.extractfile(row['path']).read();assert len(b)==row['storedBytes'] and sha(b)==row['storedSha256']
b=archive.read_bytes();result={'path':str(archive.relative_to(repo)),'bytes':len(b),'sha256':sha(b),'payloads':len(entries),'rawAndSanitizedSeparate':True,'exclusions':manifest['excluded'],'fullStore':False};(root/'archive.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
