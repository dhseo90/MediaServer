import fs from 'node:fs';
import path from 'node:path';
import {collectProcess} from '<REPO>/scripts/internal/recording_foundation_observer.mjs';
const root=path.dirname(new URL(import.meta.url).pathname);
fs.writeFileSync(path.join(root,'os-pair-started.json'),JSON.stringify({startedAt:new Date().toISOString(),order:['baseline','candidate'],callsEach:1}),{flag:'wx',mode:0o600});
const results=[];
for(const mode of ['baseline','candidate']){
 const binary=path.join(root,'os-'+mode),started=performance.now();let value=null,failure=null;
 try{value=await collectProcess(binary,process.pid);}catch(error){failure=error.collectorDiagnostic??{error:error.message};}
 const consumerMs=performance.now()-started;
 const trace=JSON.parse(fs.readFileSync(binary+'.trace.json','utf8'));
 const raw=fs.readFileSync(binary+'.native.json'),native=JSON.parse(raw);
 const result={mode,consumerMs,value,failure,trace,nativeStdoutBytes:raw.length};
 results.push(result);console.log(JSON.stringify(result));
 if(!trace.childExitedZero||trace.childError||raw.length>16384)throw Error('OS comparison setup/cleanup failure');
 if(!native.valid&&native.error!=='fd-observation-incomplete:capacity=0:closed=4')throw Error('unexpected native failure');
}
fs.writeFileSync(path.join(root,'os-pair.json'),JSON.stringify(results,null,2)+'\n',{flag:'wx',mode:0o600});
