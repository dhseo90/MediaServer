#include "recording/recording_contracts.h"
#include <fstream>
#include <iostream>
int main(int argc,char** argv){if(argc!=3)return 2;std::ifstream f(argv[1]);std::string s{std::istreambuf_iterator<char>(f),{}};recording::RecordingSourceBindingV1 b;std::string e;bool ok=recording::ParseRecordingSourceBindingV1(s,&b,&e);if(std::string(argv[2])=="reject"){std::cout<<"old-reader accepted="<<ok<<" reason="<<e<<'\n';return ok?1:0;}if(!ok||recording::SerializeRecordingSourceBindingV1(b)!=s)return 1;std::cout<<"old-reader exact roundtrip profile="<<b.file_evidence->profile<<'\n';}
