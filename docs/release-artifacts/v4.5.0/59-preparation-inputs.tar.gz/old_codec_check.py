import subprocess,pathlib
r=pathlib.Path(__file__).parent
for env,expected in [('host-export','accept'),('linux-export','reject')]:
 for i in range(5):
  cmd=[str(r/'old-codec'),str(r/f'{env}/compat/{i}.mp4.binding.json'),expected];p=subprocess.run(cmd);print('[exit]',i,env,p.returncode,flush=True);p.check_returncode()
