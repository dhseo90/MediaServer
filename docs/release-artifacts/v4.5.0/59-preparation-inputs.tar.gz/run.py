import subprocess,sys,time,json,pathlib,hashlib
r=pathlib.Path(__file__).parent
name=sys.argv[1]; cmd=sys.argv[2:]; start=time.time()
with (r/(name+'.log')).open('xb') as out:
 p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
b=(r/(name+'.log')).read_bytes()
x={'name':name,'command':cmd,'exit':p.returncode,'elapsedSeconds':time.time()-start,'logSha256':hashlib.sha256(b).hexdigest()}
with (r/'commands.jsonl').open('a') as f:f.write(json.dumps(x)+'\n')
print(json.dumps(x)); print(b[-12000:].decode(errors='replace'));sys.exit(p.returncode)
