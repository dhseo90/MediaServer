#include "/Users/dhseo/Workspace/mediaServer/src/recording/recording_file_evidence.cpp"
#include <iostream>
#include <dlfcn.h>
int main(){gst_init(nullptr,nullptr);guint a,b,c,d;gst_version(&a,&b,&c,&d);auto* profile=recording::CoreProfile(a,b,c,d);if(!profile)return 2;Dl_info info{};if(!dladdr(reinterpret_cast<void*>(&gst_version),&info))return 3;std::cout<<"core="<<a<<'.'<<b<<'.'<<c<<'.'<<d<<" path="<<info.dli_fname<<" profile="<<profile<<'\n';
GstElement* elements[2]={gst_element_factory_make("h264parse",nullptr),gst_element_factory_make("mp4mux",nullptr)};GstPlugin* plugins[2]{};const char* factories[2]{};
for(int i=0;i<2;++i){if(!elements[i])return 4;auto* f=gst_element_get_factory(elements[i]);factories[i]=gst_plugin_feature_get_name(GST_PLUGIN_FEATURE(f));plugins[i]=gst_plugin_feature_get_plugin(GST_PLUGIN_FEATURE(f));if(!plugins[i])return 5;std::cout<<"factory="<<factories[i]<<" plugin="<<gst_plugin_get_name(plugins[i])<<" version="<<gst_plugin_get_version(plugins[i])<<" path="<<gst_plugin_get_filename(plugins[i])<<'\n';}
const auto version=std::to_string(a)+"."+std::to_string(b)+"."+std::to_string(c);bool valid=recording::PluginProfile(version.c_str(),factories[0],gst_plugin_get_name(plugins[0]),gst_plugin_get_version(plugins[0]),factories[1],gst_plugin_get_name(plugins[1]),gst_plugin_get_version(plugins[1]));
for(int i=0;i<2;++i){gst_object_unref(plugins[i]);gst_object_unref(elements[i]);}return valid?0:6;}
