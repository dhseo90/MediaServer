import pathlib,json,hashlib,gzip,tarfile,subprocess,os
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');base=repo/'docs/release-artifacts/v4.5.0';scratch=pathlib.Path('/tmp/v450-rc60-hlgj_312');root=base/'test-acceptance-current-final'
summary=json.loads((root/'summary.json').read_text());run=pathlib.Path(summary['runDir']);assert run.parent==root/'runs' and run.name=='v390-test-acceptance-20261007084159-15681'
extra=[repo/p for p in summary['sourceProvenanceEnd']['unapprovedDirtyPaths']];assert len(extra)==12 and all(p.parent==base for p in extra)
files=sorted([p for p in root.rglob('*') if p.is_file()]+extra);assert all(not p.is_symlink() for p in files)
manifest={str(p.relative_to(base)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
archive=base/'60-acceptance-output.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(base)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 members=t.getmembers();assert len(members)==len(manifest)
 for m in members:
  assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
  b=t.extractfile(m).read();assert len(b)==manifest[m.name]['bytes'] and hashlib.sha256(b).hexdigest()==manifest[m.name]['sha256']
info={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'rawFiles':len(manifest),'rawBytes':sum(v['bytes'] for v in manifest.values()),'pathsRelativeTo':'docs/release-artifacts/v4.5.0','readback':'all members size/SHA256 match before removal','files':manifest}
with gzip.open(base/'60-acceptance-files.json.gz','wb') as f:f.write((json.dumps(info,ensure_ascii=False,indent=2)+'\n').encode())
tracked=set(subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0'))
cleanup=sorted([p for p in run.rglob('*') if p.is_file()]+extra)
assert all(str(p.relative_to(repo)) not in tracked and str(p.relative_to(base)) in manifest for p in cleanup)
for p in cleanup:
 assert not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==manifest[str(p.relative_to(base))]['sha256'];p.unlink()
for p in sorted([p for p in run.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):p.rmdir()
run.rmdir()
(scratch/'preservation.json').write_text(json.dumps({k:v for k,v in info.items() if k!='files'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in info.items() if k!='files'},ensure_ascii=False));print('owned unpacked new-run files removed after exact archive readback:',len(cleanup))
