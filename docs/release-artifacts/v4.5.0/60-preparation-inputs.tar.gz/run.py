import sys,subprocess,time,pathlib,json,hashlib,os
root=pathlib.Path(__file__).parent
name=sys.argv[1]; command=sys.argv[2:]
log=root/(name+'.log')
assert not log.exists(), str(log)
start=time.time()
env=os.environ.copy(); env['MEDIA_SERVER_SKIP_LOCAL_ENV']='1'
with log.open('wb') as out:
 p=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT,env=env)
b=log.read_bytes()
record={'name':name,'command':command,'exit':p.returncode,'elapsedSeconds':time.time()-start,'logSha256':hashlib.sha256(b).hexdigest(),'rawBytes':len(b)}
with (root/'commands.jsonl').open('a') as out: out.write(json.dumps(record)+'\n')
print(json.dumps(record),flush=True)
print(b.decode('utf-8',errors='replace')[-6500:],flush=True)
sys.exit(p.returncode)
