import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import crypto from 'node:crypto';
import {v450ReleaseCommands,withV450ArtifactOutput} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/v450_release_checks.mjs';
import {verifyReviewTestArtifacts} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/va_review_test_artifacts.mjs';
import {collectSourceProvenanceWithAllowedArtifacts} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/evidence_integrity_lib.mjs';
const rootDir='/Users/dhseo/Workspace/mediaServer',outputDir='/private/tmp/media-server-release61-u9l2g2bk/direct',runDir=path.join(outputDir,'runs','direct61');fs.mkdirSync(runDir,{recursive:true});
const source=fs.readFileSync(path.join(rootDir,'scripts/internal/verify_v390_test_acceptance_bundle.mjs'),'utf8');
const sourceProvenance=collectSourceProvenanceWithAllowedArtifacts(rootDir,outputDir);
const specs=v450ReleaseCommands().map(s=>withV450ArtifactOutput(s,{artifactRoot:outputDir,runDir})).filter(s=>s.env.MEDIA_SERVER_TEST_OUTPUT_DIR);
fs.writeFileSync(path.join(outputDir,'before.json'),JSON.stringify({sourceProvenance,specs,parentSourceSha256:crypto.createHash('sha256').update(source).digest('hex')},null,2));
const context=vm.createContext({fs,path,Date,Number,Promise,spawn,process,assert,rootDir,outputDir,runDir,sourceProvenance,stages:[],failedStage:'',failedCommand:'',verifyReviewTestArtifacts,collectSourceProvenanceWithAllowedArtifacts,
 commandText:s=>[s.file,...s.args].join(' '),makeStage:x=>x,tailLines:s=>s.split(/\r?\n/).filter(Boolean).slice(-40),writeJson:(p,x)=>fs.writeFileSync(p,JSON.stringify(x,null,2)),});
vm.runInContext(source.slice(source.indexOf('async function runCommandListStage('),source.indexOf('function recordFailure(')),context);
await context.runCommandListStage('feature-gates',specs);if(!context.failedStage)context.verifyFeatureSourceBinding();
const after=collectSourceProvenanceWithAllowedArtifacts(rootDir,outputDir),summary={sourceProvenance,after,sourceUnchanged:after.sourcePatchSha256===sourceProvenance.sourcePatchSha256,stages:context.stages,failedStage:context.failedStage};
fs.writeFileSync(path.join(outputDir,'summary.json'),JSON.stringify(summary,null,2));console.log(JSON.stringify(summary));process.exitCode=context.failedStage||!summary.sourceUnchanged?1:0;
