#!/bin/bash
set -euo pipefail
root=/private/tmp/media-server-release61-u9l2g2bk
export MEDIA_SERVER_GST_CACHE_DIR="$root/gst-cache" MEDIA_SERVER_GST_PLUGIN_PROFILE=headless
unset GST_REGISTRY GST_REGISTRY_1_0 GST_PLUGIN_PATH GST_PLUGIN_PATH_1_0 GST_PLUGIN_SYSTEM_PATH GST_PLUGIN_SYSTEM_PATH_1_0 MEDIA_SERVER_GST_MANAGED_REGISTRY MEDIA_SERVER_GST_MANAGED_PLUGIN_PATH MEDIA_SERVER_GST_INPUT_PLUGIN_PATH
export GST_REGISTRY="$root/registry.bin" GST_REGISTRY_1_0="$root/registry.bin"
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
read -r -a flags <<< "$(pkg-config --cflags --libs gstreamer-1.0 openssl)"
c++ -std=c++17 -pthread -Iinclude -DMEDIA_SERVER_USE_GSTREAMER=1 -DMEDIA_SERVER_USE_OPENSSL=1 "$root/host-profile.cpp" src/recording/recording_contracts.cpp src/domain/strict_json.cpp "${flags[@]}" -o "$root/host-profile"
"$root/host-profile"
env | LC_ALL=C sort | rg '^(GST_|MEDIA_SERVER_GST_)'
