import subprocess,sys,time,json,pathlib,hashlib
root=pathlib.Path(__file__).parent
name=sys.argv[1]; cmd=sys.argv[2:];start=time.time()
with (root/(name+'.log')).open('wb') as out:
 p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,cwd='/Users/dhseo/Workspace/mediaServer')
raw=(root/(name+'.log')).read_bytes()
row={'name':name,'command':cmd,'exit':p.returncode,'elapsedSeconds':time.time()-start,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
with (root/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
print(json.dumps(row));print(raw.decode(errors='replace')[-5000:]);sys.exit(p.returncode)
