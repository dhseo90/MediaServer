import subprocess
files=subprocess.check_output(['git','diff','--name-only','ea47adfcd6f97a1cdf5e09d5192196bcf53b15d1','HEAD'],text=True).splitlines()
for f in files:
 if f.endswith('.mjs'):
  r=subprocess.run(['node','--check',f]);print(f,r.returncode,flush=True);r.check_returncode()
r=subprocess.run(['git','diff','ea47adfcd6f97a1cdf5e09d5192196bcf53b15d1','HEAD','--check']);print('diff-check',r.returncode);r.check_returncode()
