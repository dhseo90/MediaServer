# 파일 용도: 기존 단기 HTTP/browser 분기 세 개만 동일 fixture binary로 실행하고 명령 직후 결과를 보존한다.
import pathlib,subprocess,shlex,os,json,time,hashlib,datetime
repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');r=pathlib.Path('/private/tmp/media-server-release62-33a9_x09');b=repo/'build-gst-onnx'
link=shlex.split((b/'CMakeFiles/media_server.dir/link.txt').read_text());flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','openssl','sqlite3','gstreamer-app-1.0'],text=True));libs=[str(b/'libmedia_server_runtime.a'),*link[link.index('libmedia_server_runtime.a')+1:]]
def run(name,args,env=None,timeout=60):
 t=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'.stdout')).open('xb') as out,(r/(name+'.stderr')).open('xb') as err:
  p=subprocess.run(args,cwd=repo,env=env,stdout=out,stderr=err,timeout=timeout)
 v={'command':args,'startedAt':at,'elapsedSeconds':time.monotonic()-t,'exit':p.returncode};(r/(name+'-execution.json')).write_text(json.dumps(v,indent=2)+'\n');print(name,v['exit'],flush=True)
 if p.returncode:print((r/(name+'.stderr')).read_text()[-1800:]);raise SystemExit(p.returncode)
freeze={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'patch':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=repo)).hexdigest(),'observer':hashlib.sha256((r/'review-observe.mjs').read_bytes()).hexdigest(),'binary':hashlib.sha256((b/'media_server').read_bytes()).hexdigest(),'suite':['A:existing --http','materials:existing --materials-http','release:existing --http-only'],'scope':'same native compile once; actual runner branches unchanged; passive observer only, no acceptance'}
(r/'scoped-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
run('review-build',['c++','-std=c++17','-Wall','-Wextra','-Werror','-pthread','-I'+str(repo/'include'),'-DMEDIA_SERVER_USE_OPENSSL=1','-DMEDIA_SERVER_USE_SQLITE3=1','-DMEDIA_SERVER_USE_GSTREAMER=1','-DMEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND=1',*flags,str(repo/'scripts/internal/va_review_smoke.cpp'),*libs,'-o',str(r/'review-smoke')])
for name,script,materials,timeout in [('A','va_review_confirmed_http.mjs','0',240),('materials','va_review_confirmed_http.mjs','1',240),('release','va_review_http_checks.mjs','0',70)]:
 env=dict(os.environ,MEDIA_SERVER_TEST_ARTIFACT_ROOT=str(r),MEDIA_SERVER_TEST_OUTPUT_DIR=str(r/name),MEDIA_SERVER_VA_REVIEW_FIXTURE_BIN=str(r/'review-smoke'),MEDIA_SERVER_VA_MATERIAL_CHECKS=materials,NODE_OPTIONS='--import='+str(r/'review-observe.mjs'))
 run(name,['node',str(repo/'scripts/internal'/script)],env,timeout)
