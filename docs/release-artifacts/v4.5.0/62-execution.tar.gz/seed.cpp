// 파일 용도: 실제 writer·독립 PNG oracle·순환 삭제·재시작과 패키지 부정 입력의 단기 검사.
#include "recording_media_test_fixture.h"
#include "recording/evidence_package_builder.h"
#include "recording/recording_runtime_composition.h"
#include "recording/recording_search_reader.h"
#include "recording/visual_frame_decoder.h"
#include "recording/recording_derived_job_service.h"
#include "recording/recording_derived_selection.h"
#include "analysis/decoded_interval_evidence.h"
#include "ingress/evidence_application_service.h"
#include <fcntl.h>
#include <fstream>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>

namespace {
int checks=0;
void Check(bool value,const std::string& label){
    ++checks;if(!value)throw std::runtime_error(label);std::cout<<"[pass] "<<label<<'\n';
}
using Clock=std::chrono::steady_clock;
auto Deadline(){return Clock::now()+std::chrono::seconds(30);}
std::vector<unsigned char> Read(int fd,std::uint64_t offset,std::size_t n){
    std::vector<unsigned char> data(n);std::size_t done=0;
    while(done<n){const auto got=::pread(fd,data.data()+done,n-done,static_cast<off_t>(offset+done));
        if(got<0&&errno==EINTR)continue;if(got<=0)throw std::runtime_error("asset-read");done+=std::size_t(got);}
    return data;
}
void Save(const std::filesystem::path& path,const std::string& bytes){
    const int fd=::open(path.c_str(),O_WRONLY|O_CREAT|O_EXCL,0600);
    if(fd<0)throw std::runtime_error("fixture-create");
    const auto n=::write(fd,bytes.data(),bytes.size());const bool ok=n==static_cast<ssize_t>(bytes.size())&&!::fsync(fd);::close(fd);
    if(!ok)throw std::runtime_error("fixture-write");
}
}
int main(int argc,char** argv){try{
    if(argc!=2&&argc!=3)return 2;gst_init(nullptr,nullptr);
    if(argc!=2)return 2;
    const auto root=std::filesystem::canonical(argv[1]);std::string error;
    recording::RecordingRuntimeStorage runtime(root/"recordings");Check(runtime.Open(&error),"V440 source storage open: "+error);
    auto input=Encode(30,false,false,160,90,30,30);Shift(input,7000000000ULL);
    const std::string source_track=std::string(64,'a')+"/001";
    input.descriptor.tracks.front().track_id=source_track;
    for(auto& packet:input.packets)packet.track_id=source_track;
    recording::GStreamerSegmentWriter writer(runtime.WriterOptions(1000));
    Check(writer.Start("1","unused",input.descriptor,[](auto,auto,auto*){return false;},&error),"writer start");
    for(const auto& packet:input.packets)writer.Push(packet,0);writer.Stop();
    const auto ids=runtime.catalog().FinalizedSegmentIdsForStartup();Check(ids.size()==1,"exact one original recording");
    const auto segment=*runtime.catalog().FindSegmentV2ById(ids.front());const auto binding=*runtime.catalog().FindSourceBinding(ids.front());
    recording::RecordingReadService reader(runtime.catalog());recording::RecordingSearchReader search(runtime.catalog(),reader);
    std::shared_ptr<const recording::RecordingSearchModel> model;
    Check(search.Refresh({"1"},{},&model,&error),"current product search model: "+error);
    const auto selected=std::find_if(model->documents().begin(),model->documents().end(),[&](const auto& d){return d.segment_id==ids.front()&&d.start_ns;});
    Check(selected!=model->documents().end(),"search result with current UTC evidence");auto hit=*selected;
    const auto evidence_root=root/"recordings/evidence-packages";
    recording::EvidencePackageStore store(evidence_root,{});Check(store.Recover(&error),"V440-S01 owned store ready");
    recording::EvidencePackageBuilder builder(runtime.catalog(),reader,store);std::string package_id;recording::EvidencePackageV1 manifest;
    Check(builder.Create(hit,"structured","",&package_id,&manifest,&error,Deadline()),"V440-M01 package from actual search: "+error);
    Check(manifest.status=="complete"&&manifest.frames.size()==8&&manifest.assets.size()==8,"representative sequence complete without optional clip");
    // 제품 derived selection/service로 실제 clip을 만든 뒤 독립 복사·출처를 확인한다.
    recording::RecordingConsumerReferenceV1 reference;reference.reference_id="evidence-reference";reference.kind="event";
    reference.owner_id="evidence-event";reference.channel_id=reference.source_id="1";
    reference.analysis_namespace="evidence-test";reference.analysis_track_id="track-1";reference.association_quality="timestamp-match";
    const auto& original=*input.packets.front().observation;
    reference.original=recording::RecordingConsumerOriginalV1{original.source_generation,original.generation_order,original.ordinal,source_track,*original.pts_ns};
    reference.request=recording::RecordingConsumerRequestV1{"media-pts-ms",7000,7500,0,0};reference.created_at_ms=1;
    analysis::DecodedIntervalCollector collector;
    for(const auto& packet:input.packets){analysis::DecodedIntervalEvidence interval;
        interval.analysis_pts_ns=packet.pts;interval.duration_ns=packet.observation->duration_ns;
        interval.association.quality=analysis::SourceAssociationQuality::TimestampMatch;
        const auto& o=*packet.observation;interval.association.original=analysis::OriginalSampleIdentity{o.source_generation,o.generation_order,o.ordinal,packet.track_id,*o.pts_ns};collector.Append(std::move(interval));}
    std::vector<recording::DerivedSourceEvidence> sources{{segment,binding,false}};
    recording::DerivedRecordingSelection selection;recording::DerivedJobIntentV1 intent;
    Check(runtime.catalog().PutConsumerReference(reference,&error)&&recording::SelectDerivedRecording(reference,*collector.Snapshot(reference.analysis_namespace),sources,nullptr,&selection,&error)&&
        recording::BuildDerivedJobIntent(selection,sources,1024*1024,10,&intent,&error),"actual clip selection/intent: "+error);
    recording::RetentionCoordinator retention(runtime.catalog(),[&]{return runtime.catalog().RetentionSnapshot();},
        [](auto* bytes,auto*){*bytes=1024ULL*1024*1024;return true;},
        [&](const auto& path,auto* e){return recording::RemoveContainedMediaFile(root/"recordings",path,e,{},true);},{0,1,root/"recordings"});
    Check(retention.UpdateChannelPolicy("1",{1024ULL*1024*1024,0,1024ULL*1024*1024,0},&error)&&retention.AdmitDerivedJob(runtime.catalog(),intent,10).accepted,"clip admitted with existing protection");
    recording::DerivedJobService derived(runtime.catalog(),runtime.journal(),{root/"recordings",30000,{}});
    const auto rendered=derived.Run(intent.job_id);
    Check(rendered.complete&&rendered.job&&rendered.job->ready&&rendered.job->ready->outputs.size()==1,"actual verified clip complete: "+rendered.reason);
    auto clip_hit=hit;clip_hit.playback_job_id=intent.job_id;clip_hit.playback_event_id=reference.owner_id;
    clip_hit.playback_segment_id=rendered.job->ready->outputs[0].segment.segment_id;
    std::string clip_id;recording::EvidencePackageV1 clip_manifest;
    Check(builder.Create(clip_hit,"structured","",&clip_id,&clip_manifest,&error,Deadline()),"actual preserved clip");
    Check(clip_manifest.assets.size()==9&&clip_manifest.assets[8].content_type=="video/mp4","real clip asset");
    auto file=store.Open(clip_id,&error);Check(bool(file),"independent package read");
    const auto clip_bytes=Read(file->fd(),file->AssetOffset(8),clip_manifest.assets[8].size_bytes);
    Check(recording::EvidenceSha256(clip_bytes.data(),clip_bytes.size())==rendered.job->ready->outputs[0].segment.checksum_sha256,"clip hash exact");file.reset();
    recording::RetentionPlanRequest request;request.channel_id="1";request.policy.continuous_max_bytes=1;request.policy.event_max_bytes=1;
    request.free_bytes=1024*1024*1024;request.now_ms=std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    auto removed=retention.Apply(recording::RetentionCoordinator::Plan(runtime.catalog().RetentionSnapshot(),request),request.now_ms);
    Check(removed.ok&&removed.deleted_count==2&&runtime.catalog().IsDeletedSegmentId(hit.segment_id),"actual source/derived retention deletion");
    std::string partial_id;recording::EvidencePackageV1 partial;
    Check(builder.Create(clip_hit,"structured","",&partial_id,&partial,&error,Deadline())&&partial.status=="partial","deleted source/clip partial");
    file=store.Open(clip_id,&error);Check(file&&Read(file->fd(),file->AssetOffset(8),clip_bytes.size())==clip_bytes,"retained clip bytes after original deletion");file.reset();
    recording::GStreamerSegmentWriter live(runtime.WriterOptions(1000));
    Check(live.Start("2","unused",input.descriptor,[](auto,auto,auto*){return false;},&error),"live channel2 start");
    for(const auto& packet:input.packets)live.Push(packet,0);live.Stop();
    Check(search.Refresh({"2"},{},&model,&error)&&!model->documents().empty(),"live search channel2");
    const auto current=std::find_if(model->documents().begin(),model->documents().end(),[](const auto& d){return d.channel_id=="2"&&d.start_ns&&d.end_ns;});
    Check(current!=model->documents().end(),"live UTC seed");
    Check(runtime.catalog().Checkpoint(&error),"seed checkpoint");
    Save(root/"seed.json","{\"packageId\":\""+package_id+"\",\"clipId\":\""+clip_id+"\",\"partialId\":\""+partial_id+"\",\"clipSha256\":\""+clip_manifest.assets[8].sha256+"\",\"startTimeMs\":"+std::to_string(*current->start_ns/1000000)+",\"endTimeMs\":"+std::to_string((*current->end_ns+999999)/1000000)+"}");
    return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<" after="<<checks<<'\n';return 1;}}
