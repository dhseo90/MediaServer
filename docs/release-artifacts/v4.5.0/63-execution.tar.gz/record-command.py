# 파일 용도: 명령별 즉시 종료 코드·stdout/stderr를 변경 없이 저장한다.
import sys,pathlib,subprocess,time,json,datetime
r=pathlib.Path('/private/tmp/media-server-release63-if986bq_');name=sys.argv[1];cmd=sys.argv[2:];at=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (r/(name+'.stdout')).open('wb') as o,(r/(name+'.stderr')).open('wb') as e:p=subprocess.run(cmd,stdout=o,stderr=e)
d={'command':cmd,'startedAt':at,'elapsedSeconds':time.monotonic()-t,'exit':p.returncode};(r/(name+'.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));print((r/(name+'.stdout')).read_text()[-3500:]);print((r/(name+'.stderr')).read_text()[-2000:]);sys.exit(p.returncode)
