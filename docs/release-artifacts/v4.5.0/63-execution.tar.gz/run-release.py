# 파일 용도: 원래 연속 seed를 포함한 출시 HTTP/UI 단기 경로를 한 번 실행한다.
import pathlib,subprocess,os,json,time,hashlib,datetime
r=pathlib.Path('/private/tmp/media-server-release63-if986bq_');repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=['scripts/internal/va_review_confirmed_checks.h','scripts/internal/va_review_http_checks.mjs','scripts/internal/va_review_seed_process.mjs','scripts/internal/va_review_test_artifacts.mjs','scripts/internal/va_review_release_ui.mjs']
freeze={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'patch':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'])).hexdigest(),'sources':{f:h(repo/f) for f in files},'fixture':h(r/'review-smoke'),'runtimeArchive':h(repo/'build-gst-onnx/libmedia_server_runtime.a'),'binary':h(repo/'build-gst-onnx/media_server'),'observer':h(r/'observe.mjs'),'attempt':1,'seedOrder':['fixture <root> --seed unused','fixture <root>/recordings --confirmed-seed unused'],'scope':'same original HTTP runner; no independent seed pre-run; 65s unchanged'}
(r/'release-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--binary']))
env=dict(os.environ,MEDIA_SERVER_TEST_ARTIFACT_ROOT=str(r),MEDIA_SERVER_TEST_OUTPUT_DIR=str(r/'release'),MEDIA_SERVER_VA_REVIEW_FIXTURE_BIN=str(r/'review-smoke'),NODE_OPTIONS='--import='+str(r/'observe.mjs'))
a=['node',str(repo/'scripts/internal/va_review_http_checks.mjs')];t=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'release.stdout').open('xb') as o,(r/'release.stderr').open('xb') as e:p=subprocess.run(a,cwd=repo,env=env,stdout=o,stderr=e,timeout=70)
d={'command':a,'startedAt':at,'elapsedSeconds':time.monotonic()-t,'exit':p.returncode};(r/'release-execution.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));print((r/'release.stdout').read_text());print((r/'release.stderr').read_text());raise SystemExit(p.returncode)
