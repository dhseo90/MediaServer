# 파일 용도: 누락된 공통 로그를 갖춘 지정 검색 14 action의 source와 실제 실행 결과를 보존한다.
import pathlib,subprocess,time,json,hashlib,datetime,os
r=pathlib.Path('/private/tmp/media-server-release63-if986bq_');repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p= subprocess.check_output(['git','diff','HEAD','--binary'],cwd=repo);(r/'search-source.patch').write_bytes(p)
files=[r/'search.mjs',r/'search-observe.mjs',repo/'scripts/internal/visual_search_ui_fixture.mjs',repo/'scripts/internal/va_review_seed_process.mjs',repo/'build-gst-onnx/media_server',repo/'build-gst-onnx/libmedia_server_runtime.a']
(r/'search-freeze.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'diffSha256':hashlib.sha256(p).hexdigest(),'files':{str(p):sha(p) for p in files},'cases':['english','korean','threshold-empty','tokens63','tokens64','invalid-time','condition-transfer','seek-play','evidence','refresh-binding','late-search','late-seek','operator','no-source'],'QwenOllamaCalls':0,'SigLIP2':'existing model real text/image search fixture'},indent=2)+'\n')
env=dict(os.environ,MEDIA_SERVER_TEST_ARTIFACT_ROOT=str(r),MEDIA_SERVER_TEST_OUTPUT_DIR=str(r/'search'),NODE_OPTIONS='--import='+str(r/'search-observe.mjs'))
t=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'search.stdout').open('wb') as o,(r/'search.stderr').open('wb') as e:p=subprocess.run(['node',str(r/'search.mjs')],cwd=repo,env=env,stdout=o,stderr=e,timeout=670)
d={'command':['node',str(r/'search.mjs')],'startedAt':at,'elapsedSeconds':time.monotonic()-t,'exit':p.returncode};(r/'search-execution.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));print((r/'search.stdout').read_text());print((r/'search.stderr').read_text());raise SystemExit(p.returncode)
