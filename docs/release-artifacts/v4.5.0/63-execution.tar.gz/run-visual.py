# 파일 용도: 고정된 여섯 시각 보완의 실제 종료 코드와 원출력을 보존한다.
import pathlib,subprocess,time,json,hashlib,datetime
r=pathlib.Path('/private/tmp/media-server-release63-if986bq_');repo=pathlib.Path('/Users/dhseo/Workspace/mediaServer')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(r/'visual-freeze.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'diffSha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--binary'],cwd=repo)).hexdigest(),'files':{str(p):sha(p) for p in [r/'visual.mjs',r/'seed',r/'seed.cpp',repo/'build-gst-onnx/media_server']},'cases':['expired','disabled','viewport-320-dark','viewport-390-dark','viewport-760-dark','viewport-1180-dark']},indent=2)+'\n')
t=time.monotonic();at=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'visual.stdout').open('wb') as o,(r/'visual.stderr').open('wb') as e:p=subprocess.run(['node',str(r/'visual.mjs')],cwd=repo,stdout=o,stderr=e,timeout=370)
d={'command':['node',str(r/'visual.mjs')],'startedAt':at,'elapsedSeconds':time.monotonic()-t,'exit':p.returncode};(r/'visual-execution.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d));print((r/'visual.stdout').read_text());print((r/'visual.stderr').read_text());raise SystemExit(p.returncode)
