import fs from "node:fs";
import {runCurrentRecovery} from "file:///Users/dhseo/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs";
await runCurrentRecovery({command:process.execPath,args:["-e","setInterval(()=>{},1000)"],observe:()=>null,onGroup:e=>{fs.appendFileSync("/private/tmp/media-server-release64-d4ane5jz/launcher-checks-final/fixture-_2j65mu1/recovery-groups.jsonl",JSON.stringify(e)+"\n");if(e.event==="started"){while(true){}}}});
