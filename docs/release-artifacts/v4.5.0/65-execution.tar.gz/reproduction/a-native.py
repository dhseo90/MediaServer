import pathlib,sys,subprocess,shlex,os,hashlib,json,shutil
root=pathlib.Path(__file__).parent;repo=pathlib.Path.cwd();build=repo/'build-gst-onnx';native=root/'a-native';native.mkdir(mode=0o700)
def run(name,args,timeout=60):
 print('[command]',name,shlex.join(map(str,args)),flush=True)
 p=subprocess.run(list(map(str,args)),timeout=timeout);print('[exit]',name,p.returncode,flush=True);p.check_returncode()
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=[str(build/'libmedia_server_runtime.a'),*link[link.index('libmedia_server_runtime.a')+1:]]
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','openssl','sqlite3','gstreamer-app-1.0'],text=True))
binary=native/'smoke'
run('compile',['c++','-std=c++17','-Wall','-Wextra','-Werror','-pthread','-I'+str(repo/'include'),'-DMEDIA_SERVER_USE_OPENSSL=1','-DMEDIA_SERVER_USE_SQLITE3=1','-DMEDIA_SERVER_USE_GSTREAMER=1','-DMEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND=1',*flags,repo/'scripts/internal/va_review_smoke.cpp',*libs,'-o',binary])
(native/'binary.json').write_text(json.dumps({'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'archiveSha256':hashlib.sha256((build/'libmedia_server_runtime.a').read_bytes()).hexdigest()},indent=2))
for kind in ('bound','confirmed'):
 seed=native/(kind+'-seed');read=native/(kind+'-read');seed.mkdir(mode=0o700);read.mkdir(mode=0o700)
 run(kind+'-seed',[binary,seed,'--'+kind+'-seed','unused'])
 if kind=='confirmed':run('confirmed-checks',[binary,seed,'--confirmed-checks','unused'])
 for name in (('evidence-packages','va-reviews') if kind=='bound' else ('va-reviews',)):
  shutil.copytree(seed/name,read/name)
 for name in (('record-id','package-id','expected-record.json') if kind=='bound' else ('confirmed-id','confirmed-expected')):
  shutil.copy2(seed/name,read/name)
 assert not (read/'recordings').exists()
 run(kind+'-read',[binary,read,'--'+kind+'-read','unused'])
print('[scope] separate read process receives only copied immutable package/record; original seed retained for preservation; no server/model/UI',flush=True)
