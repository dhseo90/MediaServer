import sys,subprocess,time,json,pathlib,hashlib,os
root=pathlib.Path(__file__).parent
name=sys.argv[1];cmd=sys.argv[2:];start=time.time()
env=dict(os.environ,MEDIA_SERVER_TEST_ARTIFACT_ROOT=str(root))
with (root/(name+'.stdout')).open('wb') as out,(root/(name+'.stderr')).open('wb') as err:
 p=subprocess.run(cmd,stdout=out,stderr=err,env=env)
r={'command':cmd,'exit':p.returncode,'elapsedSeconds':time.time()-start,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'diffSha256':hashlib.sha256(subprocess.check_output(['git','diff','--binary'])).hexdigest()}
for k in ('stdout','stderr'):
 b=(root/(name+'.'+k)).read_bytes();r[k]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(root/(name+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(p.returncode)
