import pathlib,tarfile,json,hashlib,subprocess,os,shutil,platform
p=pathlib.Path(__file__).parent;repo=pathlib.Path.cwd()
with tarfile.open(repo/'docs/release-artifacts/v4.5.0/64-preparation.tar.gz') as t: old=json.loads(t.extractfile('runtime-freeze.json').read())
rows=[]
for r in old['files']:
 if r['path'].startswith('build-'):continue
 f=repo/r['path'];actual={'path':r['path'],'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()};assert actual==r;rows.append(actual)
for f in ['build-gst-onnx/media_server','build-gst-onnx/libmedia_server_runtime.a']:
 x=repo/f;rows.append({'path':f,'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()})
assert rows[-2]['sha256']=='29da6795c7a2983c533463cdbffd1d14820892c54321c6d9519833c01789c794'
assert rows[-1]['sha256']=='69fe350383c38c5f297c5ab23d512515a3200c3429da3833919ab0b343a727b1'
result={'host':platform.platform(),'uid':os.getuid(),'parent':str(p),'parentInode':p.stat().st_ino,'freeBytes':shutil.disk_usage(p).free,'runtimeFiles':rows,'newRunAbsent':not (p/'mixed-120-01').exists(),'prepare65Reused':True,'prepare66Attempts':0}
assert result['freeBytes']>8*1024**3 and result['newRunAbsent']
result['source']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();result['tree']=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'])
(p/'inputs/host-freeze.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
