#!/usr/bin/env bash
set -euo pipefail
if [[ -f /work/repo/build-gst-onnx/media_server ]]; then
  printf '[existing-build] present; not reused without source verification\n'
  sha256sum /work/repo/build-gst-onnx/media_server
else
  printf '[existing-build] absent; rebuild from current snapshot\n'
fi
mkdir -p /work/repo /private/tmp/media-server-linux67
tar -xzf /inputs/linux-source.tar.gz -C /work/repo
cd /work/repo
uname -a
cat /etc/os-release
c++ --version
pkg-config --modversion gstreamer-1.0 openssl sqlite3
node --version
git rev-parse HEAD
cmake -S . -B build-gst-onnx -DCMAKE_BUILD_TYPE=Release -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece
