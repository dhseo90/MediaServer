import pathlib,json,hashlib,os,platform,shutil,subprocess
root=pathlib.Path(__file__).parent;old=json.loads((root/'inputs/host-reference.json').read_text());rows=[]
for row in old['runtimeFiles']:
 p=pathlib.Path(row['path']);h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 info=p.stat();actual={'path':str(p),'bytes':info.st_size,'sha256':h.hexdigest(),'uid':info.st_uid}
 assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],str(p)
 rows.append(actual)
assert not subprocess.check_output(['git','diff','0334b7449822c0e5eefcb677d792f055330365f2','--','src','include','CMakeLists.txt','VERSION'])
proc=subprocess.run(['ps','-axo','pid=,comm='],capture_output=True,text=True);assert proc.returncode==0
servers=[line.strip() for line in proc.stdout.splitlines() if line.strip().split()[-1].endswith('/media_server')]
assert not servers,servers
result={'host':platform.platform(),'uid':os.getuid(),'runtimeFiles':rows,'priorProductSourceUnchanged':True,'newRunAbsent':not (root/'mixed-120').exists(),'freeBytes':shutil.disk_usage(root).free,'activeProductProcesses':servers,'prepare65Reused':True,'newPrepareRuns':0,'QwenOllamaCalls':0}
assert result['freeBytes']>=8*1024**3
(root/'inputs/host-freeze.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
