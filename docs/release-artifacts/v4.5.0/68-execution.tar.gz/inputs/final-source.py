import pathlib,json,hashlib,subprocess
repo=pathlib.Path('/work/repo');m=json.loads(pathlib.Path('/inputs/linux-source-manifest.json').read_text());wrong=[]
for row in m:
 p=repo/row['path'];h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=row['sha256']:wrong.append(row['path'])
print(json.dumps({'sourceFiles':len(m),'mismatches':wrong}));assert not wrong
for p in ['build-gst-onnx/media_server','build-gst-onnx/libmedia_server_runtime.a']:
 print(p,hashlib.sha256((repo/p).read_bytes()).hexdigest())
for cmd in [['ldd','build-gst-onnx/media_server'],['gst-inspect-1.0','--version'],['gst-inspect-1.0','h264parse'],['gst-inspect-1.0','mp4mux']]:
 r=subprocess.run(cmd,cwd=repo,capture_output=True);print(json.dumps({'command':cmd,'exit':r.returncode}));assert r.returncode==0
 s=r.stdout.decode();print(s if cmd[0]=='ldd' or cmd[-1]=='--version' else s[:s.index('GObject')])
print('memory.peak',pathlib.Path('/sys/fs/cgroup/memory.peak').read_text());print('memory.events',pathlib.Path('/sys/fs/cgroup/memory.events').read_text())
