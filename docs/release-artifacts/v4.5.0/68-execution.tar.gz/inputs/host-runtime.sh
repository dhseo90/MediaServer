#!/usr/bin/env bash
set -euo pipefail
export MEDIA_SERVER_GST_CACHE_DIR=/private/tmp/media-server-release68-89ooe93r/host-gst-cache MEDIA_SERVER_GST_PLUGIN_PROFILE=headless
export GST_REGISTRY=/private/tmp/media-server-release68-89ooe93r/host-registry.bin GST_REGISTRY_1_0=/private/tmp/media-server-release68-89ooe93r/host-registry.bin
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
gst-inspect-1.0 --version
gst-inspect-1.0 h264parse | sed -n '1,45p'
gst-inspect-1.0 mp4mux | sed -n '1,45p'
otool -L build-gst-onnx/media_server
