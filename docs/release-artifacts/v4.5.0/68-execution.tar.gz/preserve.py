import hashlib,io,json,re,tarfile
from pathlib import Path
root=Path('/private/tmp/media-server-release68-89ooe93r')
repo=Path('/Users/dhseo/Workspace/mediaServer')
run=root/'mixed-120'; own=next(run.glob('media-server-current-observer-*'))
files={}; entries=[]
def put(name,p):
 b=p.read_bytes();files[name]=b;entries.append({'member':name,'source':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'representation':'original bytes'})
for p in sorted((root/'commands').iterdir()):put('commands/'+p.name,p)
for p in sorted((root/'inputs').iterdir()):
 if p.name not in ('linux-source.tar.gz','privacy-transform.json'):put('inputs/'+p.name,p)
for n in ('capture.py','host-preflight.py','ownership.json','preserve.py'):put(n,root/n)
for n in ('execution.json','run.log','owned-recovery-groups.jsonl'):put('mixed/'+n,run/n)
for p in sorted((run/'artifacts').iterdir()):put('mixed/artifacts/'+p.name,p)
report=json.loads((run/'artifacts/report.json').read_text())
for item in report['aLoad']['completed']:
 for area,name in [('va-reviews',item['reviewId']+'.review'),('evidence-packages',item['packageId']+'.evp')]:put('mixed/selected/'+area+'/'+name,own/'recordings'/area/name)
for n in ('active-1.jsonl','confirmed-seed.json','recording-generation.json','.recording-store-format'):put('mixed/selected/recordings/'+n,own/'recordings'/n)
put('mixed/selected/input/a-seed.mp4',own/'input/a-seed.mp4')
original=own/'server-1.private.log';b=original.read_bytes();lines=b.splitlines(keepends=True);filtered=[];removed=[];offset=0;extracted=[]
for i,line in enumerate(lines,1):
 if re.search(rb'[A-Za-z][A-Za-z0-9+.-]*://',line) or i in (1,6,7,11):
  removed.append({'line':i,'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest(),'reason':'source URI or unnecessary source/path/route setting omitted'})
  filtered.append(f'[redacted-source-setting-line {i}]\n'.encode())
 else:filtered.append(line)
 if line.startswith(b'[recording-evidence] '):extracted.append({'line':i,'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()});files['mixed/server-evidence-extract.log']=line
 offset+=len(line)
assert len(removed)==12 and len(extracted)==1
sanitized=b''.join(filtered);files['mixed/server-1.sanitized.log']=sanitized
redaction={'originalPrivatePath':str(original.relative_to(root)),'originalBytes':len(b),'originalSha256':hashlib.sha256(b).hexdigest(),'sanitizedBytes':len(sanitized),'sanitizedSha256':hashlib.sha256(sanitized).hexdigest(),'transform':'8 source URI lines and4 unnecessary source/path/route setting lines replaced by numbered placeholders; all other original byte lines preserved; not full original evidence','removed':removed,'evidenceExtract':extracted,'rawPrivateLogCommitted':False}
(root/'inputs/privacy-transform.json').write_text(json.dumps(redaction,indent=2)+'\n');put('inputs/privacy-transform.json',root/'inputs/privacy-transform.json')
for n in ('mixed/server-evidence-extract.log','mixed/server-1.sanitized.log'):
 entries.append({'member':n,'source':str(original.relative_to(root)),'bytes':len(files[n]),'sha256':hashlib.sha256(files[n]).hexdigest(),'representation':'exact original selected diagnostic line' if 'extract' in n else 'explicitly sanitized copy; not original raw bytes'})
index={'schema':'media-server.v450-selected-execution-bytes.v1','sourceCommit':'d56808abc67f34fc4d7c12f176085c7b9e948403','entries':entries,'excluded':['SDK/models/images/binaries','full product source tar','identical legacy986 candidate/migration bodies (summary/hash retained)','auth users/session state','full retention media/journals/catalog/cache','original private server log with source URIs','prior archives'],'syntheticMedia':'one necessary A seed 28161 bytes; unrelated retention inputs not copied'}
files['byte-index.json']=(json.dumps(index,indent=2)+'\n').encode()
archive=repo/'docs/release-artifacts/v4.5.0/68-execution.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as out:
 for name,b in files.items():
  t=tarfile.TarInfo(name);t.size=len(b);t.mode=0o600;t.mtime=0;out.addfile(t,io.BytesIO(b))
with tarfile.open(archive) as t:
 for name,b in files.items():assert t.extractfile(name).read()==b,name
result={'archive':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'sourceEntryCount':len(entries),'sourceByteMismatches':0,'redaction':redaction,'oldArchiveCopies':0}
(root/'preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='redaction'}))
