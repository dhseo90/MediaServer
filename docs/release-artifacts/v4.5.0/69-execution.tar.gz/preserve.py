import hashlib,io,json,re,tarfile
from pathlib import Path
root=Path('/private/tmp/media-server-release69-deth7nj4');repo=Path('/Users/dhseo/Workspace/mediaServer');run=root/'mixed';own=next(run.glob('media-server-current-observer-*'))
files={};entries=[]
def put(name,p):
 b=p.read_bytes();files[name]=b;entries.append({'member':name,'source':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'representation':'original bytes'})
for p in sorted((root/'commands').iterdir()):put('commands/'+p.name,p)
for n in ['capture.py','compile.py','saved.cpp','readback.cpp','env.sh','ownership.json','preserve.py','diagnostic-summary.json']:
 put(n,root/n)
for n in ['binding.json','diagnostic-freeze.json','comparison-correction.json','replay-boundary.json','pre-mixed.json','final-source-freeze.json','final-source.diff','first-source.diff','source.diff','source-freeze.json','linux-source-manifest.json','saved-first.cpp','configure.sh','host-runtime.sh','visual_frame_decoder_smoke.cpp','recording_visual_source_smoke.cpp','selection.json']:
 put('inputs/'+n,root/'inputs'/n)
for n in ['execution.json','run.log','owned-recovery-groups.jsonl']:put('mixed/'+n,run/n)
for p in sorted((run/'artifacts').iterdir()):put('mixed/artifacts/'+p.name,p)
d=json.loads((run/'artifacts/report.json').read_text())
for item in d['aLoad']['completed']:
 for area,key,suffix in [('va-reviews','reviewId','.review'),('evidence-packages','packageId','.evp')]:
  put('mixed/selected/'+area+'/'+item[key]+suffix,own/'recordings'/area/(item[key]+suffix))
for n in ['active-1.jsonl','confirmed-seed.json','recording-generation.json','.recording-store-format']:put('mixed/selected/recordings/'+n,own/'recordings'/n)
put('mixed/selected/input/a-seed.mp4',own/'input/a-seed.mp4')
for p in sorted((root/'replay/diagnostic-evidence').glob('*.evp')):put('saved-new-package/'+p.name,p)
# Private boot/source settings are explicitly omitted, never represented as original bytes.
p=own/'server-1.private.log';b=p.read_bytes();out=[];removed=[];offset=0
prefixes=(b'[visual-frame] ',b'[recording-completion] ',b'[recording-latency] ',b'[recording-slow-summary] ')
for i,line in enumerate(b.splitlines(keepends=True),1):
 if line.startswith(prefixes) and not re.search(rb'[A-Za-z][A-Za-z0-9+.-]*://',line):out.append(line)
 else:
  removed.append({'line':i,'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()});out.append(f'[redacted-private-setting-line {i}]\n'.encode())
 offset+=len(line)
sanitized=b''.join(out);files['mixed/server-1.sanitized.log']=sanitized
privacy={'source':str(p.relative_to(root)),'originalBytes':len(b),'originalSha256':hashlib.sha256(b).hexdigest(),'sanitizedBytes':len(sanitized),'sanitizedSha256':hashlib.sha256(sanitized).hexdigest(),'rule':'preserve exact bounded decoder/completion/latency/slow-summary lines without URI; replace other private boot/source/config lines by numbered placeholders','removed':removed,'rawPrivateLogCommitted':False,'originalAndSanitizedAreSameBytes':False}
(root/'privacy-transform.json').write_text(json.dumps(privacy,indent=2)+'\n');put('privacy-transform.json',root/'privacy-transform.json')
entries.append({'member':'mixed/server-1.sanitized.log','bytes':len(sanitized),'sha256':hashlib.sha256(sanitized).hexdigest(),'representation':'explicitly sanitized copy; all1329 decoder lines original byte-identical'})
prior={'archive':'docs/release-artifacts/v4.5.0/68-execution.tar.gz','archiveSha256':hashlib.sha256((repo/'docs/release-artifacts/v4.5.0/68-execution.tar.gz').read_bytes()).hexdigest(),'originalInputMember':'mixed/selected/input/a-seed.mp4','originalInputSha256':hashlib.sha256((root/'inputs/a-seed.mp4').read_bytes()).hexdigest(),'priorFullArchiveCopied':False,'candidateDigest':'137543c6332a73f9a77599bfaca732bd1f54b263adee078fe5d3f8c275775906','candidateFileSha256':hashlib.sha256((root/'current-candidate.json').read_bytes()).hexdigest(),'migrationFileSha256':hashlib.sha256((root/'migration.json').read_bytes()).hexdigest(),'strictEligibleItems':986,'wholeBaselineItemsIdentical':True,'producerApplications':0}
files['references.json']=(json.dumps(prior,indent=2)+'\n').encode()
files['byte-index.json']=(json.dumps({'schema':'media-server.v450-selected-execution-bytes.v1','source':'base+inputs/final-source.diff; per-command earlier diagnostic revisions explicitly preserved','entries':entries,'excluded':['binaries/SDK/models/cache/full-source-tar','prior archive duplicate','auth user/session state','full media/catalog/journals','private unredacted boot/source settings','identical986 candidate/migration full bodies']},indent=2)+'\n').encode()
archive=repo/'docs/release-artifacts/v4.5.0/69-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,b in files.items():
  m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o600;m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 for name,b in files.items():assert t.extractfile(name).read()==b,name
result={'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'sourceByteMismatches':0,'privacy':privacy}
(root/'preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='privacy'}))
