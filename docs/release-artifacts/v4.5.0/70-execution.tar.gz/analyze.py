from pathlib import Path
import json,hashlib,zlib,base64,statistics
r=Path(__file__).parent;m=r/'mixed-120';o=next(m.glob('media-server-current-observer-*'))
ls=(m/'run.log').read_text().splitlines();d=json.loads((m/'artifacts/report.json').read_text());exe=json.loads((m/'execution.json').read_text())
def rows(prefix):return [json.loads(s[len(prefix):]) for s in ls if s.startswith(prefix)]
traces=[json.loads(s[15:]) for s in (o/'server-1.private.log').read_text().splitlines() if s.startswith('[visual-frame] ')]
fail=next(x for x in traces if not x['succeeded']);observations=rows('[current-observation] ')
journal=[]
for s in (o/'recordings/active-1.jsonl').read_text().splitlines():
 x=json.loads(s)
 if x.get('codec')=='zlib-base64':x=json.loads(zlib.decompress(base64.b64decode(x['data'])))
 journal.append(x)
binding=next(x for x in journal if x.get('mutationType')=='segment_v2_bound_finalized')
(r/'mixed-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
p=o/'recordings'/binding['payload']['mediaRelpath'];b=p.read_bytes();st=p.stat();assert b==(o/'input/a-seed.mp4').read_bytes();assert st.st_ino==fail['inoBefore'] and st.st_dev==fail['devBefore'];assert binding['payload']['segment']['checksum_sha256']==hashlib.sha256(b).hexdigest()
(r/'failure-decoder.json').write_text(json.dumps(fail,indent=2)+'\n')
lat=d['evidenceLoad']['searchLatencyMs'];a=d['aLoad']['completed']
x={'executionSource':exe['source'],'sourceUnchanged':exe['source']==exe['sourceEnd'],'attempts':1,'exit':exe['exit'],'totalSeconds':exe['elapsedSeconds'],'observedLastProgressSeconds':observations[-1]['progress']['elapsedMs']/1000,'sampleSpanSeconds':d['resources']['groups'][0]['elapsedMs']/1000,'verified7200Seconds':False,'A':{'opportunities':len(d['aLoad']['schedule']),'admitted':len(a),'completed':len(a),'failedPreparation':d['aLoad']['schedule'][-1],'controlsExecuted':len(d['aLoad']['controls']),'jobLatencyMaxMs':max(v['jobElapsedMs'] for v in a)},'search':{'successByClient':d['evidenceLoad']['searchSuccessByClient'],'unavailable':d['evidenceLoad']['searchUnavailable'],'maxLatencyMs':max(lat),'medianLatencyMs':statistics.median(lat)},'evidence':{k:d['evidenceLoad'][k] for k in ['cycles','createComplete','createPartial','createBusy','visualCreated','retainedChecks','deletedSourceObserved','windows']},'channels':observations[-1]['progress']['channels'],'resources':d['resources'],'cpu':d['cpu'],'file':{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'inode':st.st_ino,'device':st.st_dev,'failureTraceIdentityMatches':True,'bindingChecksumMatches':True,'differentFrom68SavedFile':hashlib.sha256(b).hexdigest()!='3d2135fbf45804087aa7c2d451c92bbd29755e1cac1e487604ee43f7fbd5989d'},'trace':rows('[frame-trace-summary] '),'processLog':rows('[server-diagnostic] '),'cleanup':rows('[process-cleanup] '),'processesClosed':d['processesClosed'],'udpClosed':d['udpClosed'],'notRun':['remaining7200 observation','controlled cancellation and permission revocation','disabled restart/readback','independent recovery copy','reactivation/new work/final restart lifecycle'],'firstFailure':{'HTTP':rows('[A-http] ')[-1],'decoder':fail,'published':0,'jobAdmitted':False},'historical68Cause':'unconfirmed; failed decoder not preserved in68; matching public symptoms are not proof of identical cause','interpretation':'Current70 target failed with EOS and zero pulled samples in ~30ms, not5s timeout; no observed bus-error/read-error, file identity/offset stable; inner runtime cause remains unconfirmed. No decoder behavior changes or retries.'}
(r/'run-analysis.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:x[k] for k in ['attempts','exit','totalSeconds','observedLastProgressSeconds','sampleSpanSeconds','file']},indent=2))
