set -euo pipefail
source scripts/internal/env_common.sh
export MEDIA_SERVER_GST_CACHE_DIR=/private/tmp/media-server-release70-no2ho92l/gst-cache
export MEDIA_SERVER_GST_PLUGIN_PROFILE=headless
export GST_REGISTRY=/private/tmp/media-server-release70-no2ho92l/registry.bin
export GST_REGISTRY_1_0="$GST_REGISTRY"
media_server_apply_homebrew_gst_env
export MEDIA_SERVER_VERIFY_FRAME_TRACE="${TRACE_MODE:-bounded}"
exec "$@"
