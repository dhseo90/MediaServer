import hashlib,io,json,re,tarfile
from pathlib import Path
root=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');run=root/'mixed-120';own=next(run.glob('media-server-current-observer-*'));files={};entries=[]
def put(name,p):
 b=p.read_bytes();files[name]=b;entries.append({'member':name,'source':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'representation':'original bytes'})
for p in sorted((root/'commands').iterdir()):put('commands/'+p.name,p)
for n in ['capture.py','compile.py','saved.cpp','readback.cpp','env.sh','ownership.json','probe.py','probe-results.json','preserve.py','analyze.py','run-analysis.json','failure-decoder.json','mixed-binding.json','candidate-impact.json']:put(n,root/n)
for p in sorted((root/'inputs').iterdir()):
 if p.name not in ['a-seed.mp4','active-1.jsonl','linux-source.tar.gz']:put('inputs/'+p.name,p)
for n in ['execution.json','run.log','owned-recovery-groups.jsonl']:put('mixed/'+n,run/n)
for p in sorted((run/'artifacts').iterdir()):put('mixed/artifacts/'+p.name,p)
d=json.loads((run/'artifacts/report.json').read_text())
for item in d['aLoad']['completed']:
 for area,key,suffix in [('va-reviews','reviewId','.review'),('evidence-packages','packageId','.evp')]:put('mixed/selected/'+area+'/'+item[key]+suffix,own/'recordings'/area/(item[key]+suffix))
for n in ['active-1.jsonl','confirmed-seed.json','recording-generation.json','.recording-store-format']:put('mixed/selected/recordings/'+n,own/'recordings'/n)
put('mixed/selected/input/a-seed.mp4',own/'input/a-seed.mp4')
for p in sorted((root/'replay').rglob('*.evp')):put('saved-new-package/'+p.name,p)
p=own/'server-1.private.log';b=p.read_bytes();out=[];removed=[];offset=0
prefixes=(b'[visual-frame] ',b'[recording-evidence] ',b'[recording-completion] ',b'[recording-latency] ',b'[recording-slow-summary] ')
for i,line in enumerate(b.splitlines(keepends=True),1):
 if line.startswith(prefixes) and not re.search(rb'[A-Za-z][A-Za-z0-9+.-]*://',line):out.append(line)
 else:
  removed.append({'line':i,'offset':offset,'bytes':len(line),'sha256':hashlib.sha256(line).hexdigest()});out.append(f'[redacted-private-setting-line {i}]\n'.encode())
 offset+=len(line)
sanitized=b''.join(out);files['mixed/server-1.sanitized.log']=sanitized
privacy={'source':str(p.relative_to(root)),'originalBytes':len(b),'originalSha256':hashlib.sha256(b).hexdigest(),'sanitizedBytes':len(sanitized),'sanitizedSha256':hashlib.sha256(sanitized).hexdigest(),'rule':'preserve exact decoder/evidence/completion/latency/slow-summary lines without URI; replace other private boot/source/config lines by numbered placeholders','removed':removed,'rawPrivateLogCommitted':False,'originalAndSanitizedAreSameBytes':False}
(root/'privacy-transform.json').write_text(json.dumps(privacy,indent=2)+'\n');put('privacy-transform.json',root/'privacy-transform.json');entries.append({'member':'mixed/server-1.sanitized.log','bytes':len(sanitized),'sha256':hashlib.sha256(sanitized).hexdigest(),'representation':'sanitized copy; all4 decoder records and first evidence failure remain original byte-identical'})
prior={'priorArchivesCopied':False,'historical68Input':{'archive':'68-execution.tar.gz','member':'mixed/selected/input/a-seed.mp4','sha256':'3d2135fbf45804087aa7c2d451c92bbd29755e1cac1e487604ee43f7fbd5989d','bytes':28161},'candidateDigest':json.loads((root/'final-candidate.json').read_text())['candidateDigest'],'candidateFileSha256':hashlib.sha256((root/'final-candidate.json').read_bytes()).hexdigest(),'migrationFileSha256':hashlib.sha256((root/'final-migration.json').read_bytes()).hexdigest(),'wholeBaselineItemsIdentical':True,'producerApplications':0}
files['references.json']=(json.dumps(prior,indent=2)+'\n').encode()
files['byte-index.json']=(json.dumps({'schema':'media-server.v450-selected-execution-bytes.v1','source':'37077c5786312bc690a2ca23e2d64958f3768e5e for mixed; earlier direct commands bound to frozen CPP and explicit base+diff','entries':entries,'excluded':['binaries/SDK/models/cache/full-source-tar','prior archive duplicate','auth user/session state','full media/catalog/journals','private unredacted boot/source settings','identical986 candidate/migration full bodies']},indent=2)+'\n').encode()
archive=repo/'docs/release-artifacts/v4.5.0/70-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,b in files.items():
  m=tarfile.TarInfo(name);m.size=len(b);m.mode=0o600;m.mtime=0;t.addfile(m,io.BytesIO(b))
with tarfile.open(archive) as t:
 for name,b in files.items():assert t.extractfile(name).read()==b,name
result={'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'sourceByteMismatches':0,'privacy':privacy}
(root/'preservation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='privacy'}))
