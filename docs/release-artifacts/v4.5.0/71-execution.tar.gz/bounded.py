import pathlib,json,subprocess,time,hashlib
p=pathlib.Path(__file__).parent
f={'purpose':'observe first failing boundary; stop at first failure, not repeat until success','maxCalls':8,'concurrency':1,'bundleDeadlineSeconds':60,'perCallDecoderMs':5000,'sourceHash':hashlib.sha256(pathlib.Path('src/recording/visual_frame_decoder.cpp').read_bytes()).hexdigest(),'binaryHash':hashlib.sha256((p/'saved-edges').read_bytes()).hexdigest(),'inputHash':hashlib.sha256((p/'inputs/a-seed.mp4').read_bytes()).hexdigest(),'targetNs':966666667,'defaultFactory':True}
with (p/'inputs/bounded-freeze.json').open('x') as o:json.dump(f,o,indent=2)
start=time.monotonic();result=[]
for i in range(8):
 if time.monotonic()-start>50:break
 name=f'bounded-{i+1}'
 subprocess.run(['python3',str(p/'capture.py'),name,'bash',str(p/'env.sh'),str(p/'saved-edges'),'direct',str(p/'inputs/a-seed.mp4')],timeout=min(10,60-(time.monotonic()-start)),check=True)
 r=json.loads((p/f'commands/{name}.json').read_text());result.append(r)
 if r['exit']!=0:break
(p/'bounded-result.json').write_text(json.dumps({'elapsedSeconds':time.monotonic()-start,'attempts':result},indent=2)+'\n')
