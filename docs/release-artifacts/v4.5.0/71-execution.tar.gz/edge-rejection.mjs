import fs from 'node:fs';
import assert from 'node:assert/strict';
import {frameTraceSummary} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_longrun_progress.mjs';
const line=fs.readFileSync('/private/tmp/media-server-release71-8yv1nei9/commands/bounded-5.stderr','utf8').split('\n').find(x=>x.startsWith('[visual-frame] {'));
const r=JSON.parse(line.slice(15));r.edges.probeFailures=1;
const result=frameTraceSummary('[visual-frame] '+JSON.stringify(r)+'\n','bounded');console.log(JSON.stringify(result));
assert.equal(result.status,'incomplete','explicit probe collection failure must not be captured');
