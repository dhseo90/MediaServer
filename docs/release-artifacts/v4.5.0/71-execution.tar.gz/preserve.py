from pathlib import Path
import json,tarfile,hashlib,io,subprocess
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');sha=lambda b:hashlib.sha256(b).hexdigest()
selected={}
def put(name,p):
 assert p.is_file() and not p.is_symlink();selected[name]=p.read_bytes()
for p in sorted((r/'commands').iterdir()):put('commands/'+p.name,p)
for name in ['capture.py','compile.py','compile-sequential.py','env.sh','saved.cpp','saved-package.cpp','sequential.cpp','readback.cpp','probe.py','bounded.py','edge-rejection.mjs','bounded-result.json','probe-results.json','analysis.json','review-freeze.json','review-final-freeze.json','review-source.diff','review-final.diff','independent-review-before-final.json','review-provenance-addendum.json','candidate-readback.json','binary-map.json','ownership.json','preserve.py']:
 put(name,r/name)
for p in sorted((r/'inputs').iterdir()):
 if p.name not in ['a-seed.mp4','active-1.jsonl','binding.json','failure70.json','linux-source.tar.gz']:put('inputs/'+p.name,p)
put('upstream/sources.json',r/'upstream/sources.json')
for p in (r/'replay-corrected/diagnostic-evidence').glob('*.evp'):put('new-package/'+p.name,p)
refs={'reused70':{'archive':'70-execution.tar.gz','archiveSha256':sha((repo/'docs/release-artifacts/v4.5.0/70-execution.tar.gz').read_bytes()),'members':{'mp4':'mixed/selected/input/a-seed.mp4','binding':'mixed-binding.json','journal':'mixed/selected/recordings/active-1.jsonl','failure':'failure-decoder.json'}},'candidate':json.loads((r/'candidate-readback.json').read_text()),'notDuplicated':['existing70 media/logs','unchanged7.7MB candidate (same tracked fixture JSON)','Linux source tar; source manifest retained','upstream sources; official immutable1.28.1 URLs and hashes retained','binaries; hashes/link commands retained']}
selected['references.json']=(json.dumps(refs,indent=2)+'\n').encode()
manifest=[{'path':k,'bytes':len(v),'sha256':sha(v),'representation':'original bytes' if k!='references.json' else 'new reference metadata'} for k,v in selected.items()];selected['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
out=repo/'docs/release-artifacts/v4.5.0/71-execution.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for name,data in selected.items():i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o600;t.addfile(i,io.BytesIO(data))
with tarfile.open(out) as t:
 for name,data in selected.items():assert t.extractfile(name).read()==data
report={'path':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':len(selected),'memberReadback':True,'maxMemberBytes':max(map(len,selected.values()))};(r/'archive-readback.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
