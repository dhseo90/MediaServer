import os,subprocess,pathlib,json,hashlib
r=pathlib.Path('/private/tmp/media-server-release71-8yv1nei9');results=[]
for label,mode in [('off','0'),('full','1'),('bounded','bounded'),('invalid','invalid'),('write-failed','bounded')]:
 def break_stderr():
  f=os.open('/dev/null',os.O_RDONLY);os.dup2(f,2);os.close(f)
 p=subprocess.run(['bash',str(r/'env.sh'),str(r/'decoder-smoke'),str(r/(label+'.mp4')),'--trace-probe'],env=dict(os.environ,TRACE_MODE=mode),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,preexec_fn=break_stderr if label=='write-failed' else None)
 (r/'commands'/('probe-'+label+'.stdout')).write_bytes(p.stdout);(r/'commands'/('probe-'+label+'.stderr')).write_bytes(p.stderr)
 assert p.returncode==0,(label,p.returncode,p.stdout,p.stderr)
 answer=next(x for x in p.stdout.decode().splitlines() if x.startswith('PASS trace probe'))
 trace=[json.loads(x[15:]) for x in p.stderr.decode().splitlines() if x.startswith('[visual-frame] {')]
 if label=='off':assert not trace and b'[visual-frame]' not in p.stderr
 if label=='full':assert len(trace)==26 and sum(x['succeeded'] for x in trace)==25
 if label=='bounded':
  assert len(trace)==4 and sum(x['succeeded'] for x in trace)==3
  failure=[x for x in trace if not x['succeeded']][0];assert failure['error']=='visual-frame-unavailable' and failure['first']=='eos-no-target' and failure['samples']>0
  assert failure['edges']['probeFailures']==0 and failure['edges']['probesAttached']>=3
  assert failure['edges']['pulls']==failure['samples']+failure['edges']['emptyPulls']
  state=next(x for x in failure['edges']['states'] if x['point']=='eos-exit');assert state['isEos'] and state['queued']==0
  assert any(x['edge']=='appsink-in' and x['kind']=='eos' for x in failure['edges']['marks'])
  for k in ['target','offsetBefore','offsetAfter','events','requestStartNs','budgetMs']:assert k in failure
 if label=='invalid':assert b'trace-config-invalid' in p.stderr and not trace
 if label=='write-failed':assert b'trace-output-failed' in p.stdout and not trace
 results.append({'mode':label,'exit':p.returncode,'answer':answer,'traceCount':len(trace),'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()})
assert len(set(x['answer'] for x in results))==1
(r/'probe-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
