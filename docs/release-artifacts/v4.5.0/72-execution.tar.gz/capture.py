import sys,subprocess,pathlib,json,time,datetime,hashlib,os
root=pathlib.Path(__file__).parent
name=sys.argv[1];argv=sys.argv[2:];begin=time.monotonic()
record={"name":name,"argv":argv,"cwd":os.getcwd(),"uid":os.getuid(),"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (root/"commands"/(name+".stdout")).open("xb") as out,(root/"commands"/(name+".stderr")).open("xb") as err:
 try:
  child=subprocess.Popen(argv,stdout=out,stderr=err);record["pid"]=child.pid;record["exit"]=child.wait()
 except Exception as e:record.update(exit=None,errorType=type(e).__name__)
record["elapsedSeconds"]=time.monotonic()-begin
for kind in ("stdout","stderr"):
 b=(root/"commands"/(name+"."+kind)).read_bytes();record[kind]={"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()}
(root/"commands"/(name+".json")).write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(record),flush=True)
raise SystemExit(record["exit"] if record["exit"] is not None and record["exit"]>=0 else 1)
