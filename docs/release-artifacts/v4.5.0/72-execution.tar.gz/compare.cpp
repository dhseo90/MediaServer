#include "recording/visual_frame_decoder.h"
#include "recording/evidence_frame_extractor.h"
#include <chrono>
#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <libproc.h>
namespace recording {bool DecodeSoftwareFrame(int,std::uint64_t,std::int64_t,VisualRgbFrame*,std::string*,const std::function<bool()>&,std::uint32_t);}
int main(int argc,char** argv){if(argc!=3)return 2;bool sw=std::string(argv[1])=="software";int fd=open(argv[2],O_RDONLY);struct stat st{};if(fd<0||fstat(fd,&st))return 2;lseek(fd,37,SEEK_SET);
for(int i=1;i<=100;++i){recording::VisualRgbFrame out{7,9,11,{42}};std::string error;auto start=std::chrono::steady_clock::now();rusage a{},b{};getrusage(RUSAGE_SELF,&a);
bool ok=sw?recording::DecodeSoftwareFrame(fd,st.st_size,966666667,&out,&error,{},5000):recording::DecodeVisualFrame(fd,st.st_size,966666667,&out,&error,{},5000);
getrusage(RUSAGE_SELF,&b);proc_taskinfo ti{};const auto info=proc_pidinfo(getpid(),PROC_PIDTASKINFO,0,&ti,sizeof(ti));int fds=0;for(int n=0;n<1024;++n)if(fcntl(n,F_GETFD)>=0)++fds;
auto us=[](timeval v){return v.tv_sec*1000000LL+v.tv_usec;};bool exact=ok&&out.presentation_ns==966666666&&out.width==160&&out.height==90&&out.rgb.size()==43200;bool preserved=lseek(fd,0,SEEK_CUR)==37;
std::cout<<"{\"attempt\":"<<i<<",\"software\":"<<sw<<",\"ok\":"<<ok<<",\"exact\":"<<exact<<",\"fdOffsetPreserved\":"<<preserved<<",\"error\":\""<<error<<"\",\"pts\":"<<out.presentation_ns<<",\"rgb\":\""<<recording::EvidenceSha256(out.rgb.data(),out.rgb.size())<<"\",\"elapsedUs\":"<<std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now()-start).count()<<",\"cpuUs\":"<<us(b.ru_utime)+us(b.ru_stime)-us(a.ru_utime)-us(a.ru_stime)<<",\"maxRssBytes\":"<<b.ru_maxrss<<",\"fdCountBelow1024\":"<<fds<<",\"threadCount\":"<<(info==sizeof(ti)?ti.pti_threadnum:0)<<"}"<<std::endl;
if(!exact||!preserved){close(fd);return 1;}}
close(fd);return 0;}
