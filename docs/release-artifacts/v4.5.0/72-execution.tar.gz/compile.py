import pathlib,shlex,subprocess,sys
repo=pathlib.Path.cwd();build=repo/'build-gst-onnx';flags={}
for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines():
 if ' = ' in line:k,v=line.split(' = ',1);flags[k]=shlex.split(v)
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=[str(build/'libmedia_server_runtime.a'),*link[link.index('libmedia_server_runtime.a')+1:]]
cmd=[link[0],*flags['CXX_DEFINES'],*flags['CXX_INCLUDES'],*flags['CXX_FLAGS'],'-Wall','-Wextra','-Werror',sys.argv[1],*libs,'-o',sys.argv[2]]
print(shlex.join(cmd),flush=True);subprocess.run(cmd,check=True,timeout=60)
