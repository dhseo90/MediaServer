set -euo pipefail
r=/private/tmp/media-server-release72-_yo80e2o
python3 "$r/capture.py" host-default bash "$r/env.sh" "$r/decoder-smoke-vfr" "$r/default.mp4"
python3 "$r/capture.py" compile-package python3 "$r/compile.py" "$r/saved-package.cpp" "$r/package"
python3 "$r/capture.py" compile-readback python3 "$r/compile.py" "$r/readback.cpp" "$r/readback"
python3 "$r/capture.py" compile-source python3 "$r/compile.py" scripts/internal/recording_visual_source_smoke.cpp "$r/visual-source"
python3 - <<'PY'
from pathlib import Path
import shutil
r=Path('/private/tmp/media-server-release72-_yo80e2o');d=r/'replay';(d/'1').mkdir(parents=True)
shutil.copyfile(r/'mixed/selected/recordings/active-1.jsonl',d/'journal.jsonl')
shutil.copyfile(r/'mixed/selected/input/a-seed.mp4',d/'1/30e5a8b6-5320-424b-95a1-0c1f647b4a09.mp4')
PY
python3 "$r/capture.py" host-package bash "$r/env.sh" "$r/package" package "$r/replay"
python3 "$r/capture.py" host-readback bash "$r/env.sh" "$r/readback" "$r/replay/diagnostic-evidence"
mkdir "$r/source-root"
python3 "$r/capture.py" host-source bash "$r/env.sh" "$r/visual-source" "$r/source-root"
MEDIA_SERVER_TEST_ARTIFACT_ROOT="$r" python3 "$r/capture.py" host-evidence bash "$r/env.sh" bash scripts/internal/verify_evidence_package.sh
TMPDIR="$r/" python3 "$r/capture.py" host-confirmed bash "$r/env.sh" python3 scripts/internal/verify_va_review_confirmed.py
