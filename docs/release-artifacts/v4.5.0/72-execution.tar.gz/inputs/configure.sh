#!/usr/bin/env bash
set -euo pipefail
mkdir -p /work/repo /work/home/cache /private/tmp/media-server-linux72-root /private/tmp/media-server-linux72-user
tar -xzf /inputs/linux-source.tar.gz -C /work/repo
chown -R 10001:10001 /work/repo /work/home
chown 10001:10001 /private/tmp/media-server-linux72-user
chmod 0700 /work/home /private/tmp/media-server-linux72-root /private/tmp/media-server-linux72-user
cd /work/repo
uname -a
c++ --version
pkg-config --modversion gstreamer-1.0 openssl sqlite3
cmake -S . -B build-gst-onnx -DCMAKE_BUILD_TYPE=Release -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece
chown -R 10001:10001 /work/repo/build-gst-onnx
