set -euo pipefail
gst-inspect-1.0 --version
for element in decodebin avdec_h264 vtdec_hw h264parse mp4mux; do gst-inspect-1.0 "$element"; done
otool -L build-gst-onnx/media_server
