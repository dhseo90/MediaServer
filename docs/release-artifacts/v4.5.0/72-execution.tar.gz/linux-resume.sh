set -euo pipefail
r=/private/tmp/media-server-release72-_yo80e2o
args=(docker exec --user 10001:10001 --env HOME=/work/home --env TMPDIR=/private/tmp/media-server-linux72-user --env MEDIA_SERVER_VERIFY_FRAME_TRACE=bounded --workdir /work/repo mediaserver-release72-linux)
python3 "$r/capture.py" linux-compile-decoder-fixed "${args[@]}" python3 /inputs/compile.py /inputs/decoder-smoke-fixed.cpp /private/tmp/media-server-linux72-user/decoder
python3 "$r/capture.py" linux-decoder "${args[@]}" /private/tmp/media-server-linux72-user/decoder /private/tmp/media-server-linux72-user/red.mp4
python3 "$r/capture.py" linux-compile-source "${args[@]}" python3 /inputs/compile.py scripts/internal/recording_visual_source_smoke.cpp /private/tmp/media-server-linux72-user/source
python3 "$r/capture.py" linux-source "${args[@]}" /private/tmp/media-server-linux72-user/source /private/tmp/media-server-linux72-user/source-root
python3 "$r/capture.py" linux-identity "${args[@]}" sh -c 'id; uname -a; pkg-config --modversion gstreamer-1.0; sha256sum build-gst-onnx/media_server src/recording/visual_frame_decoder.cpp /inputs/decoder-smoke-fixed.cpp'
