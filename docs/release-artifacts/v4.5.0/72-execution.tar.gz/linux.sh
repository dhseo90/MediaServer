set -euo pipefail
r=/private/tmp/media-server-release72-_yo80e2o
image=mediaserver-v450-verify:rc58-arm64
[[ "$(docker image inspect "$image" --format '{{.Id}}')" == sha256:ce72c8a15363984da642e9964189957896812061c6af1d0ef67e87b38ad5a588 ]]
python3 "$r/capture.py" linux-create docker create --name mediaserver-release72-linux --network none --cpus 2 --memory 6g --memory-swap 6g --pids-limit 256 --mount "type=bind,source=$r/inputs,target=/inputs,readonly" --env LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib "$image" sleep infinity
python3 "$r/capture.py" linux-start docker start mediaserver-release72-linux
python3 "$r/capture.py" linux-configure docker exec mediaserver-release72-linux bash /inputs/configure.sh
args=(docker exec --user 10001:10001 --env HOME=/work/home --env TMPDIR=/private/tmp/media-server-linux72-user --env MEDIA_SERVER_VERIFY_FRAME_TRACE=bounded --workdir /work/repo mediaserver-release72-linux)
python3 "$r/capture.py" linux-build "${args[@]}" cmake --build build-gst-onnx -j 2
python3 "$r/capture.py" linux-compile-decoder "${args[@]}" python3 /inputs/compile.py scripts/internal/visual_frame_decoder_smoke.cpp /private/tmp/media-server-linux72-user/decoder
python3 "$r/capture.py" linux-decoder "${args[@]}" /private/tmp/media-server-linux72-user/decoder /private/tmp/media-server-linux72-user/red.mp4
python3 "$r/capture.py" linux-compile-source "${args[@]}" python3 /inputs/compile.py scripts/internal/recording_visual_source_smoke.cpp /private/tmp/media-server-linux72-user/source
python3 "$r/capture.py" linux-source "${args[@]}" /private/tmp/media-server-linux72-user/source /private/tmp/media-server-linux72-user/source-root
python3 "$r/capture.py" linux-identity "${args[@]}" sh -c 'id; uname -a; pkg-config --modversion gstreamer-1.0; sha256sum build-gst-onnx/media_server src/recording/visual_frame_decoder.cpp'
