from pathlib import Path
import subprocess,os,json
r=Path(__file__).parent;rows=[]
for policy,arg in [('auto','--trace-probe'),('software','--software-trace')]:
 for mode in ['0','1','bounded']:
  name='mode-'+policy+'-'+mode
  env=dict(os.environ,TRACE_MODE=mode)
  subprocess.run(['python3',str(r/'capture.py'),name,'bash',str(r/'env.sh'),str(r/'decoder-final'),str(r/(name+'.mp4')),arg],env=env,check=True,timeout=30)
  out=(r/'commands'/f'{name}.stdout').read_text();tr=[json.loads(x.split(' ',1)[1]) for x in (r/'commands'/f'{name}.stderr').read_text().splitlines() if x.startswith('[visual-frame] {')]
  expected=0 if mode=='0' else 26 if mode=='1' else 3 if policy=='auto' else 2
  assert len(tr)==expected,(name,len(tr));assert mode=='0' or sum(not x['succeeded'] for x in tr)==1
  rows.append({'policy':policy,'mode':mode,'traces':len(tr),'stdout':out})
for policy in ['auto','software']:assert len({x['stdout'] for x in rows if x['policy']==policy})==1
(r/'mode-results.json').write_text(json.dumps(rows,indent=2))
for name,error in [('missing-property','visual-frame-software-policy-unavailable'),('no-decoder','visual-frame-unavailable')]:
 subprocess.run(['python3',str(r/'capture.py'),name,'bash',str(r/'env.sh'),str(r/name),str(r/'mixed/selected/input/a-seed.mp4'),error],check=True,timeout=15)
