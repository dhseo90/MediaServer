from pathlib import Path
import subprocess
r=Path(__file__).parent
src=Path('src/recording/visual_frame_decoder.cpp').read_text().replace('bool DecodeVisualFrame(int fd','bool DecodeInjectedFrame(int fd')
harness=r'''#include "recording/visual_frame_decoder.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <iostream>
namespace recording {bool DecodeInjectedFrame(int,std::uint64_t,std::int64_t,VisualRgbFrame*,std::string*,const std::function<bool()>&,std::uint32_t,VisualDecodePolicy);}
int main(int argc,char**argv){if(argc!=3)return 2;int fd=open(argv[1],O_RDONLY);struct stat st{};if(fd<0||fstat(fd,&st))return 2;lseek(fd,37,SEEK_SET);recording::VisualRgbFrame out{7,9,11,{42}};std::string error;bool ok=recording::DecodeInjectedFrame(fd,st.st_size,966666667,&out,&error,{},5000,recording::VisualDecodePolicy::SoftwareOnly);bool pass=!ok&&error==argv[2]&&out.width==7&&out.rgb==std::vector<std::uint8_t>{42}&&lseek(fd,0,SEEK_CUR)==37;close(fd);std::cout<<"injected result="<<ok<<" error="<<error<<" unchanged="<<pass<<std::endl;return pass?0:1;}
'''
(r/'negative.cpp').write_text(harness)
for name in ['missing-property','no-decoder']:
 variant=src.replace('"force-sw-decoders"','"test-absent-property"') if name=='missing-property' else src.replace('    Context context{', '''    // 시험 사본에서만 모든 video decoder 후보를 unavailable로 만든다. registry/rank 변경은 없다.
    g_signal_connect(decode,"autoplug-select",G_CALLBACK(+[](GstElement*,GstPad*,GstCaps*,GstElementFactory* factory,gpointer)->gint{
        const auto* klass=gst_element_factory_get_metadata(factory,GST_ELEMENT_METADATA_KLASS);
        return klass&&std::strstr(klass,"Decoder")&&std::strstr(klass,"Video")?2:0;
    }),nullptr);
    Context context{''')
 (r/(name+'.cpp')).write_text(variant)
 compiler=(r/'compile.py').read_text().replace('sys.argv[1],*libs',f"sys.argv[1],str(pathlib.Path(__file__).parent/'{name}.cpp'),*libs")
 (r/(name+'-compile.py')).write_text(compiler)
 subprocess.run(['python3',str(r/'capture.py'),'compile-'+name,'python3',str(r/(name+'-compile.py')),str(r/'negative.cpp'),str(r/name)],check=True)
