from pathlib import Path
import subprocess,tarfile,hashlib,json,shutil
r=Path(__file__).parent;i=r/'inputs';i.mkdir(exist_ok=True)
paths=[p for p in subprocess.check_output(['git','ls-files'],text=True).splitlines() if p.startswith(('src/','include/','cmake/')) or p in ('CMakeLists.txt','VERSION')]
paths += ['scripts/internal/visual_frame_decoder_smoke.cpp','scripts/internal/recording_visual_source_smoke.cpp','scripts/internal/recording_media_test_fixture.h']
with tarfile.open(i/'linux-source.tar.gz','w:gz') as t:
 for p in paths:t.add(p,arcname=p)
(i/'source-manifest.json').write_text(json.dumps([[p,hashlib.sha256(Path(p).read_bytes()).hexdigest()] for p in paths],indent=2))
shutil.copyfile(r/'compile.py',i/'compile.py')
(i/'configure.sh').write_text((r/'prior/inputs/configure.sh').read_text().replace('linux71','linux72'))
