from pathlib import Path
import hashlib,json,tarfile,io,re,subprocess
r=Path('/private/tmp/media-server-release72-_yo80e2o'); dst=Path('docs/release-artifacts/v4.5.0'); entries={}
h=lambda b:hashlib.sha256(b).hexdigest()
def add(p,name=None):
 p=Path(p); assert p.is_file() and not p.is_symlink(); entries[name or str(p.relative_to(r))]=p.read_bytes()
def put(name,j): entries[name]=(json.dumps(j,ensure_ascii=False,indent=2)+'\n').encode()
for p in (r/'commands').iterdir(): add(p)
for p in r.iterdir():
 if p.is_file() and (p.suffix in ('.py','.sh','.cpp','.diff') or p.name in ['ownership.json','preservation-preparation.json','comparison-freeze.json','comparison-execution-freeze.json','comparison-results.json','comparison-summary.json','rgb-comparison.json','mode-results.json','old-package-preparation.json','execution-source.json','review-freeze.json','run-analysis.json','review72-initial.json','review72-final.json','auto.stdout','auto.stderr','software.stdout','software.stderr','decodebin-inspect.txt']): add(p)
for p in (r/'inputs').iterdir():
 if p.suffix in ('.json','.sh','.py','.cpp'): add(p)
for n in ['execution.json','run.log','owned-recovery-groups.jsonl']: add(r/'short-mixed'/n)
for p in (r/'short-mixed/artifacts').iterdir(): add(p)
for p in (r/'replay/diagnostic-evidence').glob('*.evp'): add(p)
add(r/'replay/journal.jsonl'); add(r/'mixed-binding.json')
# The real mixed output is synthetic, source-bound A evidence; preserve seven executed results only.
report=json.loads((r/'short-mixed/artifacts/report.json').read_text())
body=(r/'short-mixed/run.log').read_text()
result_ids={x['reviewId'] for x in report['aLoad']['completed']}
owned=r/'short-mixed/media-server-current-observer-Ocx0pF'
selected=[]
for p in (owned/'recordings/va-reviews').glob('*.review'):
 if p.stem not in result_ids: continue
 add(p,'mixed-selected/va-reviews/'+p.name)
 pkg=re.search(rb'ep-[0-9a-f]{64}',p.read_bytes()).group().decode()
 q=owned/'recordings/evidence-packages'/(pkg+'.evp'); add(q,'mixed-selected/evidence-packages/'+q.name)
 selected.append({'result':p.name,'package':q.name})
put('mixed-selected/index.json',{'scope':'IDs in report.aLoad.completed; not pre-seeded results','results':selected})
raw=owned/'server-1.private.log'; data=raw.read_bytes(); out=[]; redacted=[]; offset=0
prefixes=(b'[visual-frame] ',b'[recording-evidence] ',b'[recording-completion] ',b'[recording-latency] ',b'[recording-slow-summary] ')
for i,line in enumerate(data.splitlines(keepends=True),1):
 if line.startswith(prefixes) and not re.search(rb'[A-Za-z][A-Za-z0-9+.-]*://',line): out.append(line)
 else:
  redacted.append({'line':i,'offset':offset,'bytes':len(line),'sha256':h(line)})
  out.append(f'[redacted-private-setting-line {i}]\n'.encode())
 offset+=len(line)
clean=b''.join(out); entries['short-mixed/server-1.sanitized.log']=clean
privacy={'originalPath':str(raw.relative_to(r)),'originalBytes':len(data),'originalSha256':h(data),'preservedBytes':len(clean),'preservedSha256':h(clean),'transform':'retain diagnostic-prefix lines without URI; replace other boot/config/source lines by numbered markers','removedLines':redacted,'sameBytes':False,'uncapturedTail':'not available; not reconstructed','credentialsAndAuthStores':'not included'}
put('privacy.json',privacy)
c=json.loads((r/'candidate.json').read_text()); m=json.loads((r/'migration.json').read_text())
put('approval-reference.json',{'candidateSha256':h((r/'candidate.json').read_bytes()),'candidateDigest':c['candidateDigest'],'baselineCandidateDigest':m['baselineCandidateDigest'],'freshCandidateDigest':m['freshCandidateDigest'],'migrationSha256':h((r/'migration.json').read_bytes()),'rows':m['rows'],'strictCarryEligible':len(m['carryForwardEligible']),'independentRequired':len(m['independentReviewRequired']),'producerApplied':False,'boundary':'legacy unchanged digest is not approval of new decoder policy; independent source/evidence review required, integration acceptance blocked','commands':'commands/candidate.json and commands/migration.json; no duplicate 986-row artifact'})
put('historical-reference.json',{'input':{'archive':'70-execution.tar.gz','member':'mixed/selected/input/a-seed.mp4','bytes':28161,'sha256':'51574640bd6e851078347ba66376463a1c74f455efd5b123e528bd7899132091'},'oldPackage':{'archive':'71-execution.tar.gz','sha256':'1e970d0a7786acb7f626dc166e1aa7ede09ba6a973553b2bf7246987562e263d','disposition':'existing bytes reused, not copied into this archive'},'pastFailures':'70/71 retained unchanged; hardware internal cause unknown'})
# Reject known credential-bearing content, not ordinary source code mentioning an error contract.
privacy_hits=[]
for n,b in entries.items():
 if n.endswith(('.log','.stdout','.stderr','.evp','.review')):
  patterns=[rb'Bearer\s+[A-Za-z0-9._-]{8,}',rb'\$argon2[id]+\$',rb'"(?:passwordHash|tokenHash|passwordHistory)"\s*:',rb'rtsp://[^\s"\']+']
  if any(re.search(x,b,re.I) for x in patterns): privacy_hits.append(n)
assert not privacy_hits,privacy_hits
manifest=[{'path':n,'bytes':len(b),'sha256':h(b)} for n,b in sorted(entries.items())]
put('archive-manifest.json',{'members':manifest,'rawVersusSanitized':'privacy.json','selection':'new receipts/direct comparisons/minimal synthetic A outputs; no binaries/models/old archive copies'})
archive=dst/'72-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,b in sorted(entries.items()):
  info=tarfile.TarInfo(n); info.size=len(b); info.mode=0o600; info.mtime=0;t.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(entries)
 for n,b in entries.items(): assert t.extractfile(n).read()==b,n
receipt={'path':str(archive),'bytes':archive.stat().st_size,'sha256':h(archive.read_bytes()),'members':len(entries),'uncompressedBytes':sum(map(len,entries.values())),'byteReadback':True,'maxMemberBytes':max(map(len,entries.values())),'privacyHits':privacy_hits,'selectedResults':len(selected),'privacy':{k:v for k,v in privacy.items() if k!='removedLines'}}
(r/'preservation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n'); print(json.dumps(receipt,ensure_ascii=False,indent=2))
