#include "recording/evidence_package_store.h"
#include <iostream>
int main(int argc,char**argv){if(argc!=2)return 2;recording::EvidencePackageStore store(argv[1],{});std::string error;std::vector<std::string> ids;if(!store.Recover(&error)||!store.ListIds(&ids,&error)||ids.size()!=1)return 1;auto f=store.Open(ids[0],&error);if(!f||f->manifest().frames.size()!=1)return 1;const auto& v=f->manifest().frames.front();if(v.sample_ordinal!=30||v.pts_ns!=7966666666||v.presentation_ns!=966666666)return 1;std::cout<<"PASS independent package readback "<<ids[0]<<" rgb="<<v.rgb_sha256<<"\n";}
