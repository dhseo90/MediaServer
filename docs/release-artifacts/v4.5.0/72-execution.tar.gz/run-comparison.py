import pathlib,subprocess,json,hashlib,time,os,signal
r=pathlib.Path(__file__).parent;deadline=time.monotonic()+600;results=[]
meta={'binarySha256':hashlib.sha256((r/'compare').read_bytes()).hexdigest(),'runtimeSha256':hashlib.sha256(pathlib.Path('build-gst-onnx/libmedia_server_runtime.a').read_bytes()).hexdigest(),'uid':os.getuid(),'cwd':os.getcwd(),'env':'same env.sh/private registry/full trace; no rank overrides'}
(r/'comparison-execution-freeze.json').write_text(json.dumps(meta,indent=2))
for mode in ['auto','software']:
 env=dict(os.environ,TRACE_MODE='1');start=time.monotonic();argv=['bash',str(r/'env.sh'),str(r/'compare'),mode,str(r/'mixed/selected/input/a-seed.mp4')]
 with (r/f'{mode}.stdout').open('xb') as out,(r/f'{mode}.stderr').open('xb') as err:
  p=subprocess.Popen(argv,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=max(.001,deadline-time.monotonic()))
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=10);code='bundle-timeout'
 row={'mode':mode,'argv':argv,'pid':p.pid,'exit':code,'elapsedSeconds':time.monotonic()-start}
 results.append(row);(r/'comparison-results.json').write_text(json.dumps(results,indent=2))
 print(json.dumps(row),flush=True)
 if code=='bundle-timeout':break
