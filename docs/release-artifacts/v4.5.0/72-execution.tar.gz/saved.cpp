#include "recording/visual_frame_decoder.h"
#include "recording/evidence_frame_extractor.h"
#include "recording/evidence_package_builder.h"
#include "recording/recording_runtime_composition.h"
#include "recording/recording_search_reader.h"
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <iostream>
#include <stdexcept>
using namespace recording;
void Check(bool b,const std::string& s){if(!b)throw std::runtime_error(s);std::cout<<"PASS "<<s<<std::endl;}
int main(int argc,char**argv){try{if(argc!=3)return 2;std::string e;const std::string mode=argv[1];
 if(mode=="direct") {int fd=open(argv[2],O_RDONLY);struct stat st{};Check(fd>=0&&!fstat(fd,&st),"original open");lseek(fd,37,SEEK_SET);VisualRgbFrame out{7,9,11,{42}};
 const bool ok=DecodeVisualFrame(fd,st.st_size,966666667,&out,&e);std::cout<<"result="<<ok<<" error="<<e<<" pts="<<out.presentation_ns<<" rgb="<<EvidenceSha256(out.rgb.data(),out.rgb.size())<<std::endl;
 Check(lseek(fd,0,SEEK_CUR)==37&&fcntl(fd,F_GETFD)>=0,"caller FD/offset");close(fd);Check(ok,"saved exact decode");Check(out.presentation_ns==966666666,"original sample exact time");std::cout<<"historicalRgbEqual="<<(EvidenceSha256(out.rgb.data(),out.rgb.size())=="8a2ee77d31ada2e2f6f8175655987a9fb30e4d95f44d8b506850a59318c0a1f5")<<std::endl;return 0;}
 const std::filesystem::path root=argv[2];RecordingJournal journal(root/"journal.jsonl");const bool journal_open=journal.Open(&e);Check(journal_open,"selected journal open "+e);RecordingCatalog::Options options{root/"catalog.sqlite3",root,false};options.enable_v2_storage=true;RecordingCatalog catalog(journal,options);const bool opened=catalog.Open(&e);Check(opened,"selected journal replay "+e);RecordingReadService reader(catalog);RecordingSearchReader search(catalog,reader);std::shared_ptr<const RecordingSearchModel> model;
 Check(search.Refresh({"1"},{},&model,&e),"saved search "+e);const SearchDocument* hit=nullptr;for(const auto& d:model->documents())if(d.id=="or:36:obs-e0feb8b49b3c653f2db2c25cacec482e")hit=&d;Check(hit!=nullptr,"same original hit");
 EvidencePackageStore store(root/"diagnostic-evidence",{});Check(store.Recover(&e),"store recover "+e);
 if(mode=="package") {EvidenceFrameExtractor extractor(catalog,reader);EvidenceFrameV1 frame;const bool extracted=extractor.ExtractMedia("1","2181136d-b440-428b-8345-f3854aaa262c",7966666666,"3d2135fbf45804087aa7c2d451c92bbd29755e1cac1e487604ee43f7fbd5989d",&frame,&e,std::chrono::steady_clock::now()+std::chrono::seconds(30));Check(extracted,"actual extractor "+e);
 Check(frame.sample_ordinal==30&&frame.presentation_ns==966666666,"extract original sample and exact presentation");EvidencePackageBuilder builder(catalog,reader,store);EvidencePackageV1 manifest;std::string id;const bool made=builder.CreateWithObservations(*hit,"structured","",&id,&manifest,&e,std::chrono::steady_clock::now()+std::chrono::seconds(30));Check(made,"actual package "+e);Check(manifest.frames.size()==1&&manifest.frames[0].rgb_sha256==frame.rgb_sha256,"package same sample");std::cout<<"rgb="<<frame.rgb_sha256<<" png="<<frame.png_sha256<<" pts="<<frame.presentation_ns<<" package="<<id<<std::endl;return 0;}
 return 2;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<std::endl;return 1;}}
