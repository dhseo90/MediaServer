import fs from "node:fs";
import {runCurrentRecovery} from "file:///Users/dhseo/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs";
await runCurrentRecovery({command:process.execPath,args:["-e","setInterval(()=>{},1000)"],observe:()=>null,onGroup:e=>{fs.appendFileSync("/private/tmp/media-server-release73-9y2a17vq/launcher-checks/fixture-h4xdl0xe/recovery-groups.jsonl",JSON.stringify(e)+"\n");if(e.event==="started"){while(true){}}}});
