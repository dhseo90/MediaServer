import subprocess,time,os,signal,json,hashlib,pathlib
r=pathlib.Path(__file__).parent
cmd=['bash',str(r/'run-after.sh')]
start=time.monotonic();reason=None
with (r/'after.log').open('wb') as out:
 p=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if time.monotonic()-start>180:reason='timeout'
  if out.tell()>4194304:reason='log-cap'
  if reason:os.killpg(p.pid,signal.SIGTERM);break
  time.sleep(.1)
 try:code=p.wait(timeout=5)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
if (r/'after.log').stat().st_size>4194304:reason='log-cap'
result={'command':cmd,'uid':os.getuid(),'exit':code,'reason':reason,'elapsedSeconds':time.monotonic()-start,'bytes':(r/'after.log').stat().st_size,'sha256':hashlib.file_digest((r/'after.log').open('rb'),'sha256').hexdigest()}
(r/'after-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(code or bool(reason))
