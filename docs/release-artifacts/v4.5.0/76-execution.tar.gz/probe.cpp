// Bounded diagnostic: actual generation API; access headers only expose unchanged layout.
#include "scale-reference.cpp"
#include <malloc/malloc.h>
#include <mach/mach.h>
namespace recording { void Memory76Journal(const RecordingJournal&); }
void Sample(const char* stage,std::size_t n,const recording::RecordingRuntimeStorage* runtime=nullptr){
 malloc_statistics_t m{};malloc_zone_statistics(nullptr,&m);task_vm_info_data_t vm{};mach_msg_type_number_t count=TASK_VM_INFO_COUNT;
 if(task_info(mach_task_self(),TASK_VM_INFO,reinterpret_cast<task_info_t>(&vm),&count)!=KERN_SUCCESS)throw std::runtime_error("memory76-task-info");
 std::cout<<"[memory76] {\"stage\":\""<<stage<<"\",\"history\":"<<n<<",\"rss\":"<<vm.resident_size<<",\"footprint\":"<<vm.phys_footprint<<",\"mallocLive\":"<<m.size_in_use<<",\"mallocReserved\":"<<m.size_allocated<<",\"mallocBlocks\":"<<m.blocks_in_use;
 if(runtime){auto& c=const_cast<recording::RecordingRuntimeStorage*>(runtime)->catalog();
 std::cout<<",\"catalogMutations\":"<<c.mutation_ids_.size()<<",\"catalogOrders\":"<<c.orders_v2_.size()<<",\"retired\":"<<c.retired_v2_.size()<<",\"sourceEntries\":"<<c.source_bindings_.size()<<",\"activeSegments\":"<<c.segments_v2_.size()<<",\"acceptedOrdinals\":"<<c.accepted_generation_ordinals_.size()<<",";
 recording::Memory76Journal(c.journal_);}
 std::cout<<"}\n";if(vm.resident_size>4294967296ULL)throw std::runtime_error("memory76-rss-limit");
}
int main(int argc,char** argv){if(argc!=2)return 2;std::cout.setf(std::ios::unitbuf);gst_init(nullptr,nullptr);::alarm(180);
 try{const std::filesystem::path base=argv[1];Sample("start",0);Output input;
 {auto packets=Encode(60,false,false,160,90,30,10000);auto outputs=Record(base/"template",packets);scale::Need(outputs.size()==1,"template");input=std::move(outputs.front());}
 std::string store,error;const auto root=base/"product";
 {recording::RecordingRuntimeStorage runtime(root);scale::Need(runtime.Open(&error),error.c_str());store=runtime.journal().ManagedStoreId();auto& c=runtime.catalog();std::filesystem::create_directories(root/"probe-channel");
 for(std::size_t i=1;i<=2048;++i){auto expected=scale::Expected(input,root,store,i);std::filesystem::copy_file(input.file,expected.file);RecordingOrderReservationV1 order;
 scale::Need(c.ReserveRecordingOrder(store,expected.segment.order_request_id,expected.segment.segment_id,expected.segment.channel_id,&order,&error)&&order.sequence==static_cast<std::int64_t>(i),"reserve");
 scale::Need(c.FinalizeBoundSegmentV2(expected.segment,expected.binding,expected.file.string(),&error),"finalize");
 RecordingTombstoneV2 tomb;tomb.tombstone_id="deleted-"+std::to_string(i);tomb.segment=expected.segment;tomb.deletion_reason="continuous-age";tomb.deleted_at_ms=1000+i;
 scale::Need(c.RequestDeletion(expected.segment.segment_id,tomb.deletion_reason,&error)&&std::filesystem::remove(expected.file)&&c.CompleteDeletionV2(tomb,&error),"delete");
 if(i==32||i==128||i==512||i==2048){Sample("before-checkpoint",i,&runtime);scale::Need(c.Checkpoint(&error),"checkpoint");Sample("after-checkpoint",i,&runtime);scale::Size(base,i);
 for(std::size_t k:{std::size_t(1),i/2,i}){auto e=scale::Expected(input,root,store,k);scale::Need(c.IsDeletedSegmentId(e.segment.segment_id)&&!c.FindSegmentMediaLocation(e.segment.segment_id),"history-deleted");RecordingOrderReservationV1 old;
 scale::Need(c.ReserveRecordingOrder(store,e.segment.order_request_id,e.segment.segment_id,e.segment.channel_id,&old,&error)&&old.sequence==static_cast<std::int64_t>(k),"historical-reservation");scale::Need(!c.ReserveRecordingOrder(store,e.segment.order_request_id,"conflict",e.segment.channel_id,&old,&error),"historical-conflict");}
 }
 }
 Sample("idle",2048,&runtime);}
 Sample("released",2048);
 {recording::RecordingRuntimeStorage runtime(root);scale::Need(runtime.Open(&error),"reopen");Sample("reopened",2048,&runtime);scale::Need(runtime.catalog().IsDeletedSegmentId("scale-1")&&runtime.catalog().IsDeletedSegmentId("scale-2048"),"reopen-deleted");}
 Sample("released-again",2048);::alarm(0);std::cout<<"[memory76-result] history-readback=pass\n";return 0;
 }catch(const std::exception& e){std::cerr<<"[memory76-fail] "<<e.what()<<" phase="<<scale::phase<<'\n';return 1;}}
