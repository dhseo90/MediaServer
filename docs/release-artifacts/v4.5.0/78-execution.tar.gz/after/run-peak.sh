#!/usr/bin/env bash
set -euo pipefail
r=/private/tmp/media-server-memory78-j4nkjfzz/after
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache" MEDIA_SERVER_GST_PLUGIN_PROFILE=headless GST_REGISTRY="$r/registry.bin" GST_REGISTRY_1_0="$r/registry.bin"
unset GST_PLUGIN_PATH GST_PLUGIN_PATH_1_0 GST_PLUGIN_SYSTEM_PATH GST_PLUGIN_SYSTEM_PATH_1_0 MEDIA_SERVER_GST_MANAGED_REGISTRY MEDIA_SERVER_GST_MANAGED_PLUGIN_PATH MEDIA_SERVER_GST_INPUT_PLUGIN_PATH
source /Users/dhseo/Workspace/mediaServer/scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
exec "$r/probe-after" "$r/run-peak"
