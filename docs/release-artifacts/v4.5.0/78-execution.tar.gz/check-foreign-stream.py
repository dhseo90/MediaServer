from pathlib import Path
import tarfile,sys,json,hashlib
r=Path('/private/tmp/media-server-memory78-j4nkjfzz');expected={x['path']:x for x in json.loads((r/'foreign-before.json').read_text())};actual={}
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|*') as t:
 for m in t:
  if m.isfile():
   p=Path(m.name);key=str(Path(*p.parts[1:]));actual[key]={'bytes':m.size,'sha256':hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()}
assert set(actual)==set(expected),(set(actual)-set(expected),set(expected)-set(actual))
assert all(actual[k]['bytes']==expected[k]['bytes'] and actual[k]['sha256']==expected[k]['sha256'] for k in actual)
result={'status':'PASS','comparedFiles':len(actual),'bytes':sum(x['bytes'] for x in actual.values()),'method':'Docker tar stream readback, no extraction of read-only directories','contentChanged':[]}
(r/'foreign-stream-readback.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
