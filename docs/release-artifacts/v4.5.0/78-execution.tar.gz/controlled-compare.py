import subprocess,time,os,signal,json,hashlib,pathlib
r=pathlib.Path(__file__).parent
results=[]
for side in ['before','after']:
 cmd=['bash',str(r/side/'run-final.sh')];start=time.monotonic();reason=None;log=r/(side+'-controlled.log')
 with log.open('xb') as out:
  p=subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   if time.monotonic()-start>180:reason='timeout'
   if log.stat().st_size>4194304:reason='log-cap'
   if reason:os.killpg(p.pid,signal.SIGTERM);break
   time.sleep(.1)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
 if log.stat().st_size>4194304:reason='log-cap'
 result={'side':side,'command':cmd,'uid':os.getuid(),'exit':code,'reason':reason,'elapsedSeconds':time.monotonic()-start,'bytes':log.stat().st_size,'sha256':hashlib.file_digest(log.open('rb'),'sha256').hexdigest()}
 (r/(side+'-controlled-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);results.append(result)
 if code or reason:raise SystemExit(code or 1)
