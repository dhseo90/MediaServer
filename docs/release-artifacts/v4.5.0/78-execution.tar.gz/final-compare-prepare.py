from pathlib import Path
import shutil,json,subprocess
r=Path('/private/tmp/media-server-memory78-j4nkjfzz'); repo=Path.cwd()
a=r/'after'
# Keep the exact first observer; refresh only product source and ABI headers.
s=(a/'recording_journal-after.cpp').read_text();observer=s[s.rindex('\nnamespace recording { void Memory76Journal'):]
(a/'recording_journal-after.cpp').write_text('#include <iostream>\n'+(repo/'src/recording/recording_journal.cpp').read_text()+observer)
for p in (repo/'include').rglob('*'):
 if p.is_file():
  q=a/'include'/p.relative_to(repo/'include');q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for name in ['recording_journal.h','recording_catalog.h']:
 p=a/'include/recording'/name;p.write_text(p.read_text().replace('private:','public:'))
for side in ['before','after']:
 p=r/side/'probe.cpp';s=p.read_text();s=s.replace('#include <mach/mach.h>','#include <mach/mach.h>\n#include <sys/resource.h>\n#include <libproc.h>')
 s=s.replace(' malloc_statistics_t m{};', ' static const auto epoch=std::chrono::steady_clock::now();\n struct rusage usage{};if(getrusage(RUSAGE_SELF,&usage))throw std::runtime_error("rusage");\n const int fdbytes=proc_pidinfo(getpid(),PROC_PIDLISTFDS,0,nullptr,0);if(fdbytes<=0)throw std::runtime_error("fd observation");\n malloc_statistics_t m{};')
 s=s.replace('<<m.blocks_in_use;', '<<m.blocks_in_use<<",\\\"rssHighWater\\\":"<<usage.ru_maxrss<<",\\\"fdCount\\\":"<<fdbytes/sizeof(proc_fdinfo)<<",\\\"elapsedMs\\\":"<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-epoch).count();')
 p.write_text(s)
 run=(r/side/'run.sh').read_text();run=run.replace('"$r/run-abi-fixed"','"$r/run-final"').replace('"$r/run"','"$r/run-final"');(r/side/'run-final.sh').write_text(run)
 for cmd in json.loads((r/(side+'-build-commands.json')).read_text()):
  with (r/(side+'-build-final.log')).open('ab') as out:
   result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
  if result.returncode:raise SystemExit(result.returncode)
print('both final probes compiled')
