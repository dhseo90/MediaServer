from pathlib import Path
import json,subprocess
r=Path('/private/tmp/media-server-memory78-j4nkjfzz')
commands=[]
base=json.loads((r/'before-build-commands.json').read_text()); compile=base[0];extra=[]
for name in ['recording_catalog','recording_identity_shard','recording_runtime_composition']:
 p=r/'before'/(name+'.cpp');p.write_bytes(subprocess.check_output(['git','show','12a47d81:src/recording/'+name+'.cpp']))
 cmd=compile.copy();cmd[cmd.index('-c')+1]=str(p);cmd[-1]=str(r/'before'/(name+'.o'));extra.append(cmd[-1]);commands.append(cmd)
commands.append(compile)
link=base[1];at=link.index('/Users/dhseo/Workspace/mediaServer/build-gst-onnx/libmedia_server_runtime.a');link[at:at]=extra;commands.append(link)
commands+=json.loads((r/'after-build-commands.json').read_text())
(r/'final-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
with (r/'final-build.log').open('wb') as out:
 for cmd in commands:
  p=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(p.returncode)
print('final comparison probes compiled; baseline source overrides four changed runtime translation units')
