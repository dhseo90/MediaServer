#include "recording/recording_journal.h"
#include <iostream>
#include <limits>
#include <sys/stat.h>
#include <unistd.h>
namespace recording { struct RecordingJournalGenerationReadOnlyProbe {
 static bool Read(RecordingJournal& j,const std::string& id,std::string* error){RecordingMutationLink link;RecordingMutationHandle value;
 return j.MakeGenerationMutationLink(id,&link,error)&&j.AcquireMutationLink(link,&value,error)&&value&&value->mutation_id==id;}
}; }
int main(int argc,char** argv){if(argc!=3)return 2;struct stat st{};if(stat(argv[1],&st))return 3;std::cout<<"precondition uid="<<getuid()<<" sourceUid="<<st.st_uid<<" writable="<<(access(argv[1],W_OK)==0)<<std::endl;if(st.st_uid==getuid()||access(argv[1],W_OK)==0)return 3;
 std::cout<<"uid="<<getuid()<<" sourceUid="<<st.st_uid<<" sourceWritable=false\n";
 recording::RecordingJournal j(recording::RecordingJournal::ManagedOptions{argv[1],{}, {1073741824,1073741824,1073741824,16777217,std::numeric_limits<std::size_t>::max(),std::numeric_limits<std::size_t>::max()}});
 std::string error;bool ok=j.Open(&error)&&recording::RecordingJournalGenerationReadOnlyProbe::Read(j,argv[2],&error);std::string cleanup;if(!j.Finish(&cleanup))ok=false;
 std::cout<<"foreign-owned-source-open-cold-link "<<(ok?"PASS":"FAIL")<<" error="<<error<<" cleanup="<<cleanup<<'\n';return ok?0:1;}
