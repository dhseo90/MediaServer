from pathlib import Path
import shutil,os,json,hashlib
r=Path('/private/tmp/media-server-memory78-j4nkjfzz');src=r/'after/run/product';dst=r/'foreign-source';shutil.copytree(src,dst)
for p in dst.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted(dst.rglob('*'),reverse=True):
 if p.is_dir():p.chmod(0o555)
(dst/'.recording-store-lease').chmod(0o666);dst.chmod(0o555)
ids=[]
for p in sorted(dst.glob('identity-*.jsonl')):
 d=json.loads(p.read_text());
 if d['rows']:ids.append(d['rows'][0]['mutationId'])
(r/'foreign-id.txt').write_text(ids[0]+'\n')
rows=[{'path':str(p.relative_to(dst)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'uid':p.stat().st_uid,'mode':oct(p.stat().st_mode&0o777)} for p in sorted(dst.rglob('*')) if p.is_file()]
(r/'foreign-before.json').write_text(json.dumps(rows,indent=2)+'\n')
