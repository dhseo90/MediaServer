#include "recording_catalog_cost_probe_timer.h"
#include <iostream>
// 파일 요약: 녹화 JSONL mutation을 memory/SQLite projection에 적용한다.
// 동작 요약: idempotent replay, FK 검증, 손상 DB 격리와 range query parity를 구현한다.
#include "recording/recording_catalog.h"
#include "recording/recording_search_model.h"
#include "recording/recording_latency_trace.h"
#include "recording/recording_completion_trace.h"
#include "recording_checkpoint_validation.h"
#include "recording_catalog_history.h"
#include "recording_derived_job_context.h"
#include "recording/recording_finalize_ticket.h"
#include "recording/recording_presentation_interval.h"
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND
#include "recording/recording_generation_recovery_session.h"
#endif

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstring>
#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <type_traits>

#if defined(__APPLE__) || defined(__linux__)
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#include "domain/strict_json.h"

#ifndef MEDIA_SERVER_USE_SQLITE3
#define MEDIA_SERVER_USE_SQLITE3 0
#endif

#if MEDIA_SERVER_USE_SQLITE3
#include <sqlite3.h>
#endif

namespace recording {
namespace {

class CatalogHistoryError final : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};

bool IsDerivedJobMutation(RecordingMutationType type) {
    return type==RecordingMutationType::DerivedJobIntent||type==RecordingMutationType::DerivedJobFiles||
        type==RecordingMutationType::DerivedJobReady||type==RecordingMutationType::DerivedJobCommitted||
        type==RecordingMutationType::DerivedJobComplete||type==RecordingMutationType::DerivedJobFailed;
}

std::int64_t NowMs() {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
               std::chrono::system_clock::now().time_since_epoch())
        .count();
}

bool Fail(std::string* error, const std::string& message) {
    if (error != nullptr) *error = message;
    return false;
}

std::string Escape(const std::string& value) {
    std::string out;
    for (const char ch : value) {
        if (ch == '\\') out += "\\\\";
        else if (ch == '"') out += "\\\"";
        else if (ch == '\n') out += "\\n";
        else out.push_back(ch);
    }
    return out;
}

bool MakeRetiredReceipt(const RecordingTombstoneV2& tombstone,const std::string& path,const std::string& id,
    RecordingRetiredV2Receipt* output) {
    return BuildRecordingRetiredV2Receipt(tombstone,path,id,output,nullptr);
}

bool MaterializeRetiredV2(const RecordingRetiredV2Receipt& receipt,const RecordingMutationHandle& mutation,
    RecordingTombstoneV2* output,std::string* error) {
    RecordingTombstoneV2 tomb;RecordingRetiredV2Receipt rebuilt;std::string saved,current;
    if(!output||!mutation||mutation->mutation_id!=receipt.deletion_mutation_id||mutation->entity_id!=receipt.segment_id||
       mutation->mutation_type!=RecordingMutationType::SegmentV2Deleted||!ParseRecordingTombstoneV2(mutation->payload_json,&tomb,error)||
       SerializeRecordingTombstoneV2(tomb)!=mutation->payload_json||
       !MakeRetiredReceipt(tomb,receipt.prior_relative_path,receipt.deletion_mutation_id,&rebuilt)||
       !SerializeRecordingRetiredV2Receipt(receipt,&saved,error)||!SerializeRecordingRetiredV2Receipt(rebuilt,&current,error)||saved!=current)
        return Fail(error,"retired V2 상세/영수증 불일치");
    *output=std::move(tomb);return true;
}

#if MEDIA_SERVER_USE_SQLITE3
std::string SqliteDeletionReceipt(const RecordingTombstoneV2& value) {
    return "{\"schema\":\"media-server.recording-deletion-receipt.v1\",\"segmentId\":\""+
        Escape(value.segment.segment_id)+"\",\"tombstoneId\":\""+Escape(value.tombstone_id)+
        "\",\"reason\":\""+Escape(value.deletion_reason)+"\",\"deletedAtMs\":"+
        std::to_string(value.deleted_at_ms)+"}";
}
#endif

std::string NextMutationId() {
    static std::atomic<std::uint64_t> sequence{0};
    return "mut-" + std::to_string(NowMs()) + "-" + std::to_string(++sequence);
}

bool MergeObservation(const AnalysisObservationV2& previous, AnalysisObservationV2* next,
                      std::string* error) {
    if (previous.source_id != next->source_id || previous.channel_id != next->channel_id ||
        previous.analysis_namespace != next->analysis_namespace || previous.track_id != next->track_id ||
        previous.stream_epoch_id != next->stream_epoch_id || previous.pts != next->pts)
        return Fail(error, "observation-v2-identity-mismatch");
    const auto merge = [](const auto& first, auto* second) {
        auto values = first;
        for (const auto& value : *second)
            if (std::find(values.begin(), values.end(), value) == values.end()) values.push_back(value);
        *second = std::move(values);
    };
    merge(previous.selection_reasons, &next->selection_reasons);
    merge(previous.event_ids, &next->event_ids);
    merge(previous.zone_ids, &next->zone_ids); merge(previous.line_ids, &next->line_ids);
    merge(previous.rule_ids, &next->rule_ids); merge(previous.scenario_ids, &next->scenario_ids);
    if (previous.duration_ns && !next->duration_ns) {
        next->duration_ns = previous.duration_ns;
        next->ended_reason = previous.ended_reason;
        next->first_seen_pts = previous.first_seen_pts;
        next->last_seen_pts = previous.last_seen_pts;
    }
    next->created_at_ms = previous.created_at_ms;
    AnalysisObservationV2 validated;
    return ParseAnalysisObservationV2(SerializeAnalysisObservationV2(*next), &validated, error);
}

bool MergeReferenced(const ReferencedObservationV1& previous,ReferencedObservationV1* next,std::string* error) {
    next->reference.created_at_ms=previous.reference.created_at_ms;
    if(SerializeRecordingConsumerReferenceV1(previous.reference)!=SerializeRecordingConsumerReferenceV1(next->reference))
        return Fail(error,"referenced observation original identity 변경");
    // 새 경로에서는 분류/bbox/신뢰도를 재전달로 덮지 않고 선택·event·종료정보만 병합한다.
    const auto& p=previous.observation;auto& n=next->observation;
    if(p.schema!=n.schema || p.engine_first_seen_pts!=n.engine_first_seen_pts ||
       (p.coordinates?analysis::SerializeObservationCoordinates(*p.coordinates):"") !=
       (n.coordinates?analysis::SerializeObservationCoordinates(*n.coordinates):"") || p.class_label!=n.class_label||p.confidence!=n.confidence||p.bbox.x!=n.bbox.x||p.bbox.y!=n.bbox.y||
       p.bbox.width!=n.bbox.width||p.bbox.height!=n.bbox.height)return Fail(error,"referenced observation attributes 변경");
    return MergeObservation(p,&n,error)&&ValidateReferencedObservationV1(*next,error);
}

std::optional<std::string> ObjectField(const std::string& json, const std::string& key) {
    ingress::StrictJsonObjectDocument document;
    std::string error;
    if (!ingress::ParseStrictJsonObjectDocument(json, &document, &error)) return std::nullopt;
    return ingress::StrictJsonObjectField(document, key);
}

std::optional<std::string> StringField(const std::string& json, const std::string& key) {
    ingress::StrictJsonObjectDocument document;
    std::string error;
    if (!ingress::ParseStrictJsonObjectDocument(json, &document, &error)) return std::nullopt;
    return ingress::StrictJsonStringField(document, key);
}

bool IsRecognizedMedia(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    unsigned char bytes[12]{};
    input.read(reinterpret_cast<char*>(bytes), sizeof(bytes));
    const auto count = input.gcount();
    const bool mp4 = count >= 8 && bytes[4] == 'f' && bytes[5] == 't' && bytes[6] == 'y' && bytes[7] == 'p';
    const bool webm = count >= 4 && bytes[0] == 0x1a && bytes[1] == 0x45 && bytes[2] == 0xdf && bytes[3] == 0xa3;
    return mp4 || webm;
}

bool IsSafeMediaRelpath(const std::string& value) {
    if (value.empty()) return false;
    const std::filesystem::path path(value);
    if (path.is_absolute()) return false;
    const auto normalized = path.lexically_normal();
    if (normalized.empty() || normalized == ".") return false;
    for (const auto& part : normalized) {
        if (part == "..") return false;
    }
    return true;
}

enum class CleanupMarkerOwnership {
    Legacy,
    OwnedPartial,
    Invalid,
};

struct CleanupMarkerBinding {
    CleanupMarkerOwnership ownership{CleanupMarkerOwnership::Invalid};
    std::string partial_name;
};

CleanupMarkerBinding ReadCleanupMarkerBinding(
    const std::filesystem::path& marker,
    const std::string& final_name) {
#if defined(__APPLE__) || defined(__linux__)
    const int fd = ::open(marker.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return {};
    struct stat status {};
    if (::fstat(fd, &status) != 0 || !S_ISREG(status.st_mode) || status.st_nlink != 1 ||
        status.st_size <= 0 || status.st_size > 512) {
        ::close(fd);
        return {};
    }
    std::string contents(static_cast<std::size_t>(status.st_size), '\0');
    std::size_t offset = 0;
    while (offset < contents.size()) {
        const ssize_t count = ::read(fd, contents.data() + offset, contents.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            ::close(fd);
            return {};
        }
        offset += static_cast<std::size_t>(count);
    }
    ::close(fd);
#else
    std::ifstream input(marker, std::ios::binary);
    if (!input) return {};
    std::ostringstream buffer;
    buffer << input.rdbuf();
    const std::string contents = buffer.str();
    if (contents.empty() || contents.size() > 512) return {};
#endif
    if (contents == "recording-cleanup-pending-v1\n") {
        return {CleanupMarkerOwnership::Legacy, {}};
    }
    constexpr const char* kV2Prefix = "recording-cleanup-pending-v2\npartial=";
    if (contents.rfind(kV2Prefix, 0) != 0 || contents.back() != '\n') return {};
    const std::string partial_name = contents.substr(
        std::char_traits<char>::length(kV2Prefix),
        contents.size() - std::char_traits<char>::length(kV2Prefix) - 1);
    const std::string required_prefix = final_name + ".partial.";
    if (partial_name.size() <= required_prefix.size() || partial_name.size() > 255 ||
        partial_name.rfind(required_prefix, 0) != 0 ||
        std::filesystem::path(partial_name).filename().string() != partial_name) {
        return {};
    }
    const std::string nonce = partial_name.substr(required_prefix.size());
    if (nonce.size() != 36) return {};
    for (std::size_t index = 0; index < nonce.size(); ++index) {
        const bool hyphen_position =
            index == 8 || index == 13 || index == 18 || index == 23;
        const unsigned char ch = static_cast<unsigned char>(nonce[index]);
        const bool hex = (ch >= '0' && ch <= '9') ||
                         (ch >= 'a' && ch <= 'f') ||
                         (ch >= 'A' && ch <= 'F');
        if ((hyphen_position && ch != '-') || (!hyphen_position && !hex)) return {};
    }
    if (nonce[14] != '4' ||
        (nonce[19] != '8' && nonce[19] != '9' &&
         nonce[19] != 'a' && nonce[19] != 'A' &&
         nonce[19] != 'b' && nonce[19] != 'B')) {
        return {};
    }
    return {CleanupMarkerOwnership::OwnedPartial, partial_name};
}

bool ResolveContainedMediaPath(const std::filesystem::path& root,
                               const std::filesystem::path& relative,
                               std::filesystem::path* resolved) {
    if (resolved == nullptr || !IsSafeMediaRelpath(relative.generic_string())) return false;
    std::error_code root_error;
    std::error_code media_error;
    const auto canonical_root = std::filesystem::weakly_canonical(root, root_error);
    const auto canonical_media = std::filesystem::weakly_canonical(root / relative, media_error);
    if (root_error || media_error) return false;
    const auto containment = canonical_media.lexically_relative(canonical_root);
    if (containment.empty() || containment.is_absolute()) return false;
    for (const auto& part : containment) {
        if (part == "..") return false;
    }
    *resolved = canonical_media;
    return true;
}

#if MEDIA_SERVER_USE_SQLITE3
std::string LifecycleName(RecordingLifecycle value) {
    switch (value) {
        case RecordingLifecycle::Writing: return "writing";
        case RecordingLifecycle::Finalized: return "finalized";
        case RecordingLifecycle::DeletionPending: return "deletion_pending";
        case RecordingLifecycle::Deleted: return "deleted";
        case RecordingLifecycle::Corrupt: return "corrupt";
        case RecordingLifecycle::Unknown: return "unknown";
    }
    return "unknown";
}

std::string RetentionName(RecordingRetentionClass value) {
    switch (value) {
        case RecordingRetentionClass::Continuous: return "continuous";
        case RecordingRetentionClass::Event: return "event";
        case RecordingRetentionClass::Unknown: return "unknown";
    }
    return "unknown";
}

std::string EventStatusName(EventRecordingLinkStatus value) {
    switch (value) {
        case EventRecordingLinkStatus::Pending: return "pending";
        case EventRecordingLinkStatus::Complete: return "complete";
        case EventRecordingLinkStatus::Partial: return "partial";
        case EventRecordingLinkStatus::Failed: return "failed";
        case EventRecordingLinkStatus::Unknown: return "unknown";
    }
    return "unknown";
}

bool Exec(sqlite3* db, const std::string& sql, std::string* error) {
    char* raw_error = nullptr;
    const int rc = sqlite3_exec(db, sql.c_str(), nullptr, nullptr, &raw_error);
    if (rc == SQLITE_OK) return true;
    const std::string message = raw_error != nullptr ? raw_error : sqlite3_errmsg(db);
    sqlite3_free(raw_error);
    return Fail(error, message);
}

void BindText(sqlite3_stmt* statement, int index, const std::string& value) {
    sqlite3_bind_text(statement, index, value.c_str(), -1, SQLITE_TRANSIENT);
}
#endif

}  // namespace

RecordingCatalog::RecordingCatalog(RecordingJournal& journal, Options options)
    : journal_(journal), options_(std::move(options)) {}
#if MEDIA_SERVER_RECORDING_GENERATION_TESTING
std::function<void(sqlite3*)> RecordingCatalog::generation_sqlite_open_hook_;
#endif


std::optional<RecordingIdentityFirstAcceptance> RecordingCatalog::VisibleFirstLocked(const std::string& id) const {
    if(!completed_history_||!generation_visible_ordinal_)return {};
    std::optional<RecordingIdentityFirstAcceptance> value;std::string error;
    if(!journal_.FindGenerationFirst(id,&value,&error)){derived_job_state_authoritative_=false;throw CatalogHistoryError(error);}
    if(value&&value->first_global_ordinal>*generation_visible_ordinal_)value.reset();
    return value;
}
bool RecordingCatalog::MutationSeenLocked(const std::string& id) const {
    return completed_history_?VisibleFirstLocked(id).has_value():mutation_ids_.count(id)!=0;
}
bool RecordingCatalog::AcceptedLinkLocked(const std::string& id,RecordingMutationLink* out,std::uint64_t* ordinal) const {
    if(!completed_history_){const auto found=accepted_segment_state_mutations_.find(id);if(found==accepted_segment_state_mutations_.end())return false;
        if(out)*out=found->second;
        if(ordinal){const auto i=accepted_generation_ordinals_.find(id);if(i==accepted_generation_ordinals_.end())return false;*ordinal=i->second;}return true;}
    const auto first=VisibleFirstLocked(id);if(!first||!RecordingSnapshotRequiresAcceptedState(first->first_row.type))return false;
    if(ordinal)*ordinal=first->first_global_ordinal;
    if(out){std::string error;if(!journal_.MakeGenerationMutationLink(id,out,&error)){derived_job_state_authoritative_=false;throw CatalogHistoryError(error);}}
    return true;
}
std::optional<RecordingOrderReservationV1> RecordingCatalog::OrderLocked(const std::string& id) const {
    if(!completed_history_){const auto it=orders_v2_.find(id);return it==orders_v2_.end()?std::nullopt:std::optional<RecordingOrderReservationV1>(it->second);}
    const auto first=VisibleFirstLocked(id);return first?first->first_row.reservation:std::nullopt;
}
bool RecordingCatalog::VisitAcceptedLocked(const RecordingIdentityFirstVisitor& visitor,std::string* error) const {
    if(!completed_history_)return Fail(error,"accepted cursor requires generation history");
    return journal_.VisitGenerationFirst([&](const auto& first,std::string* detail){
        return !generation_visible_ordinal_||first.first_global_ordinal>*generation_visible_ordinal_||
            !RecordingSnapshotRequiresAcceptedState(first.first_row.type)||visitor(first,detail);
    },error);
}
bool RecordingCatalog::VisitOrdersLocked(const std::function<bool(const RecordingOrderReservationV1&,std::string*)>& visitor,std::string* error) const {
    if(!completed_history_){for(const auto& item:orders_v2_)if(!visitor(item.second,error))return false;return true;}
    return journal_.VisitGenerationFirst([&](const auto& first,std::string* detail){
        return !generation_visible_ordinal_||first.first_global_ordinal>*generation_visible_ordinal_||!first.first_row.reservation||visitor(*first.first_row.reservation,detail);
    },error);
}
std::optional<RecordingRetiredV2Receipt> RecordingCatalog::RetiredLocked(const std::string& id) const {
    if(!completed_history_){const auto i=retired_v2_.find(id);return i==retired_v2_.end()?std::nullopt:std::optional<RecordingRetiredV2Receipt>(i->second);}
    std::string bytes,error;bool found=false;
    if(!completed_history_->Get("retired-v2",id,&bytes,&found,&error)){derived_job_state_authoritative_=false;throw CatalogHistoryError(error);}
    if(!found)return {};
    RecordingRetiredV2Receipt value;if(!ParseRecordingRetiredV2Receipt(bytes,&value,&error)||value.segment_id!=id){derived_job_state_authoritative_=false;throw CatalogHistoryError("retired history domain mismatch");}
    return value;
}
bool RecordingCatalog::StoreRetiredLocked(const RecordingRetiredV2Receipt& value,const RecordingMutationLink& link,std::string* error) {
    if(!completed_history_){if(!retired_v2_.emplace(value.segment_id,value).second)return false;retired_v2_links_[value.segment_id]=link;return true;}
    if(RetiredLocked(value.segment_id))return Fail(error,"retired history collision");
    std::string bytes;return SerializeRecordingRetiredV2Receipt(value,&bytes,error)&&completed_history_->Put("retired-v2",value.segment_id,bytes,error);
}
bool RecordingCatalog::EraseRetiredLocked(const std::string& id,std::string* error){
    if(!completed_history_){retired_v2_.erase(id);retired_v2_links_.erase(id);return true;}
    return completed_history_->Put("retired-v2",id,{},error);
}
bool RecordingCatalog::VisitRetiredLocked(const std::function<bool(const std::string&,const RecordingRetiredV2Receipt&,std::string*)>& visitor,std::string* error,bool event_candidates_only)const {
    if(!completed_history_){for(const auto& item:retired_v2_)if(!visitor(item.first,item.second,error))return false;return true;}
    return completed_history_->VisitRetired([&](const std::string& id,const std::string& bytes,std::string* detail){
        RecordingRetiredV2Receipt value;return ParseRecordingRetiredV2Receipt(bytes,&value,detail)&&value.segment_id==id&&visitor(id,value,detail);
    },event_candidates_only,error);
}
std::optional<RecordingCatalog::SourceBindingEntry> RecordingCatalog::SourceEntryLocked(const std::string& id)const {
    const auto live=source_bindings_.find(id);if(live!=source_bindings_.end())return live->second;
    if(!completed_history_)return {};
    std::string bytes,error;bool found=false;if(!completed_history_->Get("source-binding",id,&bytes,&found,&error)){derived_job_state_authoritative_=false;throw CatalogHistoryError(error);}
    if(!found)return {};
    RecordingCatalogSourceSummary value;SourceBindingEntry entry;
    if(!ParseRecordingCatalogSourceSummary(bytes,&value,&error)||value.id!=id||!journal_.MakeGenerationMutationLink(value.latest_mutation_id,&entry.mutation,&error)){
        derived_job_state_authoritative_=false;throw CatalogHistoryError("source history domain/link unavailable");}
    entry.id=value.id;entry.channel=value.channel;entry.source=value.source;entry.generation=value.generation;entry.track=value.track;
    entry.order=value.order;entry.sample_count=value.sample_count;entry.latest_mutation_id=value.latest_mutation_id;return entry;
}
bool RecordingCatalog::StoreSourceEntryLocked(SourceBindingEntry value,std::string* error){
    if(completed_history_){std::string bytes;
        if(!SerializeRecordingCatalogSourceSummary({value.id,value.channel,value.source,value.generation,value.track,value.order,value.sample_count,value.latest_mutation_id},&bytes,error)||
           !completed_history_->Put("source-binding",value.id,bytes,error))return false;}
    source_bindings_[value.id]=std::move(value);return true;
}
bool RecordingCatalog::VisitSourcesLocked(const std::function<bool(const std::string&,const SourceBindingEntry&,std::string*)>& visitor,std::string* error) const {
    if(!completed_history_){for(const auto& item:source_bindings_)if(!visitor(item.first,item.second,error))return false;return true;}
    return completed_history_->Visit("source-binding",[&](const std::string& id,const std::string&,std::string* detail){
        const auto entry=SourceEntryLocked(id);return entry&&visitor(id,*entry,detail);
    },error);
}
std::optional<RecordingCatalog::DerivedJobEntry> RecordingCatalog::JobEntryLocked(const std::string& id) const {
    const auto live=derived_jobs_.find(id);if(live!=derived_jobs_.end())return live->second;
    if(!completed_history_)return {};
    std::string bytes,error;bool found=false;
    if(!completed_history_->Get("derived-job",id,&bytes,&found,&error)){derived_job_state_authoritative_=false;throw CatalogHistoryError(error);}
    if(!found)return {};
    RecordingCatalogJobSummary value;DerivedJobEntry entry;
    if(!ParseRecordingCatalogJobSummary(bytes,&value,&error)||value.id!=id||
       (value.state!=DerivedJobState::Complete&&value.state!=DerivedJobState::Failed)||
       !journal_.MakeGenerationMutationLink(value.latest_mutation_id,&entry.mutation,&error)){
        derived_job_state_authoritative_=false;throw CatalogHistoryError("job history domain/link unavailable");}
    entry.id=std::move(value.id);entry.channel=std::move(value.channel);entry.reference=std::move(value.reference);
    entry.state=value.state;entry.files=value.files;entry.reserved_bytes=value.reserved_bytes;
    entry.output_ids=std::move(value.output_ids);entry.source_ids=std::move(value.source_ids);entry.latest_mutation_id=std::move(value.latest_mutation_id);
    return entry;
}
bool RecordingCatalog::EvictCompletedJobLocked(const std::string& id,std::string* error) {
    const auto found=derived_jobs_.find(id);
    if(!completed_history_||found==derived_jobs_.end()||found->second.Active())return true;
    const auto& j=found->second;std::string bytes;
    if(!SerializeRecordingCatalogJobSummary({j.id,j.channel,j.reference,j.state,j.files,j.reserved_bytes,j.output_ids,j.source_ids,j.latest_mutation_id},&bytes,error)||
       !completed_history_->Put("derived-job",id,bytes,error)||!completed_history_->Put("job-reference",j.reference,"true",error))return false;
    for(const auto& output:j.output_ids)if(!completed_history_->Put("job-output",output,"true",error))return false;
    derived_jobs_.erase(found);return true;
}
bool RecordingCatalog::VisitJobsLocked(const std::function<bool(const std::string&,const DerivedJobEntry&,std::string*)>& visitor,std::string* error) const {
    for(const auto& item:derived_jobs_)if(!visitor(item.first,item.second,error))return false;
    if(!completed_history_)return true;
    return completed_history_->Visit("derived-job",[&](const std::string& id,const std::string&,std::string* detail){
        if(derived_jobs_.count(id))return Fail(detail,"job resident/history overlap");
        const auto entry=JobEntryLocked(id);return entry&&visitor(id,*entry,detail);
    },error);
}
bool RecordingCatalog::JobOwnsLocked(const std::string& kind,const std::string& id) const {
    for(const auto& item:derived_jobs_) {
        if(kind=="job-reference"&&item.second.reference==id)return true;
        if(kind=="job-output"&&std::find(item.second.output_ids.begin(),item.second.output_ids.end(),id)!=item.second.output_ids.end())return true;
    }
    if(!completed_history_)return false;
    std::string value,error;bool found=false;
    if(!completed_history_->Get(kind,id,&value,&found,&error)||(found&&value!="true")){
        derived_job_state_authoritative_=false;throw CatalogHistoryError("job ownership history invalid");}
    return found;
}
RecordingCatalog::~RecordingCatalog() {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    CloseSqliteLocked();
    journal_.DetachCatalog(this);
}

bool RecordingCatalog::BuildGenerationScratch(std::unique_ptr<RecordingCatalog>* output,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return BuildGenerationScratchLocked(output,nullptr,error);
}
bool RecordingCatalog::BuildGenerationScratchLocked(std::unique_ptr<RecordingCatalog>* output,
    std::shared_ptr<RecordingGenerationRecoverySession>* deferred,std::string* error) { fc::Scope fc_phase_scope("BuildGenerationScratchLocked");
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    if(!output||opened_||!options_.enable_v2_storage)return Fail(error,"B scratch 시작 조건 거부");
    std::shared_ptr<RecordingGenerationRecoverySession> session;
    if(!journal_.BeginGenerationRecovery(&session,error))return false;
    // 이동 이후 실패는 원래 projection으로 되돌리지 않는다. 새 Journal로만 재Open한다.
    const auto failed=[&](){journal_.FinishGenerationRecovery(session,false,nullptr);return false;};
    try {
        auto scratch=std::make_unique<RecordingCatalog>(journal_,options_);auto& p=session->projection;
        scratch->completed_history_=p.completed_history;
        if(!scratch->completed_history_) {Fail(error,"B completed history 없음");return failed();}
        if(p.manifest.cut_ordinal)scratch->generation_visible_ordinal_=p.manifest.cut_ordinal-1;
        const auto transfer=[](auto& from,auto& to){for(auto& item:from)to.emplace(item.first,std::move(item.second));from.clear();};
        transfer(p.segments,scratch->segments_);transfer(p.segments_v2,scratch->segments_v2_);
        transfer(p.states_v2,scratch->states_v2_);transfer(p.tombstones,scratch->tombstones_);
        transfer(p.tombstones_v2,scratch->tombstones_v2_);transfer(p.media_paths,scratch->media_relpaths_);
        for(auto& item:p.retired_v2) {
            RecordingMutationLink link;
            if(!journal_.MakeGenerationMutationLink(item.second.receipt.deletion_mutation_id,&link,error))return failed();
            scratch->retired_v2_.emplace(item.first,std::move(item.second.receipt));
            scratch->retired_v2_links_.emplace(item.first,std::move(link));
        }
        p.retired_v2.clear();
        transfer(p.deletion_reasons,scratch->deletion_reasons_);transfer(p.event_links,scratch->event_links_);
        transfer(p.observations,scratch->observations_);transfer(p.observations_v2,scratch->observations_v2_);
        transfer(p.consumer_references,scratch->consumer_references_);transfer(p.referenced_observations,scratch->referenced_observations_);
        transfer(p.orders,scratch->orders_v2_);
        scratch->mutation_ids_.insert(p.mutation_ids.begin(),p.mutation_ids.end());
        scratch->derived_accepted_references_.insert(p.derived_accepted_references.begin(),p.derived_accepted_references.end());
        for(const auto& item:p.accepted_states) {
            RecordingMutationLink link;if(!journal_.MakeGenerationMutationLink(item.first,&link,error))return failed();
            scratch->accepted_segment_state_mutations_.emplace(item.first,std::move(link));
            scratch->accepted_generation_ordinals_.emplace(item.first,item.second.first_global_ordinal);
        }
        for(auto& item:p.source_bindings) {
            auto& s=item.second.summary;SourceBindingEntry e;
            e.id=s.id;e.channel=s.channel;e.source=s.source;e.generation=s.generation;e.track=s.track;
            e.order=s.order;e.sample_count=s.sample_count;e.latest_mutation_id=s.latest_mutation_id;
            if(!journal_.MakeGenerationMutationLink(e.latest_mutation_id,&e.mutation,error))return failed();
            const auto warm=p.active_source_bindings.find(item.first);
            if(warm!=p.active_source_bindings.end())e.resident=std::make_shared<const RecordingSourceBindingV1>(std::move(warm->second));
            scratch->source_bindings_.emplace(item.first,std::move(e));
        }
        for(auto& item:p.derived_jobs) {
            auto& s=item.second.summary;DerivedJobEntry e;
            e.id=s.id;e.channel=s.channel;e.reference=s.reference;e.state=s.state;e.files=s.files;e.reserved_bytes=s.reserved_bytes;
            e.output_ids=std::move(s.output_ids);e.source_ids=std::move(s.source_ids);e.latest_mutation_id=s.latest_mutation_id;
            if(!journal_.MakeGenerationMutationLink(e.latest_mutation_id,&e.mutation,error))return failed();
            const auto warm=p.active_jobs.find(item.first);
            if(warm!=p.active_jobs.end())e.resident=std::make_shared<const DerivedJobRecordV1>(std::move(warm->second));
            scratch->derived_jobs_.emplace(item.first,std::move(e));
        }
        while(session->next<session->count) {
            std::shared_ptr<const RecordingGenerationRecoveryRow> row;
            if(!journal_.ReadGenerationRecovery(session,&row,error))return failed();
            if(row->retry){
                const auto next=scratch->generation_visible_ordinal_?*scratch->generation_visible_ordinal_+1:0;
                if(row->global_ordinal!=next){Fail(error,"B recovery ordinal gap");return failed();}
                scratch->generation_visible_ordinal_=row->global_ordinal;
                ++scratch->recovery_report_.duplicate_mutation_count;continue;
            }
            if(!scratch->ApplyMutationLocked(row->mutation,false,error,nullptr,{},nullptr,nullptr,nullptr,{},row.get()))return failed();
            if(scratch->accepted_segment_state_mutations_.count(row->mutation.mutation_id))
                scratch->accepted_generation_ordinals_.emplace(row->mutation.mutation_id,row->global_ordinal);
            if(!scratch->EvictCompletedJobLocked(row->mutation.entity_id,error))return failed();
            ++scratch->recovery_report_.replayed_mutation_count;
        }
        // snapshot 당시 hold는 사용하지 않는다. active를 모두 반영한 terminal 관계에서 재도출한다.
        const auto hold=[&](const std::string& id,RecordingRetentionClass retention) {
            const auto s=scratch->segments_.find(id);
            if(s==scratch->segments_.end()||s->second.lifecycle!=RecordingLifecycle::Finalized||s->second.retention_class!=retention)
                return Fail(error,"B pending hold 대상 불일치");
            auto& count=scratch->hold_counts_[id];
            if(count>=static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()))return Fail(error,"B pending hold overflow");
            ++count;return true;
        };
        for(const auto& item:scratch->event_links_) {
            const auto& link=item.second;if(link.status!=EventRecordingLinkStatus::Pending||!link.derived_segment_id)continue;
            const auto s=scratch->segments_.find(*link.derived_segment_id);
            if(s==scratch->segments_.end()||s->second.lifecycle!=RecordingLifecycle::Finalized||s->second.retention_class!=RecordingRetentionClass::Event)continue;
            const bool output_hold=link.completeness_reason=="event-catalog-finalize-recovery-pending"||
                link.completeness_reason=="event-marker-cleanup-recovery-pending"||link.completeness_reason=="event-terminal-release-recovery-pending"||
                link.completeness_reason=="event-terminal-output-release-pending";
            if(output_hold&&!hold(s->first,RecordingRetentionClass::Event))return failed();
            if(output_hold||link.completeness_reason=="event-terminal-source-release-pending")
                for(const auto& overlap:link.ordered_overlaps)if(!hold(overlap.segment_id,RecordingRetentionClass::Continuous))return failed();
        }
        // B에서 v1 resident release/SQLite/Open/cleanup 경로를 호출하지 않는다.
        // 보호 판정에 쓰는 활성 job source 상세는 검증된 resident로 유지한다.
        std::unordered_set<std::string> active_sources;
        for(const auto& item:scratch->derived_jobs_)if(item.second.Active())
            active_sources.insert(item.second.source_ids.begin(),item.second.source_ids.end());
        for(const auto& id:active_sources) {
            const auto source=scratch->source_bindings_.find(id);
            if(source==scratch->source_bindings_.end()) {Fail(error,"B 활성 job source binding 없음");return failed();}
            if(!source->second.resident) {
                SourceBindingHandle verified;
                if(!scratch->AcquireSourceBindingOwnedLocked(id,&verified,error)||!verified)return failed();
                source->second.resident=std::move(verified);
            }
        }
        for(auto& item:scratch->source_bindings_)if(!active_sources.count(item.first))item.second.resident.reset();
        for(auto& item:scratch->derived_jobs_)if(!item.second.Active())item.second.resident.reset();
        if(deferred)*deferred=session;
        else if(!journal_.FinishGenerationRecovery(session,true,error))return false;
        *output=std::move(scratch);return true;
    }catch(...){Fail(error,"B scratch 자원 실패");return failed();}
#else
    (void)output;(void)deferred;return Fail(error,"B scratch unsupported");
#endif
}

void RecordingCatalog::PublishGenerationMapsLocked(RecordingCatalog& source) noexcept {
#define MOVE_MAP(name) static_assert(noexcept(name.swap(source.name)),"B 게시 swap은 noexcept여야 한다");name.swap(source.name)
    MOVE_MAP(completed_history_);MOVE_MAP(generation_visible_ordinal_);
    MOVE_MAP(mutation_ids_);MOVE_MAP(accepted_segment_state_mutations_);MOVE_MAP(accepted_generation_ordinals_);
    MOVE_MAP(segments_);MOVE_MAP(segments_v2_);MOVE_MAP(source_bindings_);MOVE_MAP(derived_jobs_);
    MOVE_MAP(derived_accepted_references_);MOVE_MAP(states_v2_);MOVE_MAP(tombstones_v2_);MOVE_MAP(orders_v2_);
    MOVE_MAP(retired_v2_);MOVE_MAP(retired_v2_links_);
    MOVE_MAP(media_relpaths_);MOVE_MAP(hold_counts_);MOVE_MAP(deletion_reasons_);MOVE_MAP(event_links_);
    MOVE_MAP(observations_);MOVE_MAP(observations_v2_);MOVE_MAP(consumer_references_);MOVE_MAP(referenced_observations_);MOVE_MAP(tombstones_);
    MOVE_MAP(catalog_mode_);
#undef MOVE_MAP
    std::swap(generation_sqlite_db_,source.generation_sqlite_db_);
    static_assert(std::is_nothrow_swappable<RecordingCatalogRecoveryReport>::value,"B 복구 보고서 게시 noexcept 필요");
    std::swap(recovery_report_,source.recovery_report_);generation_backend_=true;
    generation_read_only_=!options_.enable_generation_writes;opened_=true;
}
bool RecordingCatalog::OpenGenerationLocked(std::string* error) { fc::Scope fc_phase_scope("OpenGenerationLocked");
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    if(!journal_.AttachGenerationCatalog(this,options_.media_root,options_.sqlite_path,options_.enable_v2_storage,error))return false;
    std::shared_ptr<RecordingGenerationRecoverySession> session;std::unique_ptr<RecordingCatalog> scratch;
    const auto failed=[&]() {
#if MEDIA_SERVER_USE_SQLITE3
        if(scratch&&scratch->generation_sqlite_db_)Exec(scratch->generation_sqlite_db_,"ROLLBACK",nullptr);
#endif
        if(session&&!session->ended)journal_.FinishGenerationRecovery(session,false,nullptr);
        journal_.DetachCatalog(this);return false;
    };
    try {
        if(options_.enable_generation_writes&&!journal_.EnableGenerationWrites(this,error))return failed();
        if(!BuildGenerationScratchLocked(&scratch,&session,error))return failed();
        if(!scratch->PrepareGenerationSqliteLocked(session,error))return failed();
        const auto commit=[&]() {
#if MEDIA_SERVER_USE_SQLITE3
            if(scratch->generation_sqlite_db_)return Exec(scratch->generation_sqlite_db_,"COMMIT",error);
#endif
            return true;
        };
        const auto publish=[&]() noexcept {PublishGenerationMapsLocked(*scratch);};
        if(!journal_.PublishGenerationCatalog(session,this,commit,publish,error))return failed();
        if(error)error->clear();
        return true;
    }catch(...){Fail(error,"B catalog Open 자원 실패");return failed();}
#else
    return Fail(error,"B catalog Open unsupported");
#endif
}
bool RecordingCatalog::PrepareGenerationSqliteLocked(const std::shared_ptr<RecordingGenerationRecoverySession>& session,std::string* error) { fc::Scope fc_phase_scope("PrepareGenerationSqliteLocked");
    catalog_mode_=options_.enable_generation_writes?"generation-jsonl":"generation-jsonl-readonly";
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_SQLITE3 && !defined(_WIN32)
    if(!options_.prefer_sqlite)return true;
    const auto path=options_.media_root/"recording-generation-catalog.sqlite3";
    int flags=SQLITE_OPEN_READWRITE|SQLITE_OPEN_CREATE;
#ifdef SQLITE_OPEN_NOFOLLOW
    flags|=SQLITE_OPEN_NOFOLLOW;
#endif
    if(sqlite3_open_v2(path.c_str(),&generation_sqlite_db_,flags,nullptr)!=SQLITE_OK) {
        if(generation_sqlite_db_)sqlite3_close(generation_sqlite_db_);
        generation_sqlite_db_=nullptr;
        if(error)error->clear();
        return true; // Open 자체 불가만 메모리 fallback이다.
    }
    auto* db=generation_sqlite_db_;
#if MEDIA_SERVER_RECORDING_GENERATION_TESTING
    auto hook=std::move(generation_sqlite_open_hook_);generation_sqlite_open_hook_={};if(hook)hook(db);
#endif
    if(!journal_.ValidateGenerationCache(session,error))return false;
    if(!Exec(db,"BEGIN IMMEDIATE",error))return false;
    const char* schema=
        "CREATE TABLE IF NOT EXISTS b_meta(schema TEXT NOT NULL,store TEXT NOT NULL,generation TEXT NOT NULL,cut TEXT NOT NULL);"
        "CREATE TABLE IF NOT EXISTS b_current(kind TEXT NOT NULL,id TEXT NOT NULL,value_json TEXT NOT NULL,PRIMARY KEY(kind,id));"
        "CREATE TABLE IF NOT EXISTS b_source_summary(id TEXT PRIMARY KEY,summary_json TEXT NOT NULL);"
        "CREATE TABLE IF NOT EXISTS b_job_summary(id TEXT PRIMARY KEY,summary_json TEXT NOT NULL);"
        "CREATE TABLE IF NOT EXISTS b_identity(id TEXT PRIMARY KEY,type TEXT NOT NULL,entity TEXT NOT NULL,occurred INTEGER NOT NULL,ordinal TEXT NOT NULL,identity TEXT NOT NULL);"
        "CREATE TABLE IF NOT EXISTS b_hold(id TEXT PRIMARY KEY,count INTEGER NOT NULL CHECK(count>=0));"
        "DELETE FROM b_meta;DELETE FROM b_current;DELETE FROM b_source_summary;DELETE FROM b_job_summary;DELETE FROM b_identity;DELETE FROM b_hold;";
    if(!Exec(db,schema,error))return false;
    const auto insert=[&](const char* sql,const std::vector<std::string>& values) {
        sqlite3_stmt* statement=nullptr;
        if(sqlite3_prepare_v2(db,sql,-1,&statement,nullptr)!=SQLITE_OK)return Fail(error,sqlite3_errmsg(db));
        bool ok=true;int index=1;
        for(const auto& value:values)if(sqlite3_bind_text(statement,index++,value.data(),static_cast<int>(value.size()),SQLITE_TRANSIENT)!=SQLITE_OK)ok=false;
        ok=ok&&sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        return ok?true:Fail(error,sqlite3_errmsg(db));
    };
    const auto& manifest=session->projection.manifest;
    if(!insert("INSERT INTO b_meta VALUES(?,?,?,?)",{"media-server.recording-generation-cache.v1",manifest.store_id,std::to_string(manifest.generation),std::to_string(manifest.cut_ordinal)}))return false;
    const auto row=[&](const std::string& kind,const std::string& id,const std::string& value) {
        return !value.empty()&&insert("INSERT INTO b_current VALUES(?,?,?)",{kind,id,value});
    };
#define CURRENT_ROWS(map,kind,serializer) for(const auto& p:map)if(!row(kind,p.first,serializer(p.second)))return false
    CURRENT_ROWS(segments_,"segment-v1",SerializeRecordingSegmentV1);
    CURRENT_ROWS(segments_v2_,"segment-v2",SerializeRecordingSegmentV2);
    CURRENT_ROWS(states_v2_,"state-v2",SerializeRecordingSegmentStateV2);
    CURRENT_ROWS(tombstones_,"tombstone-v1",SerializeRecordingTombstoneV1);
    CURRENT_ROWS(tombstones_v2_,"tombstone-v2",SerializeRecordingTombstoneV2);
    if(!VisitRetiredLocked([&](const auto& id,const auto& receipt,std::string* detail){std::string value;
        return SerializeRecordingRetiredV2Receipt(receipt,&value,detail)&&row("retired-v2",id,value);},error))return false;
    CURRENT_ROWS(event_links_,"event-link",SerializeEventRecordingLinkV1);
    CURRENT_ROWS(observations_,"observation-v1",SerializeAnalysisObservationV1);
    CURRENT_ROWS(observations_v2_,"observation-v2",SerializeAnalysisObservationV2);
    CURRENT_ROWS(consumer_references_,"consumer-reference",SerializeRecordingConsumerReferenceV1);
    CURRENT_ROWS(referenced_observations_,"referenced-observation",SerializeReferencedObservationV1);
#undef CURRENT_ROWS
    for(const auto& p:media_relpaths_)if(!row("media-path",p.first,"\""+Escape(p.second)+"\""))return false;
    for(const auto& p:deletion_reasons_)if(!row("deletion-reason",p.first,"\""+Escape(p.second)+"\""))return false;
    for(const auto& id:derived_accepted_references_)if(!row("derived-reference-accepted",id,"true"))return false;
    if(!VisitAcceptedLocked([&](const auto& first,std::string*){
        return row("accepted-state",first.mutation_id,std::to_string(first.first_global_ordinal));},error))return false;
    if(!VisitOrdersLocked([&](const auto& o,std::string*){
        return row("order",o.request_id,"{\"storeId\":\""+Escape(o.store_id)+"\",\"requestId\":\""+Escape(o.request_id)+"\",\"segmentId\":\""+Escape(o.segment_id)+"\",\"channelId\":\""+Escape(o.channel_id)+"\",\"sequence\":"+std::to_string(o.sequence)+"}");
    },error))return false;
    if(!VisitSourcesLocked([&](const auto& id,const auto& source,std::string* detail){std::string value;
        return SerializeRecordingCatalogSourceSummary({source.id,source.channel,source.source,source.generation,source.track,source.order,source.sample_count,source.latest_mutation_id},&value,detail)&&
            insert("INSERT INTO b_source_summary VALUES(?,?)",{id,value});},error))return false;
    if(!VisitJobsLocked([&](const auto& id,const auto& j,std::string* detail){std::string value;
        return SerializeRecordingCatalogJobSummary({j.id,j.channel,j.reference,j.state,j.files,j.reserved_bytes,j.output_ids,j.source_ids,j.latest_mutation_id},&value,detail)&&
            insert("INSERT INTO b_job_summary VALUES(?,?)",{id,value});},error))return false;
    for(const auto& p:hold_counts_)if(!insert("INSERT INTO b_hold VALUES(?,?)",{p.first,std::to_string(p.second)}))return false;
    if(!journal_.VisitGenerationIdentities(session,[&](const std::string& id,RecordingMutationType type,const std::string& entity,std::int64_t time,std::uint64_t ordinal,const std::string& identity) {
        return insert("INSERT INTO b_identity VALUES(?,?,?,?,?,?)",{id,RecordingMutationTypeName(type),entity,std::to_string(time),std::to_string(ordinal),identity});
    },error))return false;
    catalog_mode_=options_.enable_generation_writes?"generation-sqlite":"generation-sqlite-readonly";return true;
#else
    (void)session;(void)error;return true;
#endif
}
bool RecordingCatalog::UpdateGenerationHoldsLocked(const std::vector<std::pair<std::string,std::uint64_t>>& values,std::string* error) {
    if(!journal_.CommitGenerationProtection(this,[]{return true;},error))return false;
#if MEDIA_SERVER_USE_SQLITE3
    auto* db=generation_sqlite_db_;if(!db)return true;
    if(!Exec(db,"BEGIN IMMEDIATE",error))return false;
    for(const auto& p:values) {
        sqlite3_stmt* statement=nullptr;
        if(sqlite3_prepare_v2(db,"INSERT INTO b_hold VALUES(?,?) ON CONFLICT(id) DO UPDATE SET count=excluded.count",-1,&statement,nullptr)!=SQLITE_OK) {
            Exec(db,"ROLLBACK",nullptr);return Fail(error,sqlite3_errmsg(db));
        }
        BindText(statement,1,p.first);sqlite3_bind_int64(statement,2,static_cast<sqlite3_int64>(p.second));
        const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!ok){Exec(db,"ROLLBACK",nullptr);return Fail(error,sqlite3_errmsg(db));}
    }
    if(!journal_.CommitGenerationProtection(this,[&]{return Exec(db,"COMMIT",error);},error)){Exec(db,"ROLLBACK",nullptr);return false;}return true;
#else
    (void)values;(void)error;return true;
#endif
}

bool RecordingCatalog::Open(std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    checkpoint_cache_.reset();
    timeline_read_candidates_={};
    if (opened_) {const bool owns=journal_.OwnsCatalog(this);if(!owns)automatic_noop_eligible_=false;return owns&&(!generation_backend_||CanReadLocked(error));}
    static std::atomic<std::uint64_t> next_search_instance{1};
    search_instance_=next_search_instance.fetch_add(1);
    search_changes_.clear();search_rebuild_revision_=source_snapshot_revision_;
    search_resolution_revision_=source_snapshot_revision_;
    const bool first_open=!automatic_noop_open_attempted_;
    automatic_noop_open_attempted_=true;automatic_noop_eligible_=false;
    if(journal_.generation_state_)return OpenGenerationLocked(error);
    if(!journal_.AttachCatalog(this,options_.media_root,options_.sqlite_path,options_.enable_v2_storage,error))return false;
    if(OpenLocked(error)){automatic_noop_eligible_=first_open;return true;}
    opened_=false;checkpoint_cache_.reset();CloseSqliteLocked();journal_.DetachCatalog(this);return false;
}

bool RecordingCatalog::ValidateManagedWriterBinding(const RecordingJournal& journal,
        const std::filesystem::path& root,const std::string& store_id,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(&journal!=&journal_ || !opened_ || !options_.enable_v2_storage || !journal_.managed_ ||
       store_id.empty() || store_id!=journal_.managed_store_id_ || !CanWriteLocked(error) || !journal_.HasManagedLease())
        return Fail(error,"managed writer 소유권/옵션 결박 오류");
    std::error_code ec;const auto absolute=std::filesystem::absolute(root,ec);
    if(ec || absolute!=absolute.lexically_normal())return Fail(error,"managed writer root 정규 경로 필요");
    std::filesystem::path cursor;
    for(const auto& part:absolute) {
        cursor/=part;const auto status=std::filesystem::symlink_status(cursor,ec);
        if(ec || std::filesystem::is_symlink(status) || !std::filesystem::is_directory(status))
            return Fail(error,"managed writer root 안전 경로 오류");
    }
    const auto expected=std::filesystem::absolute(journal_.managed_root_,ec).lexically_normal();
    if(ec || absolute!=expected || absolute!=std::filesystem::absolute(options_.media_root,ec).lexically_normal())
        return Fail(error,"managed writer root 불일치");
    if(error)error->clear();
    return true;
}

bool RecordingCatalog::CanWriteLocked(std::string* error) const {
    if(generation_read_only_)return Fail(error,"B catalog read-only: 영속 쓰기 거부");
    return CanReadLocked(error);
}
bool RecordingCatalog::CanReadLocked(std::string* error) const {
    if(!derived_job_state_authoritative_)return Fail(error,"derived job 원장 불확실: 재open 필요");
    if(journal_.managed_&&(!opened_||!journal_.OwnsCatalog(this)))return Fail(error,"managed catalog write 소유권 거부");
    return true;
}

bool RecordingCatalog::BindRetentionOwner(const RetentionCoordinator* owner) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if (!owner || (retention_owner_ && retention_owner_ != owner)) return false;
    retention_owner_ = owner;
    return true;
}

void RecordingCatalog::UnbindRetentionOwner(const RetentionCoordinator* owner) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if (retention_owner_ == owner) retention_owner_ = nullptr;
}

bool RecordingCatalog::IsRetentionOwner(const RetentionCoordinator* owner) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return owner && retention_owner_ == owner;
}

bool RecordingCatalog::BindDerivedService(const void* owner) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!owner||derived_service_owner_)return false;
    derived_service_owner_=owner;return true;
}
void RecordingCatalog::UnbindDerivedService(const void* owner) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");if(derived_service_owner_==owner)derived_service_owner_=nullptr;
}
bool RecordingCatalog::UpdateDerivedJob(const void* owner,const DerivedJobRecordV1& record,std::string* error) try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!owner||derived_service_owner_!=owner||!opened_||!CanWriteLocked(error))return Fail(error,"derived service 소유권/원장 거부");
    const auto payload=SerializeDerivedJobRecord(record);
    const auto found=JobEntryLocked(record.intent.job_id);
    if(payload.empty()||!found||!*found)return Fail(error,"derived service record 거부");
    DerivedJobHandle current;if(!AcquireDerivedJobOwnedLocked(record.intent.job_id,&current,error)||!current)return false;
    if(current->state==record.state&&current->files.size()==record.files.size()&&
       SerializeDerivedJobRecord(*current)==payload)return true;
    RecordingMutationV1 mutation;mutation.entity_id=record.intent.job_id;mutation.payload_json=payload;
    switch(record.state) {
        case DerivedJobState::Intent:mutation.mutation_type=RecordingMutationType::DerivedJobFiles;break;
        case DerivedJobState::Ready:mutation.mutation_type=RecordingMutationType::DerivedJobReady;break;
        case DerivedJobState::Committed:mutation.mutation_type=RecordingMutationType::DerivedJobCommitted;break;
        case DerivedJobState::Complete:mutation.mutation_type=RecordingMutationType::DerivedJobComplete;break;
        case DerivedJobState::Failed:mutation.mutation_type=RecordingMutationType::DerivedJobFailed;break;
    }
    // ReserveRecordingOrder는 기존 journal에서 발급한다. 새 예약을 동일 catalog projection에 반영한다.
    if(record.ready)for(const auto& output:record.ready->outputs) {
        const auto& s=output.segment;RecordingOrderReservationV1 order{"media-server.recording-order.v1",s.store_id,s.order_request_id,s.segment_id,s.channel_id,s.order_sequence};
        if(!journal_.ManagedOrderMatches(order,error))return false;
        if(!completed_history_)orders_v2_[order.request_id]=order;
    }
    // append 전에 전체 전이를 검증한다. catalog 전체 복제나 output 부분 적용은 하지 않는다.
    PreparedDerivedMutation prepared(this,payload);
    if(!ApplyDerivedJobMutationLocked(mutation,error,false,&prepared))return false;
    if(!AppendAndApplyLocked(std::move(mutation),error,&prepared)){if(!generation_backend_)derived_job_state_authoritative_=false;return false;}
    switch(record.state){
        case DerivedJobState::Ready:completion::Point(completion::Event::Ready,record.intent.reference.reference_id,record.intent.job_id);break;
        case DerivedJobState::Committed:completion::Point(completion::Event::Committed,record.intent.reference.reference_id,record.intent.job_id);break;
        case DerivedJobState::Complete:completion::Point(completion::Event::Complete,record.intent.reference.reference_id,record.intent.job_id);break;
        case DerivedJobState::Failed:completion::Point(completion::Event::Failed,record.intent.reference.reference_id,record.intent.job_id);break;
        case DerivedJobState::Intent:break;
    }
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::Checkpoint(std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!CanWriteLocked(error)){checkpoint_cache_.reset();return false;}
    if(generation_backend_)return CheckpointGenerationLocked(error);
    return CheckpointLocked(false,error);
}

bool RecordingCatalog::CheckpointGenerationLocked(std::string* error) { fc::Scope fc_phase_scope("CheckpointGenerationLocked");
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    if(!generation_backend_||!CanWriteLocked(error))return false;
    std::shared_ptr<RecordingGenerationCheckpointPlan> plan;
    if(!journal_.PrepareGenerationCheckpoint(this,&plan,error))return false;
    if(!plan)return true;
    bool ok=false;GenerationSnapshotStream snapshot;
    try {ok=[&](){
    if(!PrepareGenerationSnapshotStreamLocked(plan->chain,plan->generation,plan->cut,&snapshot,error))return false;
    const auto sql=[&](std::uint64_t generation,std::uint64_t cut) {
#if MEDIA_SERVER_USE_SQLITE3
        auto* db=generation_sqlite_db_;if(!db)return true;
        if(!Exec(db,"BEGIN IMMEDIATE",error))return false;
        const auto fail=[&](){Exec(db,"ROLLBACK",nullptr);return false;};
        try {
            const auto gen=std::to_string(generation),next=std::to_string(cut);
            sqlite3_stmt* statement=nullptr;
            if(sqlite3_prepare_v2(db,"UPDATE b_meta SET generation=?,cut=?",-1,&statement,nullptr)!=SQLITE_OK)return fail();
            const bool bound=sqlite3_bind_text(statement,1,gen.c_str(),-1,SQLITE_TRANSIENT)==SQLITE_OK&&
                sqlite3_bind_text(statement,2,next.c_str(),-1,SQLITE_TRANSIENT)==SQLITE_OK;
            const bool updated=bound&&sqlite3_step(statement)==SQLITE_DONE&&sqlite3_changes(db)==1;sqlite3_finalize(statement);
            if(!updated||!journal_.ValidateGenerationCheckpointCommitLocked(error)||!Exec(db,"COMMIT",error))return fail();
            return true;
        }catch(...){return fail();}
#else
        (void)generation;(void)cut;return true;
#endif
    };
    return journal_.PublishGenerationCheckpoint(this,plan,snapshot.produce,sql,error);
    }();}catch(...){Fail(error,"B checkpoint serialization/resource exception");}
    if(snapshot.finish){std::string detail;if(!snapshot.finish(&detail)){
        journal_.PoisonGeneration(this);if(error)*error+="; snapshot scratch cleanup: "+detail;ok=false;
    }}
    // Before publication this is the candidate; after the swap this is the retired scratch.
    std::string cleanup;if(!plan->Finish(&cleanup)){journal_.PoisonGeneration(this);if(error)*error+="; checkpoint scratch cleanup: "+cleanup;ok=false;}
    if(!ok&&!journal_.OwnsCatalog(this))derived_job_state_authoritative_=false;
    return ok;
#else
    return Fail(error,"B checkpoint unsupported");
#endif
}
bool RecordingCatalog::FindDerivedJob(const std::string& id,
    std::optional<DerivedJobRecordV1>* result,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(result)result->reset();
    if(!result||!opened_||!derived_job_state_authoritative_||!CanReadLocked(error))return Fail(error,"derived job snapshot 미확인");
    DerivedJobHandle found;if(!AcquireDerivedJobOwnedLocked(id,&found,error))return false;
    if(found)*result=*found;
    if(error)error->clear();
    return true;
}
bool RecordingCatalog::FindEventDerivedJobIds(const std::string& channel,const std::string& event,const std::string& source,
    std::vector<std::string>* result,std::string* error,const std::function<bool()>& cancelled) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!result||!opened_||!derived_job_state_authoritative_||!CanReadLocked(error))return Fail(error,"evidence-clip-catalog-unavailable");
    std::vector<std::string> ids;
    if(!VisitJobsLocked([&](const auto& id,const auto& entry,std::string*){
        if(cancelled&&cancelled())return Fail(error,"evidence-timeout");
        if(entry.channel!=channel||entry.state!=DerivedJobState::Complete||
            std::find(entry.source_ids.begin(),entry.source_ids.end(),source)==entry.source_ids.end())return true;
        const auto ref=consumer_references_.find(entry.reference);
        if(ref==consumer_references_.end())return Fail(error,"evidence-clip-reference-unavailable");
        if(ref->second.kind!="event"||ref->second.channel_id!=channel||ref->second.owner_id!=event)return true;
        if(ids.size()==4096)return Fail(error,"evidence-clip-candidate-capacity");
        ids.push_back(id);
        return true;
    },error))return false;
    std::sort(ids.begin(),ids.end());*result=std::move(ids);if(error)error->clear();return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::SnapshotDerivedJobs(std::vector<DerivedJobRecordV1>* result,std::string* error) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(result)result->clear();
    if(!result||!opened_||!derived_job_state_authoritative_||!CanReadLocked(error))return Fail(error,"derived job snapshot 미확인");
    if(!VisitJobsLocked([&](const auto& id,const auto&,std::string* detail){DerivedJobHandle job;if(!AcquireDerivedJobOwnedLocked(id,&job,detail)||!job)return false;result->push_back(*job);return true;},error)){result->clear();return false;}
    std::sort(result->begin(),result->end(),[](const auto& a,const auto& b){return a.intent.job_id<b.intent.job_id;});
    if(error)error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::SnapshotActiveDerivedJobs(std::size_t limit,std::vector<DerivedJobRecordV1>* result,bool* more,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(result)result->clear();
    if(more)*more=false;
    if(!result||!more||limit==0||limit>8||!opened_||!derived_job_state_authoritative_||!CanReadLocked(error))return Fail(error,"derived active snapshot 미확인/상한");
    for(const auto& [id,entry]:derived_jobs_){if(!entry){result->clear();*more=false;derived_job_state_authoritative_=false;return Fail(error,"derived null job 거부");}if(entry.Active()){
        if(result->size()==limit){*more=true;break;}
        DerivedJobHandle job;if(!AcquireDerivedJobOwnedLocked(id,&job,error)||!job){result->clear();*more=false;return false;}
        result->push_back(*job);
    }}
    if(error)error->clear();
    return true;
}
bool RecordingCatalog::DerivedJobProtectsLocked(const std::string& id) const {
    if(!derived_job_state_authoritative_)return true;
    for(const auto& [_,lease]:derived_wait_leases_)if(lease.source_ids.count(id))return true;
    for(const auto& [_,job]:derived_jobs_){if(!job)return true;if(job.Active()) {
        for(const auto& source:job.source_ids)if(source==id)return true;
        for(const auto& output:job.output_ids)if(output==id)return true;
    }}
    return false;
}
bool RecordingCatalog::ValidateDerivedJobSourcesLocked(const DerivedJobIntentV1& job,std::string* error) const try {
    recording::latency::Scope latency_scope(recording::latency::Operation::ValidateSources,recording::latency::Source::Catalog,__LINE__,false);
    const auto binding_matches=[](const RecordingSourceBindingV1& live,const RecordingSourceBindingV1& saved) {
        if(saved.file_evidence)return SerializeRecordingSourceBindingV1(live)==SerializeRecordingSourceBindingV1(saved);
        // 기존 job은 file_evidence 비소비 snapshot이다. 원본 identity의 모든 기존 필드는 동일해야 한다.
        return live.schema==saved.schema&&live.segment_id==saved.segment_id&&live.source_id==saved.source_id&&
            live.channel_id==saved.channel_id&&live.store_id==saved.store_id&&live.media_epoch_id==saved.media_epoch_id&&
            live.source_generation==saved.source_generation&&live.generation_order==saved.generation_order&&live.track_id==saved.track_id&&
            live.index_complete==saved.index_complete&&live.last_accepted_ordinal==saved.last_accepted_ordinal&&live.incomplete_reason==saved.incomplete_reason&&
            live.samples.size()==saved.samples.size()&&std::equal(live.samples.begin(),live.samples.end(),saved.samples.begin(),
                [](const auto& a,const auto& b){return a.ordinal==b.ordinal&&a.pts_ns==b.pts_ns;});
    };
    for(const auto& source:job.sources) {
        const auto segment=segments_v2_.find(source.segment.segment_id);
        const auto binding=FindSourceBindingOwnedLocked(source.segment.segment_id);
        if(segment==segments_v2_.end()||!binding||
           EffectiveLifecycleV2Locked(source.segment.segment_id)!=RecordingLifecycle::Finalized||
           SerializeRecordingSegmentV2(segment->second)!=SerializeRecordingSegmentV2(source.segment)||
           !binding_matches(*binding,source.binding)||
           !media_relpaths_.count(source.segment.segment_id))return Fail(error,"derived job live source 결박 거부");
    }
    for(const auto& output:job.outputs) {
        if(segments_v2_.count(output.output_id)||segments_.count(output.output_id)||tombstones_v2_.count(output.output_id)||tombstones_.count(output.output_id)||RetiredLocked(output.output_id).has_value())
            return Fail(error,"derived job output ID 재사용 거부");
    }
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::PreparedDerivedMatchesLocked(const RecordingMutationV1& mutation,const PreparedDerivedMutation& prepared,bool applied,std::string* error) const {
    const auto expected=applied?PreparedDerivedMutation::Phase::Applied:PreparedDerivedMutation::Phase::Validated;
    if(prepared.owner!=this||prepared.phase!=expected||prepared.type!=mutation.mutation_type||
       prepared.entity!=mutation.entity_id||prepared.payload!=mutation.payload_json)
        return Fail(error,"derived prepared mutation 결박 거부");
    const auto old=derived_jobs_.find(mutation.entity_id);
    if(old==derived_jobs_.end()||!old->second||(!applied&&(old->second.WarmOwned()!=prepared.prior||old->second.state!=prepared.prior_state||old->second.files!=prepared.prior_files))||
       (applied && old->second.WarmOwned()!=prepared.applied))return Fail(error,"derived prepared prior 결박 거부");
    return true;
}
RecordingCatalog::DerivedJobHandle RecordingCatalog::ShareValidatedJob(DerivedJobRecordV1 record,const DerivedJobPool* pool) {
    if(pool){
        const auto found=pool->find(record.intent.job_id);
        const auto owned=found==pool->end()?DerivedJobHandle{}:found->second.WarmOwned();
        if(owned&&owned->state==record.state&&owned->files.size()==record.files.size()&&
           SerializeDerivedJobRecord(*owned)==SerializeDerivedJobRecord(record))return owned;
    }
    return std::make_shared<const DerivedJobRecordV1>(std::move(record));
}
RecordingCatalog::RecoveryContentScope::RecoveryContentScope(RecordingCatalog& catalog,RecoveryContentContext* context,
        std::size_t ordinal,RecordingMutationHandle envelope)
    :target(catalog),previous(catalog.recovery_content_),previous_ordinal(catalog.recovery_ordinal_),
     previous_envelope(std::move(catalog.recovery_envelope_)) {
    target.recovery_content_=context;target.recovery_ordinal_=ordinal;target.recovery_envelope_=std::move(envelope);
}
RecordingCatalog::RecoveryContentScope::~RecoveryContentScope(){
    target.recovery_content_=previous;target.recovery_ordinal_=previous_ordinal;target.recovery_envelope_=std::move(previous_envelope);
}
const RecordingCatalog::RecoveryContentContext::Entry* RecordingCatalog::RecoveryContentLocked(const RecordingMutationV1& mutation) const {
    const auto* context=recovery_content_;
    if(!context||!context->valid||context->collecting||!context->owner||
       &context->owner->journal_!=&journal_||context->owner->recovery_content_!=context||
       !journal_.OwnsCatalog(context->owner)||!recovery_envelope_)return nullptr;
    const auto same=[&](const RecordingMutationV1& value){return value.schema==mutation.schema&&value.mutation_type==mutation.mutation_type&&
        value.mutation_id==mutation.mutation_id&&value.entity_id==mutation.entity_id&&value.occurred_at_ms==mutation.occurred_at_ms&&value.payload_json==mutation.payload_json;};
    if(!same(*recovery_envelope_))return nullptr;
    for(const auto& entry:context->entries)
        if(entry.ordinal==recovery_ordinal_&&entry.envelope&&same(*entry.envelope))return &entry;
    return nullptr;
}
void RecordingCatalog::RememberRecoveryContentLocked(const RecordingMutationV1& mutation) noexcept {
    auto* context=recovery_content_;
    if(!context||!context->valid||!context->collecting||!context->owner||!recovery_envelope_||
       context->owner->recovery_content_!=context||&context->owner->journal_!=&journal_||
       context->entries.size()>=context->limit)return;
    // 최적화 소유 admission의 할당/직렬화 실패는 원래 성공한 strict 적용을 실패로 바꾸지 않는다.
    try {
        const auto& envelope=*recovery_envelope_;
        if(envelope.schema!=mutation.schema||envelope.mutation_type!=mutation.mutation_type||envelope.mutation_id!=mutation.mutation_id||
           envelope.entity_id!=mutation.entity_id||envelope.occurred_at_ms!=mutation.occurred_at_ms||envelope.payload_json!=mutation.payload_json)return;
        const auto payload=mutation.payload_json.size();
        if(payload>context->budget/2||context->charge>context->budget)return;
        const auto minimum=sizeof(RecoveryContentContext::Entry)+sizeof(RecordingMutationV1)+payload*2+
            mutation.schema.size()+mutation.mutation_id.size()+mutation.entity_id.size();
        if(minimum>context->budget-context->charge)return;
        RecoveryContentContext::Entry entry;entry.ordinal=recovery_ordinal_;entry.envelope=recovery_envelope_;
        if(IsDerivedJobMutation(mutation.mutation_type)){
            const auto found=derived_jobs_.find(mutation.entity_id);if(found==derived_jobs_.end())return;
            entry.job=found->second.WarmOwned();if(!entry.job)return;
        }else if(mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized){
            const auto found=source_bindings_.find(mutation.entity_id);const auto segment=segments_v2_.find(mutation.entity_id);
            const auto relative=media_relpaths_.find(mutation.entity_id);
            if(found==source_bindings_.end()||segment==segments_v2_.end()||relative==media_relpaths_.end())return;
            entry.binding=found->second.WarmOwned();if(!entry.binding)return;
            entry.segment=segment->second;entry.relative=relative->second;
            entry.segment_json=SerializeRecordingSegmentV2(entry.segment);entry.binding_json=SerializeRecordingSourceBindingV1(*entry.binding);
            if(entry.segment_json.empty()||entry.binding_json.empty())return;
        }else return;
        // 논리 admission 양은 실제 heap/RSS 추정치가 아니다. typed 내용과 canonical 사본을 보수적으로 함께 청구한다.
        const auto charge=minimum+entry.relative.size()+entry.segment_json.size()+entry.binding_json.size();
        if(context->charge>context->budget||charge>context->budget-context->charge)return;
        context->entries.push_back(std::move(entry));context->charge+=charge;
    }catch(...){return;}
}
RecordingCatalog::DerivedJobHandle RecordingCatalog::ContentProofRecordLocked(const RecordingMutationV1& mutation,const DerivedJobContentProof* proof) const {
    if(!proof||!proof->owner||!proof->envelope||!proof->record)return {};
    const auto& owner=*proof->owner;
    if(&owner.journal_!=&journal_||!owner.opened_||!owner.derived_job_state_authoritative_||!journal_.OwnsCatalog(&owner))return {};
    const auto current=owner.derived_jobs_.find(mutation.entity_id);
    RecordingMutationLink accepted;
    if(current==owner.derived_jobs_.end()||current->second.WarmOwned()!=proof->record||
       !owner.AcceptedLinkLocked(mutation.mutation_id,&accepted)||!journal_.MutationLinkOwns(accepted,proof->envelope))return {};
    const auto& envelope=*proof->envelope;
    if(envelope.schema!=mutation.schema||envelope.mutation_type!=mutation.mutation_type||
       envelope.mutation_id!=mutation.mutation_id||envelope.entity_id!=mutation.entity_id||
       envelope.occurred_at_ms!=mutation.occurred_at_ms||envelope.payload_json!=mutation.payload_json||
       proof->record->intent.job_id!=mutation.entity_id)return {};
    // 생성자는 성공한 strict Prepared 적용 뒤에만 호출한다. 불변 envelope의 정확한
    // payload가 그때 검증한 parsed record와 결박되므로 여기서 Parse/Serialize를 반복하지 않는다.
    return proof->record;
}
bool RecordingCatalog::ApplyDerivedJobMutationLocked(const RecordingMutationV1& mutation,std::string* error,bool apply,PreparedDerivedMutation* prepared,const DerivedJobPool* job_pool,const DerivedJobContentProof* proof,const RecordingMutationLink* link) try {
    recording::latency::Scope latency_scope(recording::latency::Operation::ApplyJob,recording::latency::Source::Catalog,__LINE__,false);
    if(prepared&&apply){
        if(!prepared->record||!PreparedDerivedMatchesLocked(mutation,*prepared,false,error))return false;
        const auto& record=*prepared->record;
        // 검증 이후 AppendOwned는 catalog 상태를 변경하거나 외부 callback을 호출하지 않는다.
        // 같은 mu_ 소유 안에서 기존 transition 검증 결과를 단 한 번 소비한다.
        DerivedJobEntry published(prepared->record,link?*link:RecordingMutationLink{},mutation.mutation_id);
        prepared->phase=PreparedDerivedMutation::Phase::Consumed;
        if(mutation.mutation_type==RecordingMutationType::DerivedJobCommitted)for(std::size_t i=0;i<record.ready->outputs.size();++i){
            const auto& s=record.ready->outputs[i].segment;segments_v2_.emplace(s.segment_id,s);media_relpaths_[s.segment_id]=record.intent.outputs[i].final_relpath;
        }
        auto& destination=derived_jobs_.find(mutation.entity_id)->second;destination=std::move(published);
        prepared->applied=std::move(prepared->record);prepared->phase=PreparedDerivedMutation::Phase::Applied;
        return true;
    }
    if(prepared&&(prepared->phase!=PreparedDerivedMutation::Phase::Empty||prepared->owner!=this||prepared->payload!=mutation.payload_json))
        return Fail(error,"derived prepared 초기 결박 거부");
    DerivedJobRecordV1 parsed_record;
    const auto* recovery=RecoveryContentLocked(mutation);
    const auto content=recovery&&recovery->job?recovery->job:ContentProofRecordLocked(mutation,proof);
    if(!journal_.managed_||!options_.enable_v2_storage||
       (!content&&!ParseDerivedJobRecord(mutation.payload_json,&parsed_record,error)))return Fail(error,"derived job mutation 계약 거부");
    const auto& record=content?*content:parsed_record;
    if(record.intent.job_id!=mutation.entity_id)return Fail(error,"derived job mutation 계약 거부");
    const auto type=mutation.mutation_type;
    const bool initial=type==RecordingMutationType::DerivedJobIntent;
    const bool files=type==RecordingMutationType::DerivedJobFiles;
    const bool ready=type==RecordingMutationType::DerivedJobReady;
    const bool committed=type==RecordingMutationType::DerivedJobCommitted;
    const bool complete=type==RecordingMutationType::DerivedJobComplete;
    const bool failed=type==RecordingMutationType::DerivedJobFailed;
    if(((initial||files)&&record.state!=DerivedJobState::Intent)||(ready&&record.state!=DerivedJobState::Ready)||
       (committed&&record.state!=DerivedJobState::Committed)||(complete&&record.state!=DerivedJobState::Complete)||
       (failed&&record.state!=DerivedJobState::Failed))return Fail(error,"derived job mutation state 불일치");
    const auto old=JobEntryLocked(mutation.entity_id);
    if(!old) {
        if(!initial||!record.files.empty()||record.ready||!ValidateDerivedJobSourcesLocked(record.intent,error))
            return Fail(error,"derived job 최초 전이 거부");
        if(apply)derived_jobs_.emplace(mutation.entity_id,DerivedJobEntry(content?content:ShareValidatedJob(std::move(parsed_record),job_pool),link?*link:RecordingMutationLink{},mutation.mutation_id));
        return true;
    }
    if(!*old)return Fail(error,"derived null prior 거부");
    DerivedJobHandle prior_owned;if(!AcquireDerivedJobOwnedLocked(mutation.entity_id,&prior_owned,error)||!prior_owned)return false;
    const auto& prior=*prior_owned;
    // incoming은 위 strict Parse/proof, prior는 strict Apply/Prepared의 불변 게시 값이다.
    // 호출-local 전체 canonical 대조는 유지하되 동일 내용의 Validate/Restore를 반복하지 않는다.
    const detail::CatalogIntentCanonical prior_intent(prior.intent),incoming_intent(record.intent);
    if(!prior_intent.Equals(incoming_intent))return Fail(error,"derived job immutable 충돌");
    // Parse의 canonical 검사 또는 봉인된 내용 증명이 incoming payload를 결박했다.
    // 상태/파일 수가 다르면 같은 Record일 수 없지만 아래 전이 검증은 계속한다.
    if(prior.state==record.state&&prior.files.size()==record.files.size()&&
       SerializeDerivedJobRecord(prior)==mutation.payload_json)return true;
    if(initial)return Fail(error,"derived job Intent 재기록 충돌");
    for(std::size_t i=0;i<prior.files.size();++i)
        if(i>=record.files.size()||SerializeDerivedJobFile(prior.files[i])!=SerializeDerivedJobFile(record.files[i]))
            return Fail(error,"derived job receipt 변경");
    const auto prior_state=prior.state;
    if(files) {
        if(prior_state!=DerivedJobState::Intent||record.files.size()!=prior.files.size()+1)return Fail(error,"derived job receipt 전이 거부");
    } else {
        if(prior.files.size()!=record.files.size())return Fail(error,"derived job receipt 누락");
        if((ready&&prior_state!=DerivedJobState::Intent)||(committed&&prior_state!=DerivedJobState::Ready)||
           (complete&&prior_state!=DerivedJobState::Committed)||(failed&&prior_state!=DerivedJobState::Intent))
            return Fail(error,"derived job 상태 전이 거부");
        if(prior.ready&&(!record.ready||SerializeDerivedJobReady(*prior.ready)!=SerializeDerivedJobReady(*record.ready)))
            return Fail(error,"derived job Ready 변경");
    }
    if(ready||committed) {
        if(!ValidateDerivedJobSourcesLocked(record.intent,error))return false;
        for(std::size_t i=0;i<record.ready->outputs.size();++i) {
            const auto& s=record.ready->outputs[i].segment;
            const auto order=OrderLocked(s.order_request_id);
            if(!order||order->store_id!=s.store_id||order->segment_id!=s.segment_id||
               order->channel_id!=s.channel_id||order->sequence!=s.order_sequence)
                return Fail(error,"derived output 예약 결박 오류");
        }
    }
    if(!apply){
        if(prepared){prepared->type=type;prepared->entity=mutation.entity_id;prepared->prior=prior_owned;prepared->prior_state=prior.state;prepared->prior_files=prior.files.size();prepared->record=content?content:std::make_shared<const DerivedJobRecordV1>(std::move(parsed_record));prepared->phase=PreparedDerivedMutation::Phase::Validated;}
        return true;
    }
    const auto published=content?content:ShareValidatedJob(std::move(parsed_record),job_pool);
    DerivedJobEntry published_entry(published,link?*link:RecordingMutationLink{},mutation.mutation_id);
    if(committed) {
        // 하나의 mutation 아래 전체 결과와 provenance/job state를 함께 적용한다.
        for(std::size_t i=0;i<published->ready->outputs.size();++i) {
            const auto& s=published->ready->outputs[i].segment;
            segments_v2_.emplace(s.segment_id,s);
            media_relpaths_[s.segment_id]=published->intent.outputs[i].final_relpath;
        }
    }
    derived_jobs_.insert_or_assign(mutation.entity_id,std::move(published_entry));return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::BeginDerivedJobIntent(const DerivedJobIntentV1& value,bool* inserted,std::string* error) try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");if(inserted)*inserted=false;
    if(!opened_||!journal_.managed_||!derived_job_state_authoritative_||!CanWriteLocked(error)||!ValidateDerivedJobIntent(value,error))return false;
    const auto old=JobEntryLocked(value.job_id);
    if(old) {
        if(!*old)return Fail(error,"derived null job 거부");
        DerivedJobHandle current;if(!AcquireDerivedJobOwnedLocked(value.job_id,&current,error)||!current)return false;
        auto same=value;same.created_at_ms=current->intent.created_at_ms;
        if(SerializeDerivedJobIntent(same)!=SerializeDerivedJobIntent(current->intent))return Fail(error,"derived job immutable 충돌");
        if(error)error->clear();
        return true;
    }
    if(!ValidateDerivedJobSourcesLocked(value,error))return false;
    DerivedJobRecordV1 record;record.intent=value;
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::DerivedJobIntent;
    mutation.entity_id=value.job_id;mutation.payload_json=SerializeDerivedJobRecord(record);
    if(mutation.payload_json.empty())return Fail(error,"derived job envelope 상한");
    if(!AppendAndApplyLocked(std::move(mutation),error)){if(!generation_backend_)derived_job_state_authoritative_=false;return false;}
    if(inserted)*inserted=true;
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::FailDerivedJobAfterCleanup(const std::string& id,const std::string& attempt,
    const std::string& reason,std::int64_t cleaned,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(derived_service_owner_)return Fail(error,"derived service 실행 소유 중 외부 terminal release 거부");
    if(!opened_||!derived_job_state_authoritative_||!CanWriteLocked(error))return Fail(error,"derived job cleanup snapshot 미확인");
    DerivedJobHandle found;if(!AcquireDerivedJobOwnedLocked(id,&found,error)||!found||found->intent.attempt_id!=attempt)return Fail(error,"derived job cleanup 소유권 거부");
    auto record=*found;record.state=DerivedJobState::Failed;record.failure_reason=reason;record.cleaned_at_ms=cleaned;
    const auto payload=SerializeDerivedJobRecord(record);
    if(payload.empty())return Fail(error,"derived job cleanup payload 거부");
    if(found->state==DerivedJobState::Failed)return SerializeDerivedJobRecord(*found)==payload;
    if(found->state!=DerivedJobState::Intent)return Fail(error,"derived job cleanup 전이 거부");
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::DerivedJobFailed;mutation.entity_id=id;mutation.payload_json=payload;
    if(!AppendAndApplyLocked(std::move(mutation),error)){if(!generation_backend_)derived_job_state_authoritative_=false;return false;}return true;
}

std::vector<std::string> RecordingCatalog::ProjectionSignatureLocked() const {
    std::vector<std::string> result;
    const auto add=[&](const std::string& type,const std::string& key,const std::string& value){
        result.push_back(type+std::to_string(key.size())+":"+key+value);
    };
    for(const auto& id:mutation_ids_)add("id",id,"");
    for(const auto& [id,v]:segments_)add("v1",id,SerializeRecordingSegmentV1(v));
    for(const auto& [id,v]:segments_v2_)add("v2",id,SerializeRecordingSegmentV2(v));
    for(const auto& [id,entry]:source_bindings_){(void)entry;SourceBindingHandle v;if(!AcquireSourceBindingOwnedLocked(id,&v,nullptr)||!v)throw std::runtime_error("binding projection unavailable");const auto bytes=SerializeRecordingSourceBindingV1(*v);if(bytes.empty())throw std::runtime_error("binding projection invalid");add("source-binding",id,bytes);}
    for(const auto& [id,entry]:derived_jobs_){(void)entry;DerivedJobHandle v;if(!AcquireDerivedJobOwnedLocked(id,&v,nullptr)||!v)throw std::runtime_error("job projection unavailable");const auto bytes=SerializeDerivedJobRecord(*v);if(bytes.empty())throw std::runtime_error("job projection invalid");add("derived-job",id,bytes);}
    for(const auto& [id,v]:consumer_references_)add("consumer-reference",id,SerializeRecordingConsumerReferenceV1(v));
    for(const auto& id:derived_accepted_references_)add("derived-reference-accepted",id,id);
    for(const auto& [id,v]:referenced_observations_)add("referenced-observation",id,SerializeReferencedObservationV1(v));
    for(const auto& [id,v]:states_v2_)add("v2-state",id,SerializeRecordingSegmentStateV2(v));
    for(const auto& [id,v]:tombstones_v2_)add("v2-deleted",id,SerializeRecordingTombstoneV2(v));
    for(const auto& [id,v]:orders_v2_) {
        add("order-store",id,v.store_id);add("order-segment",id,v.segment_id);
        add("order-channel",id,v.channel_id);add("order-sequence",id,std::to_string(v.sequence));
    }
    for(const auto& [id,v]:event_links_)add("link",id,SerializeEventRecordingLinkV1(v));
    for(const auto& [id,v]:observations_)add("obs1",id,SerializeAnalysisObservationV1(v));
    for(const auto& [id,v]:observations_v2_)add("obs2",id,SerializeAnalysisObservationV2(v));
    for(const auto& [id,v]:tombstones_)add("deleted",id,SerializeRecordingTombstoneV1(v));
    for(const auto& [id,v]:media_relpaths_)add("path",id,v);
    for(const auto& [id,v]:deletion_reasons_)add("reason",id,v);
    std::sort(result.begin(),result.end());return result;
}

RecordingCatalog::CheckpointStatusGuard::CheckpointStatusGuard(RecordingCatalog& value) noexcept : catalog(value) {
    try {
        RecordingCatalogStatusSnapshot snapshot;
        if(!catalog.BuildStatusSnapshotLocked(&snapshot,nullptr))return;
        const auto prior=catalog.checkpoint_status_generation_.fetch_add(1,std::memory_order_acq_rel);
        if(prior==std::numeric_limits<std::uint64_t>::max()){
            catalog.checkpoint_status_poisoned_.store(true,std::memory_order_release);return;
        }
        snapshot.checkpoint_generation=prior+1;
        std::atomic_store_explicit(&catalog.checkpoint_status_snapshot_,
            std::make_shared<const RecordingCatalogStatusSnapshot>(std::move(snapshot)),std::memory_order_release);
        catalog.checkpoint_status_active_.store(true,std::memory_order_release);active=true;
        catalog.checkpoint_status_wait_cv_.notify_all();
    }catch(...){catalog.checkpoint_status_poisoned_.store(true,std::memory_order_release);}
}
RecordingCatalog::CheckpointStatusGuard::~CheckpointStatusGuard() {
    if(!active)return;
    const auto snapshot=std::atomic_load_explicit(&catalog.checkpoint_status_snapshot_,std::memory_order_acquire);
    const auto generation=snapshot?snapshot->checkpoint_generation:0;
    if(success){
        catalog.checkpoint_status_success_generation_.store(generation,std::memory_order_release);
        catalog.checkpoint_status_poisoned_.store(false,std::memory_order_release);
    }else{
        catalog.checkpoint_status_failure_generation_.store(generation,std::memory_order_release);
        catalog.checkpoint_status_poisoned_.store(true,std::memory_order_release);
    }
    catalog.checkpoint_status_active_.store(false,std::memory_order_release);
    std::atomic_store_explicit(&catalog.checkpoint_status_snapshot_,
        std::shared_ptr<const RecordingCatalogStatusSnapshot>{},std::memory_order_release);
    catalog.checkpoint_status_wait_cv_.notify_all();
}

bool RecordingCatalog::CheckpointLocked(bool recover_only,std::string* error,const DerivedJobContentProof* proof) {
    if(recover_only)proof=nullptr;
    recording::latency::Scope latency_scope(recording::latency::Operation::Checkpoint,recording::latency::Source::Catalog,__LINE__,false);
    const auto measured=[](unsigned line,auto&& call){
        recording::latency::Scope phase(recording::latency::Operation::Checkpoint,recording::latency::Source::Catalog,line);
        return call();
    };
    // 모든 실패/예외는 지역 cache를 폐기한다. live catalog를 shadow로 사용하지 않는다.
    auto cached=std::move(checkpoint_cache_);
    if(recover_only)cached.reset();
    if(!journal_.managed_||!options_.enable_v2_storage||!journal_.OwnsCatalog(this))
        return Fail(error,"managed checkpoint 소유권/지원 없음");
    CheckpointStatusGuard checkpoint_status(*this);
    RecordingMutationHandles candidate;
    RecordingJournalOwnedViews candidate_views;
    RecordingCheckpointReadSnapshotHandle read_snapshot;
    std::unique_ptr<RecordingCatalog> before;
    bool identical=false;
    {
        RecordingMutationHandles original;
        RecordingJournalOwnedViews views;
        if(!measured(__LINE__,[&]{return journal_.ReadCheckpointRecords(this,&original,error,&read_snapshot,&views);})){ // read
            if(!journal_.OwnsCatalog(this))derived_job_state_authoritative_=false;
            return false;
        }
        if(!measured(__LINE__,[&]{return journal_.PrepareCheckpoint(this,&candidate,error,read_snapshot);}))return false; // prepare
        {
        recording::latency::Scope phase(recording::latency::Operation::Checkpoint,recording::latency::Source::Catalog,__LINE__); // replay/cache
        bool reuse=cached&&cached->shadow&&detail::CheckpointCacheAdmissible(original)&&cached->prefix.size()<=original.size();
        if(reuse)for(std::size_t i=0;i<cached->prefix.size();++i){
            bool matches=false;
            if(!journal_.MatchMutationLinkView(cached->prefix[i],views[i],&matches,error))return false;
            if(!matches){reuse=false;break;}
        }
        const auto first=reuse?cached->prefix.size():0;
        before=reuse?std::move(cached->shadow):std::make_unique<RecordingCatalog>(journal_,options_);
        cached.reset();
        for(std::size_t i=first;i<original.size();++i)
            if(!before->ApplyMutationLocked(*original[i],false,error,nullptr,original[i],&source_bindings_,&derived_jobs_,proof,views[i])){
                if(!before->derived_job_state_authoritative_)derived_job_state_authoritative_=false;
                return false;
            }
        identical=detail::SameCheckpointSequence(original,candidate);
        candidate_views.resize(candidate.size());
        // 변경 receipt에는 이전 입력의 출처를 붙이지 않는다. 같은 행의 전체 필드가 같은 경우만 전달한다.
        for(std::size_t i=0;i<candidate.size()&&i<original.size();++i){
            if(!candidate[i]||!original[i])continue;
            const auto& a=*candidate[i];const auto& b=*original[i];
            if(a.schema==b.schema&&a.mutation_type==b.mutation_type&&a.mutation_id==b.mutation_id&&
               a.entity_id==b.entity_id&&a.occurred_at_ms==b.occurred_at_ms&&a.payload_json==b.payload_json)candidate_views[i]=views[i];
        }
        }
    } // 원본 핸들 vector는 이후 후보 검증/commit에 필요하지 않다.
    // 변경 후보는 전체 semantic replay와 양쪽 projection 비교를 유지한다.
    std::unique_ptr<RecordingCatalog> after;
    if(!identical){
        recording::latency::Scope phase(recording::latency::Operation::Checkpoint,recording::latency::Source::Catalog,__LINE__); // candidate/projection
        after=std::make_unique<RecordingCatalog>(journal_,options_);
        for(std::size_t i=0;i<candidate.size();++i){const auto& m=candidate[i];
            if(!m||!after->ApplyMutationLocked(*m,false,error,nullptr,m,&source_bindings_,&derived_jobs_,proof,candidate_views[i])){
                if(!after->derived_job_state_authoritative_)derived_job_state_authoritative_=false;
                return false;
            }}
        try {
            if(before->ProjectionSignatureLocked()!=after->ProjectionSignatureLocked())return Fail(error,"checkpoint 투영 불일치");
        }catch(...){
            // cold 상세 실패만 live의 불확실 상태로 전달한다. 다른 Apply 예외의 기존
            // unwind/cache 폐기·다음 호출 full 검증 계약까지 변경하지 않는다.
            if(before->derived_job_state_authoritative_&&after->derived_job_state_authoritative_)throw;
            derived_job_state_authoritative_=false;
            return Fail(error,"checkpoint 상세 투영 미확인");
        }
    }
    // original 초과는 full 검증, compact candidate가 상한 내이면 다음 호출용 보관 가능.
    std::unique_ptr<CheckpointProjectionCache> next;
    if(!recover_only&&detail::CheckpointCacheAdmissible(candidate)){
        recording::latency::Scope phase(recording::latency::Operation::Checkpoint,recording::latency::Source::Catalog,__LINE__); // cache links
        next=std::make_unique<CheckpointProjectionCache>();
        next->shadow=identical?std::move(before):std::move(after);
        next->prefix.reserve(candidate.size());
        for(std::size_t i=0;i<candidate.size();++i){
            RecordingMutationLink link;
            if(!journal_.MakeMutationLink(candidate_views[i],*candidate[i],candidate[i],&link,error))return false;
            next->prefix.push_back(std::move(link));
        }
    }
    // 최종 비교가 끝난 비선택 shadow는 commit의 사본/직렬화와 겹치지 않는다.
    before.reset();after.reset();
    if(!measured(__LINE__,[&]{return journal_.CommitCheckpoint(this,candidate,recover_only,error,read_snapshot);}))return false; // commit
    if(next)checkpoint_cache_=std::move(next);
    if(!measured(__LINE__,[&]{return ReleaseInactiveDetailsLocked(nullptr,error);})){checkpoint_cache_.reset();return false;}
    checkpoint_status.success=true;return true; // release
}

bool RecordingCatalog::ReadCatalogReplay(RecordingMutationHandles* owned,RecordingJournalReplayResult* replay,
                                         std::string* error,RecordingJournalOwnedViews* views) const {
    if(!owned||!replay)return Fail(error,"catalog replay output 없음");
    owned->clear();*replay={};if(views)views->clear();
    if(!journal_.managed_){*replay=journal_.Replay();return true;}
    // 한 owner/FD 검증 snapshot으로 값 Replay와 소유 핸들을 함께 만든다.
    // 공개 Replay의 독립 값 계약은 유지하며 이 일시 값 사본은 아직 제거하지 않는다.
    if(!journal_.ReadCheckpointRecords(this,owned,error,nullptr,views)){++replay->io_error_count;return false;}
    replay->mutations.reserve(owned->size());
    for(const auto& handle:*owned){
        if(!handle){owned->clear();replay->mutations.clear();++replay->io_error_count;return Fail(error,"catalog null envelope 거부");}
        replay->mutations.push_back(*handle);
    }
    return true;
}

bool RecordingCatalog::OpenLocked(std::string* error) {
    RecoveryContentContext recovery(this);
    RecoveryContentScope recovery_scope(*this,&recovery,0,{});
    RecordingMutationHandles owned;
    RecordingJournalOwnedViews views;
    RecordingJournalReplayResult replay;
    if(!ReadCatalogReplay(&owned,&replay,error,&views))return false;
    recovery.original=&owned;
    if (replay.io_error_count != 0) return Fail(error, "journal replay I/O 오류로 catalog open 거부");
    if (replay.unsupported_record_count != 0) return Fail(error, "미지원 journal record로 catalog open 거부");
    if (!PreflightV2Locked(replay,error,nullptr,{},nullptr,owned,views)) return false;
    recovery.strict_preflight_validated=journal_.managed_&&options_.enable_v2_storage;
    recovery.collecting=false;
    if(journal_.managed_&&journal_.CheckpointPending()){
        recovery.valid=false;recovery.strict_preflight_validated=false;recovery.entries.clear();recovery.charge=0;
    }
    if(journal_.managed_&&journal_.CheckpointPending()&&!CheckpointLocked(true,error))return false;
    recovery_report_.corrupt_line_count = replay.corrupt_line_count;
    recovery_report_.truncated_tail_count = replay.truncated_tail_count;
    for (std::size_t ordinal = 0; ordinal < replay.mutations.size(); ++ordinal) {
        const auto& mutation = replay.mutations[ordinal];
        RecoveryContentScope recovery_row(*this,&recovery,ordinal,owned.empty()?RecordingMutationHandle{}:owned[ordinal]);
        const bool already_applied = mutation_ids_.count(mutation.mutation_id) != 0;
        std::string apply_error;
        if (!ApplyMutationLocked(mutation, true, &apply_error,nullptr,owned.empty()?RecordingMutationHandle{}:owned[ordinal],nullptr,nullptr,nullptr,views.empty()?RecordingJournalOwnedViewHandle{}:views[ordinal])) ++recovery_report_.projection_error_count;
        else {
            ++recovery_report_.replayed_mutation_count;
            if (!already_applied && (mutation.mutation_type == RecordingMutationType::SegmentFinalized ||
                mutation.mutation_type == RecordingMutationType::CorruptionDetected ||
                mutation.mutation_type == RecordingMutationType::SegmentV2Finalized ||
                mutation.mutation_type == RecordingMutationType::SegmentV2BoundFinalized ||
                mutation.mutation_type == RecordingMutationType::SegmentV2State ||
                mutation.mutation_type == RecordingMutationType::SegmentV2Deleted))
                accepted_segment_state_replay_ordinals_.insert(ordinal);
        }
    }
    if (options_.prefer_sqlite && OpenSqliteLocked(error)) {
        catalog_mode_ = "sqlite-primary";
        if (!RebuildSqliteLocked(error)) return false;
    } else {
        CloseSqliteLocked();
        catalog_mode_ = "jsonl-fallback";
        if (error != nullptr) error->clear();
    }
    if (!RecoverWriterCleanupMarkersLocked(error)) return false;
    // JSONL replay에는 일시 hold count를 직접 쓰지 않는다. terminal release 단계가
    // 아직 소유한다고 명시한 output/source hold만 link에서 재구성한다.
    const auto restore_hold = [&](const std::string& segment_id) {
        constexpr auto kMaxPersistentHoldCount =
            static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max());
        const std::uint64_t current = hold_counts_[segment_id];
        if (current >= kMaxPersistentHoldCount) {
            return Fail(error, "pending event hold_count 복구가 저장 범위를 넘음");
        }
        const std::uint64_t next = current + 1;
        hold_counts_[segment_id] = next;
#if MEDIA_SERVER_USE_SQLITE3
        if (sqlite_db_ != nullptr) {
            sqlite3_stmt* statement = nullptr;
            if (sqlite3_prepare_v2(sqlite_db_,
                                   "UPDATE recording_segments SET hold_count=? WHERE segment_id=?",
                                   -1, &statement, nullptr) != SQLITE_OK) {
                return Fail(error, sqlite3_errmsg(sqlite_db_));
            }
            sqlite3_bind_int64(statement, 1, static_cast<sqlite3_int64>(next));
            BindText(statement, 2, segment_id);
            const bool updated = sqlite3_step(statement) == SQLITE_DONE &&
                                 sqlite3_changes(sqlite_db_) == 1;
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement);
            if (!updated) return Fail(error, message);
        }
#endif
        return true;
    };
    for (const auto& [_, link] : event_links_) {
        if (link.status != EventRecordingLinkStatus::Pending ||
            !link.derived_segment_id.has_value()) continue;
        const auto segment = segments_.find(*link.derived_segment_id);
        if (segment == segments_.end() ||
            segment->second.lifecycle != RecordingLifecycle::Finalized ||
            segment->second.retention_class != RecordingRetentionClass::Event) continue;
        const bool output_hold_active =
            link.completeness_reason == "event-catalog-finalize-recovery-pending" ||
            link.completeness_reason == "event-marker-cleanup-recovery-pending" ||
            link.completeness_reason == "event-terminal-release-recovery-pending" ||
            link.completeness_reason == "event-terminal-output-release-pending";
        const bool source_hold_active = output_hold_active ||
            link.completeness_reason == "event-terminal-source-release-pending";
        if (output_hold_active && !restore_hold(segment->first)) return false;
        if (source_hold_active) {
            for (const auto& overlap : link.ordered_overlaps) {
                const auto source = segments_.find(overlap.segment_id);
                if (source == segments_.end() ||
                    source->second.lifecycle != RecordingLifecycle::Finalized ||
                    source->second.retention_class != RecordingRetentionClass::Continuous) {
                    return Fail(error, "pending event source hold 복구 대상이 유효하지 않음");
                }
                if (!restore_hold(source->first)) return false;
            }
        }
    }
    opened_ = true;
    if(journal_.managed_&&!ReleaseInactiveDetailsLocked(nullptr,error))return false;
    checkpoint_status_poisoned_.store(false,std::memory_order_release);
    return true;
}

std::string RecordingCatalog::catalog_mode() const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return catalog_mode_;
}

RecordingCatalogRecoveryReport RecordingCatalog::recovery_report() const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return recovery_report_;
}

bool RecordingCatalog::BuildStatusSnapshotLocked(RecordingCatalogStatusSnapshot* result,std::string* error) const {
    if(result)*result={};
    if(!result||!opened_||!derived_job_state_authoritative_||!CanReadLocked(error))
        return Fail(error,"recording status snapshot 미확인");
    const auto retention=RetentionSnapshotLocked();
    if(!retention.authoritative)return Fail(error,"recording status capacity 미확인");
    result->catalog_mode=catalog_mode_;result->recovery=recovery_report_;
    for(const auto& candidate:retention.candidates){
        auto& channel=result->channels[candidate.Channel()];
        auto& bytes=candidate.Class()==RecordingRetentionClass::Event?channel.event_bytes:channel.continuous_bytes;
        bytes+=std::min(candidate.Size(),std::numeric_limits<std::uint64_t>::max()-bytes);
    }
    if(error)error->clear();
    return true;
}

bool RecordingCatalog::SnapshotStatus(RecordingCatalogStatusSnapshot* result,std::string* error) const {
    if(result)*result={};
    if(!result)return Fail(error,"recording status output 없음");
    auto backoff=std::chrono::milliseconds(1);
    for(;;){
        if(checkpoint_status_poisoned_.load(std::memory_order_acquire))return Fail(error,"recording status checkpoint 실패");
        std::unique_lock<std::mutex> lock(mu_,std::try_to_lock);
        if(lock.owns_lock())return BuildStatusSnapshotLocked(result,error);
        if(checkpoint_status_active_.load(std::memory_order_acquire)){
            const auto snapshot=std::atomic_load_explicit(&checkpoint_status_snapshot_,std::memory_order_acquire);
            if(snapshot&&!checkpoint_status_poisoned_.load(std::memory_order_acquire)&&
               checkpoint_status_active_.load(std::memory_order_acquire)){
                *result=*snapshot;
                if(ValidateStatusSnapshot(*result)){if(error)error->clear();return true;}
                *result={};return Fail(error,"recording status checkpoint snapshot 무효");
            }
        }
        std::unique_lock<std::mutex> wait_lock(checkpoint_status_wait_mu_);
        checkpoint_status_wait_cv_.wait_for(wait_lock,backoff,[&]{
            return checkpoint_status_active_.load(std::memory_order_acquire)||
                   checkpoint_status_poisoned_.load(std::memory_order_acquire);
        });
        backoff=std::min(backoff*2,std::chrono::milliseconds(8));
    }
}

bool RecordingCatalog::ValidateStatusSnapshot(const RecordingCatalogStatusSnapshot& snapshot) const {
    if(checkpoint_status_poisoned_.load(std::memory_order_acquire))return false;
    const auto generation=snapshot.checkpoint_generation;
    if(generation==0)return true;
    if(checkpoint_status_failure_generation_.load(std::memory_order_acquire)>=generation)return false;
    if(checkpoint_status_active_.load(std::memory_order_acquire)){
        const auto current=std::atomic_load_explicit(&checkpoint_status_snapshot_,std::memory_order_acquire);
        if(current&&current->checkpoint_generation==generation)return true;
    }
    return checkpoint_status_success_generation_.load(std::memory_order_acquire)>=generation;
}

bool RecordingCatalog::RecoverWriterCleanupMarkersLocked(std::string* error) {
    constexpr const char* kCleanupSuffix = ".cleanup-pending";
    std::vector<std::filesystem::path> markers;
    std::error_code scan_error;
    if (!std::filesystem::exists(options_.media_root, scan_error)) {
        if (scan_error) return Fail(error, "writer cleanup marker root 확인 실패");
        return true;
    }
    for (std::filesystem::recursive_directory_iterator iterator(
             options_.media_root, scan_error), end;
         !scan_error && iterator != end;
         iterator.increment(scan_error)) {
        const auto& entry = *iterator;
        const std::string path = entry.path().string();
        if (entry.is_regular_file(scan_error) && !scan_error &&
            path.size() > std::char_traits<char>::length(kCleanupSuffix) &&
            path.compare(path.size() - std::char_traits<char>::length(kCleanupSuffix),
                         std::char_traits<char>::length(kCleanupSuffix),
                         kCleanupSuffix) == 0) {
            markers.push_back(entry.path());
        }
    }
    if (scan_error) return Fail(error, "writer cleanup marker 순회 실패");

    for (const auto& marker : markers) {
        std::filesystem::path final_path = marker;
        std::string final_text = final_path.string();
        final_text.resize(final_text.size() - std::char_traits<char>::length(kCleanupSuffix));
        final_path = final_text;
        if (final_path.extension() != ".mp4" && final_path.extension() != ".ts" &&
            final_path.extension() != ".webm") {
            ++recovery_report_.writer_cleanup_error_count;
            return Fail(error, "writer cleanup marker 대상 확장자가 유효하지 않음");
        }
        const std::string segment_id = final_path.stem().string();
        const auto known = segments_.find(segment_id);
        const auto known_path = media_relpaths_.find(segment_id);
        const auto relative_final = final_path.lexically_relative(options_.media_root);
        const bool tracked_final =
            known != segments_.end() && known_path != media_relpaths_.end() &&
            known_path->second == relative_final.generic_string() &&
            (known->second.lifecycle == RecordingLifecycle::Finalized ||
             known->second.lifecycle == RecordingLifecycle::DeletionPending);
        const auto marker_binding =
            ReadCleanupMarkerBinding(marker, final_path.filename().string());
        if (marker_binding.ownership == CleanupMarkerOwnership::Invalid) {
            ++recovery_report_.writer_cleanup_error_count;
            return Fail(error, "writer cleanup marker 내용 또는 소유권이 유효하지 않음");
        }
        bool preserve_ready = false;
        if (!PreserveFinalizeReadyPartial(options_.media_root, relative_final,
                                          marker_binding.partial_name, &preserve_ready, error)) {
            ++recovery_report_.writer_cleanup_error_count;
            return false;
        }
        if (preserve_ready) continue;
        std::string cleanup_error;
        if (marker_binding.ownership == CleanupMarkerOwnership::OwnedPartial) {
            const auto owned_partial = marker.parent_path() / marker_binding.partial_name;
            if (!RemoveContainedMediaFile(
                    options_.media_root, owned_partial, &cleanup_error, {}, true)) {
                ++recovery_report_.writer_cleanup_error_count;
                return Fail(error, cleanup_error.empty()
                                       ? "writer 소유 partial 제거 실패"
                                       : cleanup_error);
            }
        } else if (!tracked_final) {
            // v1 marker만으로 final/partial 소유권을 증명할 수 없다. 둘 다 삭제하지 않고
            // orphan 진단에 남긴다. v2 event marker만 nonce partial을 좁게 삭제한다.
        }
        if (!RemoveContainedMediaFile(options_.media_root, marker, &cleanup_error)) {
            ++recovery_report_.writer_cleanup_error_count;
            return Fail(error, cleanup_error.empty()
                                   ? "writer cleanup marker 제거 실패"
                                   : cleanup_error);
        }
        ++recovery_report_.writer_cleanup_recovered_count;
    }
    if (error != nullptr) error->clear();
    return true;
}

bool RecordingCatalog::ValidateMutationLocked(const RecordingMutationV1& mutation,std::string* error,PreparedDerivedMutation* prepared) try {
    if(!opened_||!CanReadLocked(error))return Fail(error,"preappend catalog 권위 거부");
    RecordingMutationV1 parsed;
    if(!ParseRecordingMutationV1(SerializeRecordingMutationV1(mutation),&parsed,error))return false;
    if(parsed.schema!=mutation.schema||parsed.mutation_id!=mutation.mutation_id||parsed.entity_id!=mutation.entity_id||
       parsed.mutation_type!=mutation.mutation_type||parsed.occurred_at_ms!=mutation.occurred_at_ms||
       parsed.payload_json!=mutation.payload_json)return Fail(error,"preappend envelope 정규화 불일치");
    if(!journal_.ValidatePreappend(this,parsed,error))return false;
    if(prepared)return PreparedDerivedMatchesLocked(parsed,*prepared,false,error);
    // 준비 결과는 저장하지 않는다. cold weak 참조와 실제 손상 시 authority 상실은
    // 기존 획득 계약을 따른다. typed 값/ID/revision/hold/SQL/원장에는 쓰지 않는다.
    return ApplyMutationLocked(parsed,false,error,nullptr,{},nullptr,nullptr,nullptr,{},nullptr,false);
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
void RecordingCatalog::NoteSearchMutationLocked(const RecordingMutationV1& mutation) noexcept {
    // 순서 예약은 ID/sequence만 확정한다. 파일·locator·재생 후보는 생기지 않으며
    // 이어지는 실제 finalized/state mutation이 검색의 resolution을 무효화한다.
    if(mutation.mutation_type==RecordingMutationType::RecordingOrderReserved)return;
    const bool observation = mutation.mutation_type == RecordingMutationType::ObservationPut ||
        mutation.mutation_type == RecordingMutationType::ObservationV2Put ||
        mutation.mutation_type == RecordingMutationType::ReferencedObservationPut;
    if (!observation) {
        search_resolution_revision_ = source_snapshot_revision_;
        search_rebuild_revision_ = source_snapshot_revision_;
        search_changes_.clear();
        return;
    }
    // 이 부가 index의 allocation 실패가 원본 녹화 쓰기를 실패시키면 안 된다.
    try {
        if (mutation.entity_id.size() > 512) {
            search_changes_.clear();search_rebuild_revision_ = source_snapshot_revision_;return;
        }
        if (search_changes_.size() == 1024) {
            search_rebuild_revision_ = search_changes_.front().revision;
            search_changes_.pop_front();
        }
        search_changes_.push_back({source_snapshot_revision_, mutation.mutation_type, mutation.entity_id});
    } catch (...) {
        search_changes_.clear();search_rebuild_revision_ = source_snapshot_revision_;
    }
}

bool RecordingCatalog::ApplyMutationLocked(const RecordingMutationV1& mutation,
                                           bool count_duplicate,
                                           std::string* error,PreparedDerivedMutation* prepared,RecordingMutationHandle owned,
                                           const SourceBindingPool* binding_pool,const DerivedJobPool* job_pool,const DerivedJobContentProof* proof,
                                           const RecordingJournalOwnedViewHandle& view,const RecordingGenerationRecoveryRow* generation_row,bool apply,GenerationDelta* delta) try {
    const auto touch=[&](const char* kind,const std::string& id){if(apply&&delta)delta->emplace(kind,id);};
    if(apply) {
    if(source_snapshot_revision_==std::numeric_limits<std::uint64_t>::max())source_snapshot_revision_valid_=false;
    else ++source_snapshot_revision_;
    NoteSearchMutationLocked(mutation);
    }
    // 소유 주소는 검증 증명이 아니다. schema/enum을 포함한 원래 모든 필드를 확인한다.
    if(owned&&(owned->schema!=mutation.schema||owned->mutation_type!=mutation.mutation_type||
       owned->mutation_id!=mutation.mutation_id||owned->entity_id!=mutation.entity_id||
       owned->occurred_at_ms!=mutation.occurred_at_ms||owned->payload_json!=mutation.payload_json))
        return Fail(error,"accepted envelope 전체 필드 불일치");
    if(prepared&&!PreparedDerivedMatchesLocked(mutation,*prepared,false,error))return false;
    const bool segment_state = mutation.mutation_type == RecordingMutationType::ReferencedObservationPut ||
                               mutation.mutation_type == RecordingMutationType::DerivedReferenceAccepted ||
                               IsDerivedJobMutation(mutation.mutation_type) ||
                               mutation.mutation_type == RecordingMutationType::ConsumerReferencePut ||
                               mutation.mutation_type == RecordingMutationType::SegmentFinalized ||
                               mutation.mutation_type == RecordingMutationType::SegmentV2State ||
                               mutation.mutation_type == RecordingMutationType::SegmentV2Deleted ||
                               mutation.mutation_type == RecordingMutationType::SegmentV2Finalized ||
                               mutation.mutation_type == RecordingMutationType::SegmentV2BoundFinalized ||
                               mutation.mutation_type == RecordingMutationType::CorruptionDetected;
    if(apply&&segment_state&&!owned&&!generation_row)owned=std::make_shared<const RecordingMutationV1>(mutation);
    RecordingMutationLink accepted_link;
    if(apply&&generation_row) {
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND
        if(&mutation!=&generation_row->mutation||generation_row->retry)return Fail(error,"B 복원 행 권위 불일치");
        accepted_link=generation_row->link;
#else
        return Fail(error,"B 복원 행 unsupported");
#endif
    }else if(apply&&(segment_state||view)&&!journal_.MakeMutationLink(view,mutation,owned,&accepted_link,error))return false;
    const bool duplicate=completed_history_?MutationSeenLocked(mutation.mutation_id):
        (apply?!mutation_ids_.insert(mutation.mutation_id).second:mutation_ids_.count(mutation.mutation_id)!=0);
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND
    if(apply&&completed_history_&&generation_row&&
       generation_row->global_ordinal!=(generation_visible_ordinal_?*generation_visible_ordinal_+1:0))
        return Fail(error,"B catalog ordinal gap");
#endif
    if (duplicate) {
        if (segment_state) {
            RecordingMutationLink accepted;RecordingMutationHandle prior;
            if (!AcceptedLinkLocked(mutation.mutation_id,&accepted) ||
                !journal_.AcquireMutationLink(accepted,&prior,error) || SerializeRecordingMutationV1(*prior) != SerializeRecordingMutationV1(mutation))
                return Fail(error, "segment state mutation ID envelope 불일치");
        }
        if (apply&&count_duplicate) ++recovery_report_.duplicate_mutation_count;
        if (error != nullptr) error->clear();
        return true;
    }
    bool ok = true;
    switch (mutation.mutation_type) {
        case RecordingMutationType::DerivedJobIntent:
        case RecordingMutationType::DerivedJobFiles:
        case RecordingMutationType::DerivedJobReady:
        case RecordingMutationType::DerivedJobCommitted:
        case RecordingMutationType::DerivedJobComplete:
        case RecordingMutationType::DerivedJobFailed:
            {
                const auto previous=JobEntryLocked(mutation.entity_id);
                const auto old_id=previous?previous->latest_mutation_id:std::string{};
                ok=ApplyDerivedJobMutationLocked(mutation,error,apply,prepared,job_pool,proof,&accepted_link);
                if(ok&&apply&&delta) {
                    const auto current=JobEntryLocked(mutation.entity_id);
                    if(!current)return Fail(error,"derived applied job missing");
                    if(current->latest_mutation_id!=old_id) {
                        touch("derived-job",mutation.entity_id);
                        if(mutation.mutation_type==RecordingMutationType::DerivedJobCommitted)
                            for(const auto& id:current->output_ids){touch("segment-v2",id);touch("media-path",id);}
                    }
                }
            }
            break;
        case RecordingMutationType::ReferencedObservationPut: {
            ReferencedObservationV1 pair;
            ok=options_.enable_v2_storage&&ParseReferencedObservationV1(mutation.payload_json,&pair,error)&&
               pair.observation.observation_id==mutation.entity_id;
            const auto old=referenced_observations_.find(mutation.entity_id);
            if(ok&&old!=referenced_observations_.end())ok=MergeReferenced(old->second,&pair,error);
            if(ok&&apply){referenced_observations_[mutation.entity_id]=std::move(pair);touch("referenced-observation",mutation.entity_id);}
            break;
        }
        case RecordingMutationType::DerivedReferenceAccepted:
        case RecordingMutationType::ConsumerReferencePut: {
            ingress::StrictJsonObjectDocument payload;
            RecordingConsumerReferenceV1 reference;
            const auto json=ObjectField(mutation.payload_json,"reference");
            ok=options_.enable_v2_storage&&
               ingress::ParseStrictJsonObjectDocument(mutation.payload_json,&payload,error)&&payload.members.size()==1&&
               json&&ParseRecordingConsumerReferenceV1(*json,&reference,error)&&reference.reference_id==mutation.entity_id;
            if(ok) {
                const auto old=consumer_references_.find(reference.reference_id);
                if(mutation.mutation_type==RecordingMutationType::DerivedReferenceAccepted) {
                    ok=old!=consumer_references_.end()&&reference.kind=="event"&&
                       SerializeRecordingConsumerReferenceV1(old->second)==SerializeRecordingConsumerReferenceV1(reference);
                    if(ok&&apply){derived_accepted_references_.insert(reference.reference_id);touch("derived-reference-accepted",reference.reference_id);}
                } else {
                    ok=old==consumer_references_.end()||SerializeRecordingConsumerReferenceV1(old->second)==SerializeRecordingConsumerReferenceV1(reference);
                    if(ok&&apply){const auto id=reference.reference_id;consumer_references_.emplace(id,std::move(reference));touch("consumer-reference",id);}
                }
            }
            if(!ok)Fail(error,"consumer reference payload/identity 충돌");
            break;
        }
        case RecordingMutationType::SegmentFinalized: {
            const auto segment_json = ObjectField(mutation.payload_json, "segment");
            const auto relpath = StringField(mutation.payload_json, "mediaRelpath");
            RecordingSegmentV1 segment;
            ok = segment_json && relpath && IsSafeMediaRelpath(*relpath) &&
                 ParseRecordingSegmentV1(*segment_json, &segment, error);
            if (ok && (segment.segment_id != mutation.entity_id ||
                       segment.lifecycle != RecordingLifecycle::Finalized)) {
                ok = Fail(error, "finalized envelope entity/lifecycle 불일치");
            }
            if (!ok && error != nullptr && error->empty()) {
                *error = "recording mediaRelpath가 안전한 상대 경로가 아님";
            }
            if (ok && tombstones_.find(segment.segment_id) != tombstones_.end()) {
                ok = Fail(error, "tombstone segment ID 재사용 금지");
            }
            if (ok && (segments_v2_.count(segment.segment_id)||RetiredLocked(segment.segment_id).has_value())) ok=Fail(error,"V1/V2 segment ID 충돌");
            if (ok) {
                const auto existing = segments_.find(segment.segment_id);
                if (existing != segments_.end()) {
                    auto identity = existing->second;
                    identity.lifecycle = RecordingLifecycle::Finalized;
                    const auto path = media_relpaths_.find(segment.segment_id);
                    if (path == media_relpaths_.end() || path->second != *relpath ||
                        SerializeRecordingSegmentV1(identity) != SerializeRecordingSegmentV1(segment)) {
                        ok = Fail(error, "finalized segment 최초 identity 불일치");
                    }
                    // 동일 identity는 재등록하지 않아 Corrupt/DeletionPending을 되살리지 않는다.
                } else if(apply) {
                    segments_[segment.segment_id] = segment;
                    media_relpaths_[segment.segment_id] = *relpath;
                    touch("segment-v1",segment.segment_id);touch("media-path",segment.segment_id);
                }
            }
            break;
        }
        case RecordingMutationType::EventLinkReceipt:
            ok=journal_.managed_&&options_.enable_v2_storage;
            if(!ok)Fail(error,"receipt managed 지원 필요");
            break;
        case RecordingMutationType::EventLinkCreated: {
            const auto link_json = ObjectField(mutation.payload_json, "link");
            EventRecordingLinkV1 link;
            ok = link_json && ParseEventRecordingLinkV1(*link_json, &link, error);
            if (ok) {
                for (const auto& [existing_link_id, existing] : event_links_) {
                    if (existing.event_id == link.event_id &&
                        existing_link_id != link.link_id) {
                        ok = Fail(error, "같은 event_id의 recording link ID 불일치");
                        break;
                    }
                }
            }
            if (ok) ok = ValidateEventLinkReferencesLocked(link, error);
            if (ok&&apply){event_links_[link.link_id] = link;touch("event-link",link.link_id);}
            break;
        }
        case RecordingMutationType::ObservationPut: {
            const auto observation_json = ObjectField(mutation.payload_json, "observation");
            AnalysisObservationV1 observation;
            ok = observation_json && ParseAnalysisObservationV1(*observation_json, &observation, error);
            if (ok && segments_.find(observation.frame_locator.segment_id) == segments_.end()) {
                ok = Fail(error, "observation segment foreign key 위반");
            }
            if (ok&&apply){observations_[observation.observation_id] = observation;touch("observation-v1",observation.observation_id);}
            break;
        }
        case RecordingMutationType::ObservationV2Put: {
            const auto json = ObjectField(mutation.payload_json, "observation");
            AnalysisObservationV2 observation;
            ok = json && ParseAnalysisObservationV2(*json, &observation, error);
            if (ok && observation.observation_id != mutation.entity_id)
                ok = Fail(error, "observation-v2-entity-mismatch");
            const auto previous = observations_v2_.find(observation.observation_id);
            if (ok && previous != observations_v2_.end())
                ok = MergeObservation(previous->second, &observation, error);
            if (ok&&apply){const auto id=observation.observation_id;observations_v2_[id] = std::move(observation);touch("observation-v2",id);}
            break;
        }
        case RecordingMutationType::DeletionRequested: {
            const auto it = segments_.find(mutation.entity_id);
            const auto reason = StringField(mutation.payload_json, "reason");
            ok = it != segments_.end();
            if (ok&&apply) {
                it->second.lifecycle = RecordingLifecycle::DeletionPending;
                deletion_reasons_[mutation.entity_id] =
                    reason.value_or("manual-corrupt-cleanup");
                touch("segment-v1",mutation.entity_id);touch("deletion-reason",mutation.entity_id);
            }
            else if(!ok) Fail(error, "삭제 요청 segment가 없음");
            break;
        }
        case RecordingMutationType::DeletionCompleted: {
            const auto tombstone_json = ObjectField(mutation.payload_json, "tombstone");
            RecordingTombstoneV1 tombstone;
            ok = tombstone_json && ParseRecordingTombstoneV1(*tombstone_json, &tombstone, error);
            // 기존 V1 tombstone이 V2 삭제 뒤에 오는 이력도 수용해 왔다. 이 특수 경계는
            // full 공존 snapshot과 동일하게 복원하여 cut 위치로 호환 상태가 달라지지 않게 한다.
            RecordingTombstoneV2 restored;
            const bool retired=ok&&RetiredLocked(tombstone.segment_id).has_value();
            if(retired)ok=AcquireRetiredV2Locked(tombstone.segment_id,&restored,error);
            if (ok&&apply) {
                if(retired) {
                    const auto& id=tombstone.segment_id;
                    RecordingSegmentStateV2 state;state.segment_id=id;state.lifecycle=RecordingLifecycle::DeletionPending;
                    state.reason=restored.deletion_reason;
                    segments_v2_[id]=restored.segment;states_v2_[id]=std::move(state);tombstones_v2_[id]=std::move(restored);
                    if(!EraseRetiredLocked(id,error))return false;
                    touch("retired-v2",id);touch("segment-v2",id);touch("state-v2",id);touch("tombstone-v2",id);
                }
                tombstones_[tombstone.segment_id] = tombstone;
                const auto it = segments_.find(tombstone.segment_id);
                if (it != segments_.end()) it->second.lifecycle = RecordingLifecycle::Deleted;
                media_relpaths_.erase(tombstone.segment_id);
                hold_counts_.erase(tombstone.segment_id);
                deletion_reasons_.erase(tombstone.segment_id);
                touch("tombstone-v1",tombstone.segment_id);touch("segment-v1",tombstone.segment_id);
                touch("media-path",tombstone.segment_id);touch("hold",tombstone.segment_id);touch("deletion-reason",tombstone.segment_id);
            }
            break;
        }
        case RecordingMutationType::CorruptionDetected: {
            const auto reason = StringField(mutation.payload_json, "reason");
            const auto it = segments_.find(mutation.entity_id);
            ok = reason && (*reason == "missing-media" || *reason == "checksum-mismatch" ||
                            *reason == "container-invalid" || *reason == "derived-media-missing") &&
                 it != segments_.end();
            if (!ok) Fail(error, "corruption known entity/reason 오류");
            else if (apply&&it->second.lifecycle == RecordingLifecycle::Finalized) {
                it->second.lifecycle = RecordingLifecycle::Corrupt;touch("segment-v1",mutation.entity_id);
            }
            // 이미 Corrupt와 삭제 pending/completed 상태는 단조적으로 보존한다.
            break;
        }
        case RecordingMutationType::RecordingOrderReserved: {
            RecordingOrderReservationV1 order;
            ok = ParseRecordingOrderReservationV1(mutation.payload_json, &order, error) &&
                 order.request_id == mutation.mutation_id && order.segment_id == mutation.entity_id;
            if (ok&&apply){if(!completed_history_)orders_v2_[order.request_id]=order;touch("order",order.request_id);}
            break;
        }
        case RecordingMutationType::SegmentV2Finalized:
        case RecordingMutationType::SegmentV2BoundFinalized: {
            const bool bound=mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized;
            const auto* recovery=RecoveryContentLocked(mutation);
            const bool recovered=bound&&recovery&&recovery->binding;
            ingress::StrictJsonObjectDocument payload;
            const bool parsed=recovered||ingress::ParseStrictJsonObjectDocument(mutation.payload_json,&payload,error);
            const auto segment_json=ingress::StrictJsonObjectField(payload,"segment");
            const auto relative=recovered?std::optional<std::string>(recovery->relative):ingress::StrictJsonStringField(payload,"mediaRelpath");
            RecordingSegmentV2 v;
            if(recovered)v=recovery->segment;
            ok=parsed && (recovered||payload.members.size()==(bound?3U:2U)) &&
               relative && (recovered||(segment_json&&ParseRecordingSegmentV2(*segment_json,&v,error))) && v.segment_id==mutation.entity_id &&
               ValidateV2Locked(v,*relative,error);
            const auto order=OrderLocked(v.order_request_id);
            if (ok && (!order || order->store_id!=v.store_id || order->segment_id!=v.segment_id ||
                order->channel_id!=v.channel_id || order->sequence!=v.order_sequence)) ok=Fail(error,"V2 예약 결박 오류");
            RecordingSourceBindingV1 binding;
            if(ok&&bound) {
                const auto json=ingress::StrictJsonObjectField(payload,"sourceBinding");
                ok=(recovered||(json&&ParseRecordingSourceBindingV1(*json,&binding,error)))&&
                   !segments_v2_.count(v.segment_id)&&ValidateRecordingSourceBindingForSegment(recovered?*recovery->binding:binding,v,error);
            }
            if(ok&&!bound&&SourceEntryLocked(v.segment_id).has_value())ok=Fail(error,"bound downgrade 거부");
            SourceBindingHandle shared_binding;
            if(ok&&bound&&apply){
                if(recovered)shared_binding=recovery->binding;
                // 새 bound ID에 대해서만 조회한다. 풀은 이 호출의 최적화 후보이며 검증 증명이 아니다.
                if(!recovered){
                    if(binding_pool)shared_binding=FindSourceBindingOwned(*binding_pool,v.segment_id);
                }
                if(!recovered&&shared_binding&&SerializeRecordingSourceBindingV1(*shared_binding)!=SerializeRecordingSourceBindingV1(binding))
                    shared_binding.reset();
                if(!shared_binding)shared_binding=std::make_shared<const RecordingSourceBindingV1>(std::move(binding));
            }
            if (ok&&apply) {segments_v2_.emplace(v.segment_id,v);media_relpaths_[v.segment_id]=*relative;
                touch("segment-v2",v.segment_id);touch("media-path",v.segment_id);
                if(bound){ok=StoreSourceEntryLocked(SourceBindingEntry(std::move(shared_binding),accepted_link,mutation.mutation_id),error);touch("source-binding",v.segment_id);}}
            break;
        }
        case RecordingMutationType::SegmentV2State: {
            RecordingSegmentStateV2 state;
            ok=ParseRecordingSegmentStateV2(mutation.payload_json,&state,error) &&
               state.segment_id==mutation.entity_id && segments_v2_.count(state.segment_id)&&!DerivedJobProtectsLocked(state.segment_id);
            if(ok) {
                const auto old=EffectiveLifecycleV2Locked(state.segment_id);
                const auto previous=states_v2_.find(state.segment_id);
                const bool same=previous!=states_v2_.end() &&
                    SerializeRecordingSegmentStateV2(previous->second)==SerializeRecordingSegmentStateV2(state);
                ok=old!=RecordingLifecycle::Deleted && (same || old==RecordingLifecycle::Finalized ||
                    (old==RecordingLifecycle::Corrupt && state.lifecycle==RecordingLifecycle::DeletionPending &&
                     state.reason=="manual-corrupt-cleanup"));
                if(ok&&apply) {states_v2_[state.segment_id]=state;
                    touch("state-v2",state.segment_id);
                    if(state.lifecycle==RecordingLifecycle::DeletionPending){deletion_reasons_[state.segment_id]=state.reason;touch("deletion-reason",state.segment_id);}}
            }
            if(!ok)Fail(error,"V2 상태 전이 거부");
            break;
        }
        case RecordingMutationType::SegmentV2Deleted: {
            RecordingTombstoneV2 tombstone;
            ok=ParseRecordingTombstoneV2(mutation.payload_json,&tombstone,error) &&
               tombstone.segment.segment_id==mutation.entity_id&&!DerivedJobProtectsLocked(mutation.entity_id);
            const auto segment=segments_v2_.find(mutation.entity_id);
            const auto old=tombstones_v2_.find(mutation.entity_id);
            if(ok&&RetiredLocked(mutation.entity_id).has_value()) {
                RecordingTombstoneV2 prior;
                ok=AcquireRetiredV2Locked(mutation.entity_id,&prior,error)&&SerializeRecordingTombstoneV2(prior)==SerializeRecordingTombstoneV2(tombstone);
            } else if(ok && old!=tombstones_v2_.end()) {
                ok=SerializeRecordingTombstoneV2(old->second)==SerializeRecordingTombstoneV2(tombstone);
            } else if(ok) {
                ok=segment!=segments_v2_.end() && EffectiveLifecycleV2Locked(mutation.entity_id)==RecordingLifecycle::DeletionPending &&
                   SerializeRecordingSegmentV2(segment->second)==SerializeRecordingSegmentV2(tombstone.segment) &&
                   (apply?deletion_reasons_[mutation.entity_id]:
                    (deletion_reasons_.count(mutation.entity_id)?deletion_reasons_.at(mutation.entity_id):std::string{}))==tombstone.deletion_reason;
                if(ok&&apply) {
                    if(generation_backend_||generation_row) {
                        const auto path=media_relpaths_.find(mutation.entity_id);RecordingRetiredV2Receipt receipt;
                        if(path==media_relpaths_.end()||!MakeRetiredReceipt(tombstone,path->second,mutation.mutation_id,&receipt) ||
                           !StoreRetiredLocked(receipt,accepted_link,error))ok=false;
                        else {if(completed_history_)source_bindings_.erase(mutation.entity_id);segments_v2_.erase(mutation.entity_id);states_v2_.erase(mutation.entity_id);
                            media_relpaths_.erase(mutation.entity_id);deletion_reasons_.erase(mutation.entity_id);touch("retired-v2",mutation.entity_id);
                            touch("segment-v2",mutation.entity_id);touch("state-v2",mutation.entity_id);touch("media-path",mutation.entity_id);touch("deletion-reason",mutation.entity_id);}
                    } else {tombstones_v2_[mutation.entity_id]=tombstone;touch("tombstone-v2",mutation.entity_id);}
                    hold_counts_.erase(mutation.entity_id);touch("hold",mutation.entity_id);
                }
            }
            if(!ok)Fail(error,"V2 삭제 완료 전이 거부");
            break;
        }
        case RecordingMutationType::Unknown:
            ok = Fail(error, "unknown mutation");
            break;
    }
    if (!apply)return ok;
    if (!ok) {if(!completed_history_)mutation_ids_.erase(mutation.mutation_id);}
    else {
        if (segment_state) {
            if(!completed_history_)accepted_segment_state_mutations_.emplace(mutation.mutation_id, std::move(accepted_link));
            touch("accepted-state",mutation.mutation_id);
        }
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND
        if(completed_history_&&generation_row)generation_visible_ordinal_=generation_row->global_ordinal;
#endif
        RememberRecoveryContentLocked(mutation);
    }
    return ok;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

#if MEDIA_SERVER_RECORDING_GENERATION_TESTING
thread_local int RecordingCatalog::generation_apply_fault_=0;
#endif
bool RecordingCatalog::PoisonGenerationLocked(std::string* error) {
    derived_job_state_authoritative_=false;journal_.PoisonGeneration(this);
    if(error&&error->empty())*error="B durable 이후 실패: 새 owner strict Open 필요";
    return false;
}
bool RecordingCatalog::AppendGenerationLocked(RecordingMutationV1 mutation,std::string* error,PreparedDerivedMutation* prepared,bool acquire_hold) { fc::Scope fc_phase_scope("AppendGenerationLocked");
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    if(!CanWriteLocked(error)||!generation_backend_)return false;
    mutation.mutation_id=mutation.mutation_id.empty()?NextMutationId():mutation.mutation_id;
    mutation.occurred_at_ms=mutation.occurred_at_ms?mutation.occurred_at_ms:NowMs();
    if(!ValidateMutationLocked(mutation,error,prepared))return false;
    std::uint64_t held=0;
    if(acquire_hold){
        if(mutation.mutation_type!=RecordingMutationType::SegmentFinalized)return Fail(error,"B finalize hold type rejected");
        const auto current=hold_counts_.find(mutation.entity_id);
        held=current==hold_counts_.end()?0:current->second;
        if(held>=static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()))return Fail(error,"B finalize hold overflow");
        if(segments_.count(mutation.entity_id)||segments_v2_.count(mutation.entity_id))return Fail(error,"B finalize hold requires new segment");
    }
    bool rotate=false;if(!journal_.GenerationRotationNeeded(this,mutation,&rotate,error))return false;
    if(rotate&&!CheckpointGenerationLocked(error))return false;
    std::shared_ptr<const RecordingGenerationRecoveryRow> row;
    if(!journal_.AppendGeneration(this,mutation,&row,error)) {
        if(!journal_.OwnsCatalog(this))derived_job_state_authoritative_=false;
        return false;
    }
    if(row->retry){if(error)error->clear();return true;}
    try {
#if MEDIA_SERVER_RECORDING_GENERATION_TESTING
        const int fault=generation_apply_fault_;generation_apply_fault_=0;
        if(fault==1){Fail(error,"B test current apply 실패");return PoisonGenerationLocked(error);}
        if(fault==2)throw std::runtime_error("B test post-fsync exception");
#endif
        GenerationDelta delta;
        if(!ApplyMutationLocked(row->mutation,false,error,prepared,{},nullptr,nullptr,nullptr,{},row.get(),true,&delta))return PoisonGenerationLocked(error);
        if(acquire_hold){hold_counts_[mutation.entity_id]=held+1;delta.emplace("hold",mutation.entity_id);}
        if(accepted_segment_state_mutations_.count(mutation.mutation_id)) {
            accepted_generation_ordinals_.emplace(mutation.mutation_id,row->global_ordinal);
            delta.emplace("accepted-state",mutation.mutation_id);
        }
        // 변경된 job/source에 한해 필요한 활성 상세를 유지한다. 과거 상세를 순회하지 않는다.
        if(IsDerivedJobMutation(mutation.mutation_type)) {
            const auto current=JobEntryLocked(mutation.entity_id);
            if(!current)return PoisonGenerationLocked(error);
            const auto& job=*current;
            for(const auto& id:job.source_ids) {
                auto found=source_bindings_.find(id);
                if(found==source_bindings_.end())continue;
                if(job.Active()) {SourceBindingHandle binding;if(!AcquireSourceBindingOwnedLocked(id,&binding,error)||!binding)return PoisonGenerationLocked(error);found->second.resident=std::move(binding);}
                else if(!DerivedJobProtectsLocked(id))found->second.resident.reset();
            }
            if(!job.Active()){const auto live=derived_jobs_.find(mutation.entity_id);if(live!=derived_jobs_.end())live->second.resident.reset();}
        }
        if(mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized&&!DerivedJobProtectsLocked(mutation.entity_id))
            source_bindings_.at(mutation.entity_id).resident.reset();
        if(!ProjectGenerationDeltaLocked(delta,*row,error))return PoisonGenerationLocked(error);
        if(prepared)prepared->phase=PreparedDerivedMutation::Phase::Consumed;
        if(!EvictCompletedJobLocked(mutation.entity_id,error))return PoisonGenerationLocked(error);
        if(error)error->clear();
        return true;
    }catch(...){Fail(error,"B durable 후 적용/투영 예외");return PoisonGenerationLocked(error);}
#else
    (void)mutation;(void)prepared;(void)acquire_hold;return Fail(error,"B append unsupported");
#endif
}
bool RecordingCatalog::ReserveRecordingOrder(const std::string& store,const std::string& request,
    const std::string& segment,const std::string& channel,RecordingOrderReservationV1* result,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!generation_backend_)return journal_.ReserveRecordingOrder(store,request,segment,channel,result,error);
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    if(!result||!generation_backend_||!CanWriteLocked(error))return Fail(error,"B Catalog 전용 예약 거부");
    RecordingOrderReservationV1 order;std::shared_ptr<const RecordingGenerationRecoveryRow> row;
    bool rotate=false;
    if(!journal_.ReserveGeneration(this,store,request,segment,channel,&order,&row,error,&rotate)) {
        if(!journal_.OwnsCatalog(this))derived_job_state_authoritative_=false;
        return false;
    }
    if(rotate) {
        if(!CheckpointGenerationLocked(error)||!journal_.ReserveGeneration(this,store,request,segment,channel,&order,&row,error))return false;
    }
    try {
        if(!row->retry) {
            GenerationDelta delta;
            if(!ApplyMutationLocked(row->mutation,false,error,nullptr,{},nullptr,nullptr,nullptr,{},row.get(),true,&delta)||
               !ProjectGenerationDeltaLocked(delta,*row,error))return PoisonGenerationLocked(error);
        }
        *result=std::move(order);if(error)error->clear();return true;
    }catch(...){Fail(error,"B durable 예약 투영 예외");return PoisonGenerationLocked(error);}
#else
    (void)store;(void)request;(void)segment;(void)channel;(void)result;return Fail(error,"B 예약 unsupported");
#endif
}
bool RecordingCatalog::ProjectGenerationDeltaLocked(const GenerationDelta& delta,const RecordingGenerationRecoveryRow& row,std::string* error) {
#if MEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND && MEDIA_SERVER_USE_SQLITE3 && !defined(_WIN32)
    auto* db=generation_sqlite_db_;
    if(!db)return journal_.CommitGenerationDelta(this,[]{return true;},error);
    if(!journal_.ValidateGenerationOwner(this,error)||!Exec(db,"BEGIN IMMEDIATE",error))return false;
    const auto fail=[&](){Exec(db,"ROLLBACK",nullptr);return false;};
    try {
        const auto statement=[&](const char* sql,const std::vector<std::string>& values) {
            sqlite3_stmt* query=nullptr;
            if(sqlite3_prepare_v2(db,sql,-1,&query,nullptr)!=SQLITE_OK)return Fail(error,sqlite3_errmsg(db));
            bool ok=true;int at=1;
            for(const auto& value:values)if(sqlite3_bind_text(query,at++,value.data(),static_cast<int>(value.size()),SQLITE_TRANSIENT)!=SQLITE_OK)ok=false;
            ok=ok&&sqlite3_step(query)==SQLITE_DONE;sqlite3_finalize(query);
            return ok?true:Fail(error,sqlite3_errmsg(db));
        };
        for(const auto& key:delta) {
            const auto& kind=key.first;const auto& id=key.second;std::string value;bool present=false;
#define DELTA_VALUE(map,serializer) do {const auto i=map.find(id);if(i!=map.end()){present=true;value=serializer(i->second);}}while(false)
            if(kind=="segment-v1")DELTA_VALUE(segments_,SerializeRecordingSegmentV1);
            else if(kind=="segment-v2")DELTA_VALUE(segments_v2_,SerializeRecordingSegmentV2);
            else if(kind=="state-v2")DELTA_VALUE(states_v2_,SerializeRecordingSegmentStateV2);
            else if(kind=="tombstone-v1")DELTA_VALUE(tombstones_,SerializeRecordingTombstoneV1);
            else if(kind=="tombstone-v2")DELTA_VALUE(tombstones_v2_,SerializeRecordingTombstoneV2);
            else if(kind=="retired-v2") {const auto i=RetiredLocked(id);if(i){present=SerializeRecordingRetiredV2Receipt(*i,&value,error);if(!present)return fail();}}
            else if(kind=="event-link")DELTA_VALUE(event_links_,SerializeEventRecordingLinkV1);
            else if(kind=="observation-v1")DELTA_VALUE(observations_,SerializeAnalysisObservationV1);
            else if(kind=="observation-v2")DELTA_VALUE(observations_v2_,SerializeAnalysisObservationV2);
            else if(kind=="consumer-reference")DELTA_VALUE(consumer_references_,SerializeRecordingConsumerReferenceV1);
            else if(kind=="referenced-observation")DELTA_VALUE(referenced_observations_,SerializeReferencedObservationV1);
            else if(kind=="media-path"||kind=="deletion-reason") {
                const auto& map=kind=="media-path"?media_relpaths_:deletion_reasons_;const auto i=map.find(id);
                if(i!=map.end()){present=true;value="\""+Escape(i->second)+"\"";}
            } else if(kind=="derived-reference-accepted") {present=derived_accepted_references_.count(id);value="true";}
            else if(kind=="accepted-state") {std::uint64_t ordinal=0;present=AcceptedLinkLocked(id,nullptr,&ordinal);if(present)value=std::to_string(ordinal);}
            else if(kind=="order") {const auto i=OrderLocked(id);if(i){present=true;const auto& o=*i;
                value="{\"storeId\":\""+Escape(o.store_id)+"\",\"requestId\":\""+Escape(o.request_id)+"\",\"segmentId\":\""+Escape(o.segment_id)+"\",\"channelId\":\""+Escape(o.channel_id)+"\",\"sequence\":"+std::to_string(o.sequence)+"}";}}
            else if(kind=="source-binding") {
                const auto i=SourceEntryLocked(id);if(i){present=true;const auto& s=*i;
                    if(!SerializeRecordingCatalogSourceSummary({s.id,s.channel,s.source,s.generation,s.track,s.order,s.sample_count,s.latest_mutation_id},&value,error))return fail();}
            } else if(kind=="derived-job") {
                const auto i=JobEntryLocked(id);if(i){present=true;const auto& j=*i;
                    if(!SerializeRecordingCatalogJobSummary({j.id,j.channel,j.reference,j.state,j.files,j.reserved_bytes,j.output_ids,j.source_ids,j.latest_mutation_id},&value,error))return fail();}
            } else if(kind=="hold") {const auto i=hold_counts_.find(id);if(i!=hold_counts_.end()){present=true;value=std::to_string(i->second);}}
            else {Fail(error,"B delta 알 수 없는 kind");return fail();}
#undef DELTA_VALUE
            if(present&&value.empty()){Fail(error,"B delta 직렬화 실패");return fail();}
            if(kind=="source-binding"||kind=="derived-job"||kind=="hold") {
                const char* upsert=kind=="source-binding"?"INSERT INTO b_source_summary VALUES(?,?) ON CONFLICT(id) DO UPDATE SET summary_json=excluded.summary_json":
                    kind=="derived-job"?"INSERT INTO b_job_summary VALUES(?,?) ON CONFLICT(id) DO UPDATE SET summary_json=excluded.summary_json":
                    "INSERT INTO b_hold VALUES(?,?) ON CONFLICT(id) DO UPDATE SET count=excluded.count";
                const char* remove=kind=="source-binding"?"DELETE FROM b_source_summary WHERE id=?":kind=="derived-job"?"DELETE FROM b_job_summary WHERE id=?":"DELETE FROM b_hold WHERE id=?";
                if(!statement(present?upsert:remove,present?std::vector<std::string>{id,value}:std::vector<std::string>{id}))return fail();
            } else if(!statement(present?"INSERT INTO b_current VALUES(?,?,?) ON CONFLICT(kind,id) DO UPDATE SET value_json=excluded.value_json":"DELETE FROM b_current WHERE kind=? AND id=?",
                present?std::vector<std::string>{kind,id,value}:std::vector<std::string>{kind,id}))return fail();
        }
        const auto& m=row.mutation;
        if(!statement("INSERT INTO b_identity VALUES(?,?,?,?,?,?)",{m.mutation_id,RecordingMutationTypeName(m.mutation_type),m.entity_id,
            std::to_string(m.occurred_at_ms),std::to_string(row.global_ordinal),row.identity}))return fail();
        if(!journal_.CommitGenerationDelta(this,[&]{return Exec(db,"COMMIT",error);},error))return fail();
        return true;
    }catch(...){Exec(db,"ROLLBACK",nullptr);throw;}
#else
    (void)delta;(void)row;return journal_.CommitGenerationDelta(this,[]{return true;},error);
#endif
}

bool RecordingCatalog::AppendAndApplyLocked(RecordingMutationV1 mutation, std::string* error,PreparedDerivedMutation* prepared) {
    recording::latency::Scope latency_scope(recording::latency::Operation::Append,recording::latency::Source::Catalog,__LINE__,false);
    if(!CanWriteLocked(error))return false;
    if(generation_backend_)return AppendGenerationLocked(std::move(mutation),error,prepared);
    if(prepared&&!PreparedDerivedMatchesLocked(mutation,*prepared,false,error))return false;
    mutation.mutation_id = mutation.mutation_id.empty() ? NextMutationId() : mutation.mutation_id;
    mutation.occurred_at_ms = mutation.occurred_at_ms == 0 ? NowMs() : mutation.occurred_at_ms;
    RecordingMutationHandle owned;
    RecordingJournalOwnedViewHandle view;
    if (!journal_.AppendOwned(mutation, this, error,&owned,&view)) return false;
    try {
        if (!ApplyMutationLocked(mutation, false, error,prepared,owned,nullptr,nullptr,nullptr,view)) {
            automatic_noop_eligible_=false;journal_.InvalidateAutomaticCheckpointNoop(this);return false;
        }
    }catch(...){
        // 기존 예외/authority/재시도 의미는 유지한다. 중간 insert된 ID를 성공 증명으로
        // 오인하지 않도록 이 attachment의 자동 no-op만 비적격으로 만든다.
        automatic_noop_eligible_=false;journal_.InvalidateAutomaticCheckpointNoop(this);throw;
    }
    std::optional<DerivedJobContentProof> content_proof;
    if(prepared&&prepared->phase==PreparedDerivedMutation::Phase::Applied&&
       PreparedDerivedMatchesLocked(mutation,*prepared,true,nullptr))
        content_proof=DerivedJobContentProof{this,owned,prepared->applied};
    if (sqlite_db_ != nullptr) {
        std::string projection_error;
        auto* projection_prepared=prepared&&prepared->phase==PreparedDerivedMutation::Phase::Applied?prepared:nullptr;
        if (!ProjectMutationSqliteLocked(mutation, &projection_error,projection_prepared)) {
            ++recovery_report_.projection_error_count;
            CloseSqliteLocked();
            catalog_mode_ = "jsonl-fallback";
            if (error != nullptr) error->clear();
        }
    }
    if(prepared)prepared->phase=PreparedDerivedMutation::Phase::Consumed;
    if(journal_.CheckpointDue(this)){
        bool handled=false;
        if(automatic_noop_eligible_&&!journal_.TryAutomaticCheckpointNoop(this,mutation_ids_,&handled,error)){
            checkpoint_cache_.reset();if(!journal_.OwnsCatalog(this))derived_job_state_authoritative_=false;
            return false;
        }
        if(!handled&&!CheckpointLocked(false,error,content_proof?&*content_proof:nullptr))return false;
    }
    return !journal_.managed_||ReleaseInactiveDetailsLocked(&mutation.entity_id,error);
}

bool RecordingCatalog::PreflightV2Locked(const RecordingJournalReplayResult& replay,std::string* error,
                                       const RecordingSegmentV2* candidate,const std::string& relative,
                                       const RecordingSourceBindingV1* binding,const RecordingMutationHandles& owned,const RecordingJournalOwnedViews& views) const {
    if(!owned.empty()&&owned.size()!=replay.mutations.size())return Fail(error,"preflight owned 기록 개수 불일치");
    if(!views.empty()&&views.size()!=replay.mutations.size())return Fail(error,"preflight view 기록 개수 불일치");
    bool orders=false,v2=false;
    std::unordered_set<std::string> v2_ids;
    for(const auto& m:replay.mutations) {
        if(m.mutation_type==RecordingMutationType::DerivedReferenceAccepted||m.mutation_type==RecordingMutationType::ConsumerReferencePut||m.mutation_type==RecordingMutationType::ReferencedObservationPut||
           IsDerivedJobMutation(m.mutation_type))v2=true;
        if(m.mutation_type==RecordingMutationType::EventLinkReceipt&&(!journal_.managed_||!options_.enable_v2_storage))
            return Fail(error,"receipt managed 지원 필요");
        orders=orders||m.mutation_type==RecordingMutationType::RecordingOrderReserved;
        if(m.mutation_type==RecordingMutationType::SegmentV2Finalized ||
           m.mutation_type==RecordingMutationType::SegmentV2BoundFinalized ||
           m.mutation_type==RecordingMutationType::SegmentV2State ||
           m.mutation_type==RecordingMutationType::SegmentV2Deleted){v2=true;v2_ids.insert(m.entity_id);}
    }
    if(v2&&!options_.enable_v2_storage)return Fail(error,"V2 storage opt-in 필요");
    if(!(options_.enable_v2_storage||orders||v2))return true;
    if(replay.io_error_count||replay.unsupported_record_count||replay.corrupt_line_count||replay.truncated_tail_count)
        return Fail(error,"V2/order 원장 불완전 상태");
    std::vector<RecordingOrderReservationV1> reservations;
    if(!ValidateRecordingOrderHistory(replay.mutations,&reservations,error))return false;
    // Open 실패가 live memory/SQLite/cleanup에 부분 상태를 남기지 않도록 임시 투영한다.
    RecordingCatalog scratch(journal_,options_);
    std::unordered_map<std::string,RecordingMutationV1> seen;
    for(std::size_t ordinal=0;ordinal<replay.mutations.size();++ordinal) {
        const auto& m=replay.mutations[ordinal];
        RecoveryContentScope recovery_row(scratch,recovery_content_,ordinal,owned.empty()?RecordingMutationHandle{}:owned[ordinal]);
        if(!owned.empty()&&!owned[ordinal])return Fail(error,"preflight null envelope 거부");
        const auto old=seen.find(m.mutation_id);
        if(old!=seen.end()&&(m.mutation_type==RecordingMutationType::ReferencedObservationPut||
           m.mutation_type==RecordingMutationType::DerivedReferenceAccepted||
           old->second.mutation_type==RecordingMutationType::DerivedReferenceAccepted||
           IsDerivedJobMutation(m.mutation_type)||
           IsDerivedJobMutation(old->second.mutation_type)||
           old->second.mutation_type==RecordingMutationType::ReferencedObservationPut||m.mutation_type==RecordingMutationType::ConsumerReferencePut||
           old->second.mutation_type==RecordingMutationType::ConsumerReferencePut||m.mutation_type==RecordingMutationType::SegmentV2Finalized||
           m.mutation_type==RecordingMutationType::SegmentV2BoundFinalized||
           old->second.mutation_type==RecordingMutationType::SegmentV2BoundFinalized||
           old->second.mutation_type==RecordingMutationType::SegmentV2Finalized)&&
           SerializeRecordingMutationV1(old->second)!=SerializeRecordingMutationV1(m))return Fail(error,"V2 mutation ID 충돌");
        seen.emplace(m.mutation_id,m);
        const bool accepted=scratch.ApplyMutationLocked(m,false,error,nullptr,owned.empty()?RecordingMutationHandle{}:owned[ordinal],nullptr,nullptr,nullptr,views.empty()?RecordingJournalOwnedViewHandle{}:views[ordinal]);
        if(!accepted&&(journal_.managed_||m.mutation_type==RecordingMutationType::DerivedReferenceAccepted||m.mutation_type==RecordingMutationType::ReferencedObservationPut||m.mutation_type==RecordingMutationType::ConsumerReferencePut||m.mutation_type==RecordingMutationType::SegmentV2Finalized||v2_ids.count(m.entity_id)))return false;
    }
    if(candidate) {
        if(binding ? !scratch.ValidateBoundLocked(*candidate,*binding,relative,error) :
           (!scratch.ValidateV2Locked(*candidate,relative,error)||scratch.SourceEntryLocked(candidate->segment_id).has_value()))return false;
        const auto order=scratch.OrderLocked(candidate->order_request_id);
        if(!order||order->store_id!=candidate->store_id||
           order->segment_id!=candidate->segment_id||order->channel_id!=candidate->channel_id||
           order->sequence!=candidate->order_sequence)return Fail(error,"V2 예약 없음/tuple 불일치");
    }
    if(error)error->clear();
    return true;
}

bool RecordingCatalog::ValidateV2Locked(const RecordingSegmentV2& v,const std::string& relative,std::string* error) const try {
    if(!options_.enable_v2_storage||!ValidateRecordingSegmentV2(v,error)||!IsSafeMediaRelpath(relative))
        return Fail(error,"V2 opt-in/metadata/path 오류");
    if(tombstones_.count(v.segment_id)||RetiredLocked(v.segment_id).has_value()||segments_.count(v.segment_id))return Fail(error,"V2 삭제/V1 ID 충돌");
    const auto found=segments_v2_.find(v.segment_id);
    if(found!=segments_v2_.end()) {
        if(EffectiveLifecycleV2Locked(v.segment_id)!=RecordingLifecycle::Finalized)
            return Fail(error,"V2 상태 변경 뒤 finalize 거부");
        const auto path=media_relpaths_.find(v.segment_id);
        if(SerializeRecordingSegmentV2(found->second)!=SerializeRecordingSegmentV2(v)||
           path==media_relpaths_.end()||path->second!=relative)return Fail(error,"V2 immutable identity/path 충돌");
    }
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::ValidateManagedCandidateLocked(const RecordingSegmentV2& v,const std::string& relative,std::string* error) const {
    RecordingOrderReservationV1 order;order.store_id=v.store_id;order.request_id=v.order_request_id;
    order.segment_id=v.segment_id;order.channel_id=v.channel_id;order.sequence=v.order_sequence;
    return CanWriteLocked(error)&&ValidateV2Locked(v,relative,error)&&journal_.ManagedOrderMatches(order,error);
}

bool RecordingCatalog::ValidateBoundLocked(const RecordingSegmentV2& s,const RecordingSourceBindingV1& b,
                                            const std::string& relative,std::string* error) const {
    if(!ValidateV2Locked(s,relative,error)||!ValidateRecordingSourceBindingForSegment(b,s,error))return false;
    const auto old=FindSourceBindingOwnedLocked(s.segment_id);
    if(segments_v2_.count(s.segment_id) && !old)return Fail(error,"unbound 소급 결박 거부");
    if(old&&SerializeRecordingSourceBindingV1(*old)!=SerializeRecordingSourceBindingV1(b))
        return Fail(error,"source binding immutable 충돌");
    return true;
}
bool RecordingCatalog::ValidateBoundFinalizeRecoveryV2(const RecordingSegmentV2& s,const RecordingSourceBindingV1& b,
                                                       const std::string& path,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!CanWriteLocked(error))return Fail(error,"bound catalog 소유권/상태 오류");
    const auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    const auto absolute=std::filesystem::absolute(path);
    if(absolute!=absolute.lexically_normal())return Fail(error,"bound path 비정규");
    const auto relative=absolute.lexically_relative(root).generic_string();
    if(!ValidateBoundLocked(s,b,relative,error))return false;
    if(journal_.managed_)return ValidateManagedCandidateLocked(s,relative,error);
    return PreflightV2Locked(journal_.Replay(),error,&s,relative,&b);
}
bool RecordingCatalog::CommitBoundLocked(const RecordingSegmentV2& s,const RecordingSourceBindingV1& b,
                                         const std::string& path,bool recovery,bool* inserted,std::string* error) {
    if(inserted)*inserted=false;
    if(!opened_||!CanWriteLocked(error))return Fail(error,"bound catalog 소유권/상태 오류");
    const auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    const auto absolute=std::filesystem::absolute(path);
    if(absolute!=absolute.lexically_normal())return Fail(error,"bound path 비정규");
    const auto relative=absolute.lexically_relative(root).generic_string();
    if(!ValidateBoundLocked(s,b,relative,error))return false;
    if(journal_.managed_) {
        if(!ValidateManagedCandidateLocked(s,relative,error))return false;
    } else if(!PreflightV2Locked(journal_.Replay(),error,&s,relative,&b))return false;
    if(segments_v2_.count(s.segment_id)) {
        if(!recovery)return Fail(error,"bound ID 이미 존재");
        if(error)error->clear();
        return true;
    }
    // 등록 경로의 각 구성요소를 확인한다. 비협력 외부 writer와의 경쟁 원자성 보장은 아니다.
    std::filesystem::path current;
    for(const auto& part:absolute) {
        current/=part;
        std::error_code ec;const auto status=std::filesystem::symlink_status(current,ec);
        if(ec||std::filesystem::is_symlink(status))return Fail(error,"bound 실제 경로 오류");
    }
    std::error_code ec;
    if(!std::filesystem::is_regular_file(absolute,ec)||ec||std::filesystem::hard_link_count(absolute,ec)!=1||ec)
        return Fail(error,"bound 실제 파일 없음/형식 오류");
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::SegmentV2BoundFinalized;
    mutation.entity_id=s.segment_id;
    mutation.payload_json="{\"segment\":"+SerializeRecordingSegmentV2(s)+",\"mediaRelpath\":\""+Escape(relative)+
        "\",\"sourceBinding\":"+SerializeRecordingSourceBindingV1(b)+"}";
    if(journal_.managed_) {
        RecordingOrderReservationV1 order;order.store_id=s.store_id;order.request_id=s.order_request_id;
        order.segment_id=s.segment_id;order.channel_id=s.channel_id;order.sequence=s.order_sequence;
        if(!completed_history_)orders_v2_[order.request_id]=order;
    } else {
        std::vector<RecordingOrderReservationV1> orders;
        if(!ValidateRecordingOrderHistory(journal_.Replay().mutations,&orders,error))return false;
        for(const auto& order:orders)orders_v2_[order.request_id]=order;
    }
    if(!AppendAndApplyLocked(std::move(mutation),error))return false;
    if(inserted)*inserted=true;
    return true;
}
bool RecordingCatalog::FinalizeBoundSegmentV2(const RecordingSegmentV2& s,const RecordingSourceBindingV1& b,
                                              const std::string& path,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");return CommitBoundLocked(s,b,path,false,nullptr,error);
}
bool RecordingCatalog::RecoverBoundSegmentV2(const RecordingSegmentV2& s,const RecordingSourceBindingV1& b,
                                             const std::string& path,bool* inserted,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");return CommitBoundLocked(s,b,path,true,inserted,error);
}
RecordingCatalog::SourceBindingHandle RecordingCatalog::FindSourceBindingOwned(const SourceBindingPool& pool,const std::string& id) {
    const auto found=pool.find(id);return found==pool.end()?SourceBindingHandle{}:found->second.WarmOwned();
}
RecordingCatalog::SourceBindingHandle RecordingCatalog::FindSourceBindingOwnedLocked(const std::string& id) const {
    SourceBindingHandle result;AcquireSourceBindingOwnedLocked(id,&result,nullptr);return result;
}
RecordingCatalog::SourceBindingEntry::SourceBindingEntry(SourceBindingHandle value,RecordingMutationLink link,std::string latest)
    :latest_mutation_id(std::move(latest)),mutation(std::move(link)),weak(value),resident(std::move(value)) {
    if(!resident)return;
    id=resident->segment_id;channel=resident->channel_id;source=resident->source_id;
    generation=resident->source_generation;track=resident->track_id;order=resident->generation_order;sample_count=resident->samples.size();
}
RecordingCatalog::DerivedJobEntry::DerivedJobEntry(DerivedJobHandle value,RecordingMutationLink link,std::string latest)
    :latest_mutation_id(std::move(latest)),mutation(std::move(link)),weak(value),resident(std::move(value)) {
    if(!resident)return;
    id=resident->intent.job_id;channel=resident->intent.reference.channel_id;reference=resident->intent.reference.reference_id;
    state=resident->state;files=resident->files.size();reserved_bytes=resident->intent.reserved_bytes;
    for(const auto& value:resident->intent.outputs)output_ids.push_back(value.output_id);
    for(const auto& value:resident->intent.sources)source_ids.push_back(value.segment.segment_id);
}
bool RecordingCatalog::MaterializeSourceBinding(const SourceBindingEntry& entry,const RecordingSegmentV2& original,
    const RecordingMutationHandle& mutation,SourceBindingHandle* out,std::string* error) {
    if(out)out->reset();
    if(!out||!mutation||mutation->mutation_id!=entry.latest_mutation_id||mutation->entity_id!=entry.id||mutation->mutation_type!=RecordingMutationType::SegmentV2BoundFinalized)
        return Fail(error,"source binding 상세 재획득 거부");
    ingress::StrictJsonObjectDocument payload;RecordingSegmentV2 segment;RecordingSourceBindingV1 binding;
    if(!ingress::ParseStrictJsonObjectDocument(mutation->payload_json,&payload,error)||payload.members.size()!=3)return false;
    const auto segment_json=ingress::StrictJsonObjectField(payload,"segment");
    const auto binding_json=ingress::StrictJsonObjectField(payload,"sourceBinding");
    const auto path=ingress::StrictJsonStringField(payload,"mediaRelpath");
    if(!segment_json||!binding_json||!path||!ParseRecordingSegmentV2(*segment_json,&segment,error)||
       !ParseRecordingSourceBindingV1(*binding_json,&binding,error)||!ValidateRecordingSourceBindingForSegment(binding,segment,error)||
       SerializeRecordingSegmentV2(segment)!=SerializeRecordingSegmentV2(original)||
       binding.segment_id!=entry.id||binding.channel_id!=entry.channel||binding.source_id!=entry.source||
       binding.source_generation!=entry.generation||binding.generation_order!=entry.order||binding.track_id!=entry.track||binding.samples.size()!=entry.sample_count)
        return Fail(error,"source binding 상세 재획득 거부");
    *out=std::make_shared<const RecordingSourceBindingV1>(std::move(binding));return true;
}
bool RecordingCatalog::AcquireRetiredV2Locked(const std::string& id,RecordingTombstoneV2* out,std::string* error) const {
    try {
        const auto receipt=RetiredLocked(id);RecordingMutationLink link;RecordingMutationHandle mutation;
        if(!receipt){derived_job_state_authoritative_=false;return Fail(error,"retired receipt 없음");}
        if(completed_history_){if(!journal_.MakeGenerationMutationLink(receipt->deletion_mutation_id,&link,error)){derived_job_state_authoritative_=false;return false;}}
        else {const auto found=retired_v2_links_.find(id);if(found==retired_v2_links_.end())return false;link=found->second;}
        if(journal_.AcquireMutationLink(link,&mutation,error)&&MaterializeRetiredV2(*receipt,mutation,out,error))return true;
    }catch(...){}
    derived_job_state_authoritative_=false;return Fail(error,"retired V2 상세 재획득 거부");
}
bool RecordingCatalog::AcquireOriginalV2Locked(const std::string& id,RecordingSegmentV2* out,std::string* error) const try {
    if(!out)return false;
    const auto full=segments_v2_.find(id);if(full!=segments_v2_.end()){*out=full->second;return true;}
    if(!RetiredLocked(id).has_value())return false;
    RecordingTombstoneV2 tomb;if(!AcquireRetiredV2Locked(id,&tomb,error))return false;
    *out=std::move(tomb.segment);return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::AcquireSourceBindingOwnedLocked(const std::string& id,SourceBindingHandle* out,std::string* error) const {
    if(out)out->reset();
    const auto failed=[&](){derived_job_state_authoritative_=false;return Fail(error,"source binding 상세 재획득 거부");};
    try {
        if(!out)return failed();
        const auto found=SourceEntryLocked(id);if(!found)return true;
        const auto& entry=*found;if(!entry)return failed();
        if(entry.resident){*out=entry.resident;return true;}
        RecordingMutationHandle mutation;
        if(!journal_.AcquireMutationLink(entry.mutation,&mutation,error)||!mutation||mutation->mutation_id!=entry.latest_mutation_id||
           mutation->entity_id!=id||mutation->mutation_type!=RecordingMutationType::SegmentV2BoundFinalized)return failed();
        RecordingSegmentV2 original;
        if(!AcquireOriginalV2Locked(id,&original,error)||!MaterializeSourceBinding(entry,original,mutation,out,error))return failed();
        // 삭제/현재 미디어 상태가 아니라, 원장에 저장한 불변 원본 결박을 검증한다.
        entry.weak=*out;return true;
    }catch(...){if(out)out->reset();return failed();}
}
bool RecordingCatalog::AcquireDerivedJobOwnedLocked(const std::string& id,DerivedJobHandle* out,std::string* error) const {
    return AcquireDerivedJobOwnedWithEnvelopeLocked(id,out,nullptr,error);
}
bool RecordingCatalog::AcquireDerivedJobOwnedWithEnvelopeLocked(const std::string& id,DerivedJobHandle* out,RecordingMutationHandle* envelope,std::string* error,
    std::shared_ptr<RecordingJournal::ColdReadProof>* proof) const {
    if(out)out->reset();
    if(envelope)envelope->reset();
    const auto failed=[&](){derived_job_state_authoritative_=false;return Fail(error,"derived job 상세 재획득 거부");};
    try {
        if(!out)return failed();
        const auto found=JobEntryLocked(id);if(!found)return true;
        const auto& entry=*found;if(!entry)return failed();
        if(entry.resident){*out=entry.resident;return true;}
        RecordingMutationHandle mutation;DerivedJobRecordV1 record;
        const bool acquired=proof?journal_.AcquireMutationLinkForRead(this,entry.mutation,proof,&mutation,error):journal_.AcquireMutationLink(entry.mutation,&mutation,error);
        if(!acquired||!mutation||mutation->mutation_id!=entry.latest_mutation_id||mutation->entity_id!=id||
           !ParseDerivedJobRecord(mutation->payload_json,&record,error))return failed();
        const auto type=mutation->mutation_type;
        const bool state_matches=(record.state==DerivedJobState::Intent&&(type==RecordingMutationType::DerivedJobIntent||type==RecordingMutationType::DerivedJobFiles))||
            (record.state==DerivedJobState::Ready&&type==RecordingMutationType::DerivedJobReady)||
            (record.state==DerivedJobState::Committed&&type==RecordingMutationType::DerivedJobCommitted)||
            (record.state==DerivedJobState::Complete&&type==RecordingMutationType::DerivedJobComplete)||
            (record.state==DerivedJobState::Failed&&type==RecordingMutationType::DerivedJobFailed);
        if(!state_matches||record.intent.job_id!=entry.id||record.intent.reference.channel_id!=entry.channel||record.intent.reference.reference_id!=entry.reference||
           record.state!=entry.state||record.files.size()!=entry.files||record.intent.reserved_bytes!=entry.reserved_bytes||
           record.intent.outputs.size()!=entry.output_ids.size()||record.intent.sources.size()!=entry.source_ids.size())return failed();
        for(std::size_t i=0;i<record.intent.outputs.size();++i)if(record.intent.outputs[i].output_id!=entry.output_ids[i])return failed();
        for(std::size_t i=0;i<record.intent.sources.size();++i){const auto& source=record.intent.sources[i];RecordingSegmentV2 original;
            if(source.segment.segment_id!=entry.source_ids[i]||!AcquireOriginalV2Locked(source.segment.segment_id,&original,error)||
               SerializeRecordingSegmentV2(original)!=SerializeRecordingSegmentV2(source.segment)||
               !ValidateRecordingSourceBindingForSegment(source.binding,source.segment,error))return failed();}
        *out=std::make_shared<const DerivedJobRecordV1>(std::move(record));
        const auto live=derived_jobs_.find(id);if(live!=derived_jobs_.end())live->second.weak=*out;
        if(envelope){*envelope=std::move(mutation);}return true;
    }catch(...){if(out)out->reset();return failed();}
}
bool RecordingCatalog::JobReadCurrentLocked(const DerivedJobEntry& entry,const DerivedJobRecordV1& record) const {
    if(!entry||record.intent.job_id!=entry.id||record.intent.reference.channel_id!=entry.channel||
       record.intent.reference.reference_id!=entry.reference||record.state!=entry.state||record.files.size()!=entry.files||
       record.intent.reserved_bytes!=entry.reserved_bytes||record.intent.outputs.size()!=entry.output_ids.size()||
       record.intent.sources.size()!=entry.source_ids.size())return false;
    for(std::size_t i=0;i<record.intent.outputs.size();++i)if(record.intent.outputs[i].output_id!=entry.output_ids[i])return false;
    for(std::size_t i=0;i<record.intent.sources.size();++i){const auto& source=record.intent.sources[i];
        RecordingSegmentV2 current;
        if(source.segment.segment_id!=entry.source_ids[i]||!AcquireOriginalV2Locked(source.segment.segment_id,&current,nullptr)||
           SerializeRecordingSegmentV2(current)!=SerializeRecordingSegmentV2(source.segment))return false;}
    return true;
}
bool RecordingCatalog::AcquireJobForReadLocked(const std::string& id,DerivedJobHandle* out,JobReadContext* context,std::string* error,bool* strict_content) const {
    if(strict_content)*strict_content=false;
    if(!context)return AcquireDerivedJobOwnedLocked(id,out,error);
    if(out)out->reset();
    const auto found=JobEntryLocked(id);
    if(!out||!found||!*found)return AcquireDerivedJobOwnedLocked(id,out,error);
    const auto& entry=*found;
    // 다른 catalog의 호출 자료는 증명으로 사용하지 않는다.
    if(context->owner&&context->owner!=this)return AcquireDerivedJobOwnedLocked(id,out,error);
    auto charge=entry.mutation.LogicalCharge();
    const auto envelope_charge=[](const RecordingMutationV1& value){
        return sizeof(value)+sizeof(DerivedJobRecordV1)+value.schema.size()+value.mutation_id.size()+
            value.entity_id.size()+value.physical_json.size()+2*value.payload_json.size();
    };
    if(!charge)for(const auto& saved:context->entries)if(saved.job&&saved.job->intent.job_id==id&&saved.envelope){charge=envelope_charge(*saved.envelope);break;}
    const bool saved_id=std::any_of(context->entries.begin(),context->entries.end(),[&](const auto& saved){return saved.job&&saved.job->intent.job_id==id;});
    const bool proof_budget=context->budget>0&&charge<=context->budget&&context->charge<=context->budget&&context->entries.size()<=8&&
        (saved_id||context->charge<=context->budget-charge);
    std::shared_ptr<RecordingJournal::ColdReadProof> proof;
    if(proof_budget){const auto found_proof=context->proofs.find(id);if(found_proof!=context->proofs.end())proof=found_proof->second;}
    const auto remember_proof=[&](){if(proof&&proof_budget&&(context->proofs.size()<8||context->proofs.count(id)))try {context->proofs.insert_or_assign(id,proof);}catch(...){};};
    const auto acquire_envelope=[&](RecordingMutationHandle* envelope){
        try {if(journal_.OwnsCatalog(this)&&
            (proof_budget?journal_.AcquireMutationLinkForRead(this,entry.mutation,&proof,envelope,error):journal_.AcquireMutationLink(entry.mutation,envelope,error))&&*envelope&&
            (*envelope)->mutation_id==entry.latest_mutation_id)return true;}
        catch(...){}
        envelope->reset();out->reset();derived_job_state_authoritative_=false;
        return Fail(error,"derived job 상세 재획득 거부");
    };
    try {
        for(const auto& saved:context->entries){if(!saved.job||saved.job->intent.job_id!=id)continue;
            RecordingMutationHandle current;
            const bool provenance=proof||journal_.CanReleaseMutationLink(saved.link)||journal_.MutationLinkOwns(saved.link,saved.envelope);
            if(!provenance||!saved.envelope)break;
            if(!acquire_envelope(&current))return false;
            const auto& a=*current;const auto& b=*saved.envelope;
            if(a.schema==b.schema&&a.mutation_id==b.mutation_id&&a.entity_id==b.entity_id&&
               a.mutation_type==b.mutation_type&&a.occurred_at_ms==b.occurred_at_ms&&a.payload_json==b.payload_json&&
               JobReadCurrentLocked(entry,*saved.job)){remember_proof();*out=saved.job;if(strict_content)*strict_content=true;return true;}
            break;
        }
        RecordingMutationHandle envelope;
        if(!AcquireDerivedJobOwnedWithEnvelopeLocked(id,out,&envelope,error,proof_budget?&proof:nullptr)||!*out)return false;
        if(!charge&&envelope)charge=envelope_charge(*envelope);
        // 비완료 snapshot에는 기존에 없던 전체 직렬화 검증을 추가하지 않는다.
        if((*out)->state!=DerivedJobState::Complete||context->entries.size()>=8)return true;
        if(charge>context->budget||context->charge>context->budget-charge)return true;
        if(!envelope){
            const auto canonical=SerializeDerivedJobRecord(**out);
            if(canonical.empty())return true;
            if(!acquire_envelope(&envelope))return false;
            if(envelope->payload_json!=canonical)return true;
        }
        if(envelope->entity_id!=id||envelope->mutation_type!=RecordingMutationType::DerivedJobComplete||!JobReadCurrentLocked(entry,**out)||
           !(proof||journal_.CanReleaseMutationLink(entry.mutation)||journal_.MutationLinkOwns(entry.mutation,envelope)))return true;
        // 재사용 예산의 할당 실패는 정상 입력의 실패/권위 상실로 바꾸지 않는다.
        try {context->entries.push_back({*out,envelope,entry.mutation});}
        catch(...){return true;}
        context->owner=this;context->charge+=charge;remember_proof();if(strict_content)*strict_content=true;
        return true;
    }catch(...){
        // 선택적 증명 보관/비교 실패는 기존 strict 획득의 결과를 대신하지 않는다.
        if(strict_content)*strict_content=false;
        return AcquireDerivedJobOwnedLocked(id,out,error);
    }
}
bool RecordingCatalog::ReleaseInactiveDetailsLocked(const std::string* changed,std::string* error) {
    try {
        // shadow에는 owner를 저장하지 않는다. 현재 호출의 live 상태로 활성 보호를 결정한다.
        const auto release=[&](RecordingCatalog& target,const std::string& id){
            const auto binding=target.source_bindings_.find(id);
            if(binding!=target.source_bindings_.end()&&journal_.CanReleaseMutationLink(binding->second.mutation))binding->second.resident.reset();
            const auto job=target.derived_jobs_.find(id);if(job==target.derived_jobs_.end())return;
            const auto live=derived_jobs_.find(id);
            const bool active=live!=derived_jobs_.end()&&live->second&&live->second.Active();
            if(!active&&journal_.CanReleaseMutationLink(job->second.mutation))job->second.resident.reset();
        };
        if(changed){release(*this,*changed);if(checkpoint_cache_&&checkpoint_cache_->shadow)release(*checkpoint_cache_->shadow,*changed);}
        else {
            for(const auto& [id,entry]:source_bindings_){(void)entry;release(*this,id);}
            for(const auto& [id,entry]:derived_jobs_){(void)entry;release(*this,id);}
            if(checkpoint_cache_&&checkpoint_cache_->shadow){auto& shadow=*checkpoint_cache_->shadow;
                for(const auto& [id,entry]:shadow.source_bindings_){(void)entry;release(shadow,id);}
                for(const auto& [id,entry]:shadow.derived_jobs_){(void)entry;release(shadow,id);}}
        }
        if(!journal_.ReleaseRecordResidents(this,error)){derived_job_state_authoritative_=false;return false;}return true;
    }catch(...){derived_job_state_authoritative_=false;return Fail(error,"상세 resident 해제 미확인");}
}
RecordingCatalog::SourceBindingHandle RecordingCatalog::ReadSourceBinding(const std::string& id,
    SourceBindingReadContext* context,std::string* error) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!context||(context->owner&&context->owner!=this)||!opened_||!derived_job_state_authoritative_||
       (generation_backend_&&!CanReadLocked(error))||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::Finalized)return {};
    const auto found=SourceEntryLocked(id);const auto original=segments_v2_.find(id);
    if(!found||!*found||original==segments_v2_.end())return {};
    const auto& entry=*found;
    const auto failed=[&]()->SourceBindingHandle{derived_job_state_authoritative_=false;Fail(error,"source binding 상세 재획득 거부");return {};};
    bool materialized=false;
    try {
        RecordingMutationHandle envelope;
        if(!journal_.OwnsCatalog(this)||!journal_.AcquireMutationLinkForRead(this,entry.mutation,&context->cold,&envelope,error)||
           !envelope||envelope->mutation_id!=entry.latest_mutation_id||envelope->entity_id!=id||
           envelope->mutation_type!=RecordingMutationType::SegmentV2BoundFinalized)return failed();
        const auto segment_json=SerializeRecordingSegmentV2(original->second);
        if(context->binding&&context->envelope&&context->binding->segment_id==id&&context->segment_json==segment_json){
            const auto& a=*envelope;const auto& b=*context->envelope;
            if(a.schema==b.schema&&a.mutation_id==b.mutation_id&&a.entity_id==b.entity_id&&
               a.mutation_type==b.mutation_type&&a.occurred_at_ms==b.occurred_at_ms&&a.payload_json==b.payload_json){
                if(error)error->clear();
                return context->binding;
            }
        }
        SourceBindingHandle parsed;
        if(!MaterializeSourceBinding(entry,original->second,envelope,&parsed,error)||!parsed)return failed();
        materialized=true;
        // 공유 handle은 한 번만 세고, 실제 vector/string capacity와 envelope/cold 보관을 포함한다.
        std::size_t retained=sizeof(SourceBindingReadContext)+sizeof(RecordingSourceBindingV1)+2*sizeof(RecordingMutationV1)+
            parsed->samples.capacity()*sizeof(RecordingSourceSampleV1)+2*segment_json.capacity()+8192;
        for(const auto* text:{&parsed->schema,&parsed->segment_id,&parsed->source_id,&parsed->channel_id,&parsed->store_id,
            &parsed->media_epoch_id,&parsed->source_generation,&parsed->track_id,&parsed->incomplete_reason})retained+=text->capacity()+1;
        if(parsed->file_evidence){const auto& evidence=*parsed->file_evidence;
            retained+=evidence.profile.capacity()+evidence.file_sha256.capacity()+2+
                evidence.samples.capacity()*sizeof(RecordingFileSampleEvidenceV1);
            for(const auto& sample:evidence.samples)retained+=sample.vcl_sha256.capacity()+sample.sample_sha256.capacity()+2;
        }
        for(const auto* text:{&envelope->schema,&envelope->mutation_id,&envelope->entity_id,&envelope->payload_json,&envelope->physical_json})
            retained+=2*(text->capacity()+1);
        SourceBindingReadContext next;next.owner=this;next.binding=std::move(parsed);next.envelope=std::move(envelope);
        next.segment_json=segment_json;next.retained_bytes=retained;next.cold=context->cold;*context=std::move(next);
        if(error)error->clear();
        return context->binding;
    }catch(...){
        // 검증된 원장의 선택적 cache 산정/보관 실패는 catalog 전체의 권위 상실이 아니다.
        if(materialized){Fail(error,"source binding read cache capacity");return {};}return failed();
    }
} catch(const CatalogHistoryError& failure) { Fail(error,failure.what());return {}; }
std::optional<RecordingSourceBindingV1> RecordingCatalog::FindSourceBinding(const std::string& id) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!derived_job_state_authoritative_||(generation_backend_&&!CanReadLocked(nullptr))||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::Finalized)return std::nullopt;
    const auto found=FindSourceBindingOwnedLocked(id);
    if(!opened_||!found||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::Finalized)return std::nullopt;
    return *found;
} catch(const CatalogHistoryError&) { return std::nullopt; }
bool RecordingCatalog::ResolveOriginalSample(const std::string& channel,const std::string& source,
    const std::string& generation,std::uint64_t order,const std::string& track,std::uint64_t ordinal,
    std::uint64_t pts,RecordingOriginalResult* result,std::string* error) const try {
    if(result)*result={};
    if(!result||!ValidateRecordingReferenceId(channel,error)||!ValidateRecordingReferenceId(source,error)||!ValidateOpaqueId(generation,error)||
       order==0||ordinal==0||pts>static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max())||
       track.empty()||track.size()>1024||std::any_of(track.begin(),track.end(),[](unsigned char c){return c<32||c==127;}))
        return Fail(error,"source lookup 입력 오류");
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!derived_job_state_authoritative_||(generation_backend_&&!CanReadLocked(error)))return Fail(error,"source lookup 미open/미확인");
    for(const auto& [id,handle]:source_bindings_) {
        if(!handle)continue;
        const auto segment=segments_v2_.find(id);
        if(segment==segments_v2_.end()||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::Finalized||
           handle.channel!=channel||handle.source!=source||handle.generation!=generation||handle.order!=order||handle.track!=track)continue;
        SourceBindingHandle owned;if(!AcquireSourceBindingOwnedLocked(id,&owned,error)||!owned){*result={};return false;}const auto& b=*owned;
        const auto sample=std::lower_bound(b.samples.begin(),b.samples.end(),ordinal,[](const auto& value,auto key){return value.ordinal<key;});
        RecordingOriginalCandidate candidate{segment->second,b.source_generation,b.track_id,b.generation_order,b.last_accepted_ordinal,{},{}};
        if(sample!=b.samples.end()&&sample->ordinal==ordinal) {
            if(sample->pts_ns==pts){candidate.sample=*sample;result->exact.push_back(std::move(candidate));}
        } else if(!b.index_complete&&ordinal>b.samples.back().ordinal&&ordinal<=b.last_accepted_ordinal) {
            candidate.reason=b.incomplete_reason;result->unknown.push_back(std::move(candidate));
        }
    }
    const auto sorted=[](const auto& a,const auto& b) {
        return std::tie(a.segment.store_id,a.segment.order_sequence,a.segment.segment_id)<
               std::tie(b.segment.store_id,b.segment.order_sequence,b.segment.segment_id);
    };
    std::sort(result->exact.begin(),result->exact.end(),sorted);
    std::sort(result->unknown.begin(),result->unknown.end(),sorted);
    if(error)error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::ValidateFinalizeRecoveryV2(const RecordingSegmentV2& v,const std::string& media_path,std::string* error) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_)return Fail(error,"V2 catalog 미open");
    if(SourceEntryLocked(v.segment_id).has_value())return Fail(error,"bound downgrade 거부");
    const auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    const auto path=std::filesystem::absolute(media_path).lexically_normal();
    const auto relative=path.lexically_relative(root).generic_string();
    if(!ValidateV2Locked(v,relative,error))return false;
    if(journal_.managed_)return ValidateManagedCandidateLocked(v,relative,error);
    const auto replay=journal_.Replay();
    return PreflightV2Locked(replay,error,&v,relative);
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::FinalizeSegmentV2(const RecordingSegmentV2& v,const std::string& media_path,std::string* error) {
    if(!ValidateFinalizeRecoveryV2(v,media_path,error))return false;
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(segments_v2_.count(v.segment_id))return Fail(error,"V2 ID 이미 존재");
    const auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    const auto path=std::filesystem::absolute(media_path).lexically_normal();
    const auto relative=path.lexically_relative(root);
    std::filesystem::path contained;
    std::error_code ec;
    if(!ValidateV2Locked(v,relative.generic_string(),error)||!ResolveContainedMediaPath(root,relative,&contained)||
       !std::filesystem::is_regular_file(contained,ec)||ec)
        return Fail(error,"V2 실제 media 경로 거부");
    // 실제 writer 활성화 전 단일 catalog 호출 경계. 외부 비협력 writer 직렬화는 별도다.
    if(journal_.managed_) {
        if(!ValidateManagedCandidateLocked(v,relative.generic_string(),error))return false;
        RecordingOrderReservationV1 order;order.store_id=v.store_id;order.request_id=v.order_request_id;
        order.segment_id=v.segment_id;order.channel_id=v.channel_id;order.sequence=v.order_sequence;
        if(!completed_history_)orders_v2_[order.request_id]=order;
    } else {
        const auto replay=journal_.Replay();std::vector<RecordingOrderReservationV1> orders;
        if(!PreflightV2Locked(replay,error,&v,relative.generic_string())||!ValidateRecordingOrderHistory(replay.mutations,&orders,error))return false;
        for(const auto& order:orders)orders_v2_[order.request_id]=order;
    }
    RecordingMutationV1 m;m.mutation_type=RecordingMutationType::SegmentV2Finalized;m.entity_id=v.segment_id;
    m.payload_json="{\"segment\":"+SerializeRecordingSegmentV2(v)+",\"mediaRelpath\":\""+Escape(relative.generic_string())+"\"}";
    return AppendAndApplyLocked(std::move(m),error);
}

std::optional<RecordingSegmentV2> RecordingCatalog::FindSegmentV2ById(const std::string& id) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");const auto found=segments_v2_.find(id);
    if(generation_backend_&&!CanReadLocked(nullptr))return std::nullopt;
    if(tombstones_.count(id)||tombstones_v2_.count(id)||found==segments_v2_.end())return std::nullopt;
    return found->second;
}
RecordingLifecycle RecordingCatalog::EffectiveLifecycleV2Locked(const std::string& id) const {
    if(RetiredLocked(id).has_value())return RecordingLifecycle::Deleted;
    if(!segments_v2_.count(id))return RecordingLifecycle::Unknown;
    if(tombstones_.count(id)||tombstones_v2_.count(id))return RecordingLifecycle::Deleted;
    const auto state=states_v2_.find(id);
    return state==states_v2_.end()?RecordingLifecycle::Finalized:state->second.lifecycle;
}
bool RecordingCatalog::MediaV2EligibleLocked(const std::string& channel,const std::string& id,JobReadContext* context) const try {
    const auto found=segments_v2_.find(id);
    if(!opened_||!derived_job_state_authoritative_||(generation_backend_&&!CanReadLocked(nullptr))||segments_.count(id)||found==segments_v2_.end()||
       found->second.channel_id!=channel||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::Finalized)return false;
    for(const auto& entry:event_links_)if(entry.second.derived_segment_id==id||entry.second.fallback_evidence_id==id)return false;
    const auto& segment=found->second;
    if(segment.retention_class==RecordingRetentionClass::Continuous)return true;
    if(segment.retention_class!=RecordingRetentionClass::Event)return false;
    DerivedJobHandle owner;
    bool strict_content=false;
    const DerivedJobReadyOutputV1* output=nullptr;
    std::size_t index=0;
    if(!VisitJobsLocked([&](const auto& job_id,const auto& entry,std::string*){if(!entry)return false;for(std::size_t i=0;i<entry.output_ids.size();++i){
        if(entry.output_ids[i]!=id)continue;
        if(owner)return false;
        if(!AcquireJobForReadLocked(job_id,&owner,context,nullptr,&strict_content)||!owner)return false;
        index=i;
    }return true;},nullptr))return false;
    if(!owner||owner->state!=DerivedJobState::Complete||!owner->ready||!owner->ready->verified_output||
       index>=owner->ready->outputs.size()||index>=owner->intent.sources.size())return false;
    output=&owner->ready->outputs[index];
    // strict record 검사로 source_index/선택/manifest/AU 출처 결박을 확인한다. 현재 원본 파일은 요구하지 않는다.
    if(output->source_index!=index||!output->provenance.verified_output||(!strict_content&&SerializeDerivedJobRecord(*owner).empty())||
       SerializeRecordingSegmentV2(output->segment)!=SerializeRecordingSegmentV2(segment))return false;
    const auto path=media_relpaths_.find(id);
    return path!=media_relpaths_.end()&&path->second==owner->intent.outputs[index].final_relpath;
} catch(const CatalogHistoryError&) { return false; }
bool RecordingCatalog::AcquireMediaV2(const std::string& channel,const std::string& id,RecordingSegmentV2* segment,
    std::pair<std::filesystem::path,std::filesystem::path>* location,std::string* error) {
    return AcquireMediaWithContext(channel,id,segment,location,error,nullptr);
}
bool RecordingCatalog::AcquireMediaWithContext(const std::string& channel,const std::string& id,RecordingSegmentV2* segment,
    std::pair<std::filesystem::path,std::filesystem::path>* location,std::string* error,JobReadContext* context) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(segment)*segment={};
    if(location)*location={};
    if(!segment||!location||!MediaV2EligibleLocked(channel,id,context))return Fail(error,"V2 media 결박/상태 거부");
    const auto path=media_relpaths_.find(id);
    if(path==media_relpaths_.end())return Fail(error,"V2 media 경로 없음");
    *segment=segments_v2_.at(id);*location={options_.media_root,path->second};
    return AdjustHoldCountLocked(id,1,error);
}
bool RecordingCatalog::ValidateMediaV2(const RecordingSegmentV2& segment,
    const std::pair<std::filesystem::path,std::filesystem::path>& location) const {
    return ValidateMediaWithContext(segment,location,nullptr);
}
bool RecordingCatalog::ValidateMediaWithContext(const RecordingSegmentV2& segment,
    const std::pair<std::filesystem::path,std::filesystem::path>& location,JobReadContext* context) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!MediaV2EligibleLocked(segment.channel_id,segment.segment_id,context))return false;
    const auto path=media_relpaths_.find(segment.segment_id);
    return path!=media_relpaths_.end()&&location.first==options_.media_root&&location.second==path->second&&
        SerializeRecordingSegmentV2(segment)==SerializeRecordingSegmentV2(segments_v2_.at(segment.segment_id));
}
RecordingLifecycle RecordingCatalog::SegmentLifecycleV2(const std::string& id) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");return EffectiveLifecycleV2Locked(id);
} catch(const CatalogHistoryError&) { return RecordingLifecycle::Unknown; }
bool RecordingCatalog::CompleteDeletionV2(const RecordingTombstoneV2& tombstone,std::string* error) try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!CanWriteLocked(error))return false;
    const auto payload=SerializeRecordingTombstoneV2(tombstone);
    const auto& id=tombstone.segment.segment_id;
    if(RetiredLocked(id).has_value()) {
        RecordingTombstoneV2 prior;
        if(payload.empty()||!AcquireRetiredV2Locked(id,&prior,error)||SerializeRecordingTombstoneV2(prior)!=payload)return Fail(error,"V2 tombstone 재시도 충돌");
        if(error)error->clear();
        return true;
    }
    const auto prior=tombstones_v2_.find(id);
    if(prior!=tombstones_v2_.end()) {
        if(payload.empty()||SerializeRecordingTombstoneV2(prior->second)!=payload)return Fail(error,"V2 tombstone 재시도 충돌");
        if(error)error->clear();
        return true;
    }
    const auto segment=segments_v2_.find(id);
    if(payload.empty()||segment==segments_v2_.end()||EffectiveLifecycleV2Locked(id)!=RecordingLifecycle::DeletionPending||
       SerializeRecordingSegmentV2(segment->second)!=SerializeRecordingSegmentV2(tombstone.segment)||
       deletion_reasons_[id]!=tombstone.deletion_reason||hold_counts_.count(id)||DerivedJobProtectsLocked(id))return Fail(error,"V2 삭제 완료 상태 불일치");
    const auto path=media_relpaths_.find(id);
    if(path==media_relpaths_.end()||!IsSafeMediaRelpath(path->second))return Fail(error,"V2 삭제 경로 없음");
#if defined(__APPLE__) || defined(__linux__)
    const auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    int directory=::open("/",O_RDONLY|O_DIRECTORY|O_CLOEXEC);
    for(const auto& part:root.relative_path()) {
        if(part.empty()||part==".")continue;
        if(directory<0)break;
        const int next=::openat(directory,part.c_str(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        ::close(directory);directory=next;
    }
    if(directory<0)return Fail(error,"V2 삭제 상위 경로 확인 실패");
    bool absent=false;
    for(const auto& part:std::filesystem::path(path->second).parent_path()) {
        if(part.empty()||part==".")continue;
        const int next=::openat(directory,part.c_str(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        const int saved=errno;::close(directory);directory=next;
        if(next<0) {if(saved==ENOENT)absent=true;else return Fail(error,"V2 삭제 하위 경로 확인 실패");break;}
    }
    struct stat status{};
    if(!absent) {
        const int rc=::fstatat(directory,std::filesystem::path(path->second).filename().c_str(),&status,AT_SYMLINK_NOFOLLOW);
        const int saved_errno=errno;::close(directory);
        if(rc==0||saved_errno!=ENOENT)return Fail(error,"V2 등록 파일 부재 미확인");
    }
#else
    return Fail(error,"V2 안전 삭제 미지원");
#endif
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::SegmentV2Deleted;
    mutation.entity_id=id;mutation.payload_json=payload;
    return AppendAndApplyLocked(std::move(mutation),error);
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::SnapshotLocationsV2(const std::string& channel, RecordingLocationCatalogSnapshot* result, std::string* error) const try {
    if(result)*result={};
    if(!result||!ValidateRecordingReferenceId(channel,error))return Fail(error,"invalid location snapshot input");
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||(generation_backend_&&!CanReadLocked(error)))return Fail(error,"catalog not open");
    RecordingLocationCatalogSnapshot snapshot;
    for(const auto& [id,segment]:segments_v2_)
        if(segment.channel_id==channel&&EffectiveLifecycleV2Locked(id)==RecordingLifecycle::Finalized)snapshot.segments.push_back(segment);
    for(const auto& [id,tombstone]:tombstones_v2_)
        if(tombstone.segment.channel_id==channel)snapshot.deleted_segment_ids.push_back(id);
    if(!VisitRetiredLocked([&](const auto& id,const auto& receipt,std::string*){
        if(receipt.channel_id==channel)snapshot.deleted_segment_ids.push_back(id);
        return true;
    },error))return false;
    for(const auto& [id,tombstone]:tombstones_)
        if(tombstone.channel_id==channel)snapshot.deleted_segment_ids.push_back(id);
    std::sort(snapshot.segments.begin(),snapshot.segments.end(),[](const auto& a,const auto& b){
        if(a.store_id!=b.store_id)return a.store_id<b.store_id;
        if(a.order_sequence!=b.order_sequence)return a.order_sequence<b.order_sequence;
        return a.segment_id<b.segment_id;
    });
    std::sort(snapshot.deleted_segment_ids.begin(),snapshot.deleted_segment_ids.end());
    *result=std::move(snapshot);if(error)error->clear();return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::RecoverFinalizedSegmentV2(const RecordingSegmentV2& v,const std::string& path,bool* inserted,std::string* error) {
    if(inserted)*inserted=false;
    if(!ValidateFinalizeRecoveryV2(v,path,error))return false;
    if(FindSegmentV2ById(v.segment_id))return true;
    const bool ok=FinalizeSegmentV2(v,path,error);if(inserted)*inserted=ok;return ok;
}

bool RecordingCatalog::FinalizeSegment(const RecordingSegmentV1& segment,
                                       const std::string& media_path,
                                       std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return FinalizeSegmentLocked(segment, media_path, false, error);
}

bool RecordingCatalog::MarkSegmentCorrupt(const std::string& segment_id,
                                         const std::string& reason,
                                         std::string* error) try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(generation_backend_&&!CanWriteLocked(error))return false;
    if (!opened_) return Fail(error, "catalog가 열리지 않음");
    if (reason != "missing-media" && reason != "checksum-mismatch" &&
        reason != "container-invalid" && reason != "derived-media-missing")
        return Fail(error, "지원하지 않는 corruption reason");
    const auto v2=segments_v2_.find(segment_id);
    if(v2!=segments_v2_.end()) {
        if(!CanWriteLocked(error)||v2->second.pinned||hold_counts_.count(segment_id)||DerivedJobProtectsLocked(segment_id))return Fail(error,"V2 corruption 보호 거부");
        const auto lifecycle=EffectiveLifecycleV2Locked(segment_id);
        if(lifecycle==RecordingLifecycle::Corrupt)return states_v2_.at(segment_id).reason==reason;
        if(lifecycle!=RecordingLifecycle::Finalized)return Fail(error,"V2 corruption 상태 거부");
        RecordingSegmentStateV2 state;state.segment_id=segment_id;state.lifecycle=RecordingLifecycle::Corrupt;state.reason=reason;
        RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::SegmentV2State;
        mutation.entity_id=segment_id;mutation.payload_json=SerializeRecordingSegmentStateV2(state);
        return AppendAndApplyLocked(std::move(mutation),error);
    }
    const auto segment = segments_.find(segment_id);
    if (segment == segments_.end()) return Fail(error, "corruption 대상 segment가 없음");
    if (segment->second.lifecycle == RecordingLifecycle::Corrupt) {
        if (error) error->clear();
        return true;
    }
    if (segment->second.lifecycle != RecordingLifecycle::Finalized)
        return Fail(error, "corruption 대상 finalized 상태가 아님");
    const auto hold = hold_counts_.find(segment_id);
    if (hold != hold_counts_.end() && hold->second > 0) return Fail(error, "held segment corruption 변경 거부");
    for (const auto& [_, link] : event_links_) {
        if (link.status != EventRecordingLinkStatus::Pending) continue;
        if (link.derived_segment_id == segment_id || std::any_of(link.ordered_overlaps.begin(),
            link.ordered_overlaps.end(), [&](const auto& overlap) { return overlap.segment_id == segment_id; }))
            return Fail(error, "pending event source/output corruption 변경 거부");
    }
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::CorruptionDetected;
    mutation.entity_id = segment_id;
    mutation.payload_json = "{\"reason\":\"" + reason + "\"}";
    return AppendAndApplyLocked(std::move(mutation), error);
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::FinalizeSegmentWithHold(const RecordingSegmentV1& segment,
                                               const std::string& media_path,
                                               std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return FinalizeSegmentLocked(segment, media_path, true, error);
}

bool RecordingCatalog::ValidateFinalizeRecovery(const RecordingSegmentV1& segment,
    const std::string& media_path,const std::optional<EventRecordingLinkV1>& event_link,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if (!opened_ || !ValidateRecordingSegmentV1(segment,error) ||
        segment.lifecycle != RecordingLifecycle::Finalized || tombstones_.count(segment.segment_id))
        return Fail(error,"ready 복구 catalog/identity/삭제 경계 거부");
    const auto known=segments_.find(segment.segment_id);
    auto root=std::filesystem::absolute(options_.media_root).lexically_normal();
    auto path=std::filesystem::absolute(media_path).lexically_normal();
#ifdef __APPLE__
    for(auto* value:{&root,&path}){const auto text=value->string();
        if(text=="/tmp"||text.rfind("/tmp/",0)==0||text=="/var"||text.rfind("/var/",0)==0)*value="/private"+text;}
#endif
    const auto relative=path.lexically_relative(root).generic_string();
    if (!IsSafeMediaRelpath(relative)) return Fail(error,"ready 복구 상대경로 거부");
    if (known!=segments_.end()) {
        const auto path=media_relpaths_.find(segment.segment_id);
        if (known->second.lifecycle!=RecordingLifecycle::Finalized ||
            SerializeRecordingSegmentV1(known->second)!=SerializeRecordingSegmentV1(segment) ||
            path==media_relpaths_.end() || path->second!=relative)
            return Fail(error,"ready 복구 기존 segment 충돌");
    }
    if (segment.retention_class==RecordingRetentionClass::Event) {
        if (!event_link) return Fail(error,"ready event link 없음");
        const auto entry=event_links_.find(event_link->link_id);
        if (entry==event_links_.end()) return Fail(error,"ready durable event link 없음");
        const auto& actual=entry->second;const auto& expected=*event_link;
        auto canonical=actual;
        // fallback 갱신/terminal release 단계는 독립 진행하되 provenance 필드는 정확히 보존한다.
        canonical.updated_at_ms=expected.updated_at_ms;
        canonical.completeness_reason=expected.completeness_reason;
        canonical.derived_actual_range=expected.derived_actual_range;
        canonical.derivation_mode=expected.derivation_mode;
        canonical.fallback_evidence_id=expected.fallback_evidence_id;
        canonical.fallback_media_locator=expected.fallback_media_locator;
        if (actual.status!=EventRecordingLinkStatus::Pending ||
            actual.derived_segment_id!=std::optional<std::string>(segment.segment_id) ||
            SerializeEventRecordingLinkV1(canonical)!=SerializeEventRecordingLinkV1(expected) ||
            !ValidateEventLinkReferencesLocked(actual,error))
            return Fail(error,"ready event provenance/참조 충돌");
        for (const auto& overlap:actual.ordered_overlaps) {
            const auto hold=hold_counts_.find(overlap.segment_id);
            if (hold!=hold_counts_.end() && hold->second>=static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max()))
                return Fail(error,"ready event hold overflow");
        }
    } else if (event_link) return Fail(error,"continuous ready에 event provenance 혼입");
    return true;
}

bool RecordingCatalog::RecoverFinalizedSegment(const RecordingSegmentV1& segment,
    const std::string& media_path,const std::optional<EventRecordingLinkV1>& event_link,bool* inserted,std::string* error) {
    if (inserted) *inserted=false;
    if (!ValidateFinalizeRecovery(segment,media_path,event_link,error)) return false;
    // 호출 계약은 Open 직후 단일 startup coordinator이며 runtime 생산자가 아직 없다.
    if (FindSegmentById(segment.segment_id)) return true;
    if (!event_link) {
        const bool ok=FinalizeSegment(segment,media_path,error);
        if (inserted) *inserted=ok;
        return ok;
    }
    std::vector<std::string> source_ids;
    for (const auto& overlap:event_link->ordered_overlaps) source_ids.push_back(overlap.segment_id);
    EventSourceLease lease;
    if (!AcquireEventSourceLease(event_link->channel_id,event_link->stream_epoch_id,source_ids,&lease,error)) return false;
    if (!FinalizeSegmentWithHold(segment,media_path,error)) {
        ReleaseEventSourceLease(lease,nullptr);
        return false;
    }
    if (inserted) *inserted=true;
    return true;
}

bool RecordingCatalog::FinalizeSegmentLocked(const RecordingSegmentV1& segment,
                                             const std::string& media_path,
                                             bool acquire_hold,
                                             std::string* error) try {
    if (!opened_) return Fail(error, "catalog가 열리지 않음");
    if (!ValidateRecordingSegmentV1(segment, error) || segment.lifecycle != RecordingLifecycle::Finalized) return false;
    if (segments_v2_.count(segment.segment_id)||RetiredLocked(segment.segment_id).has_value()) return Fail(error,"V1/V2 ID 충돌");
    if (tombstones_.find(segment.segment_id) != tombstones_.end()) {
        return Fail(error, "tombstone segment ID 재사용 금지");
    }
    if (segments_.find(segment.segment_id) != segments_.end()) {
        return Fail(error, "segment ID가 이미 catalog에 존재함");
    }
    std::error_code fs_error;
    const auto root = std::filesystem::weakly_canonical(options_.media_root, fs_error);
    if (fs_error) return Fail(error, "recording root canonicalize 실패");
    const auto media = std::filesystem::weakly_canonical(media_path, fs_error);
    if (fs_error) return Fail(error, "recording media canonicalize 실패");
    const auto relative = media.lexically_relative(root);
    std::filesystem::path contained_media;
    if (!ResolveContainedMediaPath(root, relative, &contained_media) ||
        contained_media != media || !std::filesystem::is_regular_file(media)) {
        return Fail(error, "media path가 recording root 밖이거나 파일이 없음");
    }
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::SegmentFinalized;
    mutation.entity_id = segment.segment_id;
    mutation.payload_json = "{\"segment\":" + SerializeRecordingSegmentV1(segment) +
                            ",\"mediaRelpath\":\"" + Escape(relative.generic_string()) + "\"}";
    if(generation_backend_)return AppendGenerationLocked(std::move(mutation),error,nullptr,acquire_hold);
    if (!AppendAndApplyLocked(std::move(mutation), error)) return false;
    if (!acquire_hold) return true;
    constexpr auto kMaxPersistentHoldCount =
        static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max());
    const std::uint64_t current = hold_counts_[segment.segment_id];
    if (current >= kMaxPersistentHoldCount) {
        return Fail(error, "event segment hold_count가 int64 저장 범위를 넘음");
    }
    hold_counts_[segment.segment_id] = current + 1;
#if MEDIA_SERVER_USE_SQLITE3
    if (sqlite_db_ != nullptr) {
        sqlite3_stmt* statement = nullptr;
        if (sqlite3_prepare_v2(sqlite_db_,
                               "UPDATE recording_segments SET hold_count=hold_count+1 "
                               "WHERE segment_id=? AND lifecycle='finalized'",
                               -1, &statement, nullptr) != SQLITE_OK) {
            CloseSqliteLocked();
            catalog_mode_ = "jsonl-fallback";
            if (error != nullptr) error->clear();
            return true;
        }
        BindText(statement, 1, segment.segment_id);
        const bool updated = sqlite3_step(statement) == SQLITE_DONE &&
                             sqlite3_changes(sqlite_db_) == 1;
        sqlite3_finalize(statement);
        if (!updated) {
            CloseSqliteLocked();
            catalog_mode_ = "jsonl-fallback";
            if (error != nullptr) error->clear();
            return true;
        }
    }
#endif
    if (error != nullptr) error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::ValidateEventLinkReferencesLocked(
    const EventRecordingLinkV1& link,
    std::string* error) const {
    if (!link.requested_range.has_value() && !link.ordered_overlaps.empty()) {
        return Fail(error, "UTC 미해석 link는 segment overlap을 가질 수 없음");
    }
    for (const auto& overlap : link.ordered_overlaps) {
        const auto segment = segments_.find(overlap.segment_id);
        if (segment == segments_.end() ||
            segment->second.lifecycle != RecordingLifecycle::Finalized ||
            segment->second.retention_class != RecordingRetentionClass::Continuous ||
            segment->second.channel_id != link.channel_id ||
            (!link.stream_epoch_id.empty() &&
             segment->second.stream_epoch_id != link.stream_epoch_id)) {
            return Fail(error, "event link overlap이 같은 channel/epoch의 finalized continuous segment가 아님");
        }
        const auto& requested = *link.requested_range;
        const UtcRangeV1 expected{
            std::max(segment->second.start.utc_ms, requested.start_ms),
            std::min(segment->second.end.utc_ms, requested.end_ms)};
        if (overlap.range.start_ms != expected.start_ms ||
            overlap.range.end_ms != expected.end_ms) {
            return Fail(error, "event link overlap이 source/requested range 교집합과 다름");
        }
    }
    if (link.status == EventRecordingLinkStatus::Complete) {
        const auto derived = segments_.find(*link.derived_segment_id);
        if (derived == segments_.end() ||
            derived->second.lifecycle != RecordingLifecycle::Finalized ||
            derived->second.retention_class != RecordingRetentionClass::Event ||
            derived->second.channel_id != link.channel_id ||
            derived->second.source_id != link.source_id ||
            derived->second.start.utc_ms != link.derived_actual_range->start_ms ||
            derived->second.end.utc_ms != link.derived_actual_range->end_ms) {
            return Fail(error, "complete event link의 derived segment가 유효하지 않음");
        }
    }
    return true;
}

bool RecordingCatalog::PutEventLink(const EventRecordingLinkV1& link, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if (!ValidateEventRecordingLinkV1(link, error)) return false;
    for (const auto& [existing_link_id, existing] : event_links_) {
        if (existing.event_id == link.event_id && existing_link_id != link.link_id) {
            return Fail(error, "같은 event_id에 다른 recording link ID를 사용할 수 없음");
        }
    }
    if (!ValidateEventLinkReferencesLocked(link, error)) return false;
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::EventLinkCreated;
    mutation.entity_id = link.link_id;
    mutation.payload_json = "{\"link\":" + SerializeEventRecordingLinkV1(link) + "}";
    return AppendAndApplyLocked(std::move(mutation), error);
}

bool RecordingCatalog::PutObservation(const AnalysisObservationV1& observation, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if (segments_.find(observation.frame_locator.segment_id) == segments_.end()) return Fail(error, "observation segment foreign key 위반");
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::ObservationPut;
    mutation.entity_id = observation.observation_id;
    mutation.payload_json = "{\"observation\":" + SerializeAnalysisObservationV1(observation) + "}";
    return AppendAndApplyLocked(std::move(mutation), error);
}

bool RecordingCatalog::RequestDeletion(const std::string& segment_id,
                                       const std::string& reason,
                                       std::string* error) try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto v2=segments_v2_.find(segment_id);
    if(v2!=segments_v2_.end()) {
        if(!opened_||!CanWriteLocked(error))return false;
        RecordingSegmentStateV2 state;state.segment_id=segment_id;
        state.lifecycle=RecordingLifecycle::DeletionPending;state.reason=reason;
        const auto payload=SerializeRecordingSegmentStateV2(state);
        const auto effective=EffectiveLifecycleV2Locked(segment_id);
        if(payload.empty()||v2->second.pinned||hold_counts_.count(segment_id)||DerivedJobProtectsLocked(segment_id))return Fail(error,"V2 삭제 보호/사유 거부");
        if(effective==RecordingLifecycle::DeletionPending)return deletion_reasons_[segment_id]==reason;
        if(effective!=RecordingLifecycle::Finalized &&
           !(effective==RecordingLifecycle::Corrupt&&reason=="manual-corrupt-cleanup"))return Fail(error,"V2 삭제 전이 거부");
        RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::SegmentV2State;
        mutation.entity_id=segment_id;mutation.payload_json=payload;
        return AppendAndApplyLocked(std::move(mutation),error);
    }
    const auto segment = segments_.find(segment_id);
    if (segment == segments_.end() ||
        segment->second.lifecycle != RecordingLifecycle::Finalized) {
        return Fail(error, "삭제 요청 가능한 finalized segment가 없음");
    }
    const auto hold = hold_counts_.find(segment_id);
    if (segment->second.pinned || (hold != hold_counts_.end() && hold->second > 0)) {
        return Fail(error, "pin 또는 hold가 있는 segment는 삭제 요청할 수 없음");
    }
    for (const auto& [_, link] : event_links_) {
        if (link.status != EventRecordingLinkStatus::Pending ||
            !link.derived_segment_id.has_value()) continue;
        const bool is_output = *link.derived_segment_id == segment_id;
        const bool is_source = std::any_of(
            link.ordered_overlaps.begin(), link.ordered_overlaps.end(),
            [&](const auto& overlap) { return overlap.segment_id == segment_id; });
        if (is_output || is_source) {
            return Fail(error, "terminal 미완료 event link의 source/output은 삭제 요청할 수 없음");
        }
    }
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::DeletionRequested;
    mutation.entity_id = segment_id;
    mutation.payload_json = "{\"reason\":\"" + Escape(reason) + "\"}";
    return AppendAndApplyLocked(std::move(mutation), error);
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

bool RecordingCatalog::PutReferencedObservation(const AnalysisObservationV2& observation, const RecordingConsumerReferenceV1& reference, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    ReferencedObservationV1 pair;pair.observation=observation;pair.reference=reference;
    if(observation.coordinates)pair.schema="media-server.referenced-observation.v2";
    if(!opened_||!options_.enable_v2_storage||!CanWriteLocked(error)||!ValidateReferencedObservationV1(pair,error))return false;
    const auto old=referenced_observations_.find(observation.observation_id);
    if(old!=referenced_observations_.end()) {
        if(!MergeReferenced(old->second,&pair,error))return false;
        if(SerializeReferencedObservationV1(old->second)==SerializeReferencedObservationV1(pair)) {
            if(error)error->clear();
            return true;
        }
    }
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::ReferencedObservationPut;
    mutation.entity_id=observation.observation_id;mutation.payload_json=SerializeReferencedObservationV1(pair);
    return AppendAndApplyLocked(std::move(mutation),error);
}
bool RecordingCatalog::EvidenceRowsLocked(const EvidenceSnapshot& snapshot,
    std::vector<ReferencedObservationV1>* output,std::vector<std::string>* encoded,std::string* error) const {
    std::size_t scanned=0,bytes=0;
    for(const auto& [id,p]:referenced_observations_) {
        (void)id;
        if(std::chrono::steady_clock::now()>=snapshot.deadline)return Fail(error,"evidence-timeout");
        if(++scanned>65536)return Fail(error,"evidence-observation-scan-limit");
        const auto& o=p.observation;
        if(o.channel_id!=snapshot.channel||o.source_id!=snapshot.source||o.analysis_namespace!=snapshot.ns||o.track_id!=snapshot.track)continue;
        auto text=SerializeReferencedObservationV1(p);
        if(text.empty())return Fail(error,"evidence-observation-corrupt");
        bytes+=text.size();
        if(encoded->size()>=256||bytes>256*1024)return Fail(error,"evidence-observation-snapshot-limit");
        encoded->push_back(std::move(text));if(output)output->push_back(p);
    }
    std::sort(encoded->begin(),encoded->end());return true;
}
bool RecordingCatalog::EvidenceDependenciesLocked(const EvidenceSnapshot& snapshot,
    std::vector<std::string>* output,std::string* error) const try {
    std::size_t bytes=0,scanned=0;
    const auto add=[&](const std::string& key,const std::string& value){
        bytes+=key.size()+value.size()+32;
        if(bytes>256*1024)return false;
        output->push_back(std::to_string(key.size())+":"+key+value);return true;
    };
    for(const auto& id:snapshot.segments){
        if(std::chrono::steady_clock::now()>=snapshot.deadline)return Fail(error,"evidence-timeout");
        const auto v2=segments_v2_.find(id);const auto v1=segments_.find(id);const auto path=media_relpaths_.find(id);
        const auto binding=SourceEntryLocked(id);
        if(binding&&binding->latest_mutation_id.empty())return Fail(error,"evidence-observation-corrupt");
        // bound finalize는 같은 ID의 변경을 거부한다. latest mutation은 sample/hash/generation 원문의 식별자다.
        if(!add(id+"/v2",v2==segments_v2_.end()?"":SerializeRecordingSegmentV2(v2->second))||
           !add(id+"/v1",v1==segments_.end()?"":SerializeRecordingSegmentV1(v1->second))||
           !add(id+"/state",std::to_string(static_cast<unsigned>(EffectiveLifecycleV2Locked(id)))+":"+
                std::to_string(tombstones_.count(id))+":"+std::to_string(tombstones_v2_.count(id))+":"+std::to_string(RetiredLocked(id).has_value()))||
           !add(id+"/path",path==media_relpaths_.end()?"":path->second)||
           !add(id+"/binding",binding?binding->latest_mutation_id:""))
            return Fail(error,"evidence-observation-snapshot-limit");
    }
    if(!snapshot.job.empty()){
        const auto job=JobEntryLocked(snapshot.job);
        if(!add("job/"+snapshot.job,job?job->latest_mutation_id:""))
            return Fail(error,"evidence-observation-snapshot-limit");
    }
    if(!snapshot.events.empty()){
        for(const auto& [id,link]:event_links_){
            if(std::chrono::steady_clock::now()>=snapshot.deadline)return Fail(error,"evidence-timeout");
        if(++scanned>65536)return Fail(error,"evidence-observation-scan-limit");
            if(std::find(snapshot.events.begin(),snapshot.events.end(),link.event_id)!=snapshot.events.end()&&
                !add("event/"+id,SerializeEventRecordingLinkV1(link)))return Fail(error,"evidence-observation-snapshot-limit");
        }
    }
    std::sort(output->begin(),output->end());return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::CaptureEvidenceObservations(const SearchDocument& hit,
    std::vector<ReferencedObservationV1>* output,EvidenceSnapshot* snapshot,std::string* error,
    std::chrono::steady_clock::time_point deadline) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!output||!snapshot||!opened_||!options_.enable_v2_storage||!CanReadLocked(error)||
       !source_snapshot_revision_valid_||!ValidateRecordingReferenceId(hit.channel_id,nullptr)||
       !ValidateRecordingReferenceId(hit.source_id,nullptr)||!ValidateOpaqueId(hit.analysis_namespace,nullptr)||
       !ValidateOpaqueId(hit.track_id,nullptr)||hit.event_ids.size()>64)
        return Fail(error,"evidence-observation-snapshot-unavailable");
    if(!ValidateOpaqueId(hit.segment_id,nullptr)||(!hit.playback_segment_id.empty()&&!ValidateOpaqueId(hit.playback_segment_id,nullptr))||
        (!hit.playback_job_id.empty()&&!ValidateOpaqueId(hit.playback_job_id,nullptr))||
        (!hit.playback_event_id.empty()&&!ValidateOpaqueId(hit.playback_event_id,nullptr))||
        std::any_of(hit.event_ids.begin(),hit.event_ids.end(),[](const auto& id){return !ValidateOpaqueId(id,nullptr);}))
        return Fail(error,"evidence-observation-snapshot-unavailable");
    EvidenceSnapshot next;next.deadline=deadline;next.channel=hit.channel_id;next.source=hit.source_id;next.ns=hit.analysis_namespace;next.track=hit.track_id;
    next.segments={hit.segment_id};if(!hit.playback_segment_id.empty()&&hit.playback_segment_id!=hit.segment_id)next.segments.push_back(hit.playback_segment_id);
    next.events=hit.event_ids;if(!hit.playback_event_id.empty())next.events.push_back(hit.playback_event_id);next.job=hit.playback_job_id;
    next.instance=search_instance_;next.revision=source_snapshot_revision_;
    std::vector<ReferencedObservationV1> rows;
    if(!EvidenceRowsLocked(next,&rows,&next.rows,error)||!EvidenceDependenciesLocked(next,&next.dependencies,error))return false;
    *output=std::move(rows);*snapshot=std::move(next);if(error)error->clear();return true;
}
bool RecordingCatalog::GuardEvidenceSnapshot(const EvidenceSnapshot& snapshot,const std::function<bool()>& action,
    std::uint64_t* captured,std::uint64_t* checked,bool* current,std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(captured)*captured=snapshot.revision;
    if(checked)*checked=source_snapshot_revision_;
    if(current)*current=false;
    if(!opened_||!options_.enable_v2_storage||!source_snapshot_revision_valid_||!snapshot.instance||
        snapshot.instance!=search_instance_||!CanReadLocked(nullptr))return Fail(error,"evidence-source-changed");
    std::vector<std::string> rows,dependencies;
    if(!EvidenceRowsLocked(snapshot,nullptr,&rows,error)||!EvidenceDependenciesLocked(snapshot,&dependencies,error))return false;
    if(rows!=snapshot.rows||dependencies!=snapshot.dependencies)return Fail(error,"evidence-source-changed");
    if(current)*current=true;
    if(std::chrono::steady_clock::now()>=snapshot.deadline)return Fail(error,"evidence-timeout");
    return action&&action();
}

std::vector<ReferencedObservationV1> RecordingCatalog::QueryReferencedObservations(const std::string& channel) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");std::vector<ReferencedObservationV1> result;
    if(!opened_||!options_.enable_v2_storage||(generation_backend_&&!CanReadLocked(nullptr))||!ValidateRecordingReferenceId(channel,nullptr))return result;
    for(const auto& [id,pair]:referenced_observations_) {
        (void)id;if(pair.observation.channel_id==channel)result.push_back(pair);
    }
    std::sort(result.begin(),result.end(),[](const auto& a,const auto& b){return a.observation.observation_id<b.observation.observation_id;});
    return result;
}

bool RecordingCatalog::PutConsumerReference(const RecordingConsumerReferenceV1& reference, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!options_.enable_v2_storage||!CanWriteLocked(error)||!ValidateRecordingConsumerReferenceV1(reference,error))
        return Fail(error,"consumer reference 저장 상태/입력 거부");
    const auto old=consumer_references_.find(reference.reference_id);
    if(old!=consumer_references_.end()) {
        if(SerializeRecordingConsumerReferenceV1(old->second)!=SerializeRecordingConsumerReferenceV1(reference))return Fail(error,"consumer reference ID 충돌");
        if(error)error->clear();
        return true;
    }
    RecordingMutationV1 mutation;mutation.mutation_type=RecordingMutationType::ConsumerReferencePut;
    mutation.entity_id=reference.reference_id;
    mutation.payload_json="{\"reference\":"+SerializeRecordingConsumerReferenceV1(reference)+"}";
    return AppendAndApplyLocked(std::move(mutation),error);
}
bool RecordingCatalog::AcceptDerivedReference(const RecordingConsumerReferenceV1& reference, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!opened_||!options_.enable_v2_storage||!CanWriteLocked(error)||
       !ValidateRecordingConsumerReferenceV1(reference,error)||reference.kind!="event")
        return Fail(error,"derived reference 접수 상태/입력 거부");
    const auto stored=consumer_references_.find(reference.reference_id);
    if(stored==consumer_references_.end()||
       SerializeRecordingConsumerReferenceV1(stored->second)!=SerializeRecordingConsumerReferenceV1(reference))
        return Fail(error,"derived reference canonical 결박 불일치");
    if(derived_accepted_references_.count(reference.reference_id)) {
        if(error)error->clear();
        return true;
    }
    RecordingMutationV1 mutation;
    mutation.mutation_type=RecordingMutationType::DerivedReferenceAccepted;
    mutation.entity_id=reference.reference_id;
    mutation.payload_json="{\"reference\":"+SerializeRecordingConsumerReferenceV1(reference)+"}";
    if(!AppendAndApplyLocked(std::move(mutation),error)) {
        if(!generation_backend_)derived_job_state_authoritative_=false;
        return false;
    }
    return true;
}
bool RecordingCatalog::IsDerivedReferenceAccepted(const std::string& id, bool* accepted, std::string* error) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(accepted)*accepted=false;
    if(!accepted||!opened_||!options_.enable_v2_storage||!CanReadLocked(error)||!ValidateOpaqueId(id,error))
        return Fail(error,"derived reference 조회 상태/입력 거부");
    *accepted=derived_accepted_references_.count(id)!=0;
    if(error)error->clear();
    return true;
}
bool RecordingCatalog::SnapshotDerivedSources(const RecordingConsumerReferenceV1& reference,
    std::vector<RecordingDerivedSourceSnapshotEntry>* result, std::string* error) const {
    std::optional<std::uint64_t> revision;
    if(!PrepareDerivedSourceSnapshot(reference,result,&revision,error))return false;
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return FinishDerivedSourceSnapshotLocked(reference,result,revision,error);
}
bool RecordingCatalog::SnapshotDerivedSourcesWithWaitLease(const RecordingConsumerReferenceV1& reference,
    const std::vector<RecordingConsumerOriginalV1>& observed,std::uint64_t* token,
    std::vector<RecordingDerivedSourceSnapshotEntry>* result,std::string* error,
    const std::vector<RecordingConsumerOriginalV1>& native_overlap_only) {
    // 잠금 밖 준비 전에 기존 입력/토큰 거부 순서를 유지한다. 등록 직전에 다시 확인한다.
    {
        std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
        if(result)result->clear();
        if(!token||!result||observed.size()>4096||native_overlap_only.size()>4096-observed.size())return Fail(error,"derived wait lease input/output cap");
        const auto existing=derived_wait_leases_.find(*token);
        if((*token&&existing==derived_wait_leases_.end())||(!*token&&derived_wait_leases_.size()>=32))return Fail(error,"derived wait lease token/cap");
        const auto identity=SerializeRecordingConsumerReferenceV1(reference);
        if(identity.empty()||(existing!=derived_wait_leases_.end()&&existing->second.reference_json!=identity))return Fail(error,"derived wait lease reference mismatch");
    }
    std::vector<RecordingDerivedSourceSnapshotEntry> snapshot;std::optional<std::uint64_t> revision;
    if(!PrepareDerivedSourceSnapshot(reference,&snapshot,&revision,error))return false;
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(result)result->clear();
    if(!token||!result||observed.size()>4096||native_overlap_only.size()>4096-observed.size())return Fail(error,"derived wait lease input/output cap");
    const auto existing=derived_wait_leases_.find(*token);
    if((*token&&existing==derived_wait_leases_.end())||(!*token&&derived_wait_leases_.size()>=32))
        return Fail(error,"derived wait lease token/cap");
    const auto identity=SerializeRecordingConsumerReferenceV1(reference);
    if(identity.empty()||(existing!=derived_wait_leases_.end()&&existing->second.reference_json!=identity))
        return Fail(error,"derived wait lease reference mismatch");
    if(!FinishDerivedSourceSnapshotLocked(reference,&snapshot,revision,error))return false;
    DerivedWaitLease next=existing==derived_wait_leases_.end()?DerivedWaitLease{identity,{}}:existing->second;
    for(const auto& entry:snapshot)if(entry.lifecycle==RecordingLifecycle::Finalized&&!entry.deleted&&entry.binding&&
        ValidateRecordingSourceBindingForSegment(*entry.binding,entry.segment,nullptr)) {
        const auto& binding=*entry.binding;
        const auto bound=[&](const auto& o){
            if(!reference.original||o.source_generation!=reference.original->source_generation||
               o.generation_order!=reference.original->generation_order||o.track_id!=reference.original->track_id||
               o.source_generation!=binding.source_generation||o.generation_order!=binding.generation_order||o.track_id!=binding.track_id)return false;
            const auto found=std::lower_bound(binding.samples.begin(),binding.samples.end(),o.ordinal,[](const auto& sample,std::uint64_t ordinal){return sample.ordinal<ordinal;});
            return found!=binding.samples.end()&&found->ordinal==o.ordinal&&found->pts_ns==o.pts_ns;
        };
        bool matched=std::any_of(observed.begin(),observed.end(),bound);
        // 디코딩된 길이가 없으면 원본 대기 충족 범위를 만들어내지 않는다. 이 목록은
        // 이미 입증된 네이티브 구간만 같은 스냅샷 잠금 안에서 보호한다.
        if(!matched&&binding.file_evidence&&reference.request&&reference.request->time_basis=="media-pts-ms") {
            const auto& r=*reference.request;
            const __int128 a=(static_cast<__int128>(r.start_ms)-r.pre_ms)*1000000,b=(static_cast<__int128>(r.end_ms)+r.post_ms)*1000000;
            if(a>=std::numeric_limits<std::int64_t>::min()&&b<=std::numeric_limits<std::int64_t>::max()) {
                const auto& proof=*binding.file_evidence;
                matched=std::any_of(native_overlap_only.begin(),native_overlap_only.end(),[&](const auto& o){
                    if(!bound(o))return false;
                    const auto sample=std::lower_bound(proof.samples.begin(),proof.samples.end(),o.ordinal,[](const auto& s,std::uint64_t n){return s.ordinal<n;});
                    PresentationInterval interval;
                    return sample!=proof.samples.end()&&sample->ordinal==o.ordinal&&
                        MakePresentationInterval(proof.writer_origin_ns,proof.timescale,sample->native_pts,sample->native_duration,&interval)&&
                        ComparePresentationTime(interval.start,{static_cast<std::int64_t>(b),0,1})<0&&
                        ComparePresentationTime(interval.end,{static_cast<std::int64_t>(a),0,1})>0;
                });
            }
        }
        if(!matched)continue;
        next.source_ids.insert(entry.segment.segment_id);
        if(next.source_ids.size()>8)return Fail(error,"derived wait lease source cap");
    }
    if(existing!=derived_wait_leases_.end())existing->second.source_ids.swap(next.source_ids);
    else {
        if(next_derived_wait_lease_==std::numeric_limits<std::uint64_t>::max())return Fail(error,"derived wait lease token exhausted");
        const auto value=next_derived_wait_lease_+1;
        derived_wait_leases_.emplace(value,std::move(next));next_derived_wait_lease_=value;*token=value;
    }
    result->swap(snapshot);if(error)error->clear();return true;
}
bool RecordingCatalog::ReleaseDerivedWaitLease(std::uint64_t token,std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!token||derived_wait_leases_.erase(token)!=1)return Fail(error,"derived wait lease token missing");
    if(error)error->clear();
    return true;
}
bool RecordingCatalog::RefreshDerivedWaitLeaseForIntent(const DerivedJobIntentV1& intent,std::uint64_t token,std::string* error) try {
    if(!ValidateDerivedJobIntent(intent,error))return false;
    const auto identity=SerializeRecordingConsumerReferenceV1(intent.reference);
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto found=derived_wait_leases_.find(token);
    if(found==derived_wait_leases_.end()||found->second.reference_json!=identity||!CanReadLocked(error))
        return Fail(error,"derived wait intent lease mismatch");
    const auto existing=JobEntryLocked(intent.job_id);
    if(existing) {
        if(!*existing)return Fail(error,"derived null job 거부");
        DerivedJobHandle current;if(!AcquireDerivedJobOwnedLocked(intent.job_id,&current,error)||!current)return false;
        auto same=intent;same.created_at_ms=current->intent.created_at_ms;
        if(SerializeDerivedJobIntent(same)!=SerializeDerivedJobIntent(current->intent))return Fail(error,"derived wait intent conflict");
    } else if(!ValidateDerivedJobSourcesLocked(intent,error))return false;
    auto ids=found->second.source_ids;
    for(const auto& source:intent.sources)ids.insert(source.segment.segment_id);
    if(ids.size()>8)return Fail(error,"derived wait lease source cap");
    found->second.source_ids.swap(ids);if(error)error->clear();return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::DerivedSourceRelevant(const RecordingConsumerReferenceV1& reference,
    const RecordingSegmentV2& segment,const SourceBindingEntry* metadata) {
    if(segment.source_id!=reference.source_id||segment.channel_id!=reference.channel_id||segment.retention_class!=RecordingRetentionClass::Continuous)return false;
    const auto& request=*reference.request;
    const __int128 begin=(static_cast<__int128>(request.start_ms)-request.pre_ms)*1000000;
    const __int128 end=(static_cast<__int128>(request.end_ms)+request.post_ms)*1000000;
        const bool valid_segment=ValidateRecordingSegmentV2(segment,nullptr);
        bool unrelated=false;
        if(request.time_basis=="media-pts-ms") {
            if(metadata&&*metadata&&reference.original) {
                const auto& original=*reference.original;
                unrelated=metadata->generation!=original.source_generation||
                    metadata->order!=original.generation_order||metadata->track!=original.track_id;
            }
            if(valid_segment&&segment.media_end_pts) {
                const __int128 scale=static_cast<__int128>(segment.time_base_num)*1000000000;
                unrelated=unrelated||static_cast<__int128>(*segment.media_end_pts)*scale<=begin*segment.time_base_den||
                    static_cast<__int128>(segment.media_start_pts)*scale>=end*segment.time_base_den;
            }
        } else if(request.time_basis=="utc-ms"&&valid_segment&&!segment.mappings.empty()) {
            unrelated=true;
            for(const auto& mapping:segment.mappings) {
                if(mapping.provenance=="unknown"||!mapping.utc_start_ns||!mapping.utc_end_ns||
                   !mapping.end_pts||!mapping.uncertainty_ns||*mapping.uncertainty_ns!=0||
                   (static_cast<__int128>(*mapping.utc_end_ns)>begin&&
                    static_cast<__int128>(*mapping.utc_start_ns)<end)) {
                    unrelated=false;
                    break;
                }
            }
        }
    return !unrelated;
}
bool RecordingCatalog::RetiredSourceRelevant(const RecordingConsumerReferenceV1& reference,
    const RecordingRetiredV2Receipt& receipt,const SourceBindingEntry* metadata) {
    if(receipt.source_id!=reference.source_id||receipt.channel_id!=reference.channel_id||receipt.retention_class!=RecordingRetentionClass::Continuous)return false;
    const auto& request=*reference.request;
    const __int128 begin=(static_cast<__int128>(request.start_ms)-request.pre_ms)*1000000;
    const __int128 end=(static_cast<__int128>(request.end_ms)+request.post_ms)*1000000;
    if(request.time_basis=="media-pts-ms") {
        if(metadata&&*metadata&&reference.original) {
            const auto& original=*reference.original;
            if(metadata->generation!=original.source_generation||metadata->order!=original.generation_order||metadata->track!=original.track_id)return false;
        }
        if(receipt.media_end_pts) {
            const __int128 scale=static_cast<__int128>(receipt.time_base_num)*1000000000;
            if(static_cast<__int128>(*receipt.media_end_pts)*scale<=begin*receipt.time_base_den||
               static_cast<__int128>(receipt.media_start_pts)*scale>=end*receipt.time_base_den)return false;
        }
    }else if(request.time_basis=="utc-ms"&&receipt.utc_exclusion_safe&&receipt.utc_min_ns&&receipt.utc_max_ns) {
        if(*receipt.utc_max_ns<=begin||*receipt.utc_min_ns>=end)return false;
    }
    return true;
}
bool RecordingCatalog::PrepareDerivedSourceSnapshot(const RecordingConsumerReferenceV1& reference,
    std::vector<RecordingDerivedSourceSnapshotEntry>* result,std::optional<std::uint64_t>* revision,std::string* error) const try {
    if(result)result->clear();
    revision->reset();
    struct Candidate {RecordingDerivedSourceSnapshotEntry output;std::optional<SourceBindingEntry> binding;
        std::optional<RecordingRetiredV2Receipt> retired;RecordingMutationLink deletion;};
    std::vector<Candidate> candidates;std::uint64_t captured=0;
    {
        std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
        if(!result||!opened_||!derived_job_state_authoritative_||!options_.enable_v2_storage||!CanReadLocked(error)||
           !ValidateRecordingConsumerReferenceV1(reference,error)||!reference.request)
            return Fail(error,"derived source snapshot 상태/입력 거부");
        if(!source_snapshot_revision_valid_)return true;
        captured=source_snapshot_revision_;
    for(const auto& [id,segment]:segments_v2_) {
        const auto metadata=SourceEntryLocked(id);
        if(!DerivedSourceRelevant(reference,segment,metadata?&*metadata:nullptr))continue;
        Candidate candidate;candidate.output.segment=segment;
        candidate.output.lifecycle=EffectiveLifecycleV2Locked(id);
        candidate.output.deleted=tombstones_v2_.count(id)!=0||candidate.output.lifecycle==RecordingLifecycle::Deleted;
        if(metadata.has_value())candidate.binding=*metadata;
        candidates.push_back(std::move(candidate));
        // 상한 초과의 기존 상세 검증/거부 순서는 locked 경로에 맡긴다.
        if(candidates.size()>256)return true;
    }
    if(!VisitRetiredLocked([&](const std::string& id,const RecordingRetiredV2Receipt& receipt,std::string* detail) {
        if(candidates.size()>256)return true;
        const auto metadata=SourceEntryLocked(id);
        if(!RetiredSourceRelevant(reference,receipt,metadata?&*metadata:nullptr))return true;
        RecordingMutationLink link;
        if(completed_history_){if(!journal_.MakeGenerationMutationLink(receipt.deletion_mutation_id,&link,detail))return false;}
        else {const auto found=retired_v2_links_.find(id);if(found==retired_v2_links_.end()){derived_job_state_authoritative_=false;return Fail(detail,"retired source link 없음");}link=found->second;}
        Candidate candidate;candidate.retired=receipt;candidate.deletion=std::move(link);
        candidate.output.lifecycle=RecordingLifecycle::Deleted;candidate.output.deleted=true;
        if(metadata.has_value())candidate.binding=*metadata;
        candidates.push_back(std::move(candidate));return true;
    },error))return false;
    if(candidates.size()>256)return true;
    }
    for(auto& candidate:candidates) {
        if(candidate.retired) {
            RecordingMutationHandle mutation;
            {
                std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
                if(!source_snapshot_revision_valid_||source_snapshot_revision_!=captured){result->clear();return true;}
                if(!derived_job_state_authoritative_||!CanReadLocked(error)||!journal_.AcquireMutationLink(candidate.deletion,&mutation,error)){
                    derived_job_state_authoritative_=false;result->clear();return false;
                }
            }
            RecordingTombstoneV2 tomb;bool valid=false;
            try{valid=MaterializeRetiredV2(*candidate.retired,mutation,&tomb,error);}catch(...){}
            if(!valid){
                std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");result->clear();
                if(!source_snapshot_revision_valid_||source_snapshot_revision_!=captured)return true;
                derived_job_state_authoritative_=false;return Fail(error,"retired source 상세 검증 거부");
            }
            candidate.output.segment=std::move(tomb.segment);
            if(!DerivedSourceRelevant(reference,candidate.output.segment,candidate.binding?&*candidate.binding:nullptr))continue;
        }
        if(candidate.binding) {
            SourceBindingHandle binding;RecordingMutationHandle mutation;bool materialized=false;
            {
                std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
                if(!source_snapshot_revision_valid_||source_snapshot_revision_!=captured){result->clear();return true;}
                if(!derived_job_state_authoritative_||!CanReadLocked(error)){result->clear();return false;}
                const auto& entry=*candidate.binding;
                if(!entry){derived_job_state_authoritative_=false;result->clear();return Fail(error,"source binding 상세 재획득 거부");}
                binding=entry.resident;
                try {
                    if(!binding&&(!journal_.AcquireMutationLink(entry.mutation,&mutation,error)||!mutation)){
                        derived_job_state_authoritative_=false;result->clear();return Fail(error,"source binding 상세 재획득 거부");
                    }
                }catch(...){derived_job_state_authoritative_=false;result->clear();return Fail(error,"source binding 상세 재획득 거부");}
            }
            // 원문은 이 한 항목의 계산 동안만 소유한다. mutable catalog/weak에는 접근하지 않는다.
            try {
                if(!binding)materialized=MaterializeSourceBinding(*candidate.binding,candidate.output.segment,mutation,&binding,error);
                else materialized=ValidateRecordingSourceBindingForSegment(*binding,candidate.output.segment,error);
            }catch(...){materialized=false;}
            if(!materialized||!binding) {
                std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
                result->clear();
                if(!source_snapshot_revision_valid_||source_snapshot_revision_!=captured)return true;
                derived_job_state_authoritative_=false;return Fail(error,"source binding 상세 재획득 거부");
            }
            candidate.output.binding=*binding;
        }
        result->push_back(std::move(candidate.output));
    }
    std::sort(result->begin(),result->end(),[](const auto& a,const auto& b){
        return std::tie(a.segment.store_id,a.segment.order_sequence,a.segment.segment_id)<
               std::tie(b.segment.store_id,b.segment.order_sequence,b.segment.segment_id);
    });
    *revision=captured;return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::FinishDerivedSourceSnapshotLocked(const RecordingConsumerReferenceV1& reference,
    std::vector<RecordingDerivedSourceSnapshotEntry>* result,const std::optional<std::uint64_t>& revision,std::string* error) const {
    if(!revision||!source_snapshot_revision_valid_||source_snapshot_revision_!=*revision)
        return SnapshotDerivedSourcesLocked(reference,result,error);
    if(!opened_||!derived_job_state_authoritative_||!CanReadLocked(error)){
        result->clear();return Fail(error,"derived source snapshot 상태/입력 거부");
    }
    if(error)error->clear();
    return true;
}
bool RecordingCatalog::SnapshotDerivedSourcesLocked(const RecordingConsumerReferenceV1& reference,
    std::vector<RecordingDerivedSourceSnapshotEntry>* result, std::string* error) const try {
    if(result)result->clear();
    if(!result||!opened_||!derived_job_state_authoritative_||!options_.enable_v2_storage||!CanReadLocked(error)||
       !ValidateRecordingConsumerReferenceV1(reference,error)||!reference.request)
        return Fail(error,"derived source snapshot 상태/입력 거부");
    for(const auto& [id,segment]:segments_v2_) {
        const auto metadata=SourceEntryLocked(id);
        if(!DerivedSourceRelevant(reference,segment,metadata?&*metadata:nullptr))continue;
        SourceBindingHandle binding;
        if(!AcquireSourceBindingOwnedLocked(id,&binding,error)||(metadata.has_value()&&!binding)){
            result->clear();return false;
        }
        if(binding&&!ValidateRecordingSourceBindingForSegment(*binding,segment,error)){
            derived_job_state_authoritative_=false;result->clear();return false;
        }
        if(result->size()==256) {
            result->clear();
            return Fail(error,"derived source relevant snapshot cap exceeded");
        }
        RecordingDerivedSourceSnapshotEntry entry;
        entry.segment=segment;
        if(binding)entry.binding=*binding;
        entry.lifecycle=EffectiveLifecycleV2Locked(id);
        entry.deleted=tombstones_v2_.count(id)!=0||entry.lifecycle==RecordingLifecycle::Deleted;
        result->push_back(std::move(entry));
    }
    if(!VisitRetiredLocked([&](const std::string& id,const RecordingRetiredV2Receipt& receipt,std::string*) {
        const auto metadata=SourceEntryLocked(id);const auto* binding_metadata=metadata?&*metadata:nullptr;
        if(!RetiredSourceRelevant(reference,receipt,binding_metadata))return true;
        RecordingSegmentV2 segment;SourceBindingHandle binding;
        if(!AcquireOriginalV2Locked(id,&segment,error)){result->clear();return false;}
        if(!DerivedSourceRelevant(reference,segment,binding_metadata))return true;
        if(!AcquireSourceBindingOwnedLocked(id,&binding,error)||(binding_metadata&&!binding)||
           (binding&&!ValidateRecordingSourceBindingForSegment(*binding,segment,error))){derived_job_state_authoritative_=false;result->clear();return false;}
        if(result->size()==256){result->clear();return Fail(error,"derived source relevant snapshot cap exceeded");}
        RecordingDerivedSourceSnapshotEntry entry;entry.segment=std::move(segment);if(binding)entry.binding=*binding;
        entry.lifecycle=RecordingLifecycle::Deleted;entry.deleted=true;result->push_back(std::move(entry));
        return true;
    },error))return false;
    std::sort(result->begin(),result->end(),[](const auto& a,const auto& b){
        return std::tie(a.segment.store_id,a.segment.order_sequence,a.segment.segment_id)<
               std::tie(b.segment.store_id,b.segment.order_sequence,b.segment.segment_id);
    });
    if(error)error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
bool RecordingCatalog::QueryDerivedReferenceResult(const std::string& id,
    RecordingDerivedReferenceResult* result,std::string* error) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(result)*result={};
    if(!result||!opened_||!derived_job_state_authoritative_||!options_.enable_v2_storage||!CanReadLocked(error)||!ValidateOpaqueId(id,error))
        return Fail(error,"derived reference result 조회 상태/입력 거부");
    result->managed=derived_accepted_references_.count(id)!=0;
    std::vector<std::string> selected_ids;
    if(!VisitJobsLocked([&](const auto& key,const auto& entry,std::string*){if(!entry){*result={};return Fail(error,"derived null job 거부");}if(entry.reference==id) {
        result->managed=true;
        selected_ids.push_back(key);
        std::sort(selected_ids.begin(),selected_ids.end());
        if(selected_ids.size()>8) {result->truncated=true;selected_ids.pop_back();}
    }return true;},error)){*result={};return false;}
    for(const auto& key:selected_ids) {
        DerivedJobHandle job;if(!AcquireDerivedJobOwnedLocked(key,&job,error)||!job){*result={};return false;}
        RecordingDerivedReferenceJob item;
        item.job=*job;
        if(job->ready)for(const auto& output:job->ready->outputs) {
            RecordingDerivedOutputAvailability availability;
            availability.segment_id=output.segment.segment_id;
            const auto path=media_relpaths_.find(availability.segment_id);
            if(path!=media_relpaths_.end())availability.relative_path=path->second;
            else if(const auto retired=RetiredLocked(availability.segment_id))availability.relative_path=retired->prior_relative_path;
            availability.lifecycle=EffectiveLifecycleV2Locked(availability.segment_id);
            availability.catalog_available=segments_v2_.count(availability.segment_id)!=0&&
                !tombstones_v2_.count(availability.segment_id)&&
                availability.lifecycle==RecordingLifecycle::Finalized&&path!=media_relpaths_.end();
            item.outputs.push_back(std::move(availability));
        }
        result->jobs.push_back(std::move(item));
    }
    if(result->truncated)result->reason="derived-reference-job-list-truncated";
    else if(result->jobs.empty())result->reason=result->managed?"evidence-not-durable":"derived-reference-not-accepted";
    else result->state="jobs";
    if(error)error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }
std::vector<RecordingConsumerReferenceV1> RecordingCatalog::QueryConsumerReferences(
    const std::string& channel, const std::string& kind, const std::string& owner) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<RecordingConsumerReferenceV1> result;
    if(!opened_||!options_.enable_v2_storage||(generation_backend_&&!CanReadLocked(nullptr))||!ValidateRecordingReferenceId(channel,nullptr)||!ValidateOpaqueId(owner,nullptr)||
       (kind!="observation"&&kind!="event"))return result;
    for(const auto& [id,reference]:consumer_references_) {
        (void)id;
        if(reference.channel_id==channel&&reference.kind==kind&&reference.owner_id==owner)result.push_back(reference);
    }
    std::sort(result.begin(),result.end(),[](const auto& a,const auto& b){return a.reference_id<b.reference_id;});
    return result;
}

void RecordingCatalog::ResolveObservationV2Locked(AnalysisObservationV2* o) const {
    const auto original = o->frame_locator;
    o->frame_locator.reset();
    if (o->stream_epoch_id.empty()) {
        if (o->locator_reason != "ambiguous-epoch") o->locator_reason = "missing-provenance";
        return;
    }
    if (original && tombstones_.count(original->segment_id)) {
        o->locator_reason = "deleted";
        return;
    }
    const RecordingSegmentV1* selected = nullptr;
    for (const auto& pair : segments_) {
        const auto& s = pair.second;
        if (s.channel_id != o->channel_id || s.source_id != o->source_id ||
            s.stream_epoch_id != o->stream_epoch_id || s.retention_class != RecordingRetentionClass::Continuous ||
            s.start.time_base_num != 1 || s.start.time_base_den != 1000000000 ||
            s.end.time_base_num != 1 || s.end.time_base_den != 1000000000 ||
            o->pts < s.start.pts || o->pts >= s.end.pts) continue;
        if (selected) { o->locator_reason = "ambiguous-epoch"; return; }
        selected = &s;
    }
    if (!selected) { o->locator_reason = "gap"; return; }
    const auto& s = *selected;
    if (s.lifecycle == RecordingLifecycle::Deleted || s.lifecycle == RecordingLifecycle::DeletionPending) {
        o->locator_reason = "deleted"; return;
    }
    if (s.lifecycle == RecordingLifecycle::Corrupt) { o->locator_reason = "corrupt"; return; }
    if (s.lifecycle != RecordingLifecycle::Finalized) { o->locator_reason = "pending"; return; }
    const auto relative = media_relpaths_.find(s.segment_id);
    std::filesystem::path contained;
    std::error_code media_error;
    if (relative == media_relpaths_.end() ||
        !ResolveContainedMediaPath(options_.media_root, relative->second, &contained) ||
        !std::filesystem::is_regular_file(contained, media_error) || media_error ||
        std::filesystem::file_size(contained, media_error) != s.size_bytes || media_error) {
        o->locator_reason = "missing-media"; return;
    }
    if (!IsRecognizedMedia(contained)) { o->locator_reason = "corrupt"; return; }
    const std::int64_t delta_ms = (o->pts - s.start.pts) / 1000000;
    if (delta_ms > std::numeric_limits<std::int64_t>::max() - s.start.utc_ms) {
        o->locator_reason = "out-of-range"; return;
    }
    const auto utc = s.start.utc_ms + delta_ms;
    if (utc < s.start.utc_ms || utc >= s.end.utc_ms) { o->locator_reason = "out-of-range"; return; }
    FrameLocatorV1 locator;
    locator.segment_id = s.segment_id;
    locator.frame = {utc, o->pts, 1, 1000000000};
    locator.keyframe_pts = s.start.pts;
    o->frame_locator = std::move(locator);
    o->locator_reason.clear();
}

AnalysisObservationV2 RecordingCatalog::ResolveObservationV2(AnalysisObservationV2 observation) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    ResolveObservationV2Locked(&observation);
    return observation;
}

bool RecordingCatalog::PutObservationV2(AnalysisObservationV2 observation, std::string* error) {
    // 검증과 segment lifecycle 확인 및 journal append를 동일 catalog lock 아래 수행한다.
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    AnalysisObservationV2 checked;
    if (!ParseAnalysisObservationV2(SerializeAnalysisObservationV2(observation), &checked, error)) return false;
    const auto previous = observations_v2_.find(observation.observation_id);
    if (previous != observations_v2_.end() && !MergeObservation(previous->second, &observation, error)) return false;
    if (observation.frame_locator) {
        ResolveObservationV2Locked(&checked);
        if (!checked.frame_locator ||
            SerializeFrameLocatorV1(*checked.frame_locator) != SerializeFrameLocatorV1(*observation.frame_locator))
            return Fail(error, "observation-v2-locator-mismatch");
    }
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::ObservationV2Put;
    mutation.entity_id = observation.observation_id;
    mutation.payload_json = "{\"observation\":" + SerializeAnalysisObservationV2(observation) + "}";
    return AppendAndApplyLocked(std::move(mutation), error);
}

std::vector<AnalysisObservationV2> RecordingCatalog::QueryObservationsV2(const std::string& channel_id) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<AnalysisObservationV2> output;
    if(generation_backend_&&!CanReadLocked(nullptr))return output;
    for (const auto& pair : observations_v2_) {
        if (pair.second.channel_id != channel_id) continue;
        auto observation = pair.second;
        // 조회는 기존 locator를 revoke할 수 있지만 미확정 관측의 provenance를 새로 추정하지 않는다.
        if (observation.frame_locator) ResolveObservationV2Locked(&observation);
        output.push_back(std::move(observation));
    }
    std::sort(output.begin(), output.end(), [](const auto& a, const auto& b) {
        return a.observation_id < b.observation_id;
    });
    return output;
}

bool RecordingCatalog::CompleteDeletion(const RecordingTombstoneV1& tombstone, std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    RecordingMutationV1 mutation;
    mutation.mutation_type = RecordingMutationType::DeletionCompleted;
    mutation.entity_id = tombstone.segment_id;
    mutation.payload_json = "{\"tombstone\":" + SerializeRecordingTombstoneV1(tombstone) + "}";
    return AppendAndApplyLocked(std::move(mutation), error);
}

std::vector<RecordingSegmentV1> RecordingCatalog::QuerySegments(const std::string& channel_id,
                                                                std::int64_t start_ms,
                                                                std::int64_t end_ms) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<RecordingSegmentV1> result;
    if(generation_backend_&&!CanReadLocked(nullptr))return result;
    for (const auto& [_, segment] : segments_) {
        if (segment.channel_id == channel_id && segment.lifecycle != RecordingLifecycle::Deleted &&
            HalfOpenRangesOverlap(segment.start.utc_ms, segment.end.utc_ms, start_ms, end_ms)) result.push_back(segment);
    }
    std::sort(result.begin(), result.end(), [](const auto& lhs, const auto& rhs) {
        if (lhs.start.utc_ms != rhs.start.utc_ms) return lhs.start.utc_ms < rhs.start.utc_ms;
        return lhs.segment_id < rhs.segment_id;
    });
    return result;
}

std::vector<RecordingSegmentV1> RecordingCatalog::FinalizedSegmentsForStartup() const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<RecordingSegmentV1> result;
    if(generation_backend_&&!CanReadLocked(nullptr))return result;
    for (const auto& [_, segment] : segments_) {
        if (segment.lifecycle == RecordingLifecycle::Finalized) result.push_back(segment);
    }
    std::sort(result.begin(), result.end(), [](const auto& left, const auto& right) {
        return left.segment_id < right.segment_id;
    });
    return result;
}

std::vector<std::string> RecordingCatalog::FinalizedSegmentIdsForStartup() const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<std::string> result;
    if(generation_backend_&&!CanReadLocked(nullptr))return result;
    for(const auto& [id,segment]:segments_)if(segment.lifecycle==RecordingLifecycle::Finalized)result.push_back(id);
    for(const auto& [id,segment]:segments_v2_) {
        (void)segment;
        if(EffectiveLifecycleV2Locked(id)==RecordingLifecycle::Finalized)result.push_back(id);
    }
    std::sort(result.begin(),result.end());
    return result;
} catch(const CatalogHistoryError&) { return {}; }

RetentionSnapshot RecordingCatalog::RetentionSnapshotLocked() const try {
    struct RetentionSnapshot snapshot;
    snapshot.authoritative=opened_&&derived_job_state_authoritative_&&CanReadLocked(nullptr);
    if(!snapshot.authoritative)snapshot.error="catalog reservation snapshot 미확인";
    for(const auto& [id,job]:derived_jobs_){if(!job){snapshot.authoritative=false;snapshot.error="derived null reservation";snapshot.durable_reservations.clear();return snapshot;}if(job.Active())snapshot.durable_reservations.push_back({id,job.channel,job.reserved_bytes});}
    for(const auto& [id,v]:segments_v2_) {
        const auto lifecycle=EffectiveLifecycleV2Locked(id);
        const auto path=media_relpaths_.find(id);
        if(lifecycle==RecordingLifecycle::Deleted||path==media_relpaths_.end())continue;
        RetentionCandidate candidate;candidate.segment_v2=v;candidate.effective_lifecycle=lifecycle;
        candidate.media_path=options_.media_root/std::filesystem::path(path->second);
        const auto hold=hold_counts_.find(id);candidate.hold_count=hold==hold_counts_.end()?0:hold->second;
        if(DerivedJobProtectsLocked(id)&&candidate.hold_count<std::numeric_limits<std::uint64_t>::max())++candidate.hold_count;
        const auto reason=deletion_reasons_.find(id);if(reason!=deletion_reasons_.end())candidate.deletion_reason=reason->second;
        snapshot.candidates.push_back(std::move(candidate));
    }
    for (const auto& [segment_id, segment] : segments_) {
        if (segment.lifecycle != RecordingLifecycle::Finalized &&
            segment.lifecycle != RecordingLifecycle::DeletionPending) {
            continue;
        }
        const auto path = media_relpaths_.find(segment_id);
        if (path == media_relpaths_.end()) continue;
        std::filesystem::path contained_media;
        if (!ResolveContainedMediaPath(options_.media_root, path->second, &contained_media)) {
            if (segment.lifecycle == RecordingLifecycle::DeletionPending) {
                RetentionCandidate pending;
                pending.segment = segment;
                pending.media_path = options_.media_root / path->second;
                const auto reason = deletion_reasons_.find(segment_id);
                if (reason != deletion_reasons_.end()) {
                    pending.deletion_reason = reason->second;
                }
                snapshot.candidates.push_back(std::move(pending));
            }
            continue;
        }
        RetentionCandidate candidate;
        candidate.segment = segment;
        candidate.media_path = std::move(contained_media);
        const auto hold = hold_counts_.find(segment_id);
        candidate.hold_count = hold == hold_counts_.end() ? 0 : hold->second;
        const auto reason = deletion_reasons_.find(segment_id);
        if (reason != deletion_reasons_.end()) candidate.deletion_reason = reason->second;
        snapshot.candidates.push_back(std::move(candidate));
    }
    return snapshot;
} catch(const CatalogHistoryError& failure) { struct RetentionSnapshot failed;failed.authoritative=false;failed.error=failure.what();return failed; }

RetentionSnapshot RecordingCatalog::RetentionSnapshot() const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return RetentionSnapshotLocked();
}

std::optional<EventRecordingLinkV1> RecordingCatalog::FindEventLinkByEventId(
    const std::string& event_id) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::optional<EventRecordingLinkV1> result;
    if(generation_backend_&&!CanReadLocked(nullptr))return result;
    for (const auto& [_, link] : event_links_) {
        if (link.event_id != event_id) continue;
        if (!result.has_value() || link.updated_at_ms > result->updated_at_ms ||
            (link.updated_at_ms == result->updated_at_ms && link.link_id < result->link_id)) {
            result = link;
        }
    }
    return result;
}

std::optional<RecordingSegmentV1> RecordingCatalog::FindSegmentById(
    const std::string& segment_id) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto it = segments_.find(segment_id);
    if(generation_backend_&&!CanReadLocked(nullptr))return std::nullopt;
    if (it == segments_.end() || it->second.lifecycle == RecordingLifecycle::Deleted) {
        return std::nullopt;
    }
    return it->second;
}

std::optional<std::filesystem::path> RecordingCatalog::FindSegmentMediaPath(
    const std::string& segment_id) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto segment = segments_.find(segment_id);
    if(generation_backend_&&!CanReadLocked(nullptr))return std::nullopt;
    const auto path = media_relpaths_.find(segment_id);
    if (segment == segments_.end() || path == media_relpaths_.end() ||
        segment->second.lifecycle == RecordingLifecycle::Deleted) {
        return std::nullopt;
    }
    std::filesystem::path contained;
    if (!ResolveContainedMediaPath(options_.media_root, path->second, &contained)) {
        return std::nullopt;
    }
    return contained;
}

bool RecordingCatalog::IsDeletedSegmentId(
    const std::string& segment_id) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto segment = segments_.find(segment_id);
    return RetiredLocked(segment_id).has_value()||tombstones_v2_.count(segment_id) || tombstones_.find(segment_id) != tombstones_.end() ||
        (segment != segments_.end() && segment->second.lifecycle == RecordingLifecycle::Deleted);
} catch(const CatalogHistoryError&) { return true; }

std::optional<std::pair<std::filesystem::path, std::filesystem::path>>
RecordingCatalog::FindSegmentMediaLocation(const std::string& segment_id) const try {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    const auto segment = segments_.find(segment_id);
    if(generation_backend_&&!CanReadLocked(nullptr))return std::nullopt;
    const auto path = media_relpaths_.find(segment_id);
    if(segments_v2_.count(segment_id)) {
        if(path==media_relpaths_.end()||EffectiveLifecycleV2Locked(segment_id)!=RecordingLifecycle::Finalized)return std::nullopt;
        return std::make_pair(options_.media_root,std::filesystem::path(path->second));
    }
    if (segment == segments_.end() || path == media_relpaths_.end() ||
        segment->second.lifecycle != RecordingLifecycle::Finalized) return std::nullopt;
    return std::make_pair(options_.media_root, std::filesystem::path(path->second));
} catch(const CatalogHistoryError&) { return std::nullopt; }

std::vector<EventRecordingLinkV1> RecordingCatalog::ListEventLinks(
    EventRecordingLinkStatus status) const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::vector<EventRecordingLinkV1> result;
    if(generation_backend_&&!CanReadLocked(nullptr))return result;
    for (const auto& [_, link] : event_links_) {
        if (link.status == status) result.push_back(link);
    }
    std::sort(result.begin(), result.end(), [](const auto& lhs, const auto& rhs) {
        if (lhs.updated_at_ms != rhs.updated_at_ms) {
            return lhs.updated_at_ms < rhs.updated_at_ms;
        }
        return lhs.link_id < rhs.link_id;
    });
    return result;
}

bool RecordingCatalog::AcquireEventSourceLease(
    const std::string& channel_id,
    const std::string& stream_epoch_id,
    const std::vector<std::string>& segment_ids,
    EventSourceLease* lease,
    std::string* error) {
    if (lease == nullptr || channel_id.empty() || stream_epoch_id.empty() ||
        segment_ids.empty()) {
        return Fail(error, "event source lease 인자가 유효하지 않음");
    }
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    std::unordered_set<std::string> unique;
    if(!CanReadLocked(error))return false;
    std::vector<RetentionCandidate> acquired;
    acquired.reserve(segment_ids.size());
    for (const auto& segment_id : segment_ids) {
        if (!unique.insert(segment_id).second) {
            return Fail(error, "event source lease segment ID가 중복됨");
        }
        const auto segment = segments_.find(segment_id);
        const auto path = media_relpaths_.find(segment_id);
        if (segment == segments_.end() || path == media_relpaths_.end() ||
            segment->second.lifecycle != RecordingLifecycle::Finalized ||
            segment->second.retention_class != RecordingRetentionClass::Continuous ||
            segment->second.channel_id != channel_id ||
            segment->second.stream_epoch_id != stream_epoch_id) {
            return Fail(error, "event source lease 대상이 같은 epoch의 finalized continuous segment가 아님");
        }
        constexpr auto kMaxPersistentHoldCount =
            static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max());
        const auto hold = hold_counts_.find(segment_id);
        const std::uint64_t current_hold =
            hold == hold_counts_.end() ? 0 : hold->second;
        if (current_hold >= kMaxPersistentHoldCount) {
            return Fail(error, "event source hold_count가 int64 저장 범위를 넘음");
        }
        std::filesystem::path contained;
        if (!ResolveContainedMediaPath(options_.media_root, path->second, &contained) ||
            !std::filesystem::is_regular_file(contained)) {
            return Fail(error, "event source lease media 경로가 유효하지 않음");
        }
        RetentionCandidate candidate;
        candidate.segment = segment->second;
        candidate.media_path = std::move(contained);
        candidate.hold_count = current_hold + 1;
        acquired.push_back(std::move(candidate));
    }
#if MEDIA_SERVER_USE_SQLITE3
    if (sqlite_db_ != nullptr) {
        if (!Exec(sqlite_db_, "BEGIN IMMEDIATE", error)) return false;
        for (const auto& candidate : acquired) {
            sqlite3_stmt* statement = nullptr;
            if (sqlite3_prepare_v2(sqlite_db_,
                                   "UPDATE recording_segments SET hold_count=hold_count+1 WHERE segment_id=? AND lifecycle='finalized'",
                                   -1, &statement, nullptr) != SQLITE_OK) {
                Exec(sqlite_db_, "ROLLBACK", nullptr);
                return Fail(error, sqlite3_errmsg(sqlite_db_));
            }
            BindText(statement, 1, candidate.segment.segment_id);
            const bool ok = sqlite3_step(statement) == SQLITE_DONE &&
                            sqlite3_changes(sqlite_db_) == 1;
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement);
            if (!ok) {
                Exec(sqlite_db_, "ROLLBACK", nullptr);
                return Fail(error, message.empty() ? "event source hold 갱신 실패" : message);
            }
        }
        if (!Exec(sqlite_db_, "COMMIT", error)) {
            Exec(sqlite_db_, "ROLLBACK", nullptr);
            return false;
        }
    }
#endif
    std::vector<std::pair<std::string,std::uint64_t>> generation_holds;
    if(generation_backend_) {
        for(const auto& candidate:acquired)generation_holds.emplace_back(candidate.segment.segment_id,candidate.hold_count);
        if(!UpdateGenerationHoldsLocked(generation_holds,error))return false;
    }
    for (const auto& candidate : acquired) {
        ++hold_counts_[candidate.segment.segment_id];
    }
    lease->sources = std::move(acquired);
    if (error != nullptr) error->clear();
    return true;
}

bool RecordingCatalog::ReleaseEventSourceLease(const EventSourceLease& lease,
                                                std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    if(!CanReadLocked(error))return false;
    if (lease.sources.empty()) {
        if (error != nullptr) error->clear();
        return true;
    }
    for (const auto& candidate : lease.sources) {
        const auto hold = hold_counts_.find(candidate.segment.segment_id);
        if (hold == hold_counts_.end() || hold->second == 0) {
            return Fail(error, "event source lease hold가 이미 해제됨");
        }
    }
#if MEDIA_SERVER_USE_SQLITE3
    if (sqlite_db_ != nullptr) {
        if (!Exec(sqlite_db_, "BEGIN IMMEDIATE", error)) return false;
        for (const auto& candidate : lease.sources) {
            sqlite3_stmt* statement = nullptr;
            if (sqlite3_prepare_v2(sqlite_db_,
                                   "UPDATE recording_segments SET hold_count=hold_count-1 WHERE segment_id=? AND hold_count>0",
                                   -1, &statement, nullptr) != SQLITE_OK) {
                Exec(sqlite_db_, "ROLLBACK", nullptr);
                return Fail(error, sqlite3_errmsg(sqlite_db_));
            }
            BindText(statement, 1, candidate.segment.segment_id);
            const bool ok = sqlite3_step(statement) == SQLITE_DONE &&
                            sqlite3_changes(sqlite_db_) == 1;
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement);
            if (!ok) {
                Exec(sqlite_db_, "ROLLBACK", nullptr);
                return Fail(error, message.empty() ? "event source hold 해제 실패" : message);
            }
        }
        if (!Exec(sqlite_db_, "COMMIT", error)) {
            Exec(sqlite_db_, "ROLLBACK", nullptr);
            return false;
        }
    }
#endif
    if(generation_backend_) {
        std::vector<std::pair<std::string,std::uint64_t>> values;
        for(const auto& candidate:lease.sources)values.emplace_back(candidate.segment.segment_id,hold_counts_.at(candidate.segment.segment_id)-1);
        if(!UpdateGenerationHoldsLocked(values,error))return false;
    }
    for (const auto& candidate : lease.sources) {
        auto hold = hold_counts_.find(candidate.segment.segment_id);
        if (--hold->second == 0) hold_counts_.erase(hold);
    }
    if (error != nullptr) error->clear();
    return true;
}

bool RecordingCatalog::AdjustHoldCount(const std::string& segment_id,
                                       std::int64_t delta,
                                       std::string* error) {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    return AdjustHoldCountLocked(segment_id,delta,error);
}
bool RecordingCatalog::AdjustHoldCountLocked(const std::string& segment_id,std::int64_t delta,std::string* error) try {
    if(!CanReadLocked(error))return false;
    const auto segment = segments_.find(segment_id);
    const bool v2=segments_v2_.count(segment_id)!=0;
    if ((v2&&EffectiveLifecycleV2Locked(segment_id)!=RecordingLifecycle::Finalized)||
        (!v2&&(segment == segments_.end() || segment->second.lifecycle != RecordingLifecycle::Finalized))) {
        return Fail(error, "hold 대상 finalized segment가 없음");
    }
    const auto current_hold=hold_counts_.find(segment_id);
    const std::uint64_t current = generation_backend_?(current_hold==hold_counts_.end()?0:current_hold->second):hold_counts_[segment_id];
    const std::uint64_t magnitude = delta < 0
                                        ? static_cast<std::uint64_t>(-(delta + 1)) + 1
                                        : static_cast<std::uint64_t>(delta);
    if (delta < 0 && magnitude > current) {
        return Fail(error, "hold_count는 음수가 될 수 없음");
    }
    constexpr auto kMaxPersistentHoldCount =
        static_cast<std::uint64_t>(std::numeric_limits<std::int64_t>::max());
    if (delta >= 0 && magnitude > kMaxPersistentHoldCount - current) {
        return Fail(error, "hold_count가 int64 저장 범위를 넘음");
    }
    const std::uint64_t next = delta >= 0 ? current + magnitude : current - magnitude;
    if(generation_backend_&&!UpdateGenerationHoldsLocked({{segment_id,next}},error))return false;
#if MEDIA_SERVER_USE_SQLITE3
    if (sqlite_db_ != nullptr) {
        sqlite3_stmt* statement = nullptr;
        if (sqlite3_prepare_v2(sqlite_db_,
                               v2?"UPDATE recording_segment_states_v2 SET hold_count=? WHERE segment_id=?":
                                  "UPDATE recording_segments SET hold_count=? WHERE segment_id=?",
                               -1, &statement, nullptr) != SQLITE_OK) {
            return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        sqlite3_bind_int64(statement, 1, static_cast<sqlite3_int64>(next));
        BindText(statement, 2, segment_id);
        const bool ok = sqlite3_step(statement) == SQLITE_DONE &&
                        sqlite3_changes(sqlite_db_) == 1;
        if (!ok) {
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement);
            return Fail(error, message);
        }
        sqlite3_finalize(statement);
    }
#endif
    if (next == 0) hold_counts_.erase(segment_id);
    else hold_counts_[segment_id] = next;
    if (error != nullptr) error->clear();
    return true;
} catch(const CatalogHistoryError& failure) { return Fail(error,failure.what()); }

RecordingOrphanReport RecordingCatalog::InspectOrphans() const {
    std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");
    RecordingOrphanReport report;
    std::error_code error;
    if (!std::filesystem::exists(options_.media_root, error)) return report;
    for (const auto& entry : std::filesystem::recursive_directory_iterator(options_.media_root, error)) {
        if (error || !entry.is_regular_file()) continue;
        if (entry.path().extension() != ".mp4" && entry.path().extension() != ".ts" &&
            entry.path().extension() != ".webm") continue;
        bool known = false;
        const auto relative = entry.path().lexically_relative(options_.media_root).generic_string();
        for (const auto& [_, path] : media_relpaths_) if (path == relative) { known = true; break; }
        if (known) continue;
        if (IsRecognizedMedia(entry.path())) { ++report.normal_orphan_count; report.normal_orphans.push_back(entry.path()); }
        else { ++report.corrupt_orphan_count; report.corrupt_orphans.push_back(entry.path()); }
    }
    return report;
}

bool RecordingCatalog::OpenSqliteLocked(std::string* error) {
#if !MEDIA_SERVER_USE_SQLITE3
    (void)error;
    return false;
#else
    std::error_code fs_error;
    if (!options_.sqlite_path.parent_path().empty()) std::filesystem::create_directories(options_.sqlite_path.parent_path(), fs_error);
    if (fs_error) return false;
    const bool existed = std::filesystem::exists(options_.sqlite_path);
    if (sqlite3_open(options_.sqlite_path.string().c_str(), &sqlite_db_) != SQLITE_OK) {
        CloseSqliteLocked();
    } else {
        sqlite3_stmt* statement = nullptr;
        bool healthy = sqlite3_prepare_v2(sqlite_db_, "PRAGMA quick_check", -1, &statement, nullptr) == SQLITE_OK;
        if (healthy && sqlite3_step(statement) == SQLITE_ROW) {
            const auto* text = sqlite3_column_text(statement, 0);
            healthy = text != nullptr && std::string(reinterpret_cast<const char*>(text)) == "ok";
        } else healthy = false;
        if (statement != nullptr) sqlite3_finalize(statement);
        if (healthy) return InitializeSqliteSchemaLocked(error);
        CloseSqliteLocked();
    }
    if (existed) {
        const auto quarantine = options_.sqlite_path.string() + ".corrupt-" + std::to_string(NowMs());
        std::filesystem::rename(options_.sqlite_path, quarantine, fs_error);
        if (fs_error) return false;
        recovery_report_.sqlite_quarantined = true;
        recovery_report_.sqlite_quarantine_path = quarantine;
    }
    if (sqlite3_open(options_.sqlite_path.string().c_str(), &sqlite_db_) != SQLITE_OK) { CloseSqliteLocked(); return false; }
    return InitializeSqliteSchemaLocked(error);
#endif
}

bool RecordingCatalog::InitializeSqliteSchemaLocked(std::string* error) {
#if !MEDIA_SERVER_USE_SQLITE3
    (void)error; return false;
#else
    const char* schema = R"SQL(
PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS recording_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_mutations(mutation_id TEXT PRIMARY KEY, type TEXT NOT NULL, occurred_at_ms INTEGER NOT NULL, entity_id TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_segments(segment_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, channel_id TEXT NOT NULL, stream_epoch_id TEXT NOT NULL, start_utc_ms INTEGER NOT NULL, end_utc_ms INTEGER NOT NULL, start_pts INTEGER NOT NULL, end_pts INTEGER NOT NULL, time_base_num INTEGER NOT NULL, time_base_den INTEGER NOT NULL, container TEXT NOT NULL, codecs_json TEXT NOT NULL, size_bytes INTEGER NOT NULL, checksum_sha256 TEXT NOT NULL, retention_class TEXT NOT NULL, lifecycle TEXT NOT NULL, pinned INTEGER NOT NULL, hold_count INTEGER NOT NULL DEFAULT 0, media_relpath TEXT NOT NULL, created_at_ms INTEGER NOT NULL, finalized_at_ms INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS recording_segments_v2(segment_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL,media_relpath TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_source_bindings(segment_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_derived_jobs(job_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_consumer_references(reference_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_derived_accepted_references(reference_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_referenced_observations(observation_id TEXT PRIMARY KEY,payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_segment_states_v2(segment_id TEXT PRIMARY KEY,lifecycle TEXT NOT NULL,reason TEXT NOT NULL,tombstone_json TEXT NOT NULL,hold_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS recording_event_links(link_id TEXT PRIMARY KEY, event_id TEXT UNIQUE NOT NULL, channel_id TEXT NOT NULL, requested_start_ms INTEGER NOT NULL, requested_end_ms INTEGER NOT NULL, derived_segment_id TEXT, fallback_ref TEXT, completeness TEXT NOT NULL, missing_ranges_json TEXT NOT NULL, display_priority INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS recording_event_link_segments(link_id TEXT NOT NULL REFERENCES recording_event_links(link_id) ON DELETE CASCADE, segment_id TEXT NOT NULL REFERENCES recording_segments(segment_id), overlap_start_ms INTEGER NOT NULL, overlap_end_ms INTEGER NOT NULL, PRIMARY KEY(link_id, segment_id));
CREATE TABLE IF NOT EXISTS recording_observations(observation_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, segment_id TEXT NOT NULL REFERENCES recording_segments(segment_id), utc_ms INTEGER NOT NULL, pts INTEGER NOT NULL, track_id TEXT, class_id TEXT, class_name TEXT, confidence REAL, bbox_json TEXT, event_id TEXT, selection_reason TEXT, payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_observations_v2(observation_id TEXT PRIMARY KEY, channel_id TEXT NOT NULL, segment_id TEXT, pts INTEGER NOT NULL, payload_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS recording_tombstones(entity_id TEXT PRIMARY KEY, entity_kind TEXT NOT NULL, channel_id TEXT, start_utc_ms INTEGER, end_utc_ms INTEGER, deleted_at_ms INTEGER, reason TEXT, retention_class TEXT, checksum_sha256 TEXT);
CREATE INDEX IF NOT EXISTS idx_recording_segments_channel_range ON recording_segments(channel_id,start_utc_ms,end_utc_ms);
CREATE INDEX IF NOT EXISTS idx_recording_segments_retention_end ON recording_segments(retention_class,end_utc_ms);
CREATE INDEX IF NOT EXISTS idx_recording_observations_channel_time_track ON recording_observations(channel_id,utc_ms,track_id);
CREATE INDEX IF NOT EXISTS idx_recording_event_links_event ON recording_event_links(event_id);
INSERT OR REPLACE INTO recording_meta(key,value) VALUES('schema_version','1');
)SQL";
    return Exec(sqlite_db_, schema, error);
#endif
}

bool RecordingCatalog::RebuildSqliteLocked(std::string* error) {
#if !MEDIA_SERVER_USE_SQLITE3
    (void)error; return true;
#else
    RecordingMutationHandles owned;
    RecordingJournalOwnedViews views;
    RecordingJournalReplayResult replay;
    if(!ReadCatalogReplay(&owned,&replay,error,&views))return false;
    bool same_preflight_snapshot=false;
    if(recovery_content_&&recovery_content_->valid){
        const auto* original=recovery_content_->original;
        bool same=original&&original->size()==owned.size();
        for(std::size_t i=0;same&&i<owned.size();++i){
            if(!(*original)[i]||!owned[i]){same=false;break;}
            const auto& a=*(*original)[i];const auto& b=*owned[i];
            same=a.schema==b.schema&&a.mutation_type==b.mutation_type&&a.mutation_id==b.mutation_id&&
                a.entity_id==b.entity_id&&a.occurred_at_ms==b.occurred_at_ms&&a.payload_json==b.payload_json;
        }
        if(!same){
            recovery_content_->valid=false;recovery_content_->strict_preflight_validated=false;
            recovery_content_->entries.clear();recovery_content_->charge=0;
        }else same_preflight_snapshot=recovery_content_->strict_preflight_validated;
    }
    if (replay.io_error_count != 0) return Fail(error, "journal replay I/O 오류로 SQLite rebuild 거부");
    if (replay.unsupported_record_count != 0) return Fail(error, "미지원 journal record로 SQLite rebuild 거부");
    // Open의 strict 사전 검증과 동일한 전체 원장일 때만 두 번째 scratch replay를 생략한다.
    // 변경·pending·독립 Rebuild는 기존 strict 경로를 유지한다.
    if(same_preflight_snapshot){
        if(replay.corrupt_line_count||replay.truncated_tail_count||!journal_.OwnsCatalog(this))
            return Fail(error,"V2/order 원장 불완전 상태");
    }else if (!PreflightV2Locked(replay,error,nullptr,{},nullptr,owned,views)) return false;
    if (!Exec(sqlite_db_, "BEGIN", error)) return false;
    struct RebuildRollback {
        sqlite3* db;
        bool active{true};
        ~RebuildRollback(){if(active)Exec(db,"ROLLBACK",nullptr);}
    } rollback{sqlite_db_};
    if (!Exec(sqlite_db_, "DELETE FROM recording_derived_accepted_references; DELETE FROM recording_derived_jobs; DELETE FROM recording_referenced_observations; DELETE FROM recording_consumer_references; DELETE FROM recording_source_bindings; DELETE FROM recording_event_link_segments; DELETE FROM recording_event_links; DELETE FROM recording_observations; DELETE FROM recording_observations_v2; DELETE FROM recording_segment_states_v2; DELETE FROM recording_segments_v2; DELETE FROM recording_segments; DELETE FROM recording_tombstones; DELETE FROM recording_mutations;", error)) return false;
    for (std::size_t ordinal = 0; ordinal < replay.mutations.size(); ++ordinal) {
        const auto& mutation = replay.mutations[ordinal];
        RecoveryContentScope recovery_row(*this,recovery_content_,ordinal,owned.empty()?RecordingMutationHandle{}:owned[ordinal]);
        if (mutation.mutation_type == RecordingMutationType::SegmentFinalized ||
            mutation.mutation_type == RecordingMutationType::SegmentV2State ||
            mutation.mutation_type == RecordingMutationType::SegmentV2Deleted ||
            mutation.mutation_type == RecordingMutationType::SegmentV2Finalized ||
            mutation.mutation_type == RecordingMutationType::SegmentV2BoundFinalized ||
            mutation.mutation_type == RecordingMutationType::CorruptionDetected) {
            const auto accepted = accepted_segment_state_mutations_.find(mutation.mutation_id);
            if (accepted_segment_state_replay_ordinals_.count(ordinal) == 0 ||
                accepted == accepted_segment_state_mutations_.end()) continue;
            RecordingMutationHandle accepted_owned;
            bool current_view=false;
            if(!views.empty()&&!journal_.MatchMutationLinkView(accepted->second,views[ordinal],&current_view,error))return false;
            if(current_view)accepted_owned=owned[ordinal];
            else if(!journal_.AcquireMutationLink(accepted->second,&accepted_owned,error))return false;
            if(SerializeRecordingMutationV1(*accepted_owned)!=SerializeRecordingMutationV1(mutation))continue;
        }
        if (!ProjectMutationSqliteInTransactionLocked(mutation,error,nullptr,false,
                views.empty()?RecordingJournalOwnedViewHandle{}:views[ordinal])) return false;
    }
    if(!Exec(sqlite_db_,"COMMIT",error))return false;
    rollback.active=false;
    return true;
#endif
}

bool RecordingCatalog::ProjectMutationSqliteLocked(const RecordingMutationV1& mutation, std::string* error,PreparedDerivedMutation* prepared) {
    return ProjectMutationSqliteInTransactionLocked(mutation,error,prepared,true);
}

bool RecordingCatalog::ProjectMutationSqliteInTransactionLocked(const RecordingMutationV1& mutation,
        std::string* error,PreparedDerivedMutation* prepared,bool own_transaction,
        RecordingJournalOwnedViewHandle view) {
    recording::latency::Scope latency_scope(recording::latency::Operation::Sqlite,recording::latency::Source::Catalog,__LINE__,false);
#if !MEDIA_SERVER_USE_SQLITE3
    (void)mutation; (void)error; (void)prepared; (void)own_transaction; (void)view; return true;
#else
    const auto ProjectionExec=[own_transaction](sqlite3* db,const char* sql,std::string* err){
        if(!own_transaction&&(std::strcmp(sql,"BEGIN")==0||std::strcmp(sql,"COMMIT")==0))return true;
        return Exec(db,sql,err);
    };
    if(prepared){if(!PreparedDerivedMatchesLocked(mutation,*prepared,true,error))return false;prepared->phase=PreparedDerivedMutation::Phase::Consumed;}
    if (!ProjectionExec(sqlite_db_, "BEGIN", error)) return false;
    sqlite3_stmt* statement = nullptr;
    if (sqlite3_prepare_v2(sqlite_db_, "INSERT OR IGNORE INTO recording_mutations VALUES(?,?,?,?)", -1, &statement, nullptr) != SQLITE_OK) { ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_)); }
    BindText(statement, 1, mutation.mutation_id); BindText(statement, 2, RecordingMutationTypeName(mutation.mutation_type));
    sqlite3_bind_int64(statement, 3, mutation.occurred_at_ms); BindText(statement, 4, mutation.entity_id);
    const int mutation_step = sqlite3_step(statement);
    const bool inserted = mutation_step == SQLITE_DONE && sqlite3_changes(sqlite_db_) > 0;
    const std::string mutation_error =
        mutation_step == SQLITE_DONE ? std::string() : sqlite3_errmsg(sqlite_db_);
    sqlite3_finalize(statement);
    if (mutation_step != SQLITE_DONE) {
        ProjectionExec(sqlite_db_, "ROLLBACK", nullptr);
        return Fail(error, mutation_error);
    }
    if (!inserted) return ProjectionExec(sqlite_db_, "COMMIT", error);
    if(IsDerivedJobMutation(mutation.mutation_type)) {
        const auto* recovery=RecoveryContentLocked(mutation);
        const auto recovered=recovery?recovery->job:DerivedJobHandle{};
        DerivedJobRecordV1 parsed_job;
        if((!prepared&&!recovered&&!ParseDerivedJobRecord(mutation.payload_json,&parsed_job,error))||
           sqlite3_prepare_v2(sqlite_db_,"INSERT OR REPLACE INTO recording_derived_jobs VALUES(?,?)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        const auto& job=prepared?*prepared->applied:recovered?*recovered:parsed_job;
        BindText(statement,1,job.intent.job_id);BindText(statement,2,prepared?prepared->payload:recovered?mutation.payload_json:SerializeDerivedJobRecord(job));
        const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,"derived job SQLite projection 실패");}
        if(mutation.mutation_type==RecordingMutationType::DerivedJobCommitted) {
            for(std::size_t i=0;i<job.ready->outputs.size();++i) {
                const auto& s=job.ready->outputs[i].segment;
                if(sqlite3_prepare_v2(sqlite_db_,"INSERT OR IGNORE INTO recording_segments_v2 VALUES(?,?,?)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
                BindText(statement,1,s.segment_id);BindText(statement,2,SerializeRecordingSegmentV2(s));BindText(statement,3,job.intent.outputs[i].final_relpath);
                const bool inserted=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
                if(!inserted){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,"derived output SQLite 원자 INSERT 실패");}
                if(sqlite3_prepare_v2(sqlite_db_,"INSERT OR IGNORE INTO recording_segment_states_v2 VALUES(?,'finalized','','',0)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
                BindText(statement,1,s.segment_id);const bool state=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
                if(!state){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
            }
        }
    } else if (mutation.mutation_type == RecordingMutationType::ReferencedObservationPut) {
        ReferencedObservationV1 pair;
        if(!ParseReferencedObservationV1(mutation.payload_json,&pair,error)) {ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        const auto merged=referenced_observations_.find(pair.observation.observation_id);
        if(merged!=referenced_observations_.end())pair=merged->second;
        if(
           sqlite3_prepare_v2(sqlite_db_,"INSERT OR REPLACE INTO recording_referenced_observations VALUES(?,?)",-1,&statement,nullptr)!=SQLITE_OK) {
            ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;
        }
        BindText(statement,1,pair.observation.observation_id);BindText(statement,2,SerializeReferencedObservationV1(pair));
        const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
    } else if (mutation.mutation_type == RecordingMutationType::ConsumerReferencePut ||
               mutation.mutation_type == RecordingMutationType::DerivedReferenceAccepted) {
        const auto json=ObjectField(mutation.payload_json,"reference");RecordingConsumerReferenceV1 reference;
        const char* sql=mutation.mutation_type==RecordingMutationType::DerivedReferenceAccepted
            ? "INSERT OR IGNORE INTO recording_derived_accepted_references VALUES(?,?)"
            : "INSERT OR IGNORE INTO recording_consumer_references VALUES(?,?)";
        if(!json||!ParseRecordingConsumerReferenceV1(*json,&reference,error)||
           sqlite3_prepare_v2(sqlite_db_,sql,-1,&statement,nullptr)!=SQLITE_OK) {
            ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;
        }
        BindText(statement,1,reference.reference_id);BindText(statement,2,SerializeRecordingConsumerReferenceV1(reference));
        const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
    } else if (mutation.mutation_type == RecordingMutationType::SegmentFinalized) {
        const auto segment_json = ObjectField(mutation.payload_json, "segment");
        const auto relpath = StringField(mutation.payload_json, "mediaRelpath");
        RecordingSegmentV1 s;
        if (!segment_json || !relpath || !ParseRecordingSegmentV1(*segment_json, &s, error)) { ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return false; }
        const char* sql = "INSERT OR IGNORE INTO recording_segments VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?)";
        if (sqlite3_prepare_v2(sqlite_db_, sql, -1, &statement, nullptr) != SQLITE_OK) { ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_)); }
        int i=1; BindText(statement,i++,s.segment_id); BindText(statement,i++,s.source_id); BindText(statement,i++,s.channel_id); BindText(statement,i++,s.stream_epoch_id);
        sqlite3_bind_int64(statement,i++,s.start.utc_ms); sqlite3_bind_int64(statement,i++,s.end.utc_ms); sqlite3_bind_int64(statement,i++,s.start.pts); sqlite3_bind_int64(statement,i++,s.end.pts); sqlite3_bind_int(statement,i++,s.start.time_base_num); sqlite3_bind_int(statement,i++,s.start.time_base_den);
        BindText(statement,i++,s.container); BindText(statement,i++,SerializeRecordingSegmentV1(s)); sqlite3_bind_int64(statement,i++,static_cast<sqlite3_int64>(s.size_bytes)); BindText(statement,i++,s.checksum_sha256); BindText(statement,i++,RetentionName(s.retention_class)); BindText(statement,i++,LifecycleName(s.lifecycle)); sqlite3_bind_int(statement,i++,s.pinned?1:0); BindText(statement,i++,*relpath); sqlite3_bind_int64(statement,i++,s.created_at_ms); sqlite3_bind_int64(statement,i++,s.finalized_at_ms);
        if (sqlite3_step(statement) != SQLITE_DONE) { const std::string message=sqlite3_errmsg(sqlite_db_); sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error,message); }
        sqlite3_finalize(statement);
    } else if (mutation.mutation_type == RecordingMutationType::SegmentV2Finalized ||
               mutation.mutation_type == RecordingMutationType::SegmentV2BoundFinalized) {
        const auto* recovery=RecoveryContentLocked(mutation);
        const bool recovered=recovery&&recovery->binding&&mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized;
        SourceBindingHandle live_binding;
        const RecordingSegmentV2* live_segment=nullptr;
        const std::string* live_relative=nullptr;
        if(!recovered&&view&&mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized){
            const auto binding=source_bindings_.find(mutation.entity_id);
            const auto segment=segments_v2_.find(mutation.entity_id);
            const auto relative=media_relpaths_.find(mutation.entity_id);
            if(binding!=source_bindings_.end()&&segment!=segments_v2_.end()&&relative!=media_relpaths_.end()){
                bool exact_view=false;
                if(!journal_.MatchMutationLinkView(binding->second.mutation,view,&exact_view,error)){
                    ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;
                }
                if(exact_view){
                    live_binding=binding->second.WarmOwned();
                    if(live_binding){live_segment=&segment->second;live_relative=&relative->second;}
                }
            }
        }
        // 같은 Open에서 strict 적용한 불변 bound와 원장의 동일 view가 결박될 때만 재사용한다.
        // 다른 세대·중복 행·비상주 입력은 기존 strict parse로 되돌린다.
        const bool reused=recovered||bool(live_binding);
        ingress::StrictJsonObjectDocument payload;
        if(!reused&&!ingress::ParseStrictJsonObjectDocument(mutation.payload_json,&payload,error)){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        const auto json=ingress::StrictJsonObjectField(payload,"segment");
        const auto relative=recovered?std::optional<std::string>(recovery->relative):live_relative?
            std::optional<std::string>(*live_relative):ingress::StrictJsonStringField(payload,"mediaRelpath");RecordingSegmentV2 v;
        if(recovered)v=recovery->segment;else if(live_segment)v=*live_segment;
        if(!relative||(!reused&&(!json||!ParseRecordingSegmentV2(*json,&v,error)))||
           sqlite3_prepare_v2(sqlite_db_,"INSERT OR IGNORE INTO recording_segments_v2 VALUES(?,?,?)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        BindText(statement,1,v.segment_id);BindText(statement,2,recovered?recovery->segment_json:SerializeRecordingSegmentV2(v));BindText(statement,3,*relative);
        const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,"V2 SQLite INSERT 실패");}
        if(sqlite3_prepare_v2(sqlite_db_,"INSERT OR IGNORE INTO recording_segment_states_v2 VALUES(?,'finalized','','',0)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        BindText(statement,1,v.segment_id);const bool state_ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!state_ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        if(mutation.mutation_type==RecordingMutationType::SegmentV2BoundFinalized) {
            const auto json=ingress::StrictJsonObjectField(payload,"sourceBinding");RecordingSourceBindingV1 binding;
            if((!reused&&(!json||!ParseRecordingSourceBindingV1(*json,&binding,error)))||
               sqlite3_prepare_v2(sqlite_db_,"INSERT INTO recording_source_bindings VALUES(?,?)",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
            BindText(statement,1,v.segment_id);BindText(statement,2,recovered?recovery->binding_json:
                live_binding?SerializeRecordingSourceBindingV1(*live_binding):SerializeRecordingSourceBindingV1(binding));
            const bool binding_ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
            if(!binding_ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        }
    } else if(mutation.mutation_type==RecordingMutationType::SegmentV2State ||
              mutation.mutation_type==RecordingMutationType::SegmentV2Deleted) {
        const bool deleted=mutation.mutation_type==RecordingMutationType::SegmentV2Deleted;
        RecordingSegmentStateV2 state;RecordingTombstoneV2 tombstone;
        if((deleted&&!ParseRecordingTombstoneV2(mutation.payload_json,&tombstone,error))||
           (!deleted&&!ParseRecordingSegmentStateV2(mutation.payload_json,&state,error))){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        if(sqlite3_prepare_v2(sqlite_db_,"UPDATE recording_segment_states_v2 SET lifecycle=?,reason=?,tombstone_json=? WHERE segment_id=?",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        BindText(statement,1,deleted?"deleted":LifecycleName(state.lifecycle));
        BindText(statement,2,deleted?tombstone.deletion_reason:state.reason);
        // 전체 tombstone은 원장에 남고 SQLite는 재구축 가능한 현재 상태 투영이다.
        BindText(statement,3,deleted?SqliteDeletionReceipt(tombstone):"");BindText(statement,4,mutation.entity_id);
        const bool state_ok=sqlite3_step(statement)==SQLITE_DONE&&sqlite3_changes(sqlite_db_)==1;sqlite3_finalize(statement);
        if(!state_ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        if(deleted) {
            if(sqlite3_prepare_v2(sqlite_db_,"DELETE FROM recording_segments_v2 WHERE segment_id=?",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
            BindText(statement,1,mutation.entity_id);const bool ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
            if(!ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
            // SQLite는 JSONL의 재구축 가능한 투영이다. 삭제된 원본의 상세 결박은
            // journal에서 검증·재획득하되, 투영에는 동일한 큰 payload를 중복 보관하지 않는다.
            if(sqlite3_prepare_v2(sqlite_db_,"DELETE FROM recording_source_bindings WHERE segment_id=?",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
            BindText(statement,1,mutation.entity_id);const bool binding_ok=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
            if(!binding_ok){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        }
    } else if (mutation.mutation_type == RecordingMutationType::EventLinkCreated) {
        const auto link_json=ObjectField(mutation.payload_json,"link"); EventRecordingLinkV1 link;
        if(!link_json||!ParseEventRecordingLinkV1(*link_json,&link,error)){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        const char* sql="INSERT OR REPLACE INTO recording_event_links VALUES(?,?,?,?,?,?,?,?,?,0)";
        sqlite3_prepare_v2(sqlite_db_,sql,-1,&statement,nullptr); int i=1; BindText(statement,i++,link.link_id); BindText(statement,i++,link.event_id); BindText(statement,i++,link.channel_id); sqlite3_bind_int64(statement,i++,link.requested_range.has_value()?link.requested_range->start_ms:0); sqlite3_bind_int64(statement,i++,link.requested_range.has_value()?link.requested_range->end_ms:0); BindText(statement,i++,link.derived_segment_id.value_or("")); BindText(statement,i++,link.fallback_evidence_id.value_or("")); BindText(statement,i++,EventStatusName(link.status)); BindText(statement,i++,SerializeEventRecordingLinkV1(link));
        if(sqlite3_step(statement)!=SQLITE_DONE){const std::string message=sqlite3_errmsg(sqlite_db_);sqlite3_finalize(statement);ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,message);} sqlite3_finalize(statement);
        if(sqlite3_prepare_v2(sqlite_db_,"DELETE FROM recording_event_link_segments WHERE link_id=?",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,sqlite3_errmsg(sqlite_db_));}BindText(statement,1,link.link_id);if(sqlite3_step(statement)!=SQLITE_DONE){const std::string message=sqlite3_errmsg(sqlite_db_);sqlite3_finalize(statement);ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,message);}sqlite3_finalize(statement);
        for(const auto& overlap:link.ordered_overlaps){sqlite3_prepare_v2(sqlite_db_,"INSERT INTO recording_event_link_segments VALUES(?,?,?,?)",-1,&statement,nullptr);BindText(statement,1,link.link_id);BindText(statement,2,overlap.segment_id);sqlite3_bind_int64(statement,3,overlap.range.start_ms);sqlite3_bind_int64(statement,4,overlap.range.end_ms);if(sqlite3_step(statement)!=SQLITE_DONE){const std::string message=sqlite3_errmsg(sqlite_db_);sqlite3_finalize(statement);ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return Fail(error,message);}sqlite3_finalize(statement);}
    } else if (mutation.mutation_type == RecordingMutationType::ObservationV2Put) {
        const auto json = ObjectField(mutation.payload_json, "observation");
        AnalysisObservationV2 observation;
        if (!json || !ParseAnalysisObservationV2(*json, &observation, error)) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return false;
        }
        // V2 projection은 Apply가 identity검증·사유병합을 마친 유효상태에서만 생성한다.
        // 재구축 중 거부된 원장행을 다시 신뢰해 memory와 다른 SQLite행을 만들지 않는다.
        const auto valid = observations_v2_.find(mutation.entity_id);
        if (valid == observations_v2_.end()) {
            return ProjectionExec(sqlite_db_, "COMMIT", error);
        }
        observation = valid->second;
        if (sqlite3_prepare_v2(sqlite_db_, "INSERT OR REPLACE INTO recording_observations_v2 VALUES(?,?,?,?,?)", -1,
                              &statement, nullptr) != SQLITE_OK) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        BindText(statement, 1, observation.observation_id);
        BindText(statement, 2, observation.channel_id);
        if (observation.frame_locator) BindText(statement, 3, observation.frame_locator->segment_id);
        else sqlite3_bind_null(statement, 3);
        sqlite3_bind_int64(statement, 4, observation.pts);
        BindText(statement, 5, SerializeAnalysisObservationV2(observation));
        const bool ok = sqlite3_step(statement) == SQLITE_DONE;
        sqlite3_finalize(statement); statement = nullptr;
        if (!ok) { ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_)); }
    } else if (mutation.mutation_type == RecordingMutationType::ObservationPut) {
        const auto observation_json = ObjectField(mutation.payload_json, "observation");
        AnalysisObservationV1 observation;
        if (!observation_json || !ParseAnalysisObservationV1(*observation_json, &observation, error)) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return false;
        }
        const char* sql = "INSERT OR REPLACE INTO recording_observations VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        if (sqlite3_prepare_v2(sqlite_db_, sql, -1, &statement, nullptr) != SQLITE_OK) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        int i = 1;
        BindText(statement, i++, observation.observation_id);
        BindText(statement, i++, observation.channel_id);
        BindText(statement, i++, observation.frame_locator.segment_id);
        sqlite3_bind_int64(statement, i++, observation.frame_locator.frame.utc_ms);
        sqlite3_bind_int64(statement, i++, observation.frame_locator.frame.pts);
        BindText(statement, i++, observation.track_id);
        BindText(statement, i++, observation.class_label);
        BindText(statement, i++, observation.class_label);
        sqlite3_bind_double(statement, i++, observation.confidence);
        std::ostringstream bbox;
        bbox << "{\"x\":" << observation.bbox.x << ",\"y\":" << observation.bbox.y
             << ",\"width\":" << observation.bbox.width << ",\"height\":"
             << observation.bbox.height << "}";
        BindText(statement, i++, bbox.str());
        BindText(statement, i++, observation.event_ids.empty() ? "" : observation.event_ids.front());
        BindText(statement, i++, observation.selection_reason);
        BindText(statement, i++, *observation_json);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, message);
        }
        sqlite3_finalize(statement);
    } else if (mutation.mutation_type == RecordingMutationType::CorruptionDetected) {
        if (sqlite3_prepare_v2(sqlite_db_,
            "UPDATE recording_segments SET lifecycle='corrupt' WHERE segment_id=? AND lifecycle='finalized'",
            -1, &statement, nullptr) != SQLITE_OK) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        BindText(statement, 1, mutation.entity_id);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, message);
        }
        sqlite3_finalize(statement);
    } else if (mutation.mutation_type == RecordingMutationType::DeletionRequested) {
        if (sqlite3_prepare_v2(sqlite_db_,
                               "UPDATE recording_segments SET lifecycle='deletion_pending' WHERE segment_id=?",
                               -1, &statement, nullptr) != SQLITE_OK) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        BindText(statement, 1, mutation.entity_id);
        if (sqlite3_step(statement) != SQLITE_DONE || sqlite3_changes(sqlite_db_) != 1) {
            sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr);
            return Fail(error, "SQLite 삭제 요청 대상 segment가 없음");
        }
        sqlite3_finalize(statement);
    } else if (mutation.mutation_type == RecordingMutationType::DeletionCompleted) {
        const auto tombstone_json = ObjectField(mutation.payload_json, "tombstone");
        RecordingTombstoneV1 tombstone;
        if (!tombstone_json || !ParseRecordingTombstoneV1(*tombstone_json, &tombstone, error)) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return false;
        }
        const char* sql = "INSERT OR REPLACE INTO recording_tombstones VALUES(?,?,?,?,?,?,?,?,?)";
        if (sqlite3_prepare_v2(sqlite_db_, sql, -1, &statement, nullptr) != SQLITE_OK) {
            ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, sqlite3_errmsg(sqlite_db_));
        }
        BindText(statement, 1, tombstone.segment_id);
        BindText(statement, 2, "segment");
        BindText(statement, 3, tombstone.channel_id);
        sqlite3_bind_int64(statement, 4, tombstone.recorded_range.start_ms);
        sqlite3_bind_int64(statement, 5, tombstone.recorded_range.end_ms);
        sqlite3_bind_int64(statement, 6, tombstone.deleted_at_ms);
        BindText(statement, 7, tombstone.deletion_reason);
        BindText(statement, 8, RetentionName(tombstone.retention_class));
        BindText(statement, 9, tombstone.checksum_sha256);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, message);
        }
        sqlite3_finalize(statement);
        if(sqlite3_prepare_v2(sqlite_db_,"DELETE FROM recording_segments_v2 WHERE segment_id=?",-1,&statement,nullptr)!=SQLITE_OK){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        BindText(statement,1,tombstone.segment_id);
        const bool v2_deleted=sqlite3_step(statement)==SQLITE_DONE;sqlite3_finalize(statement);
        if(!v2_deleted){ProjectionExec(sqlite_db_,"ROLLBACK",nullptr);return false;}
        sqlite3_prepare_v2(sqlite_db_,
                           "UPDATE recording_segments SET lifecycle='deleted', media_relpath='' WHERE segment_id=?",
                           -1, &statement, nullptr);
        BindText(statement, 1, tombstone.segment_id);
        if (sqlite3_step(statement) != SQLITE_DONE) {
            const std::string message = sqlite3_errmsg(sqlite_db_);
            sqlite3_finalize(statement); ProjectionExec(sqlite_db_, "ROLLBACK", nullptr); return Fail(error, message);
        }
        sqlite3_finalize(statement);
    }
    return ProjectionExec(sqlite_db_, "COMMIT", error);
#endif
}

void RecordingCatalog::CloseSqliteLocked() {
#if MEDIA_SERVER_USE_SQLITE3
    if (sqlite_db_ != nullptr) sqlite3_close(sqlite_db_);
    if (generation_sqlite_db_ != nullptr) sqlite3_close(generation_sqlite_db_);
#endif
    sqlite_db_ = nullptr;
    generation_sqlite_db_=nullptr;
}

}  // namespace recording
