from pathlib import Path
p=Path('src/recording/recording_history_index.h');s=p.read_text().replace('#include <limits>','#include <limits>\n#include <memory>')
a=s.index('    Lookup Get(')
s=s[:a]+'''    // Only a private empty build may defer node overwrites. No original/history reader uses it.
    bool BeginBufferedBuild(std::string* error) {
        try {Check();if(rows_||root_.offset||build_||visiting_)throw Failure("history buffered build requires empty private index");
            build_=std::make_unique<BuildBuffer>();return true;
        }catch(const std::exception& e){return Fail(error,e.what());}
    }
    bool SealBufferedBuild(std::string* error) {
        try {Check();if(!build_)throw Failure("history buffered build missing");
            for(auto& entry:build_->entries)Flush(entry);
            build_.reset();return Healthy(error);
        }catch(const std::exception& e){return Fail(error,e.what());}
    }
''' +s[a:]
s=s.replace('Check();if(visiting_)throw Failure("history mutation during visit");','Check();if(visiting_||(build_&&overwrite))throw Failure("history mutation during visit/buffered overwrite");')
s=s.replace('Check();if(!visitor)throw Failure("history index visitor missing");','Check();if(build_||!visitor)throw Failure("history index visitor missing/unsealed build");')
s=s.replace('Check();Key(begin);Key(end);if(begin>=end', 'Check();Key(begin);Key(end);if(build_||begin>=end')
s=s.replace('writes_,0,valid?', 'writes_,build_?sizeof(BuildBuffer):0,valid?')
s=s.replace('    bool Close(std::string* error) {\n        bool ok=true;', '    bool Close(std::string* error) {\n        build_.reset(); // unpublished private build is discarded on failure, never flushed into authority\n        bool ok=true;')
s=s.replace('struct Ref {std::uint64_t offset{0};Hash hash{};};','''struct Ref {std::uint64_t offset{0};Hash hash{};};
    struct BuildEntry {std::uint64_t offset{0},use{0};Hash original{};std::array<unsigned char,kNodeBytes> bytes{};bool dirty{false};};
    struct BuildBuffer {std::array<BuildEntry,256> entries{};std::uint64_t clock{0};};
    static_assert(sizeof(BuildBuffer)<=160*1024,"bounded checkpoint node writer");
    std::unique_ptr<BuildBuffer> build_;
    void Flush(BuildEntry& entry) {
        if(!entry.offset)return;
        std::array<unsigned char,kNodeBytes> actual{};ReadBytes(entry.offset,actual.data(),actual.size());
        if(Digest(actual.data(),actual.size())!=entry.original)throw Failure("history buffered original node changed");
        if(entry.dirty)WriteBytes(entry.offset,entry.bytes.data(),entry.bytes.size());
        entry={};
    }
    BuildEntry& Buffered(const Ref& ref) {
        const auto first=((ref.offset/kNodeBytes)%64)*4;auto* selected=&build_->entries[first];
        for(std::size_t i=first;i<first+4;++i){auto& entry=build_->entries[i];
            if(entry.offset==ref.offset){entry.use=++build_->clock;return entry;}
            if(!entry.offset||entry.use<selected->use)selected=&entry;
        }
        Flush(*selected);ReadBytes(ref.offset,selected->bytes.data(),selected->bytes.size());
        selected->original=Digest(selected->bytes.data(),selected->bytes.size());
        if(selected->original!=ref.hash)throw Failure("history buffered node hash mismatch");
        selected->offset=ref.offset;selected->use=++build_->clock;return *selected;
    }''')
s=s.replace('std::array<unsigned char,kNodeBytes> bytes{};ReadBytes(ref.offset,bytes.data(),bytes.size());++reads_;','std::array<unsigned char,kNodeBytes> bytes{};if(build_)bytes=Buffered(ref).bytes;else ReadBytes(ref.offset,bytes.data(),bytes.size());++reads_;')
s=s.replace('Ref Save(const Node& n,std::uint64_t offset) {','Ref Save(const Node& n,Ref prior) {\n        auto offset=prior.offset;')
s=s.replace('if(offset)WriteBytes(offset,bytes.data(),bytes.size());else offset=Append(bytes.data(),bytes.size());','''if(offset){
            if(build_){auto& entry=Buffered(prior);if(Digest(entry.bytes.data(),entry.bytes.size())!=prior.hash)throw Failure("history buffered write predecessor mismatch");entry.bytes=bytes;entry.dirty=true;}
            else WriteBytes(offset,bytes.data(),bytes.size());
        }else offset=Append(bytes.data(),bytes.size());''')
s=s.replace('Ref Left(Node x,std::uint64_t offset)', 'Ref Left(Node x,Ref prior)').replace('const auto next=x.right.offset','const auto next=x.right').replace('Save(x,offset)','Save(x,prior)')
s=s.replace('Ref Right(Node y,std::uint64_t offset)', 'Ref Right(Node y,Ref prior)').replace('const auto next=y.left.offset','const auto next=y.left').replace('Save(y,offset)','Save(y,prior)')
s=s.replace('Left(child,n.left.offset)','Left(child,n.left)').replace('Right(n,ref.offset)','Right(n,ref)').replace('Right(child,n.right.offset)','Right(child,n.right)').replace('Left(n,ref.offset)','Left(n,ref)').replace('Save(n,ref.offset)','Save(n,ref)')
s=s.replace('Height(&n);const auto balance=static_cast<int>(Height(n.left))-static_cast<int>(Height(n.right));','const auto left_height=Height(n.left),right_height=Height(n.right);n.height=1+std::max(left_height,right_height);\n        const auto balance=static_cast<int>(left_height)-static_cast<int>(right_height);')
p.write_text(s)
p=Path('src/recording/recording_catalog_snapshot_export.cpp');s=p.read_text().replace('RecordingHistoryIndex::BytesForRows(0),error))return false;','RecordingHistoryIndex::BytesForRows(0),error)||!sorted->BeginBufferedBuild(error))return false;')
s=s.replace('if(!ExportGenerationValuesLocked(chain.store_id,chain,generation,cut,&header,error,spool)||sorted->usage().rows!=chunks)','if(!ExportGenerationValuesLocked(chain.store_id,chain,generation,cut,&header,error,spool)||sorted->usage().rows!=chunks||\n           !sorted->SealBufferedBuild(error))')
p.write_text(s)
