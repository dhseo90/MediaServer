from pathlib import Path
p=Path('src/recording/recording_identity_shard.cpp');s=p.read_text()
s=s.replace('if(!history.index.Put("i/"+first.mutation_id,FirstBytes(first),overwrite,error))return false;\n    if(!overwrite){if(!history.index.Put(OrdinalKey(first.first_global_ordinal),first.mutation_id,false,error))return false;++history.count;}', 'const auto bytes=FirstBytes(first);\n    if(!history.index.Put("i/"+first.mutation_id,bytes,overwrite,error)||\n       !history.index.Put(OrdinalKey(first.first_global_ordinal),bytes,overwrite,error))return false;\n    if(!overwrite)++history.count;')
s=s.replace('std::string value,id;\n    if(history.index.Get', 'std::string value,ordinal_value;\n    if(history.index.Get',1)
s=s.replace('history.index.Get(OrdinalKey(first.first_global_ordinal),&id,error)!=RecordingHistoryIndex::Lookup::Found||id!=first.mutation_id)', 'history.index.Get(OrdinalKey(first.first_global_ordinal),&ordinal_value,error)!=RecordingHistoryIndex::Lookup::Found||ordinal_value!=value)')
s=s.replace('''        std::optional<RecordingIdentityFirstAcceptance> first;
        if(!FindRecordingIdentityHistory(history,value,&first,err)||!first||OrdinalKey(first->first_global_ordinal)!=key)
            return Fail(err,"history ordinal identity mismatch");
        ++count;return visitor(*first,err);''','''        RecordingIdentityFirstAcceptance first;
        if(!FirstValue(value,&first,err)||OrdinalKey(first.first_global_ordinal)!=key)
            return Fail(err,"history ordinal identity mismatch");
        ++count;return visitor(first,err);''')
p.write_text(s)
p=Path('src/recording/recording_catalog_snapshot_export.cpp');s=p.read_text();pos=s.index('bool SameOrder(')
helper='''// Two complete ordinal-ordered cursors commit to the exact fields previously compared
// per ID. Private to one locked export; never persisted or reused across a cut/owner.
class AppliedPrefixDigest {
public:
#if MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
    AppliedPrefixDigest():context_(EVP_MD_CTX_new(),EVP_MD_CTX_free) {
        if(!context_||EVP_DigestInit_ex(context_.get(),EVP_sha256(),nullptr)!=1)throw std::runtime_error("prefix digest init");
    }
    void Add(const RecordingIdentityFirstAcceptance& first) {
        const auto& r=first.first_row;
        for(const auto& value:{first.mutation_id,std::to_string(first.first_global_ordinal),RecordingMutationTypeName(r.type),
            r.entity_id,std::to_string(r.occurred_at_ms),r.identity,
            r.reservation?SerializeRecordingOrderReservationV1(*r.reservation):std::string{}}){
            std::array<unsigned char,8> size{};auto n=static_cast<std::uint64_t>(value.size());
            for(unsigned i=0;i<8;++i){size[i]=n&255;n>>=8;}
            if(EVP_DigestUpdate(context_.get(),size.data(),size.size())!=1||
               EVP_DigestUpdate(context_.get(),value.data(),value.size())!=1)throw std::runtime_error("prefix digest update");
        }
    }
    std::array<unsigned char,32> Finish(){std::array<unsigned char,32> result{};unsigned size=0;
        if(EVP_DigestFinal_ex(context_.get(),result.data(),&size)!=1||size!=result.size())throw std::runtime_error("prefix digest finish");return result;}
private:
    std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)> context_;
#else
    void Add(const RecordingIdentityFirstAcceptance&){throw std::runtime_error("prefix digest unsupported");}
    std::array<unsigned char,32> Finish(){throw std::runtime_error("prefix digest unsupported");}
#endif
};
'''
s=s[:pos]+helper+s[pos:]
s=s.replace('const bool applied_cursor=completed_history_&&chain.history;','const bool applied_cursor=completed_history_&&chain.history;\n        AppliedPrefixDigest candidate_digest,current_digest;')
s=s.replace('physical+=entry.occurrences;++first_count;','physical+=entry.occurrences;++first_count;if(applied_cursor)candidate_digest.Add(entry);')
a=s.index('                const auto candidate=first(current.mutation_id);');b=s.index('\n            },error))return false;',a)
s=s[:a]+'''                current_digest.Add(current);++visible_count;
                return !RecordingSnapshotRequiresAcceptedState(current.first_row.type)||accepted(current,detail);'''+s[b:]
s=s.replace('if(visible_count!=first_count)return Fail(error,"snapshot candidate/applied coverage mismatch");','if(visible_count!=first_count||current_digest.Finish()!=candidate_digest.Finish())return Fail(error,"snapshot candidate/applied coverage mismatch");')
p.write_text(s)
