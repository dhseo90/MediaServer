import json,subprocess
from pathlib import Path
r=Path(__file__).parent
for cmd in json.loads((r/"after-measure/commands.json").read_text()):subprocess.run(cmd,check=True)
