import json,subprocess
from pathlib import Path
r=Path(__file__).parent
for c in json.loads((r/"cost/commands.json").read_text()):subprocess.run(c,check=True)
