import json,subprocess
from pathlib import Path
r=Path(__file__).parent
for cmd in json.loads((r/"seed-build/commands81.json").read_text()):
 subprocess.run(cmd,check=True)
