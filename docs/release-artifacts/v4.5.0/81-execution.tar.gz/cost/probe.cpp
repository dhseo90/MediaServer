#include "recording_catalog_cost_probe_timer.h"
#include "recording/recording_runtime_composition.h"
#include <iostream>
int main(int argc,char** argv){if(argc!=2)return 2;std::string error;recording::RecordingRuntimeStorage runtime(argv[1]);if(!runtime.Open(&error)){std::cerr<<error;return 1;}fc::enabled=true;const bool ok=runtime.catalog().Checkpoint(&error);fc::Dump("checkpoint");fc::enabled=false;std::string cleanup;const bool closed=runtime.Finish(&cleanup);std::cout<<"result="<<ok<<" error="<<error<<" closed="<<closed<<" cleanup="<<cleanup<<std::endl;return ok&&closed?0:1;}
