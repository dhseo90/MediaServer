from pathlib import Path
p=Path('scripts/internal/recording_search_runtime_load_smoke.cpp');s=p.read_text();s=s.replace('#include <fstream>','#include <fstream>\n#include <condition_variable>\n#include <sstream>')
a='namespace {\n';i=s.index(a)+len(a)
s=s[:i]+'''// 각 thread는 자신의 원자 상태만 갱신한다. observer는 제품 객체/결과 vector를 읽지 않는다.
enum class LoadPhase : unsigned { Idle, Open, Encode, WriterStart, Observations, Warmup, Clients,
    Search, Packets, Checkpoint, WriterStop, Join, FinalValidation, Finish, Done, Failed };
const char* PhaseName(LoadPhase p) {
    static constexpr const char* names[]={"idle","open","encode","writer-start","observations","warmup",
        "clients-start","search","packets","checkpoint-request","writer-stop","thread-join","final-validation","finish","done","failed"};
    return names[static_cast<unsigned>(p)];
}
struct LoadProgress {
    using Clock=std::chrono::steady_clock;
    struct State {std::atomic<unsigned> phase{0};std::atomic<std::uint64_t> begin{0},last{0},completed{0};};
    std::array<State,14> states{};const Clock::time_point epoch=Clock::now();
    std::mutex output_mutex,wait_mutex;std::condition_variable wake;bool stopping=false;
    std::atomic<bool> output_failed{false};std::thread monitor;
    std::uint64_t Now() const {return std::chrono::duration_cast<std::chrono::microseconds>(Clock::now()-epoch).count();}
    void Line(const std::string& line) {
        std::lock_guard lock(output_mutex);
        if(std::fprintf(stdout,"%s\\n",line.c_str())<0||std::fflush(stdout)!=0)output_failed=true;
    }
    void Begin(unsigned id,LoadPhase phase) {
        auto& state=states.at(id);const auto now=Now();state.begin=now;state.last=now;state.phase=static_cast<unsigned>(phase);
        Line("[load-stage] thread="+std::to_string(id)+" phase="+PhaseName(phase)+" event=begin us="+std::to_string(now));
    }
    void Progress(unsigned id,std::uint64_t count){states.at(id).completed=count;states.at(id).last=Now();}
    void End(unsigned id) {
        auto& state=states.at(id);const auto now=Now();
        Line("[load-stage] thread="+std::to_string(id)+" phase="+PhaseName(static_cast<LoadPhase>(state.phase.load()))+
             " event=end us="+std::to_string(now)+" elapsedUs="+std::to_string(now-state.begin.load())+" completed="+std::to_string(state.completed.load()));
        state.last=now;state.phase=static_cast<unsigned>(LoadPhase::Idle);
    }
    void Failure(unsigned id,const std::string& detail) {
        Line("[load-error] thread="+std::to_string(id)+" phase="+PhaseName(static_cast<LoadPhase>(states.at(id).phase.load()))+
            " us="+std::to_string(Now())+" detail="+detail.substr(0,1024));states.at(id).phase=static_cast<unsigned>(LoadPhase::Failed);
    }
    LoadProgress():monitor([this]{
        std::unique_lock lock(wait_mutex);
        while(!wake.wait_for(lock,std::chrono::seconds(1),[this]{return stopping;})){
            const auto now=Now();std::ostringstream line;line<<"[load-progress] us="<<now;
            for(unsigned id=0;id<states.size();++id){const auto& s=states[id];const auto phase=static_cast<LoadPhase>(s.phase.load());
                if(phase!=LoadPhase::Idle)line<<" t"<<id<<"="<<PhaseName(phase)<<":"<<s.completed.load()<<":"<<s.begin.load()<<":"<<s.last.load();}
            Line(line.str());
        }
    }){}
    ~LoadProgress(){ {std::lock_guard lock(wait_mutex);stopping=true;}wake.notify_one();if(monitor.joinable())monitor.join();}
};
''' + s[i:]
s=s.replace('const bool checkpoint_overlap=','std::cout.setf(std::ios::unitbuf);LoadProgress progress;\n    const bool checkpoint_overlap=')
s=s.replace('if(!runtime.Open(&error))throw std::runtime_error(error);','progress.Begin(0,LoadPhase::Open);\n        if(!runtime.Open(&error))throw std::runtime_error(error);progress.End(0);\n        progress.Begin(0,LoadPhase::Encode);')
s=s.replace('Shift(input,7000000000ULL);','Shift(input,7000000000ULL);progress.End(0);progress.Begin(0,LoadPhase::WriterStart);')
s=s.replace('        for(int i=0;i<10000;', '        progress.End(0);progress.Begin(0,LoadPhase::Observations);\n        for(int i=0;i<10000;')
s=s.replace('if(!runtime.catalog().PutObservationV2(o,&error))throw std::runtime_error(error);}', 'if(!runtime.catalog().PutObservationV2(o,&error))throw std::runtime_error(error);\n            if(i%250==249)progress.Progress(0,i+1);}\n        progress.End(0);progress.Begin(0,LoadPhase::Warmup);')
s=s.replace('throw std::runtime_error("load-warmup");','throw std::runtime_error("load-warmup");progress.End(0);')
s=s.replace('        // 4명의 client', '        progress.Begin(0,LoadPhase::Clients);\n        // 4명의 client')
s=s.replace('try{do{const auto start=', 'try{progress.Begin(1+client,LoadPhase::Search);do{progress.states[1+client].begin=progress.Now();const auto start=')
s=s.replace('if(packets>before)++progressed[client];', 'progress.Progress(1+client,elapsed[client].size());\n                if(packets>before)++progressed[client];')
s=s.replace('}while(!stop&&finished<8);}catch(...){errors[client]=std::current_exception();stop=true;}', '}while(!stop&&finished<8);progress.End(1+client);}catch(const std::exception& e){progress.Failure(1+client,e.what());errors[client]=std::current_exception();stop=true;}catch(...){progress.Failure(1+client,"unknown");errors[client]=std::current_exception();stop=true;}')
s=s.replace('        for(std::size_t channel=0;', '        progress.End(0);\n        for(std::size_t channel=0;')
s=s.replace('try{for(const auto& packet:input.packets)', 'try{progress.Begin(5+channel,LoadPhase::Packets);unsigned supplied=0;for(const auto& packet:input.packets)')
s=s.replace('writers[channel]->Push(packet,0);++packets;', 'writers[channel]->Push(packet,0);++packets;progress.Progress(5+channel,++supplied);')
s=s.replace('writers[channel]->Stop();}catch(...){errors[4+channel]=std::current_exception();stop=true;}++finished;', 'progress.End(5+channel);progress.Begin(5+channel,LoadPhase::WriterStop);writers[channel]->Stop();progress.End(5+channel);}\n            catch(const std::exception& e){progress.Failure(5+channel,e.what());errors[4+channel]=std::current_exception();stop=true;}catch(...){progress.Failure(5+channel,"unknown");errors[4+channel]=std::current_exception();stop=true;}++finished;')
s=s.replace('const auto prior=OwnedManifest', 'progress.Begin(13,LoadPhase::Checkpoint);\n                const auto prior=OwnedManifest')
s=s.replace('if(!checkpoint_published)throw std::runtime_error("checkpoint-overlap-no-publication");','if(!checkpoint_published)throw std::runtime_error("checkpoint-overlap-no-publication");progress.Progress(13,checkpoint_end);progress.End(13);')
s=s.replace('}catch(...){errors[12]=std::current_exception();stop=true;}','}catch(const std::exception& e){progress.Failure(13,e.what());errors[12]=std::current_exception();stop=true;}catch(...){progress.Failure(13,"unknown");errors[12]=std::current_exception();stop=true;}')
s=s.replace('        for(auto& thread:threads)thread.join();','        progress.Begin(0,LoadPhase::Join);for(auto& thread:threads)thread.join();progress.End(0);\n        progress.Begin(0,LoadPhase::FinalValidation);')
s=s.replace('        if(!runtime.Finish(&error))', '        progress.End(0);progress.Begin(0,LoadPhase::Finish);\n        if(!runtime.Finish(&error))')
s=s.replace('throw std::runtime_error("load-finish:"+error);','throw std::runtime_error("load-finish:"+error);progress.End(0);\n        if(progress.output_failed)throw std::runtime_error("load-progress-output-failed");')
s=s.replace('}catch(const std::exception& e){std::cerr<<"[runtime-load] fail="', '}catch(const std::exception& e){progress.Failure(0,e.what());std::cerr<<"[runtime-load] fail="')
p.write_text(s)
