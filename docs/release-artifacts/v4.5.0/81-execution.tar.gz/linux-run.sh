#!/bin/bash
set -euo pipefail
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
mkdir /tmp/media-server-memory81
cd /tmp/media-server-memory81
mkdir repo output work
cp -R /source/src /source/include /source/scripts /source/test /source/config repo/
cp /source/CMakeLists.txt /source/VERSION repo/
export TMPDIR=/tmp/media-server-memory81/work
cd repo
id
uname -srm
g++ --version | head -1
pkg-config --modversion gstreamer-1.0 openssl sqlite3
bash scripts/internal/verify_recording_generation_checkpoint.sh all > ../output/checkpoint.log 2>&1
bash scripts/internal/verify_recording_generation_checkpoint.sh history-product > ../output/history-product.log 2>&1
bash scripts/internal/verify_recording_generation_active.sh > ../output/active.log 2>&1
bash scripts/internal/verify_recording_generation_consumers.sh > ../output/consumers.log 2>&1
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > ../output/build.log 2>&1
cmake --build ../build -j2 >> ../output/build.log 2>&1
sha256sum ../build/media_server ../build/libmedia_server_runtime.a
cp ../build/CMakeCache.txt ../output/CMakeCache.txt
find ../work -mindepth 1 -maxdepth 1 -print
