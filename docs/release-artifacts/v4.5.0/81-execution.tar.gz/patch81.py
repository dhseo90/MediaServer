from pathlib import Path
p=Path('src/recording/recording_identity_shard.cpp');s=p.read_text();a=s.index('std::string FirstBytes(');b=s.index('std::string OrdinalKey(',a)
s=s[:a]+'''// Process-local authenticated scratch only. Original JSON parsing/validation is unchanged.
// Fixed field framing avoids reparsing the same nested JSON on every cold checkpoint lookup.
std::string FirstBytes(const RecordingIdentityFirstAcceptance& first) {
    const auto& row=first.first_row;const auto& archive=first.first_archive;
    std::string out="F1";
    for(const auto& field:{std::to_string(first.occurrences),row.mutation_id,RecordingMutationTypeName(row.type),
        row.entity_id,std::to_string(row.occurred_at_ms),std::to_string(row.global_ordinal),row.identity,
        std::to_string(row.archive_slot),std::to_string(row.offset),std::to_string(row.length),row.raw_sha256,
        row.reservation?OrderJson(*row.reservation):std::string{},archive.name,std::to_string(archive.size),archive.sha256}) {
        if(field.size()>RecordingHistoryIndex::kValueBytes)throw std::runtime_error("history field admission");
        out.push_back(static_cast<char>(field.size()&255));out.push_back(static_cast<char>(field.size()>>8));out+=field;
    }
    return out;
}
bool FirstValue(const std::string& bytes,RecordingIdentityFirstAcceptance* output,std::string* error) {
    if(bytes.size()>RecordingHistoryIndex::kValueBytes||bytes.compare(0,2,"F1"))return Fail(error,"history scratch framing");
    std::array<std::string,15> fields;std::size_t at=2;
    for(auto& field:fields){
        if(at>bytes.size()||bytes.size()-at<2)return Fail(error,"history scratch short field");
        const auto size=static_cast<unsigned char>(bytes[at])+(static_cast<unsigned char>(bytes[at+1])<<8);at+=2;
        if(static_cast<std::size_t>(size)>bytes.size()-at)return Fail(error,"history scratch field bounds");
        field=bytes.substr(at,static_cast<std::size_t>(size));at+=size;
    }
    RecordingIdentityFirstAcceptance first;auto& row=first.first_row;auto& archive=first.first_archive;
    if(at!=bytes.size()||!Integer(fields[0],&first.occurrences)||!first.occurrences||
       !Integer(fields[4],&row.occurred_at_ms)||!Integer(fields[5],&row.global_ordinal)||
       !Integer(fields[7],&row.archive_slot)||!Integer(fields[8],&row.offset)||!Integer(fields[9],&row.length)||
       !Integer(fields[13],&archive.size))return Fail(error,"history scratch numeric fields");
    row.mutation_id=std::move(fields[1]);row.type=ParseRecordingMutationType(fields[2]);row.entity_id=std::move(fields[3]);
    row.identity=std::move(fields[6]);row.raw_sha256=std::move(fields[10]);
    if(!fields[11].empty()){RecordingOrderReservationV1 order;if(!ParseRecordingOrderReservationV1(fields[11],&order,error))return false;row.reservation=std::move(order);}
    archive.name=std::move(fields[12]);archive.sha256=std::move(fields[14]);
    first.mutation_id=row.mutation_id;first.first_global_ordinal=row.global_ordinal;
    if(!Descriptor(archive)||FirstBytes(first)!=bytes)return Fail(error,"history scratch noncanonical");
    *output=std::move(first);return true;
}
''' +s[b:];p.write_text(s)
p=Path('src/recording/recording_history_index.h');s=p.read_text();pos=s.index('    bool Healthy(')
s=s[:pos]+'''    // Authenticated half-open range: visited boundary nodes prove pruned subtrees are outside.
    // Caller retains its independently maintained namespace coverage count.
    bool VisitRange(const std::string& begin,const std::string& end,const Visitor& visitor,std::string* error) {
        try {
            Check();Key(begin);Key(end);if(begin>=end||!visitor||visiting_)throw Failure("history range invalid");
            struct Guard {bool& flag;~Guard(){flag=false;}} guard{visiting_};visiting_=true;
            if(!WalkRange(root_,{}, {},0,begin,end,visitor,error))return false;
            Check();if(error)error->clear();return true;
        }catch(const std::exception& e){return Fail(error,e.what());}
    }
''' +s[pos:]
pos=s.index('    bool Walk(Ref')
s=s[:pos]+'''    bool WalkRange(Ref ref,const std::string& lower,const std::string& upper,std::size_t depth,
                   const std::string& begin,const std::string& end,const Visitor& visitor,std::string* error) {
        if(!ref.offset)return true;
        if(depth>=kDepth)throw Failure("history range depth");
        const auto node=Read(ref);Order(node.key,lower,upper);
        if(node.key>begin&&!WalkRange(node.left,lower,node.key,depth+1,begin,end,visitor,error))return false;
        if(node.key>=begin&&node.key<end){const auto value=Value(node);if(!visitor(node.key,value,error))return false;}
        return node.key>=end||WalkRange(node.right,node.key,upper,depth+1,begin,end,visitor,error);
    }
''' +s[pos:];p.write_text(s)
p=Path('src/recording/recording_catalog_history.h');s=p.read_text().replace('const bool ok=index_.Visit([&]', 'const bool ok=index_.VisitRange(prefix,kind+"0",[&]');p.write_text(s)
# Ordinal cursor need not read every identity value it will independently acquire by authenticated key.
p=Path('src/recording/recording_identity_shard.cpp');s=p.read_text().replace('const bool ok=history->index.Visit([&]', 'const bool ok=history->index.VisitRange("o/","o0",[&]');p.write_text(s)
