from pathlib import Path
import re,shutil,json,subprocess
r=Path(__file__).parent;out=r/'cost4';out.mkdir();old=r/'cost'
shutil.copytree('include',out/'include')
for name in ['recording_journal.h','recording_catalog.h']:
 p=out/'include/recording'/name;p.write_text(p.read_text().replace('private:','public:'))
shutil.copy2(old/'recording_catalog_cost_probe_timer.h',out/'recording_catalog_cost_probe_timer.h');shutil.copy2(old/'probe.cpp',out/'probe.cpp')
for p in old.glob('*.cpp'):
 if p.name=='probe.cpp':continue
 s=Path('src/recording',p.name).read_text();s='#include "recording_catalog_cost_probe_timer.h"\n'+s
 for label in re.findall('fc_phase_scope\("([^"]+)"\)',p.read_text()):
  pattern=r'\bbool\s+(?:\w+::)?'+label+r'\s*\([^;{]*?\)\s*(?:const\s*)?(?:try\s*)?\{'
  s=re.sub(pattern,lambda m:m[0]+' fc::Scope fc_phase_scope("'+label+'");',s)
 if p.name=='recording_catalog.cpp':s=s.replace('recording::latency::Lock lock(mu_,recording::latency::Source::Catalog,__LINE__);','std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");')
 if p.name=='recording_catalog_snapshot_export.cpp':
  s=s.replace('std::string bytes;if(!SerializeRecordingCatalogSnapshotRow','fc::Scope spool_scope("SpoolRow");std::string bytes;if(!SerializeRecordingCatalogSnapshotRow')
  s=s.replace('if(!sorted->Put(key,bytes.substr(offset,RecordingHistoryIndex::kValueBytes),false,detail))','fc::Scope put_scope("SpoolPut");if(!sorted->Put(key,bytes.substr(offset,RecordingHistoryIndex::kValueBytes),false,detail))')
 (out/p.name).write_text(s)
cmds=json.loads((old/'commands.json').read_text())
for cmd in cmds:
 cmd[:]=[c.replace(str(old),str(out)).replace('candidate1-runtime.a','candidate3-runtime.a') for c in cmd]
(out/'commands.json').write_text(json.dumps(cmds,indent=2))
shutil.copytree(r/'candidate3-load/product',r/'cost4-product')
for cmd in cmds:subprocess.run(cmd,check=True)
