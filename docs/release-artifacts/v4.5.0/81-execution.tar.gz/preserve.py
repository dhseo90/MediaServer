from pathlib import Path
import json,hashlib,tarfile
r=Path(__file__).parent;files=[]
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.txt','.patch','.py','.sh','.h'] and p.name not in ['manifest-before.json','preservation-selection.json','archive-receipt.json']:files.append(p)
for side in ['seed-build','after-measure','cost','cost2','cost3','cost4','linux-output','selected-input','reference80']:
 for p in (r/side).rglob('*'):
  if p.is_file() and not p.is_symlink() and 'gst-cache' not in str(p) and '/include/' not in str(p) and p.suffix in ['.json','.log','.txt','.patch','.py','.sh','.h','.cpp','.mp4']:files.append(p)
files=sorted(set(files));manifest={'files':[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],'rawBytes':sum(p.stat().st_size for p in files),'count':len(files)}
(r/'preservation-selection.json').write_text(json.dumps(manifest,indent=2)+'\n');files.append(r/'preservation-selection.json')
a=Path('docs/release-artifacts/v4.5.0/81-execution.tar.gz')
with tarfile.open(a,'w:gz') as t:
 for p in files:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(a) as t:
 for row in manifest['files']:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
receipt={'path':str(a),'bytes':a.stat().st_size,'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'members':len(files),'rawBytes':manifest['rawBytes'],'allMemberReadback':True,'representation':'raw selected new executions and synthetic input; no inferred log reconstruction or prior archive duplication'}
(r/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
p=Path('docs/release-artifacts/v4.5.0/81-validation.json');v=json.loads(p.read_text());v['archive']=receipt;p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
