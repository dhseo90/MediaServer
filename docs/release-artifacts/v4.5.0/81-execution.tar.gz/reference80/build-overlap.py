import json,shlex,subprocess,sys
from pathlib import Path
r=Path(__file__).parent;repo=Path.cwd();side=sys.argv[1];build=r/(side+'-build')
entry=next(c for c in json.loads((build/'compile_commands.json').read_text()) if c['file'].endswith('/src/recording/recording_journal.cpp'))
cmd=shlex.split(entry['command']);del cmd[cmd.index('-o'):cmd.index('-o')+2];cmd.remove('-c');cmd.pop()
cmd+=['-Wall','-Wextra','-Werror']
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
cmd +=[str(repo/'scripts/internal/recording_search_runtime_load_smoke.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(r/(side+'-overlap'))]
(r/(side+'-overlap-command.json')).write_text(json.dumps(cmd,indent=2)+'\n');subprocess.run(cmd,check=True)
