import json,sys,subprocess
from pathlib import Path
r=Path(__file__).parent
for cmd in json.loads((r/(sys.argv[1]+'-measure')/'commands.json').read_text()):
 print('[compile]',json.dumps(cmd),flush=True)
 subprocess.run(cmd,check=True,cwd=Path.cwd())
