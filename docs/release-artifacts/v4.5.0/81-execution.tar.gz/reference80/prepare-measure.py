from pathlib import Path
import re,shutil,json,hashlib
r=Path(__file__).parent; repo=Path.cwd()
side=__import__('sys').argv[1]; source=r/'before-source' if side=='before' else repo
out=r/(side+'-measure');out.mkdir(exist_ok=False)
shutil.copytree(source/'include',out/'include')
for name in ['recording_journal.h','recording_catalog.h']:
 p=out/'include/recording'/name;p.write_text(p.read_text().replace('private:','public:'))
helper=(repo/'scripts/internal/recording_catalog_cost_probe_timer.h').read_text()
# Fixed callsite names only; explicit instrumentation count cap, never row IDs.
helper=helper.replace('auto& m=metrics[key];','if(metrics.size()>256)std::abort();auto& m=metrics[key];')
(out/'recording_catalog_cost_probe_timer.h').write_text(helper)
targets={
'recording_journal.cpp':['OpenGenerationReadOnlyLocked','CheckManagedStateLocked','PrepareGenerationCheckpoint','PublishGenerationCheckpoint','VisitGenerationFirst','FindGenerationFirst'],
'recording_catalog.cpp':['OpenGenerationLocked','BuildGenerationScratchLocked','CheckpointGenerationLocked','AppendGenerationLocked','PrepareGenerationSqliteLocked'],
'recording_catalog_snapshot_export.cpp':['ExportGenerationValuesLocked','PrepareGenerationSnapshotStreamLocked'],
'recording_catalog_generation_projection.cpp':['BuildProjection','CrossMaps','CompactLegacyRetired'],
'recording_identity_shard.cpp':['VisitRecordingIdentityHistory','FindRecordingIdentityHistory','CloneRecordingIdentityHistory','ValidateRecordingIdentityChainStream'],
'recording_generation_transaction.cpp':['WriteComponentStream']}
commands=json.loads((r/'before-build/compile_commands.json').read_text()); compile_cmds=[];binding=[]
for name,names in targets.items():
 p=source/'src/recording'/name
 if not p.exists(): continue
 s=p.read_text();original=hashlib.sha256(s.encode()).hexdigest();s='#include "recording_catalog_cost_probe_timer.h"\n#include <iostream>\n'+s
 marks=[]
 for label in names:
  # Function definitions only (qualified or free bool); no call matching.
  pattern=r'\bbool\s+(?:\w+::)?'+label+r'\s*\([^;{]*?\)\s*(?:const\s*)?(?:try\s*)?\{'
  s,count=re.subn(pattern,lambda m:m[0]+' fc::Scope fc_phase_scope("'+label+'");',s)
  marks.append([label,count])
 # Observe Journal mutex waits/holds without changing lock lifetime.
 if name=='recording_journal.cpp':
  s=s.replace('std::lock_guard lock(mu_);','std::unique_lock lock(mu_,std::defer_lock);fc::Measure("JournalLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("JournalLockHold");')
  s+=(r/'observer-tail.cpp').read_text()
 if name=='recording_catalog.cpp':
  s=s.replace('recording::latency::Lock lock(mu_,recording::latency::Source::Catalog,__LINE__);','std::unique_lock lock(mu_,std::defer_lock);fc::Measure("CatalogLockWait",[&]{lock.lock();});fc::Scope fc_lock_hold("CatalogLockHold");')
 (out/name).write_text(s);binding.append({'file':str(p),'original':original,'instrumented':hashlib.sha256(s.encode()).hexdigest(),'scopes':marks})
 entry=next(c for c in commands if c['file'].endswith('/src/recording/'+name)); import shlex
 cmd=shlex.split(entry['command']); obj=out/(name+'.o'); cmd[cmd.index('-o')+1]=str(obj);cmd[-1]=str(out/name)
 # Use selected source headers; private exposure changes access only, identical layout.
 cmd=[x.replace(str(r/'before-source'),str(source)) for x in cmd]
 cmd.insert(1,'-I'+str(out/'include'));cmd.insert(1,'-I'+str(source/'src/recording'));cmd.insert(1,'-I'+str(out))
 compile_cmds.append(cmd)
(out/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
probe=(r/'reference79/before/probe.cpp').read_text()
probe='#include "recording_catalog_cost_probe_timer.h"\n'+probe
probe=probe.replace('gst_init(nullptr,nullptr);','gst_init(nullptr,nullptr);fc::enabled=true;')
probe=probe.replace('std::cout<<"}\\n";','std::cout<<"}\\n";fc::Dump(std::string(stage)+"-"+std::to_string(n));')
(out/'probe.cpp').write_text(probe);shutil.copyfile(r/'reference79/before/scale-reference.cpp',out/'scale-reference.cpp')
# Match original compile macros and linked libraries exactly.
entry=next(c for c in commands if c['file'].endswith('/src/recording/recording_journal.cpp'));cmd=shlex.split(entry['command']);del cmd[cmd.index('-o'):cmd.index('-o')+2];cmd.remove('-c');cmd.pop()
cmd=[x.replace(str(r/'before-source'),str(source)) for x in cmd]
cmd[1:1]=['-I'+str(out/'include'),'-I'+str(out),'-I'+str(source/'scripts/internal')]
link=shlex.split((r/'before-build/CMakeFiles/media_server.dir/link.txt').read_text()); libs=link[link.index('libmedia_server_runtime.a')+1:]
build=r/'before-build' if side=='before' else r/'after-build'
cmd += [str(out/'probe.cpp')]+[str(out/(name+'.o')) for name in targets if (out/name).exists()]+[str(build/'libmedia_server_runtime.a')]+libs+['-o',str(out/'probe')]
compile_cmds.append(cmd);(out/'commands.json').write_text(json.dumps(compile_cmds,indent=2)+'\n')
(out/'run.sh').write_text((r/'reference79/before/run.sh').read_text().replace('/private/tmp/media-server-memory79-qostwy57/before',str(out)).replace('probe-after','probe').replace('run79','run80'))
print(out)
