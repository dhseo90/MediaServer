import os,sys,subprocess,time,signal,json,hashlib,pathlib
root=pathlib.Path(__file__).parent
name=sys.argv[1]; deadline=float(sys.argv[2]); command=sys.argv[3:]
if not name.replace('-','').isalnum() or not command: raise SystemExit('invalid run arguments')
log=root/(name+'.log'); receipt=root/(name+'.json'); reason=None; start=time.monotonic()
with log.open('xb') as out:
 p=subprocess.Popen(command,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  if time.monotonic()-start>deadline: reason='wrapper deadline'
  if log.stat().st_size>4194304: reason='log cap'
  if reason: os.killpg(p.pid,signal.SIGTERM); break
  time.sleep(.2)
 try: code=p.wait(timeout=5)
 except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL); code=p.wait()
if log.stat().st_size>4194304: reason='log cap'
record={'command':command,'cwd':os.getcwd(),'uid':os.getuid(),'elapsedSeconds':time.monotonic()-start,'exit':code,'signal':-code if code<0 else None,'collectionFailure':reason,'bytes':log.stat().st_size,'sha256':hashlib.file_digest(log.open('rb'),'sha256').hexdigest()}
receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(code or bool(reason))
