#include "recording_catalog_cost_probe_timer.h"
#include "scale-reference.cpp"
int main(int argc,char** argv){if(argc!=2)return 2;std::cout.setf(std::ios::unitbuf);gst_init(nullptr,nullptr);fc::enabled=true;std::string error;recording::RecordingRuntimeStorage r(argv[1]);if(!r.Open(&error)){std::cerr<<error;return 1;}fc::Dump("opened");const bool ok=r.catalog().Checkpoint(&error);fc::Dump("captured");std::cout<<"[diagnostic] checkpoint="<<ok<<" error="<<error<<std::endl;return r.Finish(&error)&&ok?0:1;}
