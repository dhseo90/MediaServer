import pathlib,json,subprocess,sys
r=pathlib.Path(__file__).parent
for cmd in json.loads((r/(sys.argv[1]+'-measure/commands.json')).read_text()):
 subprocess.run(cmd,check=True)
