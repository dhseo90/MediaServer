#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory82
cp /source/scripts/internal/evidence_package_smoke.cpp "$r/repo/scripts/internal/"
python3 /linux-native.py
