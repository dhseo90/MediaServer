from pathlib import Path
import json,hashlib,tarfile,subprocess
r=Path(__file__).parent
out=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0/82-execution.tar.gz')
allowed={'.json','.log','.py','.sh','.patch','.cpp','.h','.txt','.cjs','.sha256'}
selected={p for p in r.iterdir() if p.is_file() and p.suffix in allowed and p.name not in {'archive-members.json'}}
# Current task's exact instrumented sources; no prior archive, SDK, binary, media, or store duplication.
for name in ['before-measure','after-measure-initial','after-measure','after2-measure','after3-measure','after4-measure','capture-diagnostic']:
 d=r/name
 if d.exists():
  selected.update(p for p in d.rglob('*') if p.is_file() and not p.is_symlink() and p.suffix in {'.cpp','.h','.json','.sh'})
for name in ['linux-first','linux-second','linux-third','linux-fourth','linux-final-output']:
 d=r/name
 if d.exists():selected.update(p for p in d.iterdir() if p.is_file() and p.suffix in allowed)
# Reuse Git/frozen-patch header bytes instead of copying each build include tree.
reused=[]
for p in list(selected):
 rel=p.relative_to(r).parts
 if len(rel)>2 and rel[1]=='include':
  repoPath='/'.join(rel[1:]); data=p.read_bytes(); source=None
  current=Path('/Users/dhseo/Workspace/mediaServer')/repoPath
  if current.exists() and current.read_bytes()==data:source='final-measure-freeze.json + final-measure-source.patch at base b88461e7cee8cfa771ef7ec1e5e30d57212da6a8'
  else:
   b=subprocess.run(['git','show','b88461e7cee8cfa771ef7ec1e5e30d57212da6a8:'+repoPath],capture_output=True)
   if b.returncode==0 and b.stdout==data:source='b88461e7cee8cfa771ef7ec1e5e30d57212da6a8'
  if source:
   selected.remove(p);reused.append({'originalBuildPath':str(p.relative_to(r)),'repoPath':repoPath,'source':source,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(r/'reused-source-bytes.json').write_text(json.dumps(reused,indent=2)+'\n')
selected.add(r/'reused-source-bytes.json')
rows=[]
for p in sorted(selected):
 assert not p.is_symlink() and p.stat().st_size<100*1024*1024
 rows.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()})
index={'scope':'82 task-owned command/log/receipt/source evidence only; originals unredacted synthetic paths; source copies instrumented as bound in respective JSON; no reconstructed missing output','members':rows}
(r/'archive-members.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(out,'w:gz') as t:
 for p in sorted(selected|{r/'archive-members.json'}):t.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(out) as t:
 for row in rows:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'members':len(rows)+1,'uncompressedBytes':sum(x['bytes'] for x in rows)}))
