from pathlib import Path
p=Path('src/recording/recording_history_index.h');s=p.read_text();at=s.index('    bool BeginBufferedBuild(');s=s[:at]+'''    // Fixed checkpoint capture only: ordered append, authenticated complete traversal, no lookup.
    // Reuses the anonymous FD, fixed slots, admission and explicit Close. Never a history authority.
    bool BeginSequentialBuild(std::string* error) {
        try {Check();if(rows_||root_.offset||build_||visiting_||sequential_)throw Failure("sequential capture requires empty private index");
            sequential_=true;return true;}catch(const std::exception& e){return Fail(error,e.what());}
    }
    bool SealSequentialBuild(std::string* error) {
        try {Check();if(!sequential_||sequential_sealed_||size_!=BytesForRows(rows_))throw Failure("sequential capture seal mismatch");
            sequential_sealed_=true;return Healthy(error);}catch(const std::exception& e){return Fail(error,e.what());}
    }
''' +s[at:];s=s.replace('if(build_||source.build_||this==&source','if(sequential_||source.sequential_||build_||source.build_||this==&source').replace('if(rows_||root_.offset||build_||visiting_)throw Failure("history buffered','if(sequential_||rows_||root_.offset||build_||visiting_)throw Failure("history buffered');s=s.replace('if(build_)throw Failure("history lookup before build seal")','if(sequential_||build_)throw Failure("history lookup before build seal/sequential capture")');s=s.replace('bool inserted=false;\n            root_=Insert','''if(sequential_) {
                if(overwrite||sequential_sealed_||(!sequence_key_.empty()&&key<=sequence_key_))throw Failure("sequential capture mutation/order invalid");
                Node node;node.key=key;node.left=root_;node.value_size=value.size();node.value_hash=Digest(value.data(),value.size());
                std::array<unsigned char,kValueBytes> slot{};std::copy(value.begin(),value.end(),slot.begin());
                node.value_offset=Append(slot.data(),slot.size());root_=Save(node,{});++rows_;sequence_key_=key;return true;
            }
            bool inserted=false;
            root_=Insert''');s=s.replace('Check();if(build_||!visitor)throw Failure("history index visitor missing/unsealed build")','Check();if(build_||(sequential_&&!sequential_sealed_)||!visitor)throw Failure("history index visitor missing/unsealed build")');s=s.replace('std::uint64_t seen=0;\n            if(!Walk(','''if(sequential_)return WalkSequence(visitor,error);
            std::uint64_t seen=0;
            if(!Walk(''');s=s.replace('if(build_||begin>=end','if(sequential_||build_||begin>=end');s=s.replace('if(build_)throw Failure("history health before build seal")','if(build_||(sequential_&&!sequential_sealed_))throw Failure("history health before build seal")');s=s.replace('std::unique_ptr<BuildBuffer> build_;','std::unique_ptr<BuildBuffer> build_;\n    bool sequential_=false,sequential_sealed_=false;std::string sequence_key_;');at=s.index('    bool WalkRange(');s=s[:at]+'''    bool WalkSequence(const Visitor& visitor,std::string* error) {
        if(size_!=BytesForRows(rows_))throw Failure("sequential capture size/count mismatch");
        Ref prior;std::string key;
        for(std::uint64_t i=0;i<rows_;++i) {
            const auto start=kNodeBytes+i*(kValueBytes+kNodeBytes);std::array<unsigned char,kNodeBytes> bytes{};
            ReadBytes(start+kValueBytes,bytes.data(),bytes.size());const Ref ref{start+kValueBytes,Digest(bytes.data(),bytes.size())};
            const auto node=Read(ref);
            if(node.left.offset!=prior.offset||node.left.hash!=prior.hash||node.right.offset||node.right.hash!=Hash{}||
               node.height!=1||node.value_offset!=start||(!key.empty()&&node.key<=key))throw Failure("sequential capture chain/order mismatch");
            const auto value=Value(node);if(!visitor(node.key,value,error))return false;prior=ref;key=node.key;
        }
        // Consumer is private and unpublished until this final process-root check succeeds.
        if(prior.offset!=root_.offset||prior.hash!=root_.hash||key!=sequence_key_)throw Failure("sequential capture root mismatch");
        Check();if(error)error->clear();return true;
    }
''' +s[at:];p.write_text(s)
p=Path('src/recording/recording_catalog_snapshot_export.cpp');s=p.read_text().replace('!rows->BeginBufferedBuild(error)','!rows->BeginSequentialBuild(error)').replace('!rows->SealBufferedBuild(error)','!rows->SealSequentialBuild(error)');p.write_text(s)
p=Path('scripts/internal/recording_generation_checkpoint_smoke.cpp');s=p.read_text();at=s.index('    {RecordingCatalogHistoryRows rows;Need(rows.Create',s.index('void HistoryProduct('));s=s[:at]+'''    for(const std::string mode:{"valid","unsealed","value","node","duplicate","partial","consumer"}) {
        Index seq;Need(seq.Create(root.string(),Index::BytesForRows(1024),&error));Need(seq.BeginSequentialBuild(&error));
        for(unsigned i=0;i<1024;++i){const auto n=std::to_string(i);Need(seq.Put(std::string(8-n.size(),'0')+n,"value/"+n,false,&error));}
        if(mode=="unsealed")Check("MEM82-C06",!seq.Visit([](const auto&,const auto&,std::string*){return true;},&error),"private unsealed sequential capture cannot be consumed");
        else if(mode=="duplicate")Check("MEM82-C06",!seq.Put("00001023","again",false,&error),"sequential capture duplicate/order rejected");
        else if(mode=="partial"){Index::probe_fault=3;Check("MEM82-C06",!seq.ReserveRows(1025,&error)||!seq.Put("00001024","partial",false,&error),"partial sequential append remains failed/unpublished");Index::probe_fault=0;}
        else {
            Need(seq.SealSequentialBuild(&error));
            if(mode=="value"||mode=="node"){const char x='x';Need(::pwrite(seq.ProbeFd(),&x,1,512+(mode=="node"?2048:0))==1);}
            unsigned count=0;const bool visited=seq.Visit([&](const auto& key,const auto& value,std::string*){
                const auto n=std::to_string(count++);return mode!="consumer"&&key==std::string(8-n.size(),'0')+n&&value=="value/"+n;},&error);
            Check("MEM82-C06",mode=="valid"?(visited&&count==1024&&seq.usage().file_bytes==Index::BytesForRows(1024)&&seq.usage().cache_bytes==0):!visited,
                "fixed-slot sequence full chain/value/root/consumer validation with bounded RAM");
        }
        Need(seq.Close(&error));Check("MEM82-C06",std::filesystem::is_empty(root),"sequential capture closes anonymous scratch on every result");
    }
''' +s[at:];p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');p.write_text(p.read_text()+'\n- `MEM82-C06`: 고정 view 전용 순차 scratch는 기존 고정 슬롯/소유권/Close를 사용하며 duplicate·미봉인·node/value 변조·부분 쓰기·consumer 거부를 미게시 실패로 처리한다. 완전한 순회와 마지막 process root 대조 전의 부분 출력은 후보 scratch만이며 정상 lookup authority가 아니다. `verify-recording-generation-checkpoint history-product`와 C01~C05 제품 경로로 확인한다.\n')
