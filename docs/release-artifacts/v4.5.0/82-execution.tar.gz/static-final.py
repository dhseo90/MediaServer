import subprocess,sys,pathlib
r=pathlib.Path(__file__).parent
checks=[('docs-links',60,'verify_docs_links.mjs'),('metadata',60,'verify_release_metadata_consistency.mjs'),('ui-assets',60,'verify_docs_ui_assets.mjs'),('public-assets',60,'verify_v290_public_docs_assets_refresh.mjs'),('scripts',60,'verify_script_inventory.mjs'),('evidence-index',60,'verify_release_evidence_index.mjs'),('inventory',120,'verify_project_feature_test_inventory.mjs'),('coverage',180,'verify_feature_inventory_coverage.mjs'),('implementation',120,'verify_feature_implementation_evidence.mjs')]
for name,budget,file in checks:
 code=subprocess.call([sys.executable,str(r/'prior-run-command.py'),'static-'+name,str(budget),'node','scripts/internal/'+file])
 if code:sys.exit(code)
