from pathlib import Path
import json,re,hashlib
r=Path(__file__).parent
summary={}
for p in r.glob('*.json'):
 try:d=json.loads(p.read_text())
 except Exception:continue
 if isinstance(d,dict) and 'collectionFailure' in d and 'command' in d:
  log=p.with_suffix('.log');d['rawVerified']=log.exists() and log.stat().st_size==d['bytes'] and hashlib.sha256(log.read_bytes()).hexdigest()==d['sha256'];summary[p.stem]=d
(r/'execution-receipts.json').write_text(json.dumps(summary,indent=2)+'\n')
print('receipts',len(summary),'raw verified',sum(x['rawVerified'] for x in summary.values()))
for name in ['before-measure','after4-measure','final-overlap82']:
 p=r/(name+'.log')
 if not p.exists():continue
 rows=[]
 for line in p.read_text().splitlines():
  if line.startswith('[memory76] '):rows.append(json.loads(line[11:]))
 if rows:print(name,[x for x in rows if x.get('history')==2048 and x['stage'] in ['before-checkpoint','after-checkpoint','released','reopened']])
