#!/bin/bash
set -euo pipefail
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
r=/tmp/media-server-memory83
mkdir -p "$r/repo" "$r/output" "$r/work"
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
export TMPDIR="$r/work"
cp /helpers/prior-run-command.py "$r/output/collect.py"
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
for mode in all concurrency history-product; do
 python3 "$r/output/collect.py" "checkpoint-$mode" 600 bash scripts/internal/verify_recording_generation_checkpoint.sh "$mode"
done
for suite in transaction active consumers; do
 python3 "$r/output/collect.py" "$suite" 300 bash "scripts/internal/verify_recording_generation_$suite.sh"
done
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/collect.py" build 600 cmake --build ../build -j2
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
find "$r/work" -mindepth 1 -maxdepth 1 > "$r/output/remaining-work.txt"
python3 /helpers/linux-native83.py
echo 'linux complete'
