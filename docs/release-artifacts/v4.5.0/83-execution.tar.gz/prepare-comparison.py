import pathlib,shutil,subprocess,tarfile,io,json,shlex,re,hashlib,sys
r=pathlib.Path(__file__).parent;repo=pathlib.Path.cwd();side=sys.argv[1]
source=r/'before-source' if side=='before' else repo
if side=='before' and not source.exists():
 source.mkdir();data=subprocess.check_output(['git','archive','b88461e7cee8cfa771ef7ec1e5e30d57212da6a8','include','src'])
 with tarfile.open(fileobj=io.BytesIO(data)) as t:t.extractall(source,filter='data')
out=r/(side+'-measure');out.mkdir()
shutil.copytree(source/'include',out/'include')
for n in ['recording_journal.h','recording_catalog.h']:
 p=out/'include/recording'/n;p.write_text(p.read_text().replace('private:','public:'))
shutil.copyfile(repo/'scripts/internal/recording_catalog_cost_probe_timer.h',out/'recording_catalog_cost_probe_timer.h')
for n in ['probe.cpp','scale-reference.cpp']:shutil.copyfile(r/'reference81/seed-build'/n,out/n)
old='/private/tmp/media-server-memory81-3pivevrd'; commands=json.loads((r/'reference81/seed-build/commands81.json').read_text());binding=[]
for cmd in commands[:-1]:
 name=pathlib.Path(cmd[-1]).name;s=(source/'src/recording'/name).read_text();original=hashlib.sha256(s.encode()).hexdigest()
 s='#include "recording_catalog_cost_probe_timer.h"\n#include <iostream>\n'+s
 for label in ['OpenGenerationReadOnlyLocked','CheckManagedStateLocked','PrepareGenerationCheckpoint','PublishGenerationCheckpoint','CaptureGenerationSnapshotViewLocked','ExportFrozenGenerationValues','CheckpointGenerationLocked','PrepareGenerationSnapshotStreamLocked','BuildGenerationScratchLocked','WriteComponentStream']:
  s=re.sub(r'\bbool\s+(?:\w+::)?'+label+r'\s*\([^;{]*?\)\s*(?:const\s*)?(?:try\s*)?\{',lambda m:m[0]+' fc::Scope phase("'+label+'");',s)
 if name=='recording_journal.cpp':s+=(r/'observer-tail.cpp').read_text()
 (out/name).write_text(s);binding.append(dict(file=name,source=original,instrumented=hashlib.sha256(s.encode()).hexdigest()))
new=[]
for cmd in commands:
 cmd=[v.replace(old+'/seed-build',str(out)).replace(old+'/before-runtime.a',str(r/(side+'-runtime.a'))).replace(str(repo/'src/recording'),str(source/'src/recording')).replace('-I'+str(repo/'include'),'-I'+str(source/'include')) for v in cmd]
 new.append(cmd)
(out/'commands.json').write_text(json.dumps(new,indent=2));(out/'binding.json').write_text(json.dumps(binding,indent=2))
(out/'run.sh').write_text((r/'reference81/final-overlap.sh').read_text().replace(old+'/seed-build',str(out)).split('export MEDIA_SERVER_VERIFY_RECORDING_LATENCY_TRACE')[0]+'exec "'+str(out/'probe')+'" "'+str(r/(side+'-seed'))+'"\n')
