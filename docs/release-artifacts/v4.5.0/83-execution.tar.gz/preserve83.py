from pathlib import Path
import tarfile,hashlib,json,io
r=Path(__file__).parent;target=Path('docs/release-artifacts/v4.5.0/83-execution.tar.gz');selected={}
def add(p):
 if p.is_symlink() or not p.is_file():return
 rel=p.relative_to(r).as_posix()
 if p.stat().st_size>4*1024*1024:raise RuntimeError('unplanned large text/artifact '+rel)
 selected[rel]=p
# New finite receipts, first failures, patches and preparation/compile source; no binaries/runtime/models.
for p in r.iterdir():
 if p.suffix in {'.json','.log','.py','.sh','.patch','.txt','.cpp','.h'}:add(p)
for d in ['linux-first-output','linux-final-output','new-source']:
 for p in (r/d).rglob('*'):add(p)
# Only the fixture source actually used; copied headers are derivable from bound Git + visibility transform.
for d in ['before-retained-measure83','after-retained-measure83','final-retained-measure83']:
 for n in ['probe.cpp','scale-reference.cpp','binding.json']:
  add(r/d/n)
# Synthetic, small actual B/C preserved packages/records and source needed for their readback.
for d in ['bc-final-before-store','bc-final-after-store']:
 for p in (r/d).rglob('*'):
  if p.is_file() and (p.suffix in {'.json','.jsonl','.review','.evp','.mp4'} or p.name=='.recording-store-format'):add(p)
for n in ['after-measure/probe.cpp','after-measure/scale-reference.cpp']:
 add(r/'reference82'/n)
entries=[]
for name,p in sorted(selected.items()):entries.append({'path':name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
manifest={'format':'exact bytes; generated synthetic owned B/C media only; no redaction or reconstruction','excluded':'existing82 archive, runtime/binaries/models, copied header trees, large cyclic/overlap media/stores. Measurement source/hash and outputs kept.','members':entries}
with tarfile.open(target,'w:gz') as t:
 for name,p in sorted(selected.items()):t.add(p,arcname=name,recursive=False)
 data=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('archive-members.json');info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(target,'r:gz') as t:
 for e in entries:
  data=t.extractfile(e['path']).read();assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
receipt={'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'exactOriginalMembers':len(entries),'archiveMembers':len(entries)+1,'uncompressedOriginalBytes':sum(e['bytes'] for e in entries),'maxMemberBytes':max(e['bytes'] for e in entries),'verifiedEveryMember':True,'localGit':'pending','remote':'pending'}
p=Path('docs/release-artifacts/v4.5.0/83-validation.json');j=json.loads(p.read_text());j['preservation']=receipt
j['staticChecks']={f.stem:json.loads(f.read_text()) for f in r.glob('*.json') if (f.stem.startswith('static83-') or f.stem in ['inventory83-readback','coverage83-readback','implementation83-readback','diff83-final'])}
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt))
