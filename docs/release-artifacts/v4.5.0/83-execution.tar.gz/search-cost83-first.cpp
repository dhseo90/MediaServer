#define main PriorOverlapMain
#include "/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_search_runtime_load_smoke.cpp"
#undef main
#include "recording/recording_search_reader.h"
int main(int argc,char**argv){try{
 if(argc!=2)return 2;gst_init(nullptr,nullptr);std::string error;recording::RecordingRuntimeStorage runtime(argv[1]);
 const auto time=[](){return std::chrono::steady_clock::now();};
 auto begin=time();if(!runtime.Open(&error))throw std::runtime_error(error);
 std::cout<<"[cost] openMs="<<std::chrono::duration<double,std::milli>(time()-begin).count()<<std::endl;
 recording::RecordingReadService media(runtime.catalog());recording::RecordingSearchReader reader(runtime.catalog(),media);
 std::vector<std::string> channels;for(unsigned i=0;i<8;++i)channels.push_back("load-"+std::to_string(i));
 recording::SearchSourceBatch batch;begin=time();if(!runtime.catalog().CaptureSearchSource(channels,nullptr,&batch,&error))throw std::runtime_error(error);
 std::cout<<"[cost] captureMs="<<std::chrono::duration<double,std::milli>(time()-begin).count()<<" docs="<<batch.delta.upserts.size()<<std::endl;
 std::shared_ptr<const recording::RecordingSearchModel> model;begin=time();if(!recording::RecordingSearchModel::Build(batch.delta.upserts,batch.delta.source_instance,batch.delta.revision,&model,&error))throw std::runtime_error(error);
 std::cout<<"[cost] buildMs="<<std::chrono::duration<double,std::milli>(time()-begin).count()<<" bytes="<<model->accounted_bytes()<<std::endl;
 recording::RecordingSearchQuery q;q.channels=channels;q.start_time_ms=0;q.end_time_ms=2000000000000LL;q.include_unplaced=true;q.limit=10;
 std::shared_ptr<const recording::RecordingSearchModel> next;begin=time();if(!reader.WithPlayback(*model,q,&next,&error))throw std::runtime_error(error);
 std::cout<<"[cost] playbackMs="<<std::chrono::duration<double,std::milli>(time()-begin).count()<<" docs="<<next->documents().size()<<std::endl;
 if(!runtime.Finish(&error))throw std::runtime_error(error);return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<std::endl;return 1;}}
