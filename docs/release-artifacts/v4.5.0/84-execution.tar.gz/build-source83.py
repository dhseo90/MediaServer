import json,shlex,subprocess,sys
from pathlib import Path
r=Path(__file__).parent;repo=Path.cwd();side=sys.argv[1];build=repo/'build-gst-onnx'
flags={line.split(' = ',1)[0]:line.split(' = ',1)[1] for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines() if ' = ' in line}
cmd=['/usr/bin/c++']+shlex.split(' '.join(flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']))
cmd+=['-Wall','-Wextra','-Werror']
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
cmd +=[str(repo/'scripts/internal/recording_search_source_smoke.cpp'),str(repo/'build-gst-onnx/libmedia_server_runtime.a')]+libs+['-o',str(r/(side+'-overlap'))]
(r/(side+'-overlap-command.json')).write_text(json.dumps(cmd,indent=2)+'\n');subprocess.run(cmd,check=True)
