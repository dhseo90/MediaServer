#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory84
cp /source/scripts/internal/recording_public_timeline_smoke.cpp "$r/repo/scripts/internal/"
cp /source/scripts/internal/recording_search_application_smoke.cpp "$r/repo/scripts/internal/"
cd "$r/repo"
python3 /helpers/linux-native84-resume.py
