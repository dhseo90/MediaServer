#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory84
export TMPDIR="$r/work"
cd "$r/repo"
python3 "$r/output/collect.py" history-product 600 bash scripts/internal/verify_recording_generation_checkpoint.sh history-product
