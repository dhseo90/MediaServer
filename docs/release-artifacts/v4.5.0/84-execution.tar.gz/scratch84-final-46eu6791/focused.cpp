#include "recording/recording_generation_transaction.h"
#include "recording_history_index.h"
#include <fstream>
#include <iostream>
#include <thread>
#include <vector>
unsigned failures=0;std::string error;
void Need(bool ok){if(!ok)throw std::runtime_error("setup failure: "+error);}
void Check(const char* id,bool ok,const char* why){std::cout<<id<<" "<<(ok?"PASS ":"FAIL ")<<why<<std::endl;if(!ok)++failures;}
void Write(const std::filesystem::path& path,const std::string& value){std::ofstream f(path);f<<value;Need(bool(f));}
void IndexRun(const std::filesystem::path& root){using Index=recording::RecordingHistoryIndex;std::string value;
    { // Actual live/clone/sequential index owners, not synthetic Reserve-only tickets.
      using Budget=recording::RecordingScratchResidency;
      const auto bytes=Index::BytesForRows(4);
      auto ram=std::make_shared<recording::SearchModelResidency>(16*1024*1024);
      auto budget=std::make_shared<Budget>(Budget::Usage{3*bytes,4,ram->limit()},ram);
      auto live=std::make_shared<Index>();
      Need(live->Create(root.string(),bytes,&error,budget));Need(live->Put("live","retained",false,&error));
      auto clone=std::make_shared<Index>();Need(clone->Create(root.string(),bytes,&error,live->resources()));
      Need(clone->CopyFrom(*live,&error));
      Index sequence;{Budget::Scope scope(budget);Need(sequence.Create(root.string(),bytes,&error));}
      Need(sequence.BeginSequentialBuild(&error));Need(sequence.Put("k","capture",false,&error));Need(sequence.SealSequentialBuild(&error));
      Index rejected;const auto held=budget->usage();
      Check("MEM84-D02",!rejected.Create(root.string(),bytes,&error,budget)&&error=="recording-resource-unavailable"&&
          budget->usage().disk_bytes==held.disk_bytes&&ram->used()==held.ram_bytes,
          "live clone and sequential capture consume one owner; fourth scratch denied before file creation with rollback");
      Check("MEM84-D03",!live->ReserveRows(5,&error)&&error=="recording-resource-unavailable"&&
          live->Get("live",&value,&error)==Index::Lookup::Found&&value=="retained"&&live->Healthy(&error),
          "aggregate growth denial preserves existing index health and original value");
      auto reader=clone;clone.reset();
      Check("MEM84-D02",budget->usage().disk_bytes==3*bytes&&reader->Get("live",&value,&error)==Index::Lookup::Found,
          "last actual shared scratch owner retains charge and readable clone");
      reader.reset();Index resumed;Need(resumed.Create(root.string(),bytes,&error,budget));
      Check("MEM84-D02",budget->usage().disk_bytes==3*bytes&&budget->usage().file_descriptors==3,
          "last clone owner destruction releases resources and identical request resumes");
      Need(resumed.Close(&error));Need(sequence.Close(&error));Need(live->Close(&error));
      Check("MEM84-D02",budget->usage().disk_bytes==0&&budget->usage().file_descriptors==0&&ram->used()==0&&std::filesystem::is_empty(root),
          "explicit Close reclaims all anonymous files FD and RAM reservations");
      auto fd_budget=std::make_shared<Budget>(Budget::Usage{bytes,0,ram->limit()},ram);
      Index partial;Check("MEM84-D04",!partial.Create(root.string(),bytes,&error,fd_budget)&&ram->used()==0&&
          fd_budget->usage().disk_bytes==0&&fd_budget->usage().file_descriptors==0,
          "RAM acquisition rolls back when the same request fails FD admission");
      Index uncertain;Need(uncertain.Create(root.string(),bytes,&error,budget));const int fd=uncertain.ProbeFd();
      Index::probe_fault=4;const bool closed=uncertain.Close(&error);Index::probe_fault=0;
      Check("MEM84-D05",!closed&&!uncertain.Close(&error)&&::fcntl(fd,F_GETFD)==-1&&errno==EBADF&&
          budget->usage().disk_bytes==0&&budget->usage().file_descriptors==0&&ram->used()==0,
          "injected Close uncertainty remains failed but actually closed FD and its reservation are not retained or double returned");
      std::atomic<unsigned> successes{0},bad{0};std::vector<std::thread> callers;
      for(unsigned i=0;i<8;++i)callers.emplace_back([&,i](){
          for(unsigned n=0;n<8;++n){Index item;std::string detail;
              if(item.Create(root.string(),bytes,&detail,budget)){
                  if(!item.Put("thread",std::to_string(i),false,&detail)||!item.Close(&detail))++bad;
                  else ++successes;
              }else if(detail!="recording-resource-unavailable")++bad;
          }
      });
      for(auto& caller:callers)caller.join();
      Check("MEM84-D06",successes>0&&bad==0&&budget->peak().disk_bytes<=3*bytes&&budget->peak().file_descriptors<=4&&
          budget->usage().disk_bytes==0&&budget->usage().file_descriptors==0&&ram->used()==0,
          "concurrent real index Create Close never exceeds shared admission and releases exactly once");
    }

}
namespace recording {struct RecordingGenerationTransactionProbe {static void Run(const std::filesystem::path& base){
        {
            using Index=RecordingHistoryIndex;using Budget=RecordingScratchResidency;
            const auto root=base/"aggregate";std::filesystem::create_directories(root);
            auto memory=std::make_shared<SearchModelResidency>(4*1024*1024);
            auto resources=std::make_shared<Budget>(Budget::Usage{548,8,memory->limit()},memory);
            {
                Budget::Scope scope(resources);Index live;Need(live.Create(root.string(),512,&error));
                RecordingGenerationTransaction transaction;Need(transaction.Create(root,&error));RecordingGenerationOwnedFile result;
                const bool written=transaction.WriteComponentStream("partial",1024,[&](const auto& sink,std::string* detail){
                    return sink(std::string(20,'a'),detail)&&sink(std::string(20,'b'),detail);
                },&result,&error);
                RecordingGenerationOwnedFile prefix;const auto refusal=error;
                Need(transaction.Describe(true,"partial",&prefix,&error));
                Check("MEM84-D08",!written&&refusal=="recording-resource-unavailable"&&prefix.file.size==20&&resources->usage().disk_bytes==533,
                    "actual anonymous live index and candidate writer share aggregate disk; refused suffix has only verified first prefix");
                Need(live.Close(&error));Need(transaction.WriteComponent("resumed",std::string(40,'c'),&result,&error));
                Check("MEM84-D08",result.file.size==40&&resources->usage().disk_bytes==61,
                    "same candidate owner resumes after actual live index Close without increasing budget");
                Need(transaction.CleanupUnprepared(&error));
                Check("MEM84-D08",resources->usage().disk_bytes==0&&resources->usage().file_descriptors==6,
                    "verified candidate deletion returns disk while live transaction directory FDs stay charged");
            }
            Check("MEM84-D08",resources->usage().disk_bytes==0&&resources->usage().file_descriptors==0&&memory->used()==0,
                "transaction destruction closes its actual directory FDs then returns working reservations");
            {
                Budget::Scope scope(resources);RecordingGenerationTransaction transaction;Need(transaction.Create(root,&error));
                RecordingGenerationOwnedFile result;Need(transaction.WriteComponent("preserved",std::string(20,'p'),&result,&error));
                Write(transaction.StagePath()/"foreign","unknown");
                Check("MEM84-D09",!transaction.CleanupUnprepared(&error),"unknown stage entry blocks cleanup rather than deleting unowned data");
            }
            Check("MEM84-D09",resources->usage().disk_bytes==21&&resources->preserved_disk_bytes()==21&&resources->usage().file_descriptors==0,
                "failed cleanup preserves known candidate and directory charge after transaction object destruction");
        }
}};}
int main(int argc,char** argv){if(argc!=2)return 2;IndexRun(std::filesystem::path(argv[1])/"index");recording::RecordingGenerationTransactionProbe::Run(std::filesystem::path(argv[1])/"transaction");return failures?1:0;}
