// 파일 용도: 한 녹화 owner의 익명 scratch 공간·FD·유한 작업 RAM을 합산 예약한다.
#pragma once
#include "recording/recording_memory_reservation.h"
#include <cstdint>
#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <mutex>
#include <string>
#include <limits>
#if MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
#include <dirent.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#endif

namespace recording {
class RecordingScratchResidency final : public std::enable_shared_from_this<RecordingScratchResidency> {
public:
    struct Usage { std::uint64_t disk_bytes{0}, file_descriptors{0}, ram_bytes{0}; };
    class Reservation {
        friend class RecordingScratchResidency;
        std::shared_ptr<RecordingScratchResidency> owner_;
        Usage amount_{};
        SearchModelResidency::Reservation ram_;
        Reservation(std::shared_ptr<RecordingScratchResidency> owner,Usage amount,
            SearchModelResidency::Reservation ram):owner_(std::move(owner)),amount_(amount),ram_(std::move(ram)){}
    public:
        Reservation()=default;
        Reservation(const Reservation&)=delete;
        Reservation& operator=(const Reservation&)=delete;
        Reservation(Reservation&& other)noexcept:owner_(std::move(other.owner_)),amount_(other.amount_),ram_(std::move(other.ram_)){other.amount_={};}
        Reservation& operator=(Reservation&& other)noexcept {Reservation next(std::move(other));swap(next);return *this;}
        ~Reservation(){if(owner_)owner_->Release(amount_);}
        void swap(Reservation& other)noexcept {owner_.swap(other.owner_);std::swap(amount_,other.amount_);ram_.swap(other.ram_);}
        // Exclusive ticket: reserve growth before filesystem writes. No blocking wait.
        bool GrowDisk(std::uint64_t bytes){
            if(!owner_||bytes<amount_.disk_bytes)return false;
            std::lock_guard<std::mutex> lock(owner_->mu_);
            const auto extra=bytes-amount_.disk_bytes;
            if(extra>owner_->limits_.disk_bytes-owner_->used_.disk_bytes)return false;
            owner_->used_.disk_bytes+=extra;amount_.disk_bytes=bytes;owner_->PeakLocked();return true;
        }
        void ReleaseFd(){
            if(!owner_||!amount_.file_descriptors)return;
            std::lock_guard<std::mutex> lock(owner_->mu_);
            --amount_.file_descriptors;--owner_->used_.file_descriptors;
        }
    };
    // Explicit limits are also the deterministic saturation injection boundary.
    // Production Discover freezes existing filesystem availability / process FD headroom;
    // these are NOT a storage-format, full-process RAM, or physical allocation guarantee.
    RecordingScratchResidency(Usage limits,std::shared_ptr<SearchModelResidency> ram,
        std::uint64_t block=1,std::uint64_t device=0)
        :limits_(limits),ram_(std::move(ram)),block_(block?block:1),device_(device){}
    std::optional<Reservation> Reserve(Usage amount){
        if(!ram_||amount.ram_bytes>std::numeric_limits<std::size_t>::max())return std::nullopt;
        auto ram=ram_->ReserveOwned(static_cast<std::size_t>(amount.ram_bytes));
        if(!ram)return std::nullopt;
        std::lock_guard<std::mutex> lock(mu_);
        if(amount.disk_bytes>limits_.disk_bytes-used_.disk_bytes||
           amount.file_descriptors>limits_.file_descriptors-used_.file_descriptors||
           amount.ram_bytes>limits_.ram_bytes-used_.ram_bytes)return std::nullopt;
        used_.disk_bytes+=amount.disk_bytes;used_.file_descriptors+=amount.file_descriptors;
        used_.ram_bytes+=amount.ram_bytes;PeakLocked();
        return Reservation(shared_from_this(),amount,std::move(*ram));
    }
    std::uint64_t DiskCharge(std::uint64_t bytes)const{
        if(bytes>UINT64_MAX-(block_-1))throw RecordingResourceUnavailable();
        return ((bytes+block_-1)/block_)*block_;
    }
    Usage usage()const{std::lock_guard<std::mutex> lock(mu_);return used_;}
    Usage peak()const{std::lock_guard<std::mutex> lock(mu_);return peak_;}
    Usage limits()const{return limits_;}
    std::uint64_t device()const{return device_;}
    static std::shared_ptr<RecordingScratchResidency> Discover(const std::string& directory,
        const std::shared_ptr<SearchModelResidency>& ram){
#if MEDIA_SERVER_USE_OPENSSL && !defined(_WIN32)
        struct stat st{};struct statvfs space{};struct rlimit files{};
        if(!ram||stat(directory.c_str(),&st)||statvfs(directory.c_str(),&space)||!space.f_frsize||
           space.f_bavail>UINT64_MAX/space.f_frsize||getrlimit(RLIMIT_NOFILE,&files)||files.rlim_cur==RLIM_INFINITY)
            throw RecordingResourceUnavailable();
        DIR* descriptors=opendir("/dev/fd");if(!descriptors)throw RecordingResourceUnavailable();
        const int own=dirfd(descriptors);std::uint64_t open_count=0;errno=0;
        while(auto* entry=readdir(descriptors)){
            char* end=nullptr;const auto fd=std::strtol(entry->d_name,&end,10);
            if(end!=entry->d_name&&!*end&&fd>=0&&fd!=own)++open_count;
        }
        const int scan_error=errno;const int close_error=closedir(descriptors);
        if(scan_error||close_error||open_count>=files.rlim_cur)throw RecordingResourceUnavailable();
        return std::make_shared<RecordingScratchResidency>(Usage{
            space.f_bavail*space.f_frsize,files.rlim_cur-open_count,ram->limit()},ram,space.f_frsize,st.st_dev);
#else
        (void)directory;(void)ram;throw RecordingResourceUnavailable();
#endif
    }
    class Scope {
        std::shared_ptr<RecordingScratchResidency> prior_;
    public:
        explicit Scope(std::shared_ptr<RecordingScratchResidency> owner):prior_(std::move(current_)){current_=std::move(owner);}
        ~Scope(){current_=std::move(prior_);}
        Scope(const Scope&)=delete;Scope& operator=(const Scope&)=delete;
    };
    static const std::shared_ptr<RecordingScratchResidency>& Current(){return current_;}
    static std::shared_ptr<RecordingScratchResidency> Default(const std::string& directory){
        // Standalone codecs/fixtures share one fallback domain; managed runtime binds
        // its own domain explicitly. Scope is deliberately not inherited by threads.
        static auto owner=Discover(directory,std::make_shared<SearchModelResidency>());
        return owner;
    }
private:
    void Release(Usage amount){std::lock_guard<std::mutex> lock(mu_);used_.disk_bytes-=amount.disk_bytes;used_.file_descriptors-=amount.file_descriptors;used_.ram_bytes-=amount.ram_bytes;}
    void PeakLocked(){peak_.disk_bytes=std::max(peak_.disk_bytes,used_.disk_bytes);peak_.file_descriptors=std::max(peak_.file_descriptors,used_.file_descriptors);peak_.ram_bytes=std::max(peak_.ram_bytes,used_.ram_bytes);}
    const Usage limits_;std::shared_ptr<SearchModelResidency> ram_;
    const std::uint64_t block_,device_;mutable std::mutex mu_;Usage used_{},peak_{};
    inline static thread_local std::shared_ptr<RecordingScratchResidency> current_;
};
} // namespace recording
