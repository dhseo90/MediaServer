#include "recording/recording_generation_transaction.h"
#include "recording_history_index.h"
#include <fstream>
#include <iostream>
unsigned failures=0;std::string error;
void Need(bool ok){if(!ok)throw std::runtime_error("setup failure: "+error);}
void Check(const char* id,bool ok,const char* why){std::cout<<id<<" "<<(ok?"PASS ":"FAIL ")<<why<<std::endl;if(!ok)++failures;}
void Write(const std::filesystem::path& path,const std::string& value){std::ofstream f(path);f<<value;Need(bool(f));}
namespace recording {struct RecordingGenerationTransactionProbe {static void Run(const std::filesystem::path& base){
        {
            using Index=RecordingHistoryIndex;using Budget=RecordingScratchResidency;
            const auto root=base/"aggregate";std::filesystem::create_directories(root);
            auto memory=std::make_shared<SearchModelResidency>(4*1024*1024);
            auto resources=std::make_shared<Budget>(Budget::Usage{548,8,memory->limit()},memory);
            {
                Budget::Scope scope(resources);Index live;Need(live.Create(root.string(),512,&error));
                RecordingGenerationTransaction transaction;Need(transaction.Create(root,&error));RecordingGenerationOwnedFile result;
                const bool written=transaction.WriteComponentStream("partial",1024,[&](const auto& sink,std::string* detail){
                    return sink(std::string(20,'a'),detail)&&sink(std::string(20,'b'),detail);
                },&result,&error);
                RecordingGenerationOwnedFile prefix;const auto refusal=error;
                Need(transaction.Describe(true,"partial",&prefix,&error));
                Check("MEM84-D08",!written&&refusal=="recording-resource-unavailable"&&prefix.file.size==20&&resources->usage().disk_bytes==533,
                    "actual anonymous live index and candidate writer share aggregate disk; refused suffix has only verified first prefix");
                Need(live.Close(&error));Need(transaction.WriteComponent("resumed",std::string(40,'c'),&result,&error));
                Check("MEM84-D08",result.file.size==40&&resources->usage().disk_bytes==61,
                    "same candidate owner resumes after actual live index Close without increasing budget");
                Need(transaction.CleanupUnprepared(&error));
                Check("MEM84-D08",resources->usage().disk_bytes==0&&resources->usage().file_descriptors==6,
                    "verified candidate deletion returns disk while live transaction directory FDs stay charged");
            }
            Check("MEM84-D08",resources->usage().disk_bytes==0&&resources->usage().file_descriptors==0&&memory->used()==0,
                "transaction destruction closes its actual directory FDs then returns working reservations");
            {
                Budget::Scope scope(resources);RecordingGenerationTransaction transaction;Need(transaction.Create(root,&error));
                RecordingGenerationOwnedFile result;Need(transaction.WriteComponent("preserved",std::string(20,'p'),&result,&error));
                Write(transaction.StagePath()/"foreign","unknown");
                Check("MEM84-D09",!transaction.CleanupUnprepared(&error),"unknown stage entry blocks cleanup rather than deleting unowned data");
            }
            Check("MEM84-D09",resources->usage().disk_bytes==21&&resources->preserved_disk_bytes()==21&&resources->usage().file_descriptors==0,
                "failed cleanup preserves known candidate and directory charge after transaction object destruction");
        }
}};}
int main(int argc,char** argv){if(argc!=2)return 2;recording::RecordingGenerationTransactionProbe::Run(argv[1]);return failures?1:0;}
