import pathlib,shlex,subprocess,json,hashlib,sys
r=pathlib.Path(__file__).parent;repo=pathlib.Path.cwd();side='http'
include=r/'before-source/include' if side=='before' else repo/'include'
archive=r/'before-runtime.a' if side=='before' else repo/'build-gst-onnx/libmedia_server_runtime.a'
link=shlex.split((repo/'build-gst-onnx/CMakeFiles/media_server.dir/link.txt').read_text());libs=[str(archive),*link[link.index('libmedia_server_runtime.a')+1:]]
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','openssl','sqlite3','gstreamer-app-1.0'],text=True))
cmd=['c++','-std=c++17','-Wall','-Wextra','-Werror','-pthread','-I'+str(include),'-DMEDIA_SERVER_USE_OPENSSL=1','-DMEDIA_SERVER_USE_SQLITE3=1','-DMEDIA_SERVER_USE_GSTREAMER=1','-DMEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND=1',*flags,str(repo/'scripts/internal/recording_http_owner_smoke.cpp'),*libs,'-o',str(r/(side+'-bc'))]
print(shlex.join(cmd),flush=True);subprocess.run(cmd,check=True)
(r/(side+'-bc-binding.json')).write_text(json.dumps({'command':cmd,'archive':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'binary':hashlib.file_digest((r/(side+'-bc')).open('rb'),'sha256').hexdigest(),'fixture':hashlib.file_digest((repo/'scripts/internal/recording_http_owner_smoke.cpp').open('rb'),'sha256').hexdigest()},indent=2))
