from pathlib import Path
import shlex,subprocess,json,hashlib,os
r=Path('/tmp/media-server-memory85');repo=r/'repo';build=r/'build';out=r/'output'
flags={line.split(' = ',1)[0]:line.split(' = ',1)[1] for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines() if ' = ' in line}
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
for name in ['recording_http_owner_smoke','recording_retained_lifetime_smoke']:
 cmd=['g++']+shlex.split(' '.join(flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']))+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(r/name)]
 (out/f'{name}-compile-lifetime.json').write_text(json.dumps(cmd,indent=2));subprocess.run(cmd,check=True,timeout=60,cwd=repo)
 (out/f'{name}.sha256').write_text(hashlib.sha256((r/name).read_bytes()).hexdigest()+'\n')
 (r/(name+'-fixed-root')).mkdir()
 commands=[[str(r/name),str(r/(name+'-fixed-root'))]+(['--combined-d'] if name=='recording_retained_lifetime_smoke' else [])]
 (out/f'{name}-commands.json').write_text(json.dumps(commands,indent=2))
 with (out/f'{name}-fixed.log').open('w') as log:
  for cmd in commands:
   log.write(json.dumps(cmd)+'\n');log.flush();result=subprocess.run(cmd,timeout=90,cwd=repo,stdout=log,stderr=subprocess.STDOUT); log.write('exit='+str(result.returncode)+'\n'); log.flush()
  log.write('commands completed; see actual exit\n')
print('native source/application owner PASS')
