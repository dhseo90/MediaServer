from pathlib import Path
import shlex,subprocess,json,hashlib,os
r=Path('/tmp/media-server-memory85');repo=r/'repo';build=r/'build';out=r/'output'
flags={line.split(' = ',1)[0]:line.split(' = ',1)[1] for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines() if ' = ' in line}
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
for name in ['recording_search_source_smoke','recording_search_application_smoke','recording_http_owner_smoke','recording_retained_lifetime_smoke']:
 cmd=['g++']+shlex.split(' '.join(flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']))+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(r/name)]
 (out/f'{name}-compile.json').write_text(json.dumps(cmd,indent=2));subprocess.run(cmd,check=True,timeout=60,cwd=repo)
 (out/f'{name}.sha256').write_text(hashlib.sha256((r/name).read_bytes()).hexdigest()+'\n')
 (r/(name+'-root')).mkdir()
 commands=[[str(r/name),str(r/(name+'-root'))]+(['--combined-d'] if name=='recording_retained_lifetime_smoke' else [])]
 (out/f'{name}-commands.json').write_text(json.dumps(commands,indent=2))
 with (out/f'{name}.log').open('w') as log:
  for cmd in commands:
   log.write(json.dumps(cmd)+'\n');log.flush();subprocess.run(cmd,check=True,timeout=90,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  log.write('PASS all commands exit0\n')
print('native source/application owner PASS')
