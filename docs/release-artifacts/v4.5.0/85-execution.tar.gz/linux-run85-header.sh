#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory85
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r/work"
cp /source/src/ingress/webrtc_http_server_detail.h "$r/repo/src/ingress/"
cd "$r/repo"
python3 "$r/output/collect.py" build-header-fixed 600 cmake --build ../build -j2
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries-header-fixed.sha256"
python3 /helpers/linux-native85-resume.py
