#!/bin/bash
set -euo pipefail
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
r=/tmp/media-server-memory85
mkdir -p "$r/repo" "$r/output" "$r/work"
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
export TMPDIR="$r/work"
cp /helpers/run-command.py "$r/output/collect.py"
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
python3 "$r/output/collect.py" transaction-fixed 600 bash scripts/internal/verify_recording_generation_transaction.sh
python3 "$r/output/collect.py" history-large 600 bash scripts/internal/verify_recording_generation_checkpoint.sh history-large
python3 "$r/output/collect.py" history-product 600 bash scripts/internal/verify_recording_generation_checkpoint.sh history-product
python3 "$r/output/collect.py" search-owner 60 bash scripts/internal/verify_recording_search_lifetime.sh
python3 "$r/output/collect.py" checkpoint-concurrency 600 bash scripts/internal/verify_recording_generation_checkpoint.sh concurrency
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/collect.py" build 600 cmake --build ../build -j2
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
python3 /helpers/linux-native85.py
find "$r/work" -mindepth 1 -maxdepth 1 > "$r/output/remaining-work.txt"
echo 'linux complete'
