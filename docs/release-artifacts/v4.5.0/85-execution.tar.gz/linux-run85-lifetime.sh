#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory85
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r/work" LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
cp /source/scripts/internal/recording_retained_lifetime_smoke.cpp scripts/internal/
python3 /helpers/linux-native85-lifetime.py
