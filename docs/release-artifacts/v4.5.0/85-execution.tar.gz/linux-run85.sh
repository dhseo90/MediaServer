#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory85
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r/work" LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
mkdir "$r/http-stop-root"
python3 "$r/output/collect.py" http-stop-only 45 "$r/recording_http_owner_smoke" "$r/http-stop-root" --stop-only
