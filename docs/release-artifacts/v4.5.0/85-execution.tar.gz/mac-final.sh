#!/usr/bin/env bash
set -euo pipefail
r=/private/tmp/media-server-memory85-c6xh2hns
export TMPDIR="$r/work" MEDIA_SERVER_SKIP_LOCAL_ENV=1
python3 "$r/run-command.py" history-large-crypto-fixed 600 bash scripts/internal/verify_recording_generation_checkpoint.sh history-large
python3 "$r/run-command.py" history-product-final 600 bash scripts/internal/verify_recording_generation_checkpoint.sh history-product
python3 "$r/run-command.py" transaction-final 600 bash scripts/internal/verify_recording_generation_transaction.sh
python3 "$r/run-command.py" concurrency-final 600 bash scripts/internal/verify_recording_generation_checkpoint.sh concurrency
python3 "$r/run-command.py" search-owner-final 60 bash scripts/internal/verify_recording_search_lifetime.sh
python3 "$r/run-command.py" native-build-ready 60 bash -c 'python3 /private/tmp/media-server-memory85-c6xh2hns/build-bc.py after && python3 /private/tmp/media-server-memory85-c6xh2hns/build-overlap.py after'
