import pathlib,re,subprocess,json,shlex
root=pathlib.Path(__file__).parent
script=pathlib.Path('scripts/internal/verify_recording_generation_checkpoint.sh').read_text()
sources=re.search(r'task_sources=\((.*?)\n\)',script,re.S)[1].split()
cmd=['/usr/bin/c++','-std=c++17','-Wall','-Wextra','-Werror','-pthread','-Iinclude','-Isrc/recording','-DMEDIA_SERVER_USE_OPENSSL=1','-DMEDIA_SERVER_USE_SQLITE3=1','-DMEDIA_SERVER_ENABLE_RECORDING_GENERATION_BACKEND=1','-DMEDIA_SERVER_RECORDING_GENERATION_TESTING=1']+shlex.split(subprocess.check_output(['pkg-config','--cflags','openssl','sqlite3'],text=True))+sources+shlex.split(subprocess.check_output(['pkg-config','--libs','openssl','sqlite3'],text=True))+['-lz','-o',str(root/'checkpoint')]
(root/'build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
subprocess.run(cmd,check=True)
