from pathlib import Path
import os,stat,json,subprocess,hashlib
root=Path('/private/tmp/media-server-memory86-occmd_8c')
repo=Path('/Users/dhseo/Workspace/mediaServer')
receipt=Path('/private/tmp/media-server-memory86-cleanup.json')
assert root.resolve()==root and root.name=='media-server-memory86-occmd_8c' and root.lstat().st_uid==os.getuid()
# The archive must already be committed and its Git blob must match disk.
p='docs/release-artifacts/v4.5.0/86-execution.tar.gz'
b=subprocess.check_output(['git','show','HEAD:'+p],cwd=repo)
assert hashlib.sha256(b).hexdigest()==hashlib.sha256((repo/p).read_bytes()).hexdigest()
result={'preservationCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'archiveSha256':hashlib.sha256(b).hexdigest(),'containers':[],'root':str(root),'removedFiles':0,'removedDirectories':0,'removedSymlinks':0,'removedRegularBytes':0,'errors':[]}
for name in ['media-server-memory86','media-server-memory86b','media-server-memory86c']:
 info=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 assert info['Name']=='/'+name and not info['State']['Running']
 x=subprocess.run(['docker','rm',info['Id']],capture_output=True,text=True)
 result['containers'].append({'name':name,'id':info['Id'],'wasRunning':False,'exit':x.returncode,'output':x.stdout.strip(),'error':x.stderr.strip()});assert x.returncode==0
# Remove only verified owned entries; never follow links into the SDK.
for base,dirs,files in os.walk(root,topdown=False,followlinks=False):
 for name in files+dirs:
  q=Path(base)/name;s=q.lstat();assert s.st_uid==os.getuid()
  if stat.S_ISLNK(s.st_mode):q.unlink();result['removedSymlinks']+=1
  elif stat.S_ISREG(s.st_mode):result['removedRegularBytes']+=s.st_size;q.unlink();result['removedFiles']+=1
  elif stat.S_ISDIR(s.st_mode):q.rmdir();result['removedDirectories']+=1
  else:raise RuntimeError('unexpected owned entry type '+str(q))
root.rmdir();result['removedDirectories']+=1
pointer=Path('/private/tmp/media-server-memory86-root')
if pointer.exists():
 assert pointer.lstat().st_uid==os.getuid() and pointer.read_text().strip()==str(root)
 pointer.unlink()
result['rootAbsent']=not root.exists()
ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
result['remainingOwnedProcessRows']=[s for s in ps.splitlines() if str(root) in s and 'cleanup86.py' not in s and 'exec_command' not in s]
ports=[34971,42051,59871,59895,60747,60758,61172,61182]
x=subprocess.run(['lsof','-nP','-iTCP:'+','.join(map(str,ports)),'-sTCP:LISTEN'],capture_output=True,text=True)
result['portInspectionExit']=x.returncode;result['portListeners']=x.stdout.splitlines();result['portInspectionError']=x.stderr.strip()
result['containerNamesRemaining']=subprocess.check_output(['docker','ps','-a','--format','{{.Names}}'],text=True).splitlines()
result['containerNamesRemaining']=[n for n in result['containerNamesRemaining'] if n in ['media-server-memory86','media-server-memory86b','media-server-memory86c']]
result['existingImagePreserved']=subprocess.run(['docker','image','inspect','sha256:ce72c8a15363984da642e9964189957896812061c6af1d0ef67e87b38ad5a588'],stdout=subprocess.DEVNULL).returncode==0
result['status']='PASS' if result['rootAbsent'] and not result['errors'] and not result['remainingOwnedProcessRows'] and not result['portListeners'] and x.returncode in (0,1) and not x.stderr and not result['containerNamesRemaining'] and result['existingImagePreserved'] else 'INCOMPLETE'
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['status']=='PASS'
