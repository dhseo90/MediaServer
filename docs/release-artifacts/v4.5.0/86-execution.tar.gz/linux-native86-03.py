from pathlib import Path
import shlex,subprocess,json,hashlib
r=Path('/tmp/media-server-memory86');repo=r/'repo';build=r/'build';out=r/'output'
flags={line.split(' = ',1)[0]:line.split(' = ',1)[1] for line in (build/'CMakeFiles/media_server_runtime.dir/flags.make').read_text().splitlines() if ' = ' in line}
link=shlex.split((build/'CMakeFiles/media_server.dir/link.txt').read_text());libs=link[link.index('libmedia_server_runtime.a')+1:]
names=['recording_search_source_smoke','recording_search_application_smoke','recording_http_owner_smoke','recording_retained_lifetime_smoke','recording_search_runtime_load_smoke']
for name in names:
 cmd=['g++']+shlex.split(' '.join(flags[k] for k in ['CXX_DEFINES','CXX_INCLUDES','CXX_FLAGS']))+['-Wall','-Wextra','-Werror',str(repo/'scripts/internal'/f'{name}.cpp'),str(build/'libmedia_server_runtime.a')]+libs+['-o',str(r/name)]
 (out/f'{name}-compile.json').write_text(json.dumps(cmd,indent=2));subprocess.run(cmd,check=True,timeout=60,cwd=repo)
 (out/f'{name}.sha256').write_text(hashlib.file_digest((r/name).open('rb'),'sha256').hexdigest()+'\n')
for name in names:
 target=r/(name+'-root');target.mkdir()
 args=['--combined-d'] if name=='recording_retained_lifetime_smoke' else ['checkpoint'] if name=='recording_search_runtime_load_smoke' else []
 deadline=90 if name=='recording_search_runtime_load_smoke' else 45 if name=='recording_http_owner_smoke' else 90
 subprocess.run(['python3',str(out/'collect.py'),name,str(deadline),str(r/name),str(target),*args],check=True,cwd=repo)
print('native source/application/HTTP/D/overlap complete')
