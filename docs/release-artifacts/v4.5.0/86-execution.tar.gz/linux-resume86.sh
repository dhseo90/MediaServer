#!/bin/bash
set -euo pipefail
r=/tmp/media-server-memory86
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r/work" GST_REGISTRY="$r/work/gst-registry.bin" GST_REGISTRY_1_0="$r/work/gst-registry.bin" LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
cp /source/scripts/internal/recording_search_runtime_load_smoke.cpp scripts/internal/
python3 /helpers/linux-native86.py
mkdir "$r/http-stop-root"
python3 "$r/output/collect.py" http-stop 30 "$r/recording_http_owner_smoke" "$r/http-stop-root" --stop-only
find "$r/work" -mindepth 1 -maxdepth 1 > "$r/output/remaining-work.txt"
echo 'linux complete'
