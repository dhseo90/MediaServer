#!/bin/bash
set -euo pipefail
r=/private/tmp/media-server-memory86-occmd_8c
export TMPDIR="$r" MEDIA_SERVER_SKIP_LOCAL_ENV=1
python3 "$r/run-command.py" mac-event-bridge02 180 bash scripts/internal/verify_v410_event_recording.sh --bridge-only
python3 "$r/run-command.py" mac-checkpoint-contracts 600 bash scripts/internal/verify_recording_generation_checkpoint.sh all
python3 "$r/run-command.py" mac-search-owner 60 bash scripts/internal/verify_recording_search_lifetime.sh
python3 "$r/run-command.py" mac-http-build 60 python3 "$r/build-http.py" after
python3 "$r/run-command.py" mac-d-build 60 python3 "$r/build-bc.py" after
python3 "$r/run-command.py" mac-overlap-build 60 python3 "$r/build-overlap.py" after
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache" MEDIA_SERVER_GST_PLUGIN_PROFILE=headless GST_REGISTRY="$r/registry-final.bin" GST_REGISTRY_1_0="$r/registry-final.bin"
unset GST_PLUGIN_PATH GST_PLUGIN_PATH_1_0 GST_PLUGIN_SYSTEM_PATH GST_PLUGIN_SYSTEM_PATH_1_0 MEDIA_SERVER_GST_MANAGED_REGISTRY MEDIA_SERVER_GST_MANAGED_PLUGIN_PATH MEDIA_SERVER_GST_INPUT_PLUGIN_PATH
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
mkdir "$r/mac-http-final" "$r/mac-http-stop" "$r/mac-d-final" "$r/mac-overlap-final"
export MEDIA_SERVER_SITE_OPERATIONS_REQUEST_DIAGNOSTIC=1
python3 "$r/run-command.py" mac-http-final 45 "$r/after-http" "$r/mac-http-final"
python3 "$r/run-command.py" mac-http-stop 30 "$r/after-http" "$r/mac-http-stop" --stop-only
python3 "$r/run-command.py" mac-d-final 90 "$r/after-bc" "$r/mac-d-final" --combined-d
python3 "$r/run-command.py" mac-overlap-final 90 "$r/after-overlap" "$r/mac-overlap-final" checkpoint
