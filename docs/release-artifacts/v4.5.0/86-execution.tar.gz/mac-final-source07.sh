#!/bin/bash
set -euo pipefail
r=/private/tmp/media-server-memory86-occmd_8c
export TMPDIR="$r" MEDIA_SERVER_SKIP_LOCAL_ENV=1
python3 "$r/run-command.py" mac-runtime-build04 600 cmake --build build-gst-onnx -j2
python3 "$r/run-command.py" mac-lazy-build-final 90 python3 "$r/c1/build.py"
mkdir "$r/mac-lazy-final"
python3 "$r/run-command.py" mac-lazy-final 90 "$r/c1/checkpoint" "$r/mac-lazy-final" lazy-reason
python3 "$r/run-command.py" mac-http-build-final 60 python3 "$r/build-http.py" final
python3 "$r/run-command.py" mac-d-build-final 60 python3 "$r/build-bc.py" final
python3 "$r/run-command.py" mac-overlap-build-final 60 python3 "$r/build-overlap.py" final
export MEDIA_SERVER_GST_CACHE_DIR="$r/gst-cache" MEDIA_SERVER_GST_PLUGIN_PROFILE=headless GST_REGISTRY="$r/registry-final.bin" GST_REGISTRY_1_0="$r/registry-final.bin"
unset GST_PLUGIN_PATH GST_PLUGIN_PATH_1_0 GST_PLUGIN_SYSTEM_PATH GST_PLUGIN_SYSTEM_PATH_1_0 MEDIA_SERVER_GST_MANAGED_REGISTRY MEDIA_SERVER_GST_MANAGED_PLUGIN_PATH MEDIA_SERVER_GST_INPUT_PLUGIN_PATH
source scripts/internal/env_common.sh
media_server_apply_homebrew_gst_env
mkdir "$r/mac-http-final02" "$r/mac-http-stop02" "$r/mac-d-final02" "$r/mac-overlap-final02"
export MEDIA_SERVER_SITE_OPERATIONS_REQUEST_DIAGNOSTIC=1
python3 "$r/run-command.py" mac-http-final02 45 "$r/final-http" "$r/mac-http-final02"
python3 "$r/run-command.py" mac-http-stop02 30 "$r/final-http" "$r/mac-http-stop02" --stop-only
python3 "$r/run-command.py" mac-d-final02 90 "$r/final-bc" "$r/mac-d-final02" --combined-d
python3 "$r/run-command.py" mac-overlap-final02 90 "$r/final-overlap" "$r/mac-overlap-final02" checkpoint
