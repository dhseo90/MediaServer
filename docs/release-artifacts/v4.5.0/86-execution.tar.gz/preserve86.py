from pathlib import Path
import tarfile,hashlib,json,io,stat
r=Path(__file__).parent;out=Path('/Users/dhseo/Workspace/mediaServer/docs/release-artifacts/v4.5.0/86-execution.tar.gz')
allowed={'.json','.log','.patch','.diff','.txt','.py','.sh','.mjs','.h','.cpp','.sha256','.data'}
exclude={'prior-audit.json','prior-approvals.json'}
files=[]
for folder in [r,r/'c1',r/'linux-first',r/'linux-final',r/'linux-final03',r/'linux-complete']:
 for p in folder.iterdir():
  if p.is_file() and not p.is_symlink() and p.suffix in allowed and p.name not in exclude:files.append(p)
store=json.loads((r/'c1-preserved-store.json').read_text())
files += [r/x['path'] for x in store['members']]
files=sorted(set(files),key=lambda x:str(x.relative_to(r)))
records=[]
for p in files:
 assert p.resolve().is_relative_to(r) and not p.is_symlink()
 records.append({'member':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'representation':'original collected bytes'})
manifest={'schema':'media-server.execution-preservation.v1','task':86,'sourceRoot':str(r),'members':records,'excluded':['compiled binaries/runtime/weights','test auth stores and unrelated generated media','rebuildable SQLite/registry/plugin caches','prior applied audit/approval duplicated copies: use prior-bindings.json Git commit/path'],'originalOrSanitized':'All selected members are original task-owned non-sensitive bytes; no invented historical logs. Post-checkpoint generation3 source is distinguished from removed input snapshot2.'}
blob=(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()
assert not out.exists()
with tarfile.open(out,'w:gz',compresslevel=6) as t:
 for p in files:t.add(p,arcname=str(p.relative_to(r)),recursive=False)
 info=tarfile.TarInfo('preservation.json');info.size=len(blob);info.mode=0o600;t.addfile(info,io.BytesIO(blob))
with tarfile.open(out,'r:gz') as t:
 for row in records:
  b=t.extractfile(row['member']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
result={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'originalMembers':len(records),'totalOriginalBytes':sum(x['bytes'] for x in records),'allMembersReadbackVerified':True,'largestOriginalBytes':max(x['bytes'] for x in records)}
(r/'preservation-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
