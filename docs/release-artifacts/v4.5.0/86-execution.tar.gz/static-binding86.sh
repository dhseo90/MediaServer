#!/bin/bash
set -euo pipefail
r=/private/tmp/media-server-memory86-occmd_8c
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r"
for check in verify-v390-review4-feature-semantic-source-audit verify-v390-review4-feature-semantic-source-approvals verify-project-inventory verify-feature-inventory-coverage verify-feature-implementation-evidence verify-script-inventory; do
 python3 "$r/run-command.py" "static-$check" 120 ./server.sh "$check"
done
