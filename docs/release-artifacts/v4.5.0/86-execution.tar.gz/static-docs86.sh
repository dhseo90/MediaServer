#!/bin/bash
set -euo pipefail
r=/private/tmp/media-server-memory86-occmd_8c
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 TMPDIR="$r"
for check in verify-docs-links verify-release-metadata verify-release-evidence-index; do
 python3 "$r/run-command.py" "static-$check" 120 ./server.sh "$check"
done
python3 "$r/run-command.py" static-diff-check 20 git diff --check
