import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';import assert from 'node:assert/strict';
import {runCurrentRecovery,measureCurrentCopy,workspaceBounds} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_current_observer.mjs';
import {snapshotTree,copyVerified} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_archive_diagnostic_profile.mjs';
import {resourceTraceCollector,collectResourceTrace,finishResourceTrace} from '/Users/dhseo/Workspace/mediaServer/scripts/internal/recording_resource_trace.mjs';
const base='/private/tmp/media-server-memory87-4cw818or',prepared=path.join(base,'prepare02'),source=fs.readdirSync(prepared).find(n=>n.startsWith('media-server-current-observer-')),run=path.join(prepared,source),original=path.join(run,'recordings'),tree=snapshotTree(original);
const copyRoot=fs.realpathSync(fs.mkdtempSync(path.join(base,'media-server-current-observer-copy-')));fs.chmodSync(copyRoot,0o700);const st=fs.statSync(copyRoot),copy=path.join(copyRoot,'recordings');copyVerified(original,copy,tree);
let samples=0,peak=0,identity=null;
const result=await runCurrentRecovery({command:path.join(run,'normalize'),args:['--snapshot',copy],env:{PATH:process.env.PATH,TMPDIR:copyRoot,HOME:copyRoot,MEDIA_SERVER_ARCHIVE_PHASE_TRACE:'1',MEDIA_SERVER_VERIFY_RECORDING_RESOURCE_TRACE:'1'},observe:({pid,running})=>{
 const named=measureCurrentCopy(copyRoot,{dev:st.dev,ino:st.ino});let anon=null;
 if(running){const r=spawnSync(path.join(run,'process-metrics'),[String(pid)],{encoding:'utf8',timeout:3000,maxBuffer:16384});assert(!r.error&&!r.signal);const m=JSON.parse(r.stdout);
  if(m.valid){assert.equal(r.status,0);assert.equal(m.pid,pid);if(identity)assert.equal(m.startIdentity,identity);identity=m.startIdentity;anon=Math.max(m.anonymousFileBytes,m.anonymousAllocatedBytes);assert(Number.isSafeInteger(anon));peak=Math.max(peak,anon);samples++;}
  else assert.equal(m.error,'process-exited-or-absent');}
 return {...workspaceBounds(tree.bytes,0,named.bytes+(anon??0),448*1024*1024),anonymousBytes:anon};}});
fs.writeFileSync(path.join(base,'recovery-native.stdout'),result.stdout,{flag:'wx'});fs.writeFileSync(path.join(base,'recovery-native.stderr'),result.stderr,{flag:'wx'});
const collector=resourceTraceCollector(result.pid);collectResourceTrace(collector,Buffer.from(result.stderr));
const evidence={...result,stdout:undefined,stderr:undefined,resource:finishResourceTrace(collector),samples,anonymousPeak:peak,sourceBytes:tree.bytes,sourceUnchanged:snapshotTree(original).sha256===tree.sha256,copyRoot};
fs.writeFileSync(path.join(base,'recovery-observation-result.json'),JSON.stringify(evidence,null,2)+'\n');
assert.equal(result.status,0);assert.equal(result.monitor.failure,null);assert(result.groupClosed&&evidence.sourceUnchanged&&samples>0);assert.equal(JSON.parse(result.stdout).catalogRecovered,true);
console.log(JSON.stringify(evidence));
