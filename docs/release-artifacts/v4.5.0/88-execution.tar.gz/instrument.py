from pathlib import Path
p=Path('include/recording/recording_latency_trace.h');s=p.read_text();anchor='inline void FinishThread() noexcept'
new='''// Visual diagnosis emits bounded start/end records immediately, including a still-running phase.
// Fixed literal names only; no query, path, token or media content. Same process steady clock.
class VisualPhase {
    inline static std::atomic<unsigned> sequence_{0},lines_{0};
    inline static std::atomic<bool> failed_{false};
    inline static thread_local unsigned current_{0};
    const char* name_;unsigned id_=0,parent_=0;bool active_=false;
    void Emit(bool end) noexcept {
        const auto n=lines_.fetch_add(1);
        if(n>=4096){if(!failed_.exchange(true))std::fputs("[visual-phase-loss] cap\\n",stderr);return;}
        char row[256];const int size=std::snprintf(row,sizeof(row),
            "[visual-phase] {\\"id\\":%u,\\"parent\\":%u,\\"thread\\":%u,\\"phase\\":\\"%s\\",\\"end\\":%s,\\"ns\\":%llu}\\n",
            id_,parent_,local.thread,name_,end?"true":"false",(unsigned long long)Now());
        if(size<=0||size>=int(sizeof(row))||std::fwrite(row,1,std::size_t(size),stderr)!=std::size_t(size)){
            failed_=true;std::fputs("[visual-phase-loss] write\\n",stderr);
        }
    }
public:
    static bool Enabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_VISUAL_LATENCY_TRACE");return p&&std::strcmp(p,"1")==0;}();return yes;}
    explicit VisualPhase(const char* name,bool selected=true) noexcept:name_(name){
        if(!(active_=selected&&Enabled()))return;
        id_=++sequence_;parent_=current_;current_=id_;Emit(false);
    }
    void End() noexcept {if(active_){Emit(true);current_=parent_;active_=false;}}
    ~VisualPhase(){End();}
    VisualPhase(const VisualPhase&)=delete;VisualPhase& operator=(const VisualPhase&)=delete;
};
'''
assert anchor in s;s=s.replace(anchor,new+anchor);p.write_text(s)
def edit(n,changes):
 p=Path(n);s=p.read_text()
 if '#include "recording/recording_latency_trace.h"' not in s:s='#include "recording/recording_latency_trace.h"\n'+s
 for a,b in changes:
  assert a in s,(n,a);s=s.replace(a,b)
 p.write_text(s)
edit('src/ingress/visual_search_application_service.cpp',[
 ('temporary=source_.Prepare(doc,error,cancelled_,deadline_);','recording::latency::VisualPhase phase("source-prepare");temporary=source_.Prepare(doc,error,cancelled_,deadline_);'),
 ('if(!source_.ResolvePrepared(doc,*proof,target,error,cancelled_,deadline_))','recording::latency::VisualPhase phase("source-resolve");\n        if(!source_.ResolvePrepared(doc,*proof,target,error,cancelled_,deadline_))'),
 ('std::unique_lock<std::timed_mutex> lock(inference_,std::defer_lock);\n                while','recording::latency::VisualPhase wait("image-inference-wait");\n                std::unique_lock<std::timed_mutex> lock(inference_,std::defer_lock);\n                while'),
 ('if(cancelled())return false;return media->Encode','wait.End();recording::latency::VisualPhase hold("image-inference-held");\n                if(cancelled())return false;return media->Encode'),
 ('ApplicationServiceResult VisualSearchApplicationService::Search(const Query& raw,const Authorize& authorize){','ApplicationServiceResult VisualSearchApplicationService::Search(const Query& raw,const Authorize& authorize){\n    recording::latency::VisualPhase request_phase("visual-search");'),
 ('{std::unique_lock<std::timed_mutex> lock(inference_,std::defer_lock);','{recording::latency::VisualPhase wait("text-inference-wait");\n            std::unique_lock<std::timed_mutex> lock(inference_,std::defer_lock);'),
 ('try{\n                text=encoder_->InspectText','wait.End();recording::latency::VisualPhase hold("text-inference-held");\n            try{\n                text=encoder_->InspectText'),
 ('if(!index->Search(query,eligible,&hits,&error))return Error(503,"visual-search-unavailable");','{recording::latency::VisualPhase phase("index-search-current-sources");\n        if(!index->Search(query,eligible,&hits,&error))return Error(503,"visual-search-unavailable");}'),
 ('std::vector<std::shared_ptr<const recording::ResolvedRecordingMedia>> response_holds;','recording::latency::VisualPhase final_phase("final-source-json");\n        std::vector<std::shared_ptr<const recording::ResolvedRecordingMedia>> response_holds;')])
edit('src/recording/recording_visual_source.cpp',[
 ('VisualRgbFrame frame;\n    if(!DecodeVisualFrame','VisualRgbFrame frame;\n    latency::VisualPhase decode("image-decode");\n    if(!DecodeVisualFrame'),
 ('if(cancelled&&cancelled())return Fail(error,"visual-cancelled");\n    doc->embedding=encoder.EncodeRgb','decode.End();\n    if(cancelled&&cancelled())return Fail(error,"visual-cancelled");\n    doc->embedding=encoder.EncodeRgb')])
edit('src/recording/visual_index_worker.cpp',[
 ('bool VisualIndexWorker::Rebuild(const Cancelled& cancelled,std::string* error){','bool VisualIndexWorker::Rebuild(const Cancelled& cancelled,std::string* error){\n    latency::VisualPhase rebuild("index-rebuild");'),
 ('if(!source_(&docs,&coverage,cancelled,error))return false;','{latency::VisualPhase collect("index-collect");if(!source_(&docs,&coverage,cancelled,error))return false;}'),
 ('if(!store_.Save(*complete,error))return false;','{latency::VisualPhase save("index-save");if(!store_.Save(*complete,error))return false;}')])
edit('src/analysis/siglip2_encoder.cpp',[
 ('const std::lock_guard<std::mutex> guard(impl_->mutex);','recording::latency::VisualPhase wait("encoder-mutex-wait");\n    const std::lock_guard<std::mutex> guard(impl_->mutex);wait.End();\n    recording::latency::VisualPhase hold("encoder-mutex-held");'),
 ('auto ids = impl_->Tokens(value).ids;','recording::latency::VisualPhase tokens("text-tokens");\n    auto ids = impl_->Tokens(value).ids;tokens.End();'),
 ('return Impl::Infer(*impl_->text, "input_ids", input);','recording::latency::VisualPhase run("text-session-run");\n    return Impl::Infer(*impl_->text, "input_ids", input);'),
 ('auto pixels = PreprocessRgb(rgb, width, height, stride);','recording::latency::VisualPhase preprocess("image-preprocess");\n    auto pixels = PreprocessRgb(rgb, width, height, stride);preprocess.End();'),
 ('return Impl::Infer(*impl_->image, "pixel_values", input);','recording::latency::VisualPhase run("image-session-run");\n    return Impl::Infer(*impl_->image, "pixel_values", input);')])
edit('src/ingress/webrtc_http_server_runtime.cpp',[
 ('auto request_opt = ReadHttpRequest(client_fd, &response);','auto request_opt = ReadHttpRequest(client_fd, &response);\n                const bool visual_request=request_opt&&request_opt->method=="GET"&&request_opt->path=="/ops/api/recordings/visual-search";\n                recording::latency::VisualPhase visual_http("http-parsed-through-send",visual_request);'),
 ('response = [&]() -> HttpResponse {','recording::latency::VisualPhase visual_handler("http-auth-handler",visual_request);\n                    response = [&]() -> HttpResponse {'),
 ('site_diagnostic.Emit(SiteOperationsRequestDiagnostic::Phase::HandlerEnd);','visual_handler.End();\n                    site_diagnostic.Emit(SiteOperationsRequestDiagnostic::Phase::HandlerEnd);'),
 ('const bool sent = SendAllObserved(client_fd, encoded, observation.get());','recording::latency::VisualPhase visual_send("http-send",visual_request);\n                    const bool sent = SendAllObserved(client_fd, encoded, observation.get());')])
p=Path('scripts/internal/v450_recording_a_mixed.mjs');s=p.read_text().replace('VERIFY_RECORDING_RESOURCE_TRACE:1,','VERIFY_VISUAL_LATENCY_TRACE:1,VERIFY_RECORDING_RESOURCE_TRACE:1,');p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');s=p.read_text();s+='''\n### MEM88 — 장면 검색과 배경 색인의 응답 예산 (내부/API, UI 비대상)\n\n- 원래 준비의 2장면/2구조화 검색·2채널·30초/180초·5초 요청·기존 p95/최대 기준을 유지한다. 제한 단계 진단은 공유 잠금·파일 준비/decoder·encoder mutex/추론·현재 원본 검증·응답을 구분하며 원문/credential을 출력하지 않는다.\n- 확인된 병목만 수정하고, 고정 latch 순서에서 이전 완성본 검색·새 게시·현재 원본/권한·Stop/실패 수명을 검증한다. 가짜 encoder 반례와 실제 SigLIP2 준비를 구분한다. 소유/메모리 한도·모델/전처리/vector·scan/sample·결과 의미·decoder·시간 상한은 변경하지 않는다.\n- 직접 영향 macOS/비특권 Linux 회귀와 실제 준비를 연결한다. 새120분/전체UI/기존 B/C/D 전체 반복은 실행하지 않는다.\n''';p.write_text(s)
