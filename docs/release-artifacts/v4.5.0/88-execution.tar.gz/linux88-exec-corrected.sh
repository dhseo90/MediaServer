#!/bin/bash
set -euo pipefail
preserve_output() {
 code=$?
 printf '%s\n' "$code" > /tmp/media-server-search88/output/container-exit.txt
 tar -C /tmp/media-server-search88/output -czf - .
 exit "$code"
}
trap preserve_output EXIT
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
r=/tmp/media-server-search88
mkdir -p "$r/repo" "$r/output" "$r/work"
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
ln -s /source/models "$r/repo/models"
cp /helpers/run-command.py /helpers/native88.py "$r/output/"
export TMPDIR="$r/work" GST_REGISTRY="$r/work/registry.bin" GST_REGISTRY_1_0="$r/work/registry.bin"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
cp /helpers/linux-preserved-final/linuxfinal/visual_request_media_cache_smoke "$r/output/cache-smoke"
sha256sum "$r/output/cache-smoke" > "$r/output/binaries.sha256"
mkdir "$r/work/cache-root"
python3 "$r/output/run-command.py" cache-run 90 "$r/output/cache-smoke" "$r/work/cache-root" > "$r/output/cache-console.log" 2>&1
python3 "$r/output/run-command.py" request-proof 600 bash scripts/internal/verify_recording_generation_request_proof.sh > "$r/output/proof-console.log" 2>&1
find "$r/work" -mindepth 1 -maxdepth 1 > "$r/output/remaining-work.txt"
echo 'Linux affected regression complete' > "$r/output/completed.txt"
