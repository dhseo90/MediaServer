#!/bin/bash
set -euo pipefail
preserve_output() {
 code=$?
 printf '%s\n' "$code" > /tmp/linux88-exit
 # 제품/검사의 제한은 각 collector가 적용한다. 종료 뒤 원출력 회수만 기다린다.
 end=$((SECONDS+300))
 while [ ! -e /tmp/linux88-release ] && [ "$SECONDS" -lt "$end" ]; do sleep 1; done
 exit "$code"
}
trap preserve_output EXIT
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
r=/tmp/media-server-search88
mkdir -p "$r/repo" "$r/output" "$r/work"
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
ln -s /source/models "$r/repo/models"
cp /helpers/run-command.py /helpers/native88.py "$r/output/"
export TMPDIR="$r/work" GST_REGISTRY="$r/work/registry.bin" GST_REGISTRY_1_0="$r/work/registry.bin"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/run-command.py" build 600 cmake --build ../build -j2
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
python3 "$r/output/native88.py" ../build "$r/output/linuxnative" recording_retention_smoke recording_search_source_smoke recording_search_application_smoke siglip2_encoder_smoke visual_index_worker_smoke visual_search_application_smoke
python3 "$r/output/run-command.py" cache 150 python3 scripts/internal/verify_visual_request_media_cache.py --build ../build --output "$r/output/cache-result.json"
python3 "$r/output/run-command.py" request-proof 600 bash scripts/internal/verify_recording_generation_request_proof.sh
find "$r/work" -mindepth 1 -maxdepth 1 > "$r/output/remaining-work.txt"
echo 'Linux affected regression complete'
