import pathlib,json,hashlib,re,tarfile,os
r=pathlib.Path(__file__).parent;dest=r/'preserved';dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=[]
def add(p,rel=None):
 if p.is_symlink() or not p.is_file():return
 rel=pathlib.Path(rel or p.relative_to(r));data=p.read_bytes();old=data
 if p.suffix in {'.log','.stdout','.stderr'} or p.name.endswith('.private.log'):
  text=data.decode('utf-8',errors='strict')
  text=re.sub(r'(?:rtsp|rtsps|http|https)://[^\s\"<>]+','<owned-url-redacted>',text)
  data=text.encode()
  if data!=old:rel=rel.with_name(rel.name+'.sanitized')
 if p.suffix in {'.json','.log','.stdout','.stderr','.jsonl'} and any(x in data for x in (b'"passwordHash":',b'"tokenHash":',b'Authorization: Bearer ',b'Set-Cookie:')):
  raise RuntimeError('sensitive candidate: '+str(p))
 target=dest/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest.append({'source':str(p.relative_to(r)),'member':str(rel),'rawBytes':len(old),'rawSha256':sha(old),'preservedBytes':len(data),'preservedSha256':sha(data),'transformation':'replace HTTP(S)/RTSP(S) URLs only' if data!=old else 'none'})
excluded={'prior-audit.json','prior-approvals.json','prior-package-helper.mjs','pre-format-visual-application.cpp','preservation.json'}
for p in sorted(r.iterdir()):
 if p.name in excluded:continue
 if p.is_file() and p.suffix in {'.json','.log','.patch','.py','.sh','.mjs'}:add(p)
for label in ['diagnostic-before','diagnostic-refined','prepare-reservations','prepare-combined','prepare-rowreuse','prepare-structured-diagnostic']:
 run=r/label
 for p in sorted(run.iterdir()):
  if p.is_file():add(p)
 for folder in ['artifacts','receipts']:
  for p in sorted((run/folder).rglob('*')):add(p)
 roots=list(run.glob('media-server-current-observer-*'));assert len(roots)==1
 own=roots[0]
 for p in sorted(own.glob('server-*.private.log')):add(p)
 for p in [own/'seed.json',own/'input/a-seed.mp4',own/'recordings/confirmed-seed.json',own/'recordings/recording-generation.json']:
  if p.exists():add(p)
 # Actual closed synthetic source bindings and retained evidence/records; no users/sessions/model/index cache.
 for p in sorted((own/'recordings').glob('*.jsonl')):
  if p.is_file():add(p)
 for folder in ['evidence-packages','va-reviews','1']:
  for p in sorted((own/'recordings'/folder).rglob('*')):
   if p.suffix in {'.json','.jsonl','.png','.mp4'}:add(p)
for name in ['linux-first','linux-second','linux-resume-first','linux-preserved-final','linux-exec-corrected','macnative','macformat']:
 for p in sorted((r/name).rglob('*')):
  if not any(part.endswith('-root') for part in p.relative_to(r/name).parts) and p.suffix in {'.json','.log','.sha256','.txt'}:add(p)
(dest/'preservation.json').write_text(json.dumps({'schema':'media-server.raw-preservation.v1','scope':'Task88 new selected outputs only. Raw hashes precede URL-only sanitization. Credentials/models/binaries/old archives excluded. Lost Linux tmpfs detailed logs are not reconstructed; actual repeat is separate.','files':manifest},indent=2)+'\n')
print(json.dumps({'files':len(manifest),'bytes':sum(x['preservedBytes'] for x in manifest),'transformed':sum(x['transformation']!='none' for x in manifest)}))
