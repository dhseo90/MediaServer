from pathlib import Path
import json,hashlib,re,os
root=Path(__file__).parent;r=root/'mixed120';obs=next(r.glob('media-server-current-observer-*'));stage=root/'preserved';stage.mkdir(exist_ok=True)
selected=[root/'preflight.json',root/'analysis.json',root/'actual-seed-manifest.json',root/'summarize.py',root/'preserve.py',root/'launcher.log']
selected += [p for p in r.rglob('*') if p.is_file() and not p.is_symlink() and obs not in p.parents]
selected += [obs/'server-1.private.log',obs/'seed.json',obs/'catalog-instrumented.cpp',obs/'state/sources.json',obs/'state/views.json']
selected += [p for d in ['input','recordings','record-input'] for p in (obs/d).rglob('*') if p.is_file() and not p.is_symlink()]
manifest={'schema':'media-server.selected-evidence.v1','scope':'Task89 one failed mixed120 attempt; stopped owned synthetic source/store2MiB preserved for exact search/data state. No past archive/model/runtime/auth credential copy.','transform':'Only HTTP(S)/RTSP(S) URLs in text logs replaced with [redacted-local-url]; all other selected bytes unchanged. Original hash and preserved hash distinct.','files':[],'excluded':['state/users.json (authentication hashes)','runtime/helper binaries (source+hash retained)','gst-cache linked plugins and registry','model weights','past archives']}
url=re.compile(r'(?:https?|rtsps?)://[^\s"\x27<>\\]+')
for p in sorted(set(selected)):
 assert p.is_file() and not p.is_symlink() and p.stat().st_uid==501
 rel=str(p.relative_to(root));raw=p.read_bytes();out=raw;transform='none'
 if p.suffix in ['.log','.stdout','.stderr']:
  s=raw.decode('utf-8');t=url.sub('[redacted-local-url]',s)
  if t!=s:out=t.encode();transform='url-only'
 # Credentials must never enter chosen raw evidence.
 if p.suffix not in ['.py','.cpp'] and (b'passwordHash' in out or b'passwordHistory' in out or b'tokenHash' in out or b'Authorization: Bearer' in out):raise Exception('credential content '+rel)
 dest=stage/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(out)
 manifest['files'].append({'path':rel,'rawBytes':len(raw),'rawSha256':hashlib.sha256(raw).hexdigest(),'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),'transform':transform})
(stage/'preservation.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(manifest['files']),'bytes':sum(v['bytes'] for v in manifest['files']),'transforms':[v['path'] for v in manifest['files'] if v['transform']!='none']}))
