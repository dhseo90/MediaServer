#!/bin/bash
set -euo pipefail
r=/tmp/media-server-search90
mkdir -p "$r/repo" "$r/output" "$r/work"
preserve_output() { code=$?; printf '%s\n' "$code" > "$r/output/container-exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap preserve_output EXIT
export MEDIA_SERVER_SKIP_LOCAL_ENV=1
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
ln -s /source/models "$r/repo/models"
cp /helpers/run-command.py /helpers/native88.py "$r/output/"
export TMPDIR="$r/work" GST_REGISTRY="$r/work/registry.bin" GST_REGISTRY_1_0="$r/work/registry.bin"
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/run-command.py" build 600 cmake --build ../build -j2 > "$r/output/build-console.log" 2>&1
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
python3 scripts/internal/verify_recording_search_scope.py --build ../build --output "$r/output/scope" > "$r/output/scope-console.log" 2>&1
python3 "$r/output/native88.py" ../build "$r/output/native" recording_search_seek_smoke recording_search_derived_seek_smoke > "$r/output/native-console.log" 2>&1
python3 "$r/output/run-command.py" request-proof 600 bash scripts/internal/verify_recording_generation_request_proof.sh > "$r/output/proof-console.log" 2>&1
printf 'Linux affected regression complete\n' > "$r/output/completed.txt"
