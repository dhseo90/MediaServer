from pathlib import Path
p=Path('include/recording/recording_latency_trace.h');s=p.read_text();anchor='inline std::atomic<unsigned> next_thread'
insert=r'''// 요청별 비용 요약: 고정 배열만 사용. 각 phase는 inclusive이며 부모/자식을 합산하지 않는다.
// 단계 번호는 Names 순서, counters는 prepared/reused/evicted/eligible/scored/returned.
class VisualRequestSummary {
public:
    inline static constexpr const char* Names[]={"visual-search","text-inference-wait","text-inference-held","encoder-mutex-wait","encoder-mutex-held","text-tokens","text-session-run","index-search-current-sources","source-prepare","source-resolve","prepare-binding","prepare-media-inspect","seek-current-source-media","final-source-json","vector-score","eligible","prepare-file-proof"};
    inline static thread_local VisualRequestSummary* current=nullptr;
private:
    inline static std::atomic<unsigned> sequence{0};
    inline static std::atomic<bool> loss{false};
    bool active_=false;unsigned id_=0,status_=503;const char* reason_="exception";
    std::uint64_t start_=0,generation_=0,documents_=0;
    std::array<std::uint64_t,17> count_{},ns_{};
    std::array<std::uint64_t,6> counters_{};
    std::array<std::uint64_t,5> locks_{},wait_{},held_{};
    static void Loss() noexcept {if(!loss.exchange(true)){std::fputs("[visual-request-loss] collection\n",stderr);std::fflush(stderr);}}
public:
    static bool Enabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_VISUAL_REQUEST_TRACE");return p&&std::strcmp(p,"1")==0;}();return yes;}
    VisualRequestSummary() noexcept {
        if(!Enabled())return;
        id_=++sequence;if(id_==1){std::fputs("[visual-request-probe] 1\n",stderr);std::fflush(stderr);}
        if(id_>1024||current){Loss();return;}active_=true;start_=Now();current=this;
    }
    static void Result(unsigned status,const char* reason) noexcept {if(current){current->status_=status;current->reason_=reason;}}
    static void Index(std::uint64_t generation,std::uint64_t docs) noexcept {if(current){current->generation_=generation;current->documents_=docs;}}
    static void Count(unsigned counter,std::uint64_t n=1) noexcept {if(current&&counter<6)current->counters_[counter]+=n;}
    static void Phase(const char* name,std::uint64_t elapsed) noexcept {if(!current)return;for(unsigned i=0;i<17;++i)if(std::strcmp(name,Names[i])==0){++current->count_[i];current->ns_[i]+=elapsed;return;}}
    static void LockCost(const Row& r) noexcept {if(current&&r.k==0&&r.s>=1&&r.s<=5){const auto i=r.s-1;++current->locks_[i];current->wait_[i]+=r.w;current->held_[i]+=r.h;}}
    ~VisualRequestSummary() noexcept {
        if(!active_)return;
        current=nullptr;char text[3072];std::size_t used=0;bool valid=true;
        const auto add=[&](const char* format,auto... values){if(!valid)return;const int n=std::snprintf(text+used,sizeof(text)-used,format,values...);if(n<0||std::size_t(n)>=sizeof(text)-used){valid=false;return;}used+=std::size_t(n);};
        // reason is a fixed application code, never exception.what/query/path.
        add("[visual-request] {\"id\":%u,\"status\":%u,\"code\":\"%s\",\"startNs\":%llu,\"elapsedNs\":%llu,\"generation\":%llu,\"documents\":%llu,\"phases\":[",id_,status_,reason_,(unsigned long long)start_,(unsigned long long)(Now()-start_),(unsigned long long)generation_,(unsigned long long)documents_);
        for(unsigned i=0;i<17;++i)add("%s[%llu,%llu]",i?",":"",(unsigned long long)count_[i],(unsigned long long)ns_[i]);
        add("],\"counters\":[");for(unsigned i=0;i<6;++i)add("%s%llu",i?",":"",(unsigned long long)counters_[i]);
        add("],\"locks\":[");for(unsigned i=0;i<5;++i)add("%s[%llu,%llu,%llu]",i?",":"",(unsigned long long)locks_[i],(unsigned long long)wait_[i],(unsigned long long)held_[i]);
        add("]}\n");if(!valid||std::fwrite(text,1,used,stderr)!=used||std::fflush(stderr)!=0)Loss();
    }
    VisualRequestSummary(const VisualRequestSummary&)=delete;VisualRequestSummary& operator=(const VisualRequestSummary&)=delete;
};
'''
s=s.replace(anchor,insert+anchor);s=s.replace('if(SlowOnly()){SlowTail().Add(row);return;}','VisualRequestSummary::LockCost(row);\n    if(SlowOnly()){SlowTail().Add(row);return;}')
s=s.replace('const char* name_;unsigned id_=0,parent_=0;bool active_=false;','const char* name_;unsigned id_=0,parent_=0;bool active_=false;std::uint64_t summaryStart_=0;bool summary_=false;')
s=s.replace('if(!(active_=selected&&Enabled()))return;','summary_=selected&&VisualRequestSummary::current;if(summary_)summaryStart_=Now();\n        if(!(active_=selected&&Enabled()))return;')
s=s.replace('void End() noexcept {if(active_){','void End() noexcept {if(summary_){VisualRequestSummary::Phase(name_,Now()-summaryStart_);summary_=false;}if(active_){');p.write_text(s)
p=Path('src/ingress/visual_search_application_service.cpp');s=p.read_text().replace('ApplicationServiceResult Error(int status,const char* reason){return','ApplicationServiceResult Error(int status,const char* reason){recording::latency::VisualRequestSummary::Result(status,reason);return');s=s.replace('recording::latency::VisualPhase request_phase("visual-search");','recording::latency::VisualRequestSummary request_summary;\n    recording::latency::VisualPhase request_phase("visual-search");')
s=s.replace('++reused_;','++reused_;recording::latency::VisualRequestSummary::Count(1);').replace('++prepared_;','++prepared_;recording::latency::VisualRequestSummary::Count(0);').replace('entries_.erase(oldest);','entries_.erase(oldest);recording::latency::VisualRequestSummary::Count(2);')
s=s.replace('std::vector<recording::VisualSnapshotEvent> events;\n        if(!EventFacts','recording::latency::VisualRequestSummary::Index(view.publication&&view.publication->generation?*view.publication->generation:0,index->documents().size());\n        std::vector<recording::VisualSnapshotEvent> events;\n        if(!EventFacts',1)
s=s.replace('const auto eligible=[&](const auto& doc){','const auto eligible=[&](const auto& doc){\n            recording::latency::VisualPhase phase("eligible");recording::latency::VisualRequestSummary::Count(3);')
s=s.replace('return {200,"OK",out.str()};\n    }catch(const std::exception&){return Error(503,"visual-search-unavailable");}\n}\nApplicationServiceResult VisualSearchApplicationService::Seek','recording::latency::VisualRequestSummary::Count(5,hits.size());recording::latency::VisualRequestSummary::Result(200,"ok");\n        return {200,"OK",out.str()};\n    }catch(const std::exception&){return Error(503,"visual-search-unavailable");}\n}\nApplicationServiceResult VisualSearchApplicationService::Seek');p.write_text(s)
p=Path('src/recording/visual_search_index.cpp');s=p.read_text();s='#include "recording/recording_latency_trace.h"\n'+s;s=s.replace('double score = 0;','latency::VisualPhase scoring("vector-score");latency::VisualRequestSummary::Count(4);\n            double score = 0;').replace('score = std::clamp(score, -1.0, 1.0);','score = std::clamp(score, -1.0, 1.0);scoring.End();');p.write_text(s)
p=Path('scripts/internal/v450_recording_a_mixed.mjs');s=p.read_text().replace('VERIFY_RECORDING_SEARCH_TRACE:1,','VERIFY_VISUAL_REQUEST_TRACE:1,VERIFY_RECORDING_SEARCH_TRACE:1,');p.write_text(s)
p=Path('docs/project-feature-test-inventory.md');s=p.read_text().replace('| V430-A01-APP |','| V430-A01-APP | 요청-local 고정 단계 요약(전체1024×3072B상한, 손실은FAIL), 실제동시모델/현재원본경계 비용대조·동일top-k/권한·수명 직접 회귀와 기존600초 원래p95/max gate 유지. ');p.write_text(s)
