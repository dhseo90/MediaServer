// Fixed closed input, real product RequestMedia, no model/HTTP performance claim.
#include "recording/recording_runtime_composition.h"
#include "visual_request_media_cache_under_test.cpp"
#include <iostream>
#include <iomanip>
#include <fcntl.h>
#include <unistd.h>
int Fds(){int n=0;for(int fd=0;fd<4096;++fd)if(fcntl(fd,F_GETFD)!=-1)++n;return n;}
int main(int argc,char** argv)try{
 if(argc!=2)return 2;std::string error;recording::RecordingRuntimeStorage runtime(argv[1]);
 if(!runtime.Open(&error))throw std::runtime_error(error);
 std::vector<recording::VisualSearchDocument> docs;
 auto ids=runtime.catalog().FinalizedSegmentIdsForStartup();std::sort(ids.begin(),ids.end());
 for(const auto& id:ids){auto segment=runtime.catalog().FindSegmentV2ById(id);auto binding=runtime.catalog().FindSourceBinding(id);std::vector<recording::VisualSearchDocument> selected;
 if(!segment||!binding)continue;
 if(!recording::RecordingVisualSource::SelectSamples(*segment,*binding,1,&selected,&error)||selected.empty())throw std::runtime_error(error);
 docs.push_back(selected.front());}
 if(docs.empty()||docs.size()>200)throw std::runtime_error("fixed input admission");
 recording::RecordingReadService reader(runtime.catalog());recording::RecordingVisualSource source(runtime.catalog(),reader);
 const auto baseline=Fds();
 for(int iteration=0;iteration<3;++iteration){
  {recording::latency::VisualRequestSummary summary;recording::latency::VisualPhase phase("visual-search",true,false);
   ingress::RequestMedia cache(source,{},std::chrono::steady_clock::now()+std::chrono::seconds(5));
   for(int pass=0;pass<2;++pass)for(const auto& doc:docs){recording::SearchSeekTarget target;
    if(!cache.Resolve(doc,&target,nullptr,&error))throw std::runtime_error(error);
    std::cout<<"TARGET "<<iteration<<' '<<pass<<' '<<doc.segment_id<<' '<<std::setprecision(17)<<target.seconds<<' '<<target.basis<<'\n';}
   if(cache.bytes_>8U*1024*1024||cache.entries_.size()>200)throw std::runtime_error("cache admission");
   std::cout<<"COST "<<iteration<<" documents="<<docs.size()<<" bytes="<<cache.bytes_<<" prepared="<<cache.prepared_<<" reused="<<cache.reused_<<'\n';
   recording::latency::VisualRequestSummary::Result(200,"ok");}
  if(Fds()!=baseline)throw std::runtime_error("descriptor lifetime");
 }
 if(!runtime.Finish(&error))throw std::runtime_error(error);
 std::cout<<"PASS fixed input source cost and Finish\n";return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
