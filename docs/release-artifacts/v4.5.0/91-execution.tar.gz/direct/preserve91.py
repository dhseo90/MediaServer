import pathlib,json,hashlib,tarfile,io,re
r=pathlib.Path('/private/tmp/media-server-memory91-0g_muxdk');out=pathlib.Path('/private/tmp/media-server-memory91-preserved');out.mkdir(mode=0o700,exist_ok=True);selected={}
def add(p,name):
 assert p.is_file() and not p.is_symlink();assert name not in selected;selected[name]=p
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.log','.json','.py','.sh','.cpp','.sha256']:add(p,'direct/'+p.name)
for folder in ['evidence','mac-direct','fixed-cost','linux91-selected','linux91-second-gcc-fixture-selected']:
 for p in (r/folder).rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(r/folder)
  if any(x.endswith('-data') or x=='gst-cache' for x in rel.parts):continue
  if folder=='evidence' and p.name=='candidate.json':continue
  if folder=='fixed-cost' and p.suffix not in ['.log','.json']:continue
  if p.suffix not in ['.log','.json','.txt','.sha256','.py','.patch']:continue
  add(p,folder+'/'+str(rel))
for mode in ['before30','after30','final-after30','mixed600']:
 run=r/mode;root=next(run.glob('media-server-current-observer-*'))
 for p in run.iterdir():
  if p.is_file():add(p,mode+'/'+p.name)
 for folder in ['artifacts','receipts']:
  for p in (run/folder).rglob('*'):
   if p.is_file():add(p,mode+'/'+folder+'/'+str(p.relative_to(run/folder)))
 for p in root.glob('server-*.private.log'):add(p,mode+'/server/'+p.name.replace('.private.log','.sanitized.log'))
 for p in [root/'seed.json',root/'catalog-instrumented.cpp']:
  if p.is_file():add(p,mode+'/fixture/'+p.name)
 # Current synthetic authority/media; no auth state, model, SDK or derived DB.
 if mode in ['before30','mixed600']:
  for p in (root/'recordings').rglob('*'):
   if not p.is_file() or p.is_symlink() or 'sqlite' in p.name or p.name.endswith(('-wal','-shm')):continue
   if mode=='mixed600' and 'visual-cache' in p.parts:continue
   add(p,mode+'/recordings/'+str(p.relative_to(root/'recordings')))
manifest=[]
for name,p in sorted(selected.items()):
 original=p.read_bytes();data=original;transform='none'
 if name.endswith('.sanitized.log'):
  data=re.sub(rb'(?:https?|rtsp)://[^\s"<>]+',b'[owned-local-url-redacted]',data)
  if data!=original:transform='replace URL tokens only; structured request/frame/resource JSON kept'
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 manifest.append({'member':name,'source':str(p.relative_to(r)),'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'transform':transform})
(out/'preservation.json').write_text(json.dumps({'schema':'task91-selected-bytes-v1','root':str(r),'entries':manifest,'exclusions':['prior90 archive','model/runtime/tool binaries','auth/session state','derived SQLite','duplicate full candidate986; digest and existing apply retained'],'firstLinuxLimitation':'full first noexec archive overwritten; tool-observed error excerpt only; no reconstruction'},ensure_ascii=False,indent=2)+'\n')
archive=pathlib.Path('docs/release-artifacts/v4.5.0/91-execution.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for name in [x['member'] for x in manifest]+['preservation.json']:t.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())=={x['member'] for x in manifest}|{'preservation.json'}
 for row in manifest:
  b=t.extractfile(row['member']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest),'selectedOriginalBytes':sum(x['originalBytes'] for x in manifest),'byteReadback':'PASS'},indent=2))
