import pathlib,hashlib,subprocess,os,json,time
r=pathlib.Path('/private/tmp/media-server-memory91-0g_muxdk');root=next((r/'before30').glob('media-server-current-observer-*'))/'recordings';out=r/'fixed-cost'
# Authority/media bytes only: exclude derived sqlite, lock metadata, scratch.
def hashes():
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and 'sqlite' not in p.name and not p.name.endswith(('-shm','-wal','.lock'))}
initial=hashes();(out/'input-hashes.json').write_text(json.dumps(initial,indent=2));env=os.environ.copy();env.update(MEDIA_SERVER_SKIP_LOCAL_ENV='1',MEDIA_SERVER_VERIFY_VISUAL_REQUEST_TRACE='1',MEDIA_SERVER_VERIFY_RECORDING_LATENCY_TRACE='1',MEDIA_SERVER_VERIFY_RECORDING_SLOW_ONLY='1')
results=[]
for name in ['before','after']:
 t=time.monotonic()
 with (out/(name+'.log')).open('xb') as f:p=subprocess.run([str(out/name),str(root)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 results.append({'variant':name,'exit':p.returncode,'elapsedSeconds':time.monotonic()-t,'inputUnchanged':hashes()==initial})
 (out/'result.json').write_text(json.dumps(results,indent=2));print(results[-1],flush=True)
 if p.returncode or hashes()!=initial:raise SystemExit(1)
lines=lambda name:[x for x in (out/(name+'.log')).read_text().splitlines() if x.startswith(('TARGET ','COST '))]
assert lines('before')==lines('after'),'selected target/cache accounting changed'
print('PASS identical current-source targets and accounting')
