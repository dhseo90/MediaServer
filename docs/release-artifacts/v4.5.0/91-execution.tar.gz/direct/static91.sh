#!/bin/bash
set -euo pipefail
node scripts/internal/verify_v390_ui_native_exact_cases.mjs --update-manifest
node --test scripts/internal/recording_latency_trace.test.mjs scripts/internal/recording_longrun_progress.test.mjs
node --check scripts/internal/v450_recording_a_mixed.mjs
node scripts/internal/verify_feature_inventory_coverage.mjs
git diff --check
