from pathlib import Path
p=Path('include/recording/recording_latency_trace.h');s=p.read_text();pos=s.index('// k: 0=잠금')
s=s[:pos]+'''// Diagnostic-only selected windows. No allocation, output or diagnostic mutex under
// the product lock. Completed intervals are published after unlock; never an owner guess.
enum class Work : unsigned { Other=0, Visual=1, Structured=2, Retention=3, Index=4, Writer=5, Evidence=6 };
inline thread_local Work holder_work=Work::Other;
struct WorkScope {Work previous;explicit WorkScope(Work work):previous(holder_work){holder_work=work;}~WorkScope(){holder_work=previous;}};
inline bool HolderEnabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_CATALOG_HOLDER_TRACE");return p&&std::strcmp(p,"1")==0;}();return yes;}
inline thread_local std::array<std::uint64_t,4> holder_counts{}; // binding checks, cold link calls, visited rows, Journal ReadAt requested bytes
inline void HolderCount(unsigned i,std::uint64_t n=1) noexcept {if(HolderEnabled()&&i<4)holder_counts[i]+=n;}
struct HolderTrace {
    struct Event {std::uint64_t b=0,a=0,e=0;std::array<std::uint64_t,4> counts{};const char* site=nullptr;unsigned m=0,t=0,r=0,line=0,work=0;};
    struct Slot {Event event;std::atomic<bool> ready{false};};
    std::array<Slot,8192> slots{};std::atomic<unsigned> count{0};
    std::array<std::atomic<std::uint64_t>,3> windows{};
    std::atomic<unsigned> inflight{0};std::atomic<bool> loss{false};
    static constexpr unsigned Requests[3]={7,41,77};
    static constexpr std::uint64_t Width=1000000000;
    void Select(unsigned id,std::uint64_t ns) noexcept {for(unsigned i=0;i<3;++i)if(id==Requests[i])windows[i].store(ns,std::memory_order_release);}
    void Add(const Event& e) noexcept {
        bool selected=false;for(const auto& w:windows){const auto b=w.load(std::memory_order_acquire);if(b&&e.b<b+Width&&e.e>b)selected=true;}
        if(!selected)return;
        const auto i=count.fetch_add(1);if(i>=slots.size()){loss=true;return;}
        slots[i].event=e;slots[i].ready.store(true,std::memory_order_release);
    }
    ~HolderTrace() noexcept {
        bool good=!loss.load()&&inflight.load()==0;const unsigned total=count.load();
        for(unsigned i=0;i<total&&i<slots.size();++i){
            if(!slots[i].ready.load(std::memory_order_acquire)){good=false;continue;}
            const auto& e=slots[i].event;char row[320];
            const int n=std::snprintf(row,sizeof(row),"[catalog-holder] {\\"id\\":%u,\\"m\\":%u,\\"t\\":%u,\\"r\\":%u,\\"l\\":%u,\\"work\\":%u,\\"site\\":\\"%s\\",\\"b\\":%llu,\\"a\\":%llu,\\"e\\":%llu,\\"counts\\":[%llu,%llu,%llu,%llu]}\\n",i+1,e.m,e.t,e.r,e.line,e.work,e.site?e.site:"unknown",(unsigned long long)e.b,(unsigned long long)e.a,(unsigned long long)e.e,(unsigned long long)e.counts[0],(unsigned long long)e.counts[1],(unsigned long long)e.counts[2],(unsigned long long)e.counts[3]);
            if(n<=0||n>=int(sizeof(row))||std::fwrite(row,1,std::size_t(n),stderr)!=std::size_t(n))good=false;
        }
        if(std::fprintf(stderr,"[catalog-holder-end] {\\"version\\":1,\\"records\\":%u,\\"loss\\":%s,\\"inflight\\":%u,\\"endNs\\":%llu,\\"widthNs\\":%llu,\\"windows\\":[%llu,%llu,%llu]}\\n",total,good?"false":"true",inflight.load(),(unsigned long long)Now(),(unsigned long long)Width,(unsigned long long)windows[0].load(),(unsigned long long)windows[1].load(),(unsigned long long)windows[2].load())<0||std::fflush(stderr)!=0){std::fputs("[catalog-holder-loss] write\\n",stdout);std::fflush(stdout);}
    }
};
inline HolderTrace& Holder() noexcept {static HolderTrace value;return value;}
''' +s[pos:]
s=s.replace('static bool Enabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_VISUAL_REQUEST_TRACE")','static unsigned CurrentId() noexcept {return current?current->id_:0;}\n    static bool Enabled() noexcept {static const bool yes=[] {const char* p=std::getenv("MEDIA_SERVER_VERIFY_VISUAL_REQUEST_TRACE")',1)
s=s.replace('active_=true;start_=Now();current=this;','active_=true;start_=Now();current=this;if(HolderEnabled())Holder().Select(id_,start_);',1)
s=s.replace('bool owned_=false,always_;Lock* enclosing_=nullptr;','bool owned_=false,always_;Lock* enclosing_=nullptr;\n    bool holder_=false;const char* site_=nullptr;HolderTrace::Event event_;std::array<std::uint64_t,4> begin_counts_{};')
s=s.replace('mutex_.lock();owned_=true;','mutex_.lock();owned_=true;',1)
s=s.replace('if(enabled_){row_.a=Now();previous_=local.mutex;local.mutex=row_.m;++local.depth;}','if(enabled_){row_.a=Now();previous_=local.mutex;local.mutex=row_.m;++local.depth;}\n        if(holder_){event_.b=row_.b;event_.a=row_.a;event_.m=row_.m;event_.t=local.thread;event_.r=VisualRequestSummary::CurrentId();event_.line=row_.l;event_.site=site_;event_.work=static_cast<unsigned>(holder_work);begin_counts_=holder_counts;}',1)
s=s.replace('mutex_.unlock();owned_=false;','if(holder_){event_.e=row_.e;for(unsigned i=0;i<4;++i)event_.counts[i]=holder_counts[i]-begin_counts_[i];}\n        mutex_.unlock();owned_=false;\n        if(holder_){Holder().Add(event_);--Holder().inflight;}',1)
s=s.replace('if(enabled_){row_.b=Now();row_.e=0;}','if(holder_)++Holder().inflight;\n        if(enabled_){row_.b=Now();row_.e=0;}',1)
s=s.replace('bool always=false):mutex_(mutex),enabled_(Enabled()),always_(always){','bool always=false,const char* site=nullptr):mutex_(mutex),enabled_(Enabled()),always_(always),holder_(Enabled()&&HolderEnabled()&&source==Source::Catalog),site_(site){',1)
# Try-lock preserves original status semantics, no blocking/acquisition policy change.
needle='    ~Lock() noexcept {Release();current_=enclosing_;}'
s=s.replace(needle,'''    Lock(std::mutex& mutex,Source source,unsigned line,std::try_to_lock_t,const char* site):mutex_(mutex),enabled_(Enabled()),always_(false),holder_(Enabled()&&HolderEnabled()&&source==Source::Catalog),site_(site){
        if(enabled_){row_.o=1;row_.s=static_cast<unsigned>(source);row_.l=line;row_.m=MutexId(&mutex);row_.b=Now();}
        owned_=mutex_.try_lock();
        if(owned_){if(enabled_){row_.a=Now();previous_=local.mutex;local.mutex=row_.m;++local.depth;}
            if(holder_){++Holder().inflight;event_.b=row_.b;event_.a=row_.a;event_.m=row_.m;event_.t=local.thread;event_.r=VisualRequestSummary::CurrentId();event_.line=line;event_.site=site_;event_.work=static_cast<unsigned>(holder_work);begin_counts_=holder_counts;}}
        enclosing_=current_;current_=this;
    }
    bool owns_lock()const noexcept{return owned_;}
'''+needle)
p.write_text(s)
p=Path('src/recording/recording_catalog.cpp');s=p.read_text().replace('Source::Catalog,__LINE__);','Source::Catalog,__LINE__,false,__func__);')
# above affects ONLY Lock? revert Scope/Visual unmatched? Scope(...__LINE__) also matches -> bad: fix lines without latency::Lock
s='\n'.join(l.replace('Source::Catalog,__LINE__,false,__func__);','Source::Catalog,__LINE__);') if 'latency::Lock ' not in l else l for l in s.split('\n'))
s=s.replace('std::unique_lock<std::mutex> lock(mu_,std::try_to_lock);','recording::latency::Lock lock(mu_,recording::latency::Source::Catalog,__LINE__,std::try_to_lock,__func__);')
start=s.index('RetentionSnapshot RecordingCatalog::RetentionSnapshotLocked()');end=s.index('RetentionSnapshot RecordingCatalog::RetentionSnapshot()',start)
part=s[start:end].replace('for(const auto& [id,v]:segments_v2_) {','for(const auto& [id,v]:segments_v2_) {\n        recording::latency::HolderCount(2);').replace('for (const auto& [segment_id, segment] : segments_) {','for (const auto& [segment_id, segment] : segments_) {\n        recording::latency::HolderCount(2);')
s=s[:start]+part+s[end:];p.write_text(s)
for file in ['recording_catalog_snapshot_export.cpp','recording_catalog_cutover_candidate.cpp']:
 p=Path('src/recording')/file;s=p.read_text();s='#include "recording/recording_latency_trace.h"\n'+s
 s=s.replace('std::lock_guard<std::mutex> lock(mu_);','recording::latency::Lock lock(mu_,recording::latency::Source::Catalog,__LINE__,false,__func__);').replace('std::lock_guard lock(mu_);','recording::latency::Lock lock(mu_,recording::latency::Source::Catalog,__LINE__,false,__func__);');p.write_text(s)
p=Path('src/recording/recording_journal.cpp');s=p.read_text();s='#include "recording/recording_latency_trace.h"\n'+s
s=s.replace('bool RecordingJournal::CheckManagedFdStateLocked(std::string* error) const {','bool RecordingJournal::CheckManagedFdStateLocked(std::string* error) const {\n    latency::HolderCount(0);')
s=s.replace('std::string* error,const void* owner,std::shared_ptr<ColdReadProof>* proof) const {','std::string* error,const void* owner,std::shared_ptr<ColdReadProof>* proof) const {\n    latency::HolderCount(1);')
s=s.replace('bool ReadAt(int fd, off_t start, std::string* bytes) {','bool ReadAt(int fd, off_t start, std::string* bytes) {\n    latency::HolderCount(3,bytes->size());');p.write_text(s)
# Caller classification is a fixed enum, nested scopes restore their caller.
for file,func,work in [('src/ingress/visual_search_application_service.cpp','VisualSearchApplicationService::Search','Visual'),('src/recording/visual_index_worker.cpp','VisualIndexWorker::Rebuild','Index'),('src/recording/recording_read_service.cpp','RecordingReadService::QueryTimelineImpl','Structured'),('src/recording/evidence_package_builder.cpp','EvidencePackageBuilder::CreateImpl','Evidence'),('src/recording/retention_coordinator.cpp','RetentionCoordinator::RunPeriodic','Retention'),('src/recording/retention_coordinator.cpp','RetentionCoordinator::ReadSnapshot','Retention')]:
 p=Path(file);s=p.read_text();idx=s.index('{',s.index(func));s=s[:idx+1]+'\n    recording::latency::WorkScope holder_work_scope(recording::latency::Work::'+work+');'+s[idx+1:]
 if '#include "recording/recording_latency_trace.h"' not in s:s='#include "recording/recording_latency_trace.h"\n'+s
 p.write_text(s)
p=Path('scripts/internal/v450_recording_a_mixed.mjs');s=p.read_text().replace('VERIFY_VISUAL_REQUEST_TRACE:1,','VERIFY_CATALOG_HOLDER_TRACE:diagnose?1:0,VERIFY_VISUAL_REQUEST_TRACE:1,');p.write_text(s)
