import pathlib,json,math,statistics
r=pathlib.Path(__file__).parent
for mode in ['diagnostic600','final600']:
 run=r/mode
 if not (run/'execution.json').exists():continue
 summary=None
 for line in (run/'run.log').read_text().splitlines():
  if '"resources":' in line and '"processesClosed":' in line:summary=json.loads(line[line.index('{'):])
 if summary is None:continue
 root=next(run.glob('media-server-current-observer-*')); trace=json.loads(next(root.glob('catalog-holders-*.json')).read_text())
 requests=[]
 for line in (root/'server-1.private.log').read_text().splitlines():
  if line.startswith('[visual-request] '):requests.append(json.loads(line.split(' ',1)[1]))
 a=sorted(summary['evidenceLoad']['searchLatencyMs']); windows=[]
 for w in trace['windows']:
  retention=[(k,v) for k,v in w['held'].items() if k.startswith('3:RetentionSnapshot:')]
  windows.append({'selectedRequest':w['selectedRequest'],'waitMs':w['waitNs']/1e6,'unclassifiedMs':w['unclassifiedNs']/1e6,'retention':retention,'overlapByHolderMs':{k:v/1e6 for k,v in w['overlapByHolder'].items()}})
 populated=[q for q in requests if q['status']==200 and q['documents']>1];first=min(q['startNs'] for q in requests)
 periods=[]
 for lo,hi in [(0,200),(200,400),(400,610)]:
  rows=[q for q in populated if lo<=(q['startNs']-first)/1e9<hi]
  periods.append({'seconds':[lo,hi],'count':len(rows),'documents':sorted(set(q['documents'] for q in rows)),'meanElapsedMs':statistics.mean(q['elapsedNs']/1e6 for q in rows) if rows else None,'meanCatalogWaitMs':statistics.mean(q['locks'][0][1]/1e6 for q in rows) if rows else None,'meanCatalogHeldMs':statistics.mean(q['locks'][0][2]/1e6 for q in rows) if rows else None,'meanTextRunMs':statistics.mean(q['phases'][6][1]/1e6 for q in rows) if rows else None})
 result={'mode':mode,'gatePopulation':'original successful search array; no A/helper requests added','searchCount':len(a),'p95Ms':a[math.ceil(len(a)*.95)-1],'maxMs':max(a),'failures':summary['failed'],'passed':summary['passed'],'elapsedMs':summary['elapsedMs'],'verifiedDurationMs':summary['verifiedDurationMs'],'frameDiagnosticPass':summary['frameDiagnosticPass'],'searchUnavailable':summary['evidenceLoad']['searchUnavailable'],'aCompleted':len(summary['aLoad']['completed']),'windows':windows,'periods':periods,'limits':['3 selected1s windows; no full600 holder census','inclusive phases not summed','other work0 and residual are not attributed','Journal bytes omit history-index IO; controlled node counts are logical not physical IO','cross-run seed/store/timing may differ'],'processesClosed':summary['processesClosed'],'udpClosed':summary['udpClosed']}
 (r/'evidence'/f'{mode}-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ['windows','periods','limits']}))
