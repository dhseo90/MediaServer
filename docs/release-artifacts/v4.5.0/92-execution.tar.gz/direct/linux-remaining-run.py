import subprocess,pathlib,time,json,hashlib,tarfile,os
r=pathlib.Path(__file__).parent
name="media-server-memory92-linux-remaining"
cmd=["docker","run","--name",name,"--network","none","--user","10001:10001","--cpus","2","--memory","4g","--tmpfs","/tmp:rw,exec,size=3g,uid=10001,gid=10001,mode=1777","-v","/Users/dhseo/Workspace/mediaServer:/source:ro","-v",str(r)+":/helpers:ro","sha256:ce72c8a15363984da642e9964189957896812061c6af1d0ef67e87b38ad5a588","bash","/helpers/linux92-remaining.sh"]
archive=r/"linux92-attempt2.tar.gz";err=r/"linux92-attempt2.stderr";start=time.monotonic()
with archive.open("xb") as out,err.open("xb") as e:
 p=subprocess.run(cmd,stdout=out,stderr=e,timeout=1200)
record={"command":cmd,"exit":p.returncode,"elapsedSeconds":time.monotonic()-start,"bytes":archive.stat().st_size,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest()}
with tarfile.open(archive) as t:
 members=t.getmembers(); record["members"]=[{"name":m.name,"bytes":m.size,"sha256":hashlib.sha256(t.extractfile(m).read()).hexdigest()} for m in members if m.isfile()]
 record["containerExit"]=t.extractfile("./container-exit.txt").read().decode()
with (r/"linux92-attempt2.json").open("x") as f:json.dump(record,f,indent=2)
print(json.dumps({k:v for k,v in record.items() if k!="members"}),flush=True)
raise SystemExit(p.returncode)
