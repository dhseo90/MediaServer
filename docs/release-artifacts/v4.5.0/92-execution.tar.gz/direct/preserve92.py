import pathlib,json,hashlib,tarfile,re
r=pathlib.Path(__file__).parent;out=r/'preserved92';out.mkdir(mode=0o700);selected={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and name not in selected
 selected[name]=p
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.log','.json','.py','.sh','.cpp','.sha256','.stderr']:add(p,'direct/'+p.name)
for folder in ['evidence','mac-native','mac-remaining','retention-before-native','retention-before2-native','retention-after-native','linux92-attempt1-selected','linux92-attempt2-selected']:
 for p in (r/folder).rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(r/folder)
  if any(x.endswith('-data') or x=='gst-cache' for x in rel.parts):continue
  if p.name=='candidate.json':continue
  if p.suffix in ['.log','.json','.txt','.sha256','.py','.patch','.cpp']:add(p,folder+'/'+str(rel))
for mode in ['diagnostic600','final600']:
 run=r/mode;root=next(run.glob('media-server-current-observer-*'))
 for p in run.iterdir():
  if p.is_file():add(p,mode+'/'+p.name)
 for folder in ['artifacts','receipts']:
  for p in (run/folder).rglob('*'):
   if p.is_file():add(p,mode+'/'+folder+'/'+str(p.relative_to(run/folder)))
 for p in root.glob('server-*.private.log'):add(p,mode+'/server/'+p.name.replace('.private.log','.sanitized.log'))
 for p in root.glob('catalog-holders-*.json'):add(p,mode+'/server/'+p.name)
 for p in [root/'seed.json',root/'catalog-instrumented.cpp']:
  if p.is_file():add(p,mode+'/fixture/'+p.name)
 for p in (root/'recordings').rglob('*'):
  if not p.is_file() or p.is_symlink() or 'sqlite' in p.name or p.name.endswith(('-wal','-shm')) or 'visual-cache' in p.parts:continue
  add(p,mode+'/recordings/'+str(p.relative_to(root/'recordings')))
# Only the independently selected synthetic input from the controlled comparison, no whole scratch/binary copy.
for folder in ['retention-before2-native','retention-after-native']:
 for p in (r/folder).rglob('input.mp4'):add(p,folder+'/input/'+str(p.relative_to(r/folder)))
manifest=[]
for name,p in sorted(selected.items()):
 original=p.read_bytes();data=original;transform='none'
 if name.endswith('.sanitized.log'):
  data=re.sub(rb'(?:https?|rtsp)://[^\s"<>]+',b'[owned-local-url-redacted]',data)
  if data!=original:transform='URL token redaction only; structured holder/request/frame/resource records unchanged'
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(data)
 manifest.append({'member':name,'source':str(p.relative_to(r)),'originalBytes':len(original),'originalSha256':hashlib.sha256(original).hexdigest(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'transform':transform})
with (out/'preservation.json').open('x') as f:json.dump({'schema':'task92-selected-bytes-v1','entries':manifest,'exclusions':['prior91 archive','model/SDK/runtime/test binaries','auth/session state','derivedSQLite','duplicate986 candidate','full Linux transport tars (selected original logs and receipts retained)'],'firstLinux92':'first GCC failure logs preserved; first91 noexec whole archive already lost, not reconstructed'},f,ensure_ascii=False,indent=2)
archive=pathlib.Path('docs/release-artifacts/v4.5.0/92-execution.tar.gz')
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:
  for name in [x['member'] for x in manifest]+['preservation.json']:t.add(out/name,arcname=name,recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())=={x['member'] for x in manifest}|{'preservation.json'}
 for row in manifest:
  b=t.extractfile(row['member']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest)+1,'byteReadback':'PASS'}
with (r/'preservation-readback.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
