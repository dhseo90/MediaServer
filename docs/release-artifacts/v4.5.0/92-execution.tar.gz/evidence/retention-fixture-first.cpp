// 실제 원본 append/삭제로 이력만 증가시킨 뒤 같은 retention 후보의 비용을 비교한다.
#define main RetentionCostMediaFixtureMain
#include "recording_file_evidence_smoke.cpp"
#undef main
#include "recording/recording_latency_trace.h"
#include <set>

int main(int argc,char** argv) try {
    if(argc!=2)return 2;
    gst_init(nullptr,nullptr);const std::filesystem::path root=argv[1];
    auto input=Encode(12,false,false);const auto original=Record(root/"input",input).at(0);
    std::string error;std::map<std::string,std::string> expected;
    {
        Store store(root/"store");
        const auto add=[&](const std::string& id){
            auto o=original;o.root=store.root;o.file=store.root/(id+".mp4");
            o.segment.segment_id=id;o.segment.order_request_id="order-"+id;o.binding.segment_id=id;
            RecordingOrderReservationV1 order;
            Check(store.catalog.ReserveRecordingOrder("probe-store",o.segment.order_request_id,id,o.segment.channel_id,&order,&error),"R92 reserve "+error);
            o.segment.order_sequence=order.sequence;
            std::filesystem::copy_file(original.file,o.file);
            Check(store.catalog.FinalizeBoundSegmentV2(o.segment,o.binding,o.file.string(),&error),"R92 finalize "+error);
            return o;
        };
        for(unsigned i=0;i<16;++i){const auto o=add("keep-"+std::to_string(i));expected.emplace(o.segment.segment_id,SerializeRecordingSegmentV2(o.segment));}
        const auto measure=[&](unsigned history){
            for(unsigned round=0;round<6;++round){
                latency::history_node_reads=0;const auto begin=Clock::now();
                const auto snapshot=store.catalog.RetentionSnapshot();const auto elapsed=Us(begin);
                const auto nodes=latency::history_node_reads;
                Check(snapshot.authoritative&&snapshot.candidates.size()==16,"R92 exact active count");
                std::set<std::string> seen;
                for(const auto& row:snapshot.candidates){
                    Check(row.segment_v2&&expected.at(row.segment_v2->segment_id)==SerializeRecordingSegmentV2(*row.segment_v2)&&
                        row.effective_lifecycle==RecordingLifecycle::Finalized&&row.hold_count==0&&
                        row.media_path==store.root/(row.segment_v2->segment_id+".mp4")&&seen.insert(row.segment_v2->segment_id).second,"R92 independent active row");
                }
                if(round){const auto scratch=store.catalog.ScratchResidency()->usage();
                    std::cout<<"[retention-cost] {\"history\":"<<history<<",\"active\":16,\"round\":"<<round<<",\"us\":"<<elapsed
                        <<",\"nodeReads\":"<<nodes<<",\"ownedRam\":"<<store.catalog.SearchResidency()->used()
                        <<",\"scratchBytes\":"<<scratch.disk_bytes<<",\"scratchFd\":"<<scratch.file_descriptors<<"}"<<std::endl;}
            }
        };
        measure(0);
        for(unsigned i=0;i<128;++i){
            const auto o=add("gone-"+std::to_string(i));
            Check(store.catalog.RequestDeletion(o.segment.segment_id,"continuous-age",&error),"R92 deletion intent "+error);
            Check(std::filesystem::remove(o.file),"R92 own media removed");
            RecordingTombstoneV2 tomb;tomb.tombstone_id="tomb-"+o.segment.segment_id;tomb.segment=o.segment;tomb.deleted_at_ms=1000+i;tomb.deletion_reason="continuous-age";
            Check(store.catalog.CompleteDeletionV2(tomb,&error)&&store.catalog.IsDeletedSegmentId(o.segment.segment_id),"R92 exact durable deletion "+error);
            if(i==31||i==127)measure(i+1);
        }
        Check(store.catalog.AdjustHoldCount("keep-0",1,&error),"R92 hold");
        const auto held=store.catalog.RetentionSnapshot();
        const auto row=std::find_if(held.candidates.begin(),held.candidates.end(),[](const auto& r){return r.segment_v2&&r.segment_v2->segment_id=="keep-0";});
        Check(row!=held.candidates.end()&&row->hold_count==1&&!store.catalog.RequestDeletion("keep-0","continuous-age",&error),"R92 held reader protected");
        Check(store.catalog.AdjustHoldCount("keep-0",-1,&error)&&store.catalog.Checkpoint(&error),"R92 release and checkpoint "+error);
        Check(store.journal.Finish(&error),"R92 explicit Finish "+error);
    }
    {Store reopened(root/"store");const auto snapshot=reopened.catalog.RetentionSnapshot();
     Check(snapshot.authoritative&&snapshot.candidates.size()==16&&reopened.catalog.IsDeletedSegmentId("gone-127"),"R92 reopened membership");
     for(const auto& row:snapshot.candidates)Check(row.segment_v2&&expected.at(row.segment_v2->segment_id)==SerializeRecordingSegmentV2(*row.segment_v2),"R92 reopened original bytes");
     Check(reopened.journal.Finish(&error),"R92 reopened Finish "+error);}
    std::cout<<"[retention-cost-complete] PASS checks="<<passes<<std::endl;return 0;
}catch(const std::exception& e){std::cerr<<"[fail] "<<e.what()<<std::endl;return 1;}
