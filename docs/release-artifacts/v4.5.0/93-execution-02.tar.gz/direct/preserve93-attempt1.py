from pathlib import Path
import json,hashlib,tarfile,re,io,os
root=Path(__file__).parent;run=root/'final120';app=next(run.glob('media-server-current-observer-*'));selected={}
def add(p,name):
 assert p.is_file() and not p.is_symlink() and p.stat().st_uid==os.getuid() and name not in selected
 selected[name]=p
for name in ['entry.json','preflight.json','analysis.json','analyze93.py','preserve93.py','launcher.stdout']:add(root/name,'direct/'+name)
for p in run.iterdir():
 if p.is_file():add(p,'final120/'+p.name)
for folder in ['artifacts','receipts']:
 for p in (run/folder).rglob('*'):
  if p.is_file():add(p,'final120/'+folder+'/'+str(p.relative_to(run/folder)))
for p in app.glob('server-*.private.log'):add(p,'final120/server/'+p.name.replace('.private.log','.sanitized.log'))
for name in ['seed.json','catalog-instrumented.cpp']:
 if (app/name).is_file():add(app/name,'final120/fixture/'+name)
for p in (app/'input').glob('*.mp4'):add(p,'final120/input/'+p.name)
for p in (app/'recordings').rglob('*'):
 if not p.is_file() or p.is_symlink() or 'sqlite' in p.name or p.name.endswith(('-wal','-shm')) or 'visual-cache' in p.parts:continue
 add(p,'final120/recordings/'+str(p.relative_to(app/'recordings')))
manifest=[]; archive=Path('docs/release-artifacts/v4.5.0/93-execution.tar.gz')
with archive.open('xb') as f:
 with tarfile.open(fileobj=f,mode='w:gz') as t:
  for name,p in sorted(selected.items()):
   orig=p.read_bytes();data=orig;transform='none'
   if name.endswith('.sanitized.log'):
    data=re.sub(rb'(?:https?|rtsp)://[^\s"<>]+',b'[owned-local-url-redacted]',orig);transform='URL tokens only; trace/frame/resource/request bytes unchanged' if data!=orig else 'none'
   assert not re.search(rb'passwordHash|passwordHistory|tokenHash|Set-Cookie:|Authorization:|password=',data),name
   info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;t.addfile(info,io.BytesIO(data))
   manifest.append({'member':name,'source':str(p.relative_to(root)),'originalBytes':len(orig),'originalSha256':hashlib.sha256(orig).hexdigest(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'transform':transform})
  doc={'schema':'task93-selected-bytes-v1','entries':manifest,'scope':'one failed120 attempt, required closed original journal/shards/snapshot/binding/synthetic media/evidence/A preserved; no reconstructed missing status body','exclusions':['auth/session state','derivedSQLite/visualcache','models/SDK/runtime/helper binaries (hashes retained)','prior archives','GStreamer registry/cache'],'privacy':'Synthetic owned inputs only. Private server URL tokens redacted; other selected originals unchanged.'}
  data=(json.dumps(doc,ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('preservation.json');info.size=len(data);info.mode=0o600;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:
 assert set(t.getnames())=={v['member'] for v in manifest}|{'preservation.json'}
 for row in manifest:
  data=t.extractfile(row['member']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(manifest)+1,'payloadBytes':sum(x['bytes'] for x in manifest),'largestPayload':max(x['bytes'] for x in manifest),'byteReadback':'PASS','transforms':[x for x in manifest if x['transform']!='none']}
(root/'preservation-readback.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps(receipt,ensure_ascii=False))
