from pathlib import Path
def edit(path,a,b):
 p=Path(path);s=p.read_text();assert a in s,(path,a);p.write_text(s.replace(a,b))
p='include/recording/recording_store_port.h'
edit(p,'class RecordingStorePort {','// Protected is a pre-mutation rejection, never an I/O or authority failure.\nenum class RecordingDeletionAdmission { Accepted, Protected, Failed };\n\nclass RecordingStorePort {')
edit(p,'    virtual bool CompleteDeletion(','''    virtual RecordingDeletionAdmission RequestDeletionForAdmission(
        const std::string& id, const std::string& reason, std::string* error) {
        return RequestDeletion(id,reason,error) ? RecordingDeletionAdmission::Accepted
                                               : RecordingDeletionAdmission::Failed;
    }
    virtual bool CompleteDeletion(''')
p='include/recording/recording_catalog.h'
edit(p,'    bool RequestDeletion(const std::string& segment_id,','    RecordingDeletionAdmission RequestDeletionForAdmission(const std::string&,const std::string&,std::string*) override;\n    bool RequestDeletion(const std::string& segment_id,')
edit(p,'    bool RevalidateRotatedMutationLocked(const RecordingMutationV1&,std::string*);','    bool RequestDeletionImpl(const std::string&,const std::string&,std::string*,bool*);\n    bool RevalidateRotatedMutationLocked(const RecordingMutationV1&,std::string*,bool* deletion_protected=nullptr);')
edit(p,'PreparedDerivedMutation*,bool acquire_hold=false);','PreparedDerivedMutation*,bool acquire_hold=false,bool* deletion_protected=nullptr);')
edit(p,'PreparedDerivedMutation* prepared=nullptr);','PreparedDerivedMutation* prepared=nullptr,bool* deletion_protected=nullptr);')
p='src/recording/recording_catalog.cpp'
edit(p,'RevalidateRotatedMutationLocked(const RecordingMutationV1& m,std::string* error) {','RevalidateRotatedMutationLocked(const RecordingMutationV1& m,std::string* error,bool* deletion_protected) {')
edit(p,'''        if(v==segments_.end()||v->second.lifecycle!=RecordingLifecycle::Finalized||
           protected_id(m.mutation_type==RecordingMutationType::DeletionRequested))return Fail(error,"rotated V1 lifecycle/protection changed");''','''        if(v==segments_.end()||v->second.lifecycle!=RecordingLifecycle::Finalized)return Fail(error,"rotated V1 lifecycle changed");
        if(protected_id(m.mutation_type==RecordingMutationType::DeletionRequested)) {
            if(deletion_protected)*deletion_protected=true;
            return Fail(error,"rotated V1 protection changed");
        }''')
edit(p,'    if(m.mutation_type==RecordingMutationType::SegmentV2State&&protected_id(true))return Fail(error,"rotated V2 protection changed");','''    if(m.mutation_type==RecordingMutationType::SegmentV2State&&protected_id(true)) {
        if(deletion_protected)*deletion_protected=true;
        return Fail(error,"rotated V2 protection changed");
    }''')
edit(p,'PreparedDerivedMutation* prepared,bool acquire_hold) {','PreparedDerivedMutation* prepared,bool acquire_hold,bool* deletion_protected) {')
edit(p,'!RevalidateRotatedMutationLocked(mutation,error)))','!RevalidateRotatedMutationLocked(mutation,error,deletion_protected)))')
edit(p,'(void)mutation;(void)prepared;(void)acquire_hold;return Fail','(void)mutation;(void)prepared;(void)acquire_hold;(void)deletion_protected;return Fail')
edit(p,'bool RecordingCatalog::AppendAndApplyLocked(RecordingMutationV1 mutation, std::string* error,PreparedDerivedMutation* prepared) {','bool RecordingCatalog::AppendAndApplyLocked(RecordingMutationV1 mutation, std::string* error,PreparedDerivedMutation* prepared,bool* deletion_protected) {')
edit(p,'return AppendGenerationLocked(std::move(mutation),error,prepared);','return AppendGenerationLocked(std::move(mutation),error,prepared,false,deletion_protected);')
a='''bool RecordingCatalog::RequestDeletion(const std::string& segment_id,
                                       const std::string& reason,
                                       std::string* error) try {'''
b='''bool RecordingCatalog::RequestDeletion(const std::string& id,const std::string& reason,std::string* error) {
    return RequestDeletionImpl(id,reason,error,nullptr);
}
RecordingDeletionAdmission RecordingCatalog::RequestDeletionForAdmission(
    const std::string& id,const std::string& reason,std::string* error) {
    bool protection=false;
    if(RequestDeletionImpl(id,reason,error,&protection))return RecordingDeletionAdmission::Accepted;
    return protection?RecordingDeletionAdmission::Protected:RecordingDeletionAdmission::Failed;
}
bool RecordingCatalog::RequestDeletionImpl(const std::string& segment_id,
                                       const std::string& reason,
                                       std::string* error,bool* deletion_protected) try {'''
edit(p,a,b)
pth=Path(p);s=pth.read_text();start=s.index('bool RecordingCatalog::RequestDeletionImpl');end=s.index('bool RecordingCatalog::PutReferencedObservation',start);part=s[start:end]
part=part.replace('    const auto v2=','    if(!opened_||!CanWriteLocked(error))return false;\n    const auto v2=',1).replace('        if(!opened_||!CanWriteLocked(error))return false;\n','',1)
part=part.replace('if(payload.empty()||v2->second.pinned||hold_counts_.count(segment_id)||DerivedJobProtectsLocked(segment_id))return Fail(error,"V2 삭제 보호/사유 거부");','''if(payload.empty())return Fail(error,"V2 삭제 사유 거부");
        if(v2->second.pinned||hold_counts_.count(segment_id)||DerivedJobProtectsLocked(segment_id)) {
            if(deletion_protected)*deletion_protected=true;
            return Fail(error,"V2 삭제 보호 거부");
        }''')
part=part.replace('return AppendAndApplyLocked(std::move(mutation),error);','return AppendAndApplyLocked(std::move(mutation),error,nullptr,deletion_protected);').replace('return AppendAndApplyLocked(std::move(mutation), error);','return AppendAndApplyLocked(std::move(mutation),error,nullptr,deletion_protected);')
part=part.replace('        return Fail(error, "pin 또는 hold','        if(deletion_protected)*deletion_protected=true;\n        return Fail(error, "pin 또는 hold')
part=part.replace('            return Fail(error, "terminal 미완료','            if(deletion_protected)*deletion_protected=true;\n            return Fail(error, "terminal 미완료')
s=s[:start]+part+s[end:];pth.write_text(s)
p='include/recording/retention_coordinator.h'
edit(p,'    std::string last_error;\n};\n\nstruct RetentionAdmissionResult','    std::string last_error;\n    std::size_t protected_count{0};\n};\n\nstruct RetentionAdmissionResult')
edit(p,'    RetentionApplyResult RecoverPendingForChannel','    RetentionApplyResult ApplyPlan(const RetentionPlan&,std::int64_t,bool defer_protection);\n    RetentionApplyResult RecoverPendingForChannel')
p='src/recording/retention_coordinator.cpp'
edit(p,'''                                                 std::int64_t deleted_at_ms) {
    std::lock_guard apply_lock(apply_mu_);''','''                                                 std::int64_t deleted_at_ms) {
    return ApplyPlan(plan,deleted_at_ms,false);
}
RetentionApplyResult RetentionCoordinator::ApplyPlan(const RetentionPlan& plan,
    std::int64_t deleted_at_ms,bool defer_protection) {
    std::lock_guard apply_lock(apply_mu_);''')
edit(p,'''        if (!store_.RequestDeletion(deletion.candidate.Id(), reason, &error)) {''','''        const auto outcome=defer_protection
            ?store_.RequestDeletionForAdmission(deletion.candidate.Id(),reason,&error)
            :(store_.RequestDeletion(deletion.candidate.Id(),reason,&error)
                ?RecordingDeletionAdmission::Accepted:RecordingDeletionAdmission::Failed);
        if(outcome==RecordingDeletionAdmission::Protected) {
            ++result.protected_count; // no pending, unlink, tombstone or reclaimed bytes
            continue;
        }
        if (outcome!=RecordingDeletionAdmission::Accepted) {''')
# Only continuous admission changes: other consumers retain strict Apply.
pth=Path(p);s=pth.read_text();start=s.index('RetentionAdmissionResult RetentionCoordinator::AdmitContinuousWrite(');end=s.index('void RetentionCoordinator::UpdateContinuousWriteProgress',start);part=s[start:end]
part=part.replace('const auto applied = Apply(plan, now_ms);','const auto applied = ApplyPlan(plan, now_ms, true);')
a='''    const std::uint64_t refreshed_free = refreshed_physical_free > inflight_bytes
                                             ? refreshed_physical_free - inflight_bytes
                                             : 0;'''
b='''    bool quota_satisfied=plan.continuous_quota_satisfied;
    std::uint64_t current_inflight=inflight_bytes;
    if(applied.ok&&applied.protected_count) {
        // A planned victim acquired protection before mutation. Projected reclaim is
        // no longer evidence of capacity; charge every actual remaining byte.
        const auto current=ReadSnapshot();
        refreshed=refreshed&&current.authoritative;
        if(!current.authoritative)refresh_error=current.error;
        std::uint64_t charged=expected_segment_bytes;
        for(const auto& candidate:current.candidates) {
            if(candidate.Channel()==channel_id&&candidate.Class()==RecordingRetentionClass::Continuous&&
               (candidate.Lifecycle()==RecordingLifecycle::Finalized||
                candidate.Lifecycle()==RecordingLifecycle::DeletionPending||candidate.Lifecycle()==RecordingLifecycle::Corrupt))
                charged=SaturatingAdd(charged,candidate.Size());
        }
        quota_satisfied=charged<=policy.continuous_max_bytes;
        current_inflight=SaturatingAdd(OutstandingReservationsLocked(),DurableOutstanding(current));
        if(refreshed)refreshed=free_space_provider_&&free_space_provider_(&refreshed_physical_free,&refresh_error);
        TraceRecordingState(channel_id,"admission-protection-deferred",quota_satisfied?"actual-quota-available":"actual-quota-blocked");
    }
    const std::uint64_t refreshed_free = refreshed_physical_free > current_inflight
                                             ? refreshed_physical_free - current_inflight
                                             : 0;'''
assert a in part;part=part.replace(a,b).replace('applied.ok && refreshed && plan.continuous_quota_satisfied','applied.ok && refreshed && quota_satisfied');s=s[:start]+part+s[end:];pth.write_text(s)
