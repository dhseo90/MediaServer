#!/bin/bash
set -euo pipefail
r=/tmp/media-server-search92
mkdir -p "$r/repo" "$r/output" "$r/work"
finish() { code=$?; printf '%s\n' "$code" > "$r/output/container-exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap finish EXIT
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
ln -s /source/models "$r/repo/models"
cp /helpers/run-command.py /helpers/native.py "$r/output/"
export XDG_CACHE_HOME="$r/work/cache"
export TMPDIR="$r/work" GST_REGISTRY="$r/work/registry.bin" GST_REGISTRY_1_0="$r/work/registry.bin"
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/run-command.py" build 600 cmake --build ../build -j2 > "$r/output/build-console.log" 2>&1
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/source
export GIT_DIR=/source/.git GIT_WORK_TREE="$r/repo"
export TASK_REPO="$r/repo" TASK_BUILD="$r/build"
python3 "$r/output/native.py" "$r/output/native" recording_search_seek_smoke recording_search_playback_smoke visual_search_index_smoke recording_retention_smoke recording_retention_v2_smoke > "$r/output/native-console.log" 2>&1
python3 "$r/output/run-command.py" request-proof 600 bash scripts/internal/verify_recording_generation_request_proof.sh > "$r/output/proof-console.log" 2>&1
python3 scripts/internal/verify_visual_request_media_cache.py --build ../build --output "$r/output/cache.json" > "$r/output/cache-console.log" 2>&1
MEDIA_SERVER_VERIFY_CATALOG_HOLDER_TRACE=1 python3 "$r/output/native.py" "$r/output/retention-cost" recording_retention_cost_smoke > "$r/output/retention-cost-console.log" 2>&1
node --test scripts/internal/recording_latency_trace.test.mjs scripts/internal/recording_longrun_progress.test.mjs > "$r/output/collector.log" 2>&1
printf 'Linux affected regression complete\n' > "$r/output/completed.txt"
