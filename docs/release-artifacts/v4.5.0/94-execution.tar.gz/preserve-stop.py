from pathlib import Path
import json,hashlib,subprocess,tarfile,io,os,datetime,math
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');out=repo/'docs/release-artifacts/v4.5.0';out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
# Original outside-run config is intentionally neither copied into Git nor restored.
p=repo/'.media_server.sources.json';st=p.stat()
stop={'reason':'AGENTS.md section 4 isolation-breach stop; explicit user instruction required before resuming',
 'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'helper':'native.py omitted MEDIA_SERVER_SOURCE_REGISTRY and MEDIA_SERVER_PUBLISHED_VIEWS for recording_segment_writer_smoke',
 'defaultSourceFile':{'path':str(p),'bytes':st.st_size,'sha256':sha(p.read_bytes()),'modifiedAt':datetime.datetime.fromtimestamp(st.st_mtime,datetime.timezone.utc).isoformat()},
 'sourceIds':[x.get('sourceId',x.get('id')) for x in json.loads(p.read_text())['sources']],
 'testIds':['91','93'],'beforeBytes':'not-preserved; exact prior values and all earlier task writes not established',
 'defaultViews':'pre-existing file unchanged mtime observed; no before hash available',
 'action':'No default config restoration/deletion; product changes and all originals retained. No more implementation/tests/delegation. Owned checkpoint process group 87457 terminated with SIGTERM; wrapper exit -15, cleanup receipt retained.',
 'scope':'The earlier native helper executions also lack these overrides; their writer isolation claim is not qualified. Isolated mixed45 had explicit own state paths and is separate.',
 'notRun':['corrected candidate cumulative run','corrected candidate Linux','final independent fix/result approval','new product producer/readback']}
write(r/'isolation-stop.json',stop)
patch=subprocess.check_output(['git','diff','--binary'],cwd=repo);(r/'unreviewed-retention-fix.patch').write_bytes(patch)
source={str(x):sha((repo/x).read_bytes()) for x in subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines()}
write(r/'unreviewed-fix-binding.json',{'base':'df4aa5a6eecfda313b3ca46eea46b52cf49b0bb8','patchSha256':sha(patch),'files':source,'status':'uncommitted, not independently approved, not release adopted','binary':{'sha256':sha((repo/'build-gst-onnx/media_server').read_bytes()),'runtimeSha256':sha((repo/'build-gst-onnx/libmedia_server_runtime.a').read_bytes())}})
files=[]
# Existing receipts, commands and bounded logs. No copied SDK/models/binaries or prior archives.
for p in r.iterdir():
 if p.is_file() and p.suffix in {'.json','.log','.py','.sh','.patch'}:files.append(p)
for name in ['native-macos','native-macos-2','hold-red-native','fix-native1-data','linux-final-selected']:
 d=r/name
 if d.exists():files += [p for p in d.rglob('*') if p.is_file() and p.suffix in {'.log','.json','.txt','.sha256'}]
d=r/'diagnostic45';w=d/'media-server-current-observer-Ja3Kxr'
files += [p for p in d.iterdir() if p.is_file()]
files += [p for p in (d/'artifacts').iterdir() if p.is_file()]
files += [w/'server-1.private.log', w/'seed.json', w/'catalog-instrumented.cpp']
# Closed original generation + live retained media/package bytes: needed to inspect admission state.
files += [p for p in (w/'recordings').rglob('*') if p.is_file() and not p.is_symlink()]
files += [p for p in (w/'input').iterdir() if p.is_file()]
files=sorted(set(files));manifest=[]
archive=out/'94-execution.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:
  b=p.read_bytes();rel=str(p.relative_to(r));manifest.append({'path':rel,'bytes':len(b),'sha256':sha(b),'kind':'original'})
  info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o600;tar.addfile(info,io.BytesIO(b))
 b=(json.dumps({'files':manifest,'excluded':['SDK/models/product binaries','auth users and source/view configs','old task archives','default host source configuration']},ensure_ascii=False,indent=2)+'\n').encode();info=tarfile.TarInfo('preserved-bytes.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
# Byte readback, not just existence.
with tarfile.open(archive,'r:gz') as tar:
 for x in manifest:assert sha(tar.extractfile(x['path']).read())==x['sha256']
report=json.loads((d/'artifacts/report.json').read_text());lat=sorted(report['evidenceLoad']['searchLatencyMs'])
resource=report['resources'];groups=resource.get('groups',[])
val={'schema':'media-server.v450.validation.v1','task':94,'status':'PARTIAL_BLOCKED_ISOLATION','memoryP0':'unresolved','release':'held','ownerRiskAcceptance':'not-granted',
 'model':{'requestedMain':{'model':'gpt-6-astra','effort':'high'},'mainRuntime':'not-exposed','independentRequested':{'model':'gpt-6-astra','effort':'high'},'independentToolAccepted':'gpt-6-astra/high (existing reviewer)','independentRuntime':'not-exposed'},
 'baseline':'1988d55b56d09c1c40d9fb15bfd5e61a37e4e0b1','diagnosticSource':'df4aa5a6eecfda313b3ca46eea46b52cf49b0bb8','diagnosticTree':'27088d32175adf1517808cb3f8ee8a23daeda1a3',
 'diagnostic':{'executions':1,'authorizedMaximumSeconds':2700,'lastObservedSeconds':2107.996293083,'launcherElapsedSeconds':2124.0325847909553,'exit':1,'firstFailure':'LP26-O05 active 9101: exactlyOne/enabled/active true, notStorageBlocked false','sameResponse':{'status':200,'bytes':908,'sha256':'b3d1de397fee230ddd1ef617d98b165795311704fcda51adf8cc9a243ac18670','requestId':422,'receivedLatencyMs':226.058750},'stateTrace':{'capturedEvents':51,'collectionIssues':0,'serverReceivedAndStoredBytes':791820,'processLogCapBytes':4194304},'ACompleted':35,'search':{'successfulSamples':len(lat),'unavailable':report['evidenceLoad']['searchUnavailable'],'partialP95Ms':lat[math.floor((len(lat)-1)*.95)],'partialMaxMs':max(lat),'finalGate':'not-run'},'subsequentControlsRecoveryRestart':'not-run-after-failure','processCleanup':'launcher confirms groups absent; normal finally server stop'},
 'causalBoundary':{'newRun':'Deletion protection/reason denial propagated to continuous admission; exact pin/hold/job vs invalid-reason branch not identifiable from that trace. No active=false evidence.','deterministic':'Actual catalog: fixed Plan then hold acquired; old code fails immediately and skips remaining eligible victim although actual capacity after safe other deletion can satisfy write. RED preserved.','past93':'same body was never preserved; not reconstructed, exact cause remains unconfirmed','search':'93 partial p95 2242.620ms and new partial p95 remain separate performance residuals'},
 'unreviewedFix':{'status':'working tree only; exact patch in archive; not release candidate','behavior':'typed pre-mutation protection only; preserve held file, other selected deletions, re-read actual bytes/free/durable reservations before continuous admission; strict public Apply and hard errors remain','direct':'macOS V2 28 PASS, retention57 PASS; checkpoint first crypto/sqlite/backend 1/1/1 partial success including typed rotation protection; full suite interrupted','firstCompileFailure':'two unrelated private declarations mistakenly received optional parameter; original log preserved and corrected build PASS','writerFailure':'110 PASS/8 FAIL due default registry usage/duplicate source; not a product regression PASS','correctedCumulativeRun':'not-run','LinuxAndFinalReview':'not-run'},
 'stop':stop,'priorEvidence':'92 retention/600 and historical memory scopes maintained; preflight writer isolation qualification withdrawn, original preflight review not edited',
 'approvalBinding':'df4aa diagnostic inventory producer/readback completed with unchanged legacy986 digest; later product/inventory delta is not bound/approved',
 'preservation':{'archive':'94-execution.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'originalFiles':len(manifest),'uncompressedBytes':sum(x['bytes'] for x in manifest),'byteReadback':'all selected member hashes match'},
 'cleanup':{'checkpoint':'owned group SIGTERM, wrapper cleanup original directory removed','mixed':'owned groups absent per launcher','root':'retained for isolation audit/resume; not deleted','containers':'stopped; final inspection/removal pending','defaultSource':'not restored/deleted; prior bytes unavailable'},
 'notPerformed':['new120','acceptance','fullUI','Qwen/Ollama','unload gate','PR','merge','tag','Release'],
 'remaining':['isolation incident resolution and explicit resumption instruction','minimal fix final review/macOS+Linux/binding','at most one approved fixed candidate cumulative run if still necessary','separate search latency','memory P0/final mixed and release hold']}
write(out/'94-validation.json',val)
# Historical independent judgment retained as-is; no invented final approval.
(out/'94-independent-preflight.json').write_bytes((r/'independent-preflight.json').read_bytes())
print(json.dumps({'archiveBytes':archive.stat().st_size,'files':len(manifest),'rawBytes':sum(x['bytes'] for x in manifest),'partialP95Ms':val['diagnostic']['search']['partialP95Ms']}))
