#!/bin/bash
set -euo pipefail
r=/tmp/media-server-state95
umask 077
mkdir -p "$r/repo" "$r/output" "$r/work"
finish() { code=$?; printf '%s\n' "$code" > "$r/output/container-exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap finish EXIT
cp -R /source/src /source/include /source/scripts /source/test /source/config "$r/repo/"
cp /source/CMakeLists.txt /source/VERSION "$r/repo/"
ln -s /source/models "$r/repo/models"
cp /helpers/run-command.py /helpers/native.py "$r/output/"
export XDG_CACHE_HOME="$r/work/cache"
export TMPDIR="$r/work" GST_REGISTRY="$r/work/registry.bin" GST_REGISTRY_1_0="$r/work/registry.bin"
export MEDIA_SERVER_SKIP_LOCAL_ENV=1 LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib
cd "$r/repo"
{ id; uname -srm; g++ --version; pkg-config --modversion gstreamer-1.0 openssl sqlite3; } > "$r/output/environment.log" 2>&1
cmake -S . -B ../build -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
python3 "$r/output/run-command.py" build 600 cmake --build ../build -j2 > "$r/output/build-console.log" 2>&1
sha256sum ../build/media_server ../build/libmedia_server_runtime.a > "$r/output/binaries.sha256"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/source
export GIT_DIR=/source/.git GIT_WORK_TREE="$r/repo"
export TASK_REPO="$r/repo" TASK_BUILD="$r/build"
export MEDIA_SERVER_VERIFY_RECORDING_STATE_TRACE=1
python3 "$r/output/native.py" "$r/output/native" recording_retention_smoke recording_retention_v2_smoke recording_segment_writer_smoke recording_managed_writer_smoke recording_derived_jobs_smoke > "$r/output/native-console.log" 2>&1
printf 'Linux affected regression complete\n' > "$r/output/completed.txt"
