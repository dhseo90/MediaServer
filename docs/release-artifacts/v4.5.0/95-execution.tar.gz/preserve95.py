from pathlib import Path
import json,hashlib,tarfile,io,os,math,collections
r=Path(__file__).parent;repo=Path('/Users/dhseo/Workspace/mediaServer');d=r/'fixed-candidate';w=d/'media-server-current-observer-qc8tgq'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
lines=(d/'run.log').read_text().splitlines()
def values(tag):return [json.loads(l[len(tag)+1:]) for l in lines if l.startswith(tag+' ')]
report=json.loads((d/'artifacts/report.json').read_text());execution=json.loads((d/'execution.json').read_text());obs=values('[current-observation]');storage=values('[root-storage]');trace=values('[recording-state-summary]')[0];lat=sorted(report['evidenceLoad']['searchLatencyMs']);group=report['resources']['groups'][0]
analysis={'source':execution['source'],'runtimeSha256':json.loads((r/'pre-run-inputs.json').read_text())['runtimeSha256'],'executions':1,'firstFailure':'workspace-variable-cap','exit':execution['exit'],'timedOut':execution['timedOut'],'totalWithFinalBindingSeconds':execution['totalWithFinalBindingSeconds'],'lastEmittedObservation':obs[-1],'emittedObservations':len(obs),'summarySampleCount':report['resources']['sampleCount'],'samplingLimit':'last point pushed before workspace guard; anonymous bytes of failing sample not emitted. No reconstructed scalar or root cause attribution. Last visible storage and anonymous sample are different observation instants.','lastSampleStorage':next(x for x in reversed(storage) if x['reason']=='sample'),'postStopStorage':storage[-1],'search':{'successfulSamples':len(lat),'unavailable':report['evidenceLoad']['searchUnavailable'],'partialP95Ms':lat[math.ceil(len(lat)*.95)-1],'partialMaximumMs':max(lat),'p95LimitMs':2000,'maximumLimitMs':5000,'finalGate':'not-run-after-space-failure','partialP95WithinLimit':False},'aCompleted':sum(x['state']=='completed' for x in report['aLoad']['schedule']),'evidence':{k:v for k,v in report['evidenceLoad'].items() if not isinstance(v,(dict,list))},'stateTrace':{'status':trace['status'],'events':len(trace['events']),'phaseCounts':dict(collections.Counter(x['phase'] for x in trace['events'])),'issues':trace.get('issues',[]),'recordingStatusFailure':report['recordingStatusFailure'],'interpretation':'actual capacity shortage remained blocked and recovered; absence of failing sampled HTTP status is not absence of transient admission blocking. Exact 93/94 historical protection branch remains unknown.'},'decoder':values('[frame-trace-summary]')[0],'serverCapture':values('[server-diagnostic]')[0],'resources':report['resources'],'sampledFootprintMax':max(x['footprintBytes'] for x in obs if x['footprintBytes'] is not None),'cleanup':values('[process-cleanup]')[0],'sourceUnchanged':execution['source']==execution['sourceEnd'],'notRun':['remaining observation duration','final latency/progress gate','controls','independent recovery','restart','reactivation','new120'],'memoryP0':'unresolved','release':'held'}
write(r/'result-analysis.json',analysis)
configs=[]
for x in json.loads((r/'pre-run-inputs.json').read_text())['configs']:
 p=repo/x['name'];b=p.read_bytes();assert sha(b)==x['sha256'];configs.append({'name':x['name'],'bytes':len(b),'sha256':sha(b),'unchangedAfterAuthorizedCleanup':True})
write(r/'final-config-check.json',configs)
files=[p for p in r.iterdir() if p.is_file() and p.suffix in {'.json','.log','.py','.sh','.patch'}]
for name in ['native-final','jobs-final','jobs-revalidated','linux-final-evidence','isolation-final-types','isolation-final','isolation']:
 for p in (r/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix in {'.log','.sha256'}:files.append(p)
# Linux initial compiler failure only: no full previous archive duplication.
with tarfile.open(r/'linux95-output.tar.gz') as t:
 selected=[m for m in t if m.isfile() and ('derived_jobs' in m.name and m.name.endswith('compile.log'))]
 for i,m in enumerate(selected):(r/f'linux-first-job-compile-{i}.log').write_bytes(t.extractfile(m).read());files.append(r/f'linux-first-job-compile-{i}.log')
files += [p for p in d.iterdir() if p.is_file()]
files += [p for p in (d/'artifacts').iterdir() if p.is_file()]
files += [w/'server-1.private.log',w/'seed.json',w/'catalog-instrumented.cpp']
files += [p for p in (w/'recordings').rglob('*') if p.is_file() and not p.is_symlink()]
files += [p for p in (w/'input').iterdir() if p.is_file()]
files += [p for p in (r/'linux-final-evidence').rglob('*.json') if p.is_file()]
files=sorted(set(files));manifest=[]
for p in files:
 assert p.is_relative_to(r) and not p.is_symlink()
 rel=str(p.relative_to(r));assert '/state/' not in rel and '/auth/' not in rel and '.media_server.' not in rel
 b=p.read_bytes();manifest.append({'path':rel,'bytes':len(b),'sha256':sha(b),'kind':'original' if p.name not in ['result-analysis.json'] else 'derived-analysis'})
write(r/'preservation-selection.json',{'files':manifest,'excluded':['private postincident config backup and config values','all test auth/source/views/state files','SDK/models/product/helper binaries and caches','previous archives'],'count':len(manifest),'bytes':sum(x['bytes'] for x in manifest)})
print(json.dumps({'files':len(manifest),'bytes':sum(x['bytes'] for x in manifest),'largest':sorted([(x['bytes'],x['path']) for x in manifest],reverse=True)[:4],'search':analysis['search'],'footprint':analysis['sampledFootprintMax']}))
