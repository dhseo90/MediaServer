#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-space96-diagnostics
mkdir -p "$r/output" "$r/work"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" HOME="$r/work" MEDIA_SERVER_SKIP_LOCAL_ENV=1
cd /source
id > "$r/output/environment.log"
node scripts/internal/recording_process_metrics.test.mjs > "$r/output/metrics.log" 2>&1
node scripts/internal/recording_foundation_observer.test.mjs > "$r/output/foundation.log" 2>&1
node --test scripts/internal/recording_current_root_storage.test.mjs scripts/internal/recording_current_http_diagnostics.test.mjs > "$r/output/workspace-status.log" 2>&1
