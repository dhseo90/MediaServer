import pathlib,sys,os,subprocess,time,json,hashlib
r=pathlib.Path('$RUN96');name=sys.argv[1];binary=r/sys.argv[2];data=r/(name+'-data');data.mkdir(mode=0o700)
ns={'__name__':'isolation_readonly_module','__file__':str(pathlib.Path('scripts/internal/recording_native_isolation.py').resolve())};exec(compile(pathlib.Path(ns['__file__']).read_text(),ns['__file__'],'exec'),ns)
env=ns['environment'](data);cmd=[str(binary),str(data)];begin=time.monotonic();samples=0;error=None;peaks={'anonymousLogical':0,'anonymousAllocated':0,'rss':0,'fd':0};largest=None
(r/(name+'-command.json')).write_text(json.dumps({'cmd':cmd,'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'intervalMs':200,'deadlineSeconds':180,'dataRoot':str(data),'source':'same Reserve/FinalizeBound/Delete/Checkpoint generation procedure; new store/media fixture, not 95 replay'}))
with (r/(name+'.log')).open('x') as log,(r/(name+'-metrics.jsonl')).open('x') as metrics:
 p=subprocess.Popen(cmd,cwd=data,env=env,stdout=log,stderr=subprocess.STDOUT)
 try:
  while p.poll() is None:
   if time.monotonic()-begin>180:raise RuntimeError('scale deadline')
   started=time.monotonic();q=subprocess.run([str(r/'process-metrics'),str(p.pid)],capture_output=True,text=True,timeout=3)
   m=json.loads(q.stdout)
   if not m.get('valid'):
    if m.get('error')=='process-exited-or-absent' and p.poll() is not None:break
    (r/(name+'-first-collector-failure.json')).write_text(json.dumps({'measurementStarted':started,'measurementCompleted':time.monotonic(),'exit':q.returncode,'measurement':m},indent=2));raise RuntimeError('metrics invalid '+str(m.get('error')))
   if q.returncode or m['pid']!=p.pid or not all(isinstance(m.get(k),int) for k in ['anonymousFileBytes','anonymousAllocatedBytes']):raise RuntimeError('metrics incomplete')
   # The named traversal follows the anonymous measurement: a bounded sequential sample, not atomic.
   named=None;entries=0
   for attempt in range(3):
    try:
     candidate=0;entries=0
     def failed_walk(e):raise e
     for base,dirs,files in os.walk(data,onerror=failed_walk):
      for f in files:
       st=os.lstat(pathlib.Path(base)/f);entries+=1;candidate+=st.st_size
     named=candidate;break
    except FileNotFoundError:
     if attempt==2:raise RuntimeError('named measurement incomplete')
   row={'elapsed':time.monotonic()-begin,'measurementStarted':started,'measurementCompleted':time.monotonic(),'namedBytes':named,'namedCoverage':'diagnostic non-atomic; full traversal with bounded retries; not gate','resource':m}
   text=json.dumps(row)+'\n'
   if metrics.tell()+len(text)>1048576:raise RuntimeError('metrics log cap')
   metrics.write(text);metrics.flush();samples+=1
   peaks={k:max(peaks[k],v) for k,v in dict(anonymousLogical=m['anonymousFileBytes'],anonymousAllocated=m['anonymousAllocatedBytes'],rss=m['rssBytes'],fd=m['fdCount']).items()}
   if largest is None or max(m['anonymousFileBytes'],m['anonymousAllocatedBytes'])>max(largest['resource']['anonymousFileBytes'],largest['resource']['anonymousAllocatedBytes']):largest=row
   time.sleep(max(0,.2-(time.monotonic()-started)))
 except Exception as e:
  error=str(e);p.terminate()
 finally:
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();code=p.wait(timeout=5)
result={'exit':code,'elapsed':time.monotonic()-begin,'samples':samples,'error':error,'sampledPeaks':peaks,'anonymousMaximumSample':largest,'scope':'external product PID; sequential samples, not instantaneous maximum; named traversal diagnostic only'}
(r/(name+'-result.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result));sys.exit(1 if error or code else 0)
