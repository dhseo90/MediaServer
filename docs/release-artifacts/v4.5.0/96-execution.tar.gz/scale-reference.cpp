// 파일 용도: 녹화 세대 자료구조의 규모별 비용을 격리 probe로 관측한다.
// 검증 전용 실제 B 누적. 준비용 legacy template와 제품 B 비용을 분리한다.
#define main file_evidence_unused_main
#include "recording_file_evidence_smoke.cpp"
#undef main
#include "recording/recording_runtime_composition.h"
#include "recording/recording_latency_trace.h"
#include "domain/strict_json.h"
#include <openssl/evp.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <sstream>
#include "recording_generation_observation.h"

namespace scale {
constexpr std::uint64_t RootCap=448ULL*1024*1024,RssCap=1024ULL*1024*1024;
std::string phase="arguments";
std::string program;
void Need(bool ok,const char* code){if(!ok){phase=code;throw std::runtime_error("scale-failed");}}
std::uint64_t Rss(){struct rusage r{};Need(::getrusage(RUSAGE_SELF,&r)==0,"rss-read");
#ifdef __APPLE__
return r.ru_maxrss;
#else
return static_cast<std::uint64_t>(r.ru_maxrss)*1024;
#endif
}
void Metric(const std::string& op,std::size_t n,Clock::time_point start){
 const auto rss=Rss();std::cout<<"[measure] op="<<op<<" count="<<n<<" us="<<Us(start)<<" rss_peak_bytes="<<rss<<'\n';Need(rss<=RssCap,"rss-cap");
}
std::map<std::string,std::string> Sealed(const std::filesystem::path& root){
 std::map<std::string,std::string> result;
 for(const auto& e:std::filesystem::directory_iterator(root)){
  const auto name=e.path().filename().string();if((name.rfind("active-",0)==0||name.rfind("evidence-",0)==0)&&e.is_regular_file())result[name]=Digest(Bytes(e.path()));
 }return result;
}
void Preserved(const std::filesystem::path& root,const std::map<std::string,std::string>& before){
 for(const auto& x:before)Need(Digest(Bytes(root/x.first))==x.second,"sealed-changed");
}
void Size(const std::filesystem::path& base,std::size_t count){
 std::map<std::string,std::uint64_t> categories;std::uint64_t total=0;
 for(const auto& e:std::filesystem::recursive_directory_iterator(base)){
  struct stat s{};Need(::lstat(e.path().c_str(),&s)==0&&!S_ISLNK(s.st_mode),"root-stat");if(S_ISDIR(s.st_mode))continue;
  Need(S_ISREG(s.st_mode)&&s.st_nlink==1&&s.st_size>=0,"root-file");const auto name=e.path().filename().string();std::string kind="other";
  for(const auto* k:{"active","snapshot","identity","evidence"})if(name.rfind(std::string(k)+"-",0)==0)kind=k;
  if(name.find("sqlite3")!=std::string::npos)kind="sqlite";if(e.path().extension()==".mp4")kind="media";
  total+=static_cast<std::uint64_t>(s.st_size);categories[kind]+=s.st_size;
 }
 for(const auto& x:categories)std::cout<<"[bytes] count="<<count<<" kind="<<x.first<<" bytes="<<x.second<<'\n';
 std::cout<<"[bytes] count="<<count<<" kind=total bytes="<<total<<'\n';Need(total<=RootCap,"root-cap");
}
Output Expected(const Output& input,const std::filesystem::path& root,const std::string& store,std::size_t index){
 auto out=input;out.root=root;out.segment.store_id=store;out.binding.store_id=store;
 out.segment.segment_id="scale-"+std::to_string(index);out.segment.order_request_id="scale-order-"+std::to_string(index);
 out.segment.order_sequence=index;out.binding.segment_id=out.segment.segment_id;
 out.file=root/"probe-channel"/(out.segment.segment_id+".mp4");return out;
}
}
