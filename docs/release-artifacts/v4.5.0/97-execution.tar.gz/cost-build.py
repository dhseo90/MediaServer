import pathlib,json,subprocess,shlex
r=pathlib.Path(__file__).parent
cmd=json.loads((r/'native-output/recording_retention_v2_smoke-compile-command.json').read_text())
for name in ['before','after']:
 args=cmd.copy();args[-1]=str(r/('cost-'+name));
 if name=='before':args.insert(args.index('<REPO>/build-gst-onnx/libmedia_server_runtime.a'),str(r/'before-retention.cpp'))
 (r/('cost-'+name+'-compile-command.json')).write_text(json.dumps(args))
 with (r/('cost-'+name+'-compile.log')).open('x') as f:p=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
