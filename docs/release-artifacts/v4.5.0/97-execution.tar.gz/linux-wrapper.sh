#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-retention97-wrapper
mkdir -p "$r/output" "$r/work/wrapper"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" HOME="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
cd /source
id > "$r/output/environment.log"
timeout 240 python3 scripts/internal/recording_native_isolation.py "$r/work/wrapper" -- bash scripts/internal/verify_recording_retention_v2.sh > "$r/output/wrapper.log" 2>&1
