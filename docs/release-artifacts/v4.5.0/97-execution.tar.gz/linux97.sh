#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-retention97
mkdir -p "$r/output" "$r/work"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" HOME="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib TASK_REPO=/source TASK_BUILD="$r/build"
cd /source
{ id; uname -srm; g++ --version; } > "$r/output/environment.log"
timeout 600 cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" -j2 > "$r/output/build.log" 2>&1
sha256sum "$r/build/media_server" "$r/build/libmedia_server_runtime.a" > "$r/output/binary.sha256"
python3 /input/native.py "$r/output/native" recording_retention_smoke recording_retention_v2_smoke recording_managed_writer_smoke recording_derived_jobs_smoke > "$r/output/native.log" 2>&1
timeout 240 python3 scripts/internal/recording_native_isolation.py "$r/work/wrapper" -- bash scripts/internal/verify_recording_retention_v2.sh > "$r/output/wrapper.log" 2>&1
