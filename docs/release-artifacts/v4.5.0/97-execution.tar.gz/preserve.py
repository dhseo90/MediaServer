from pathlib import Path
import json,hashlib,tarfile,io,subprocess
r=Path(__file__).parent;repo=Path('<REPO>');out=repo/'docs/release-artifacts/v4.5.0'
sha=lambda b:hashlib.sha256(b).hexdigest()
selected=[]
for p in r.iterdir():
 if p.is_file() and p.name!='candidate.json' and p.suffix in ['.log','.json','.py','.sh','.patch','.cpp']:selected.append(p)
for folder in ['native-output','linux97','linux-wrapper','linux-wrapper-final']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and not p.is_symlink() and '-data' not in str(p.relative_to(r/folder)) and p.suffix in ['.log','.json','.sha256','.txt']:selected.append(p)
# Two small generated comparison inputs only, not stores or all media.
for n in ['before','after']:selected.append(r/f'cost-{n}-run/fixture.mp4')
manifest=[];path=out/'97-execution.tar.gz';assert not path.exists()
with tarfile.open(path,'w:gz') as t:
 for p in sorted(set(selected)):
  raw=p.read_bytes();data=raw
  if p.suffix!='.mp4':
   data=raw.replace(str(r).encode(),b'<RUN_ROOT>').replace(str(repo).encode(),b'<REPO>').replace(b'<USER_HOME>/',b'<USER_HOME>/')
  name=str(p.relative_to(r));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=int(p.stat().st_mtime);t.addfile(info,io.BytesIO(data))
  manifest.append({'member':name,'originalBytes':len(raw),'originalSha256':sha(raw),'preservedBytes':len(data),'preservedSha256':sha(data),'relation':'original' if raw==data else 'path-redacted'})
with tarfile.open(path) as t:
 for row in manifest:assert sha(t.extractfile(row['member']).read())==row['preservedSha256']
receipt={'schema':'media-server.execution-preservation.v1','task':97,'archive':path.name,'archiveBytes':path.stat().st_size,'archiveSha256':sha(path.read_bytes()),'members':manifest,'originalLocalReadback':len(manifest),'archiveMemberReadback':len(manifest),'exclusions':'no user config/private backup/models/SDK/whole old archives/store trees/binaries; candidate986 repeated payload excluded, equality receipt and source review retained','transformation':'only ownedrun/repo/userhome path strings; originals and redacted hash differ explicitly'}
(out/'97-preservation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
p=out/'97-validation.json';v=json.loads(p.read_text());v['source']['implementationCommit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True,cwd=repo).strip();v['source']['executionProvenance']='runs used base plus recorded implementation patch; implementation commit made after final runs, byte-identical source files verified';v['binding']['readback']='PASS986 valid/15negative; no execution evidence claim';v['binding']['coverage']='PASS9/0 covered986/missing0';v['preservation']={'archive':path.name,'bytes':receipt['archiveBytes'],'sha256':receipt['archiveSha256'],'members':len(manifest),'readback':'all preserved bytes checked; original/redacted distinguished in97-preservation.json'};p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archiveBytes':receipt['archiveBytes'],'members':len(manifest),'original':sum(x['relation']=='original' for x in manifest),'sanitized':sum(x['relation']!='original' for x in manifest)},indent=2))
