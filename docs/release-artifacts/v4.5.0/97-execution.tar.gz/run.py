import sys,os,pathlib,subprocess,time,json,signal
repo=pathlib.Path('<REPO>');r=pathlib.Path(__file__).parent
ns={};exec(compile((repo/'scripts/internal/recording_native_isolation.py').read_text(),'native-isolation','exec'),ns)
name=sys.argv[1];cmd=sys.argv[2:];own=r/name;own.mkdir(mode=0o700);env=ns['environment'](own);env['MEDIA_SERVER_VERIFY_V410_RECORDING_RETENTION_BUILD_DIR']=str(own/'legacy-build')
start=time.monotonic();p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
# Bounded output/time, preserving first failure and whole small native run.
import selectors
sel=selectors.DefaultSelector();sel.register(p.stdout,selectors.EVENT_READ);data=bytearray();failure=None
while sel.get_map():
 if time.monotonic()-start>240:failure='deadline240';os.killpg(p.pid,signal.SIGTERM);break
 for key,_ in sel.select(.2):
  chunk=os.read(key.fd,65536)
  if not chunk:sel.unregister(key.fileobj);continue
  data.extend(chunk)
  if len(data)>4*1024**2:failure='log-cap';os.killpg(p.pid,signal.SIGTERM);break
 if failure:break
try:code=p.wait(timeout=10)
except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait();failure=failure or 'cleanup-kill'
(r/(name+'.log')).write_bytes(data);(r/(name+'.json')).write_text(json.dumps({'command':cmd,'elapsed':time.monotonic()-start,'exit':code,'failure':failure,'bytes':len(data)},indent=2));print(name,code,failure,time.monotonic()-start);print(data.decode(errors='replace')[-4000:]);sys.exit(code or bool(failure))
