import fs from 'node:fs';import assert from 'node:assert/strict';
import {assertMixedFixtureInput} from '<REPO>/scripts/internal/recording_longrun_progress.mjs';
const root='<RUN>';
for(const file of ['input-bound/recording_managed_writer_smoke-data/mixed-input.mp4','bound-corrected/mixed-input.mp4','native-corrected/recording_managed_writer_smoke-data/mixed-input.mp4']){
 const original=fs.readFileSync(root+'/'+file);const binding=assertMixedFixtureInput(original,'continuous-r98');
 const time=Buffer.from(original),where=time.indexOf(Buffer.from('mvhd'));assert(where>0);time[where+8]^=1;assertMixedFixtureInput(time,'continuous-r98');
 const payload=Buffer.from(original),mdat=payload.indexOf(Buffer.from('mdat'));assert(mdat>0);payload[mdat+5]^=1;assert.throws(()=>assertMixedFixtureInput(payload,'continuous-r98'),/input-binding/);
 console.log(JSON.stringify({file,...binding,timeOnlyChangeAccepted:true,payloadTamperRejected:true}));
}
