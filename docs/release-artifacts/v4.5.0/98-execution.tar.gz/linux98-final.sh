#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-fixture98
mkdir -p "$r/output" "$r/work"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" --exclude='*-data' -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" HOME="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib TASK_REPO=/source TASK_BUILD="$r/build"
cd /source
{ id; uname -srm; g++ --version; } > "$r/output/environment.log"
timeout 600 cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" --target media_server_runtime -j2 > "$r/output/build.log" 2>&1
sha256sum "$r/build/libmedia_server_runtime.a" > "$r/output/runtime.sha256"
python3 /input/native.py "$r/output/native" recording_retention_v2_smoke recording_managed_writer_smoke > "$r/output/native.log" 2>&1
mkdir "$r/bound"
python3 /source/scripts/internal/recording_native_isolation.py "$r/bound" -- "$r/output/native/recording_managed_writer_smoke" "$r/bound" --mixed-fixture-bound > "$r/output/bound.log" 2>&1
cp "$r/output/native/recording_managed_writer_smoke-data/mixed-input.mp4" "$r/output/linux-fixed-input.mp4"
node scripts/internal/recording_longrun_progress.test.mjs > "$r/output/progress.log" 2>&1
