import pathlib,hashlib,json,tarfile,io,subprocess
r=pathlib.Path('<RUN>');repo=pathlib.Path.cwd();dst=repo/'docs/release-artifacts/v4.5.0';picked=[]
for p in r.iterdir():
 if p.is_file() and p.suffix in ['.log','.json','.py','.mjs','.sh','.patch'] and p.name not in ['candidate.json','manifest-before.json']:picked.append(p)
for name in ['input-bound','profile-direct','native-final','native-corrected','linux-first-failure','linux-final']:
 for p in (r/name).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.log','.json','.sha256','.txt'] and not any(x.endswith('-data') for x in p.relative_to(r).parts):picked.append(p)
for name in ['input-bound/recording_managed_writer_smoke-data/mixed-input.mp4','bound-corrected/mixed-input.mp4','native-corrected/recording_managed_writer_smoke-data/mixed-input.mp4','linux-final/linux-fixed-input.mp4']:picked.append(r/name)
files=sorted(set(picked));entries=[];payload={}
for p in files:
 raw=p.read_bytes();data=raw
 if p.suffix!='.mp4':data=raw.replace(str(repo).encode(),b'<REPO>').replace(str(r).encode(),b'<RUN>').replace(b'<HOME>/',b'<HOME>/')
 name=p.relative_to(r).as_posix();payload[name]=data;entries.append({'path':name,'sourceBytes':len(raw),'sourceSha256':hashlib.sha256(raw).hexdigest(),'preservedBytes':len(data),'preservedSha256':hashlib.sha256(data).hexdigest(),'transformation':'owned absolute paths redacted' if data!=raw else 'original bytes'})
archive=dst/'98-execution.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(payload.items()):
  m=tarfile.TarInfo(name);m.size=len(data);m.mode=0o600;m.mtime=0;t.addfile(m,io.BytesIO(data))
with tarfile.open(archive) as t:
 for m in t.getmembers():assert t.extractfile(m).read()==payload[m.name]
receipt={'schema':'media-server.preservation.v1','task':98,'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(entries),'membersReadback':True,'entries':entries,'omitted':'native binaries/repeated media stores/build outputs and prior large archives; candidate JSON identical to existing Git audit is referenced by hash; no user config or private95 backup accessed'}
(dst/'98-preservation.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['archive','bytes','sha256','members']}))
