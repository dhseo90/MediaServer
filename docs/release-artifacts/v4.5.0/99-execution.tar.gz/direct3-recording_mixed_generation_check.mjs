// 파일 용도: R99 source-bound generation/copy 복구의 부모 수집·공간 보호. 제품 기본 설정에 접근하지 않는다.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawn,spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {collectProcess} from './recording_foundation_observer.mjs';
import {admitWorkspaceSnapshot,createWorkspaceFailureCapture,measureCurrentCopy} from './recording_current_observer.mjs';
const [root,binary,collector]=process.argv.slice(2),repo=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
if(!root||fs.realpathSync(root)!==root||!/^\/private\/tmp\/media-server-|^\/tmp\/media-server-/.test(root))throw Error('owned-run');
const rs=fs.lstatSync(root);if(rs.uid!==process.getuid()||(rs.mode&511)!==448)throw Error('run-owner');
const capture=createWorkspaceFailureCapture(root),baseline={fixedBytes:0,capBytes:448*1024**2};
const data=path.join(root,'live'),copy=path.join(root,'copy');fs.mkdirSync(data,{mode:0o700});
let first=null,sampleCount=0,summary={schema:'r99-generation-cyclic-v1',status:'RUNNING',cyclicRecoveryPass:false,spacePass:false,sourceHead:spawnSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).stdout.trim(),sourceSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(repo,'scripts/internal/recording_mixed_generation_fixture.h'))).digest('hex')};
const measure=dir=>{const s=fs.lstatSync(dir);return measureCurrentCopy(dir,{dev:s.dev,ino:s.ino});};
const samples=fs.openSync(path.join(root,'space.jsonl'),'wx',0o600);
function named(){const all=measure(root),recovery=fs.existsSync(copy)?measure(copy).bytes:0;return {totalBytes:all.bytes-recovery,copyBytes:recovery,measurementCompletedAt:performance.now()};}
function tree(dir){let rows=[];const walk=d=>{for(const name of fs.readdirSync(d).sort()){const f=path.join(d,name),s=fs.lstatSync(f);if(s.isDirectory())walk(f);else {if(!s.isFile()||s.nlink!==1||s.isSymbolicLink())throw Error('tree-file');rows.push([path.relative(dir,f),s.size,crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex')]);}}};walk(dir);return crypto.createHash('sha256').update(JSON.stringify(rows)).digest('hex');}
async function run(mode,dir,isCopy){
  const child=spawn('python3',[path.join(repo,'scripts/internal/recording_native_isolation.py'),dir,'--',binary,dir,mode],{cwd:repo,stdio:['pipe','pipe','pipe'],detached:true});
  const raw=fs.openSync(path.join(root,mode.slice(2)+'.log'),'wx',0o600);let bytes=0,pid=null,identity=null,phase='spawn',pending='',observing=false,primary=null,closed=false,seen=0;
  const stop=e=>{primary??=e;try{process.kill(-child.pid,'SIGTERM');}catch(x){if(x.code!=='ESRCH')primary??=x;}};
  async function observe(ack=false){if(observing||!pid||closed)return;observing=true;try{
    const begin=performance.now(),m=await collectProcess(collector,pid);if(!m.valid||m.error!==null||m.rssBytes>4*1024**3)throw Error('native-metric-budget');
    identity??=m.startIdentity;const storage=named();const decision=admitWorkspaceSnapshot({storage,baseline,metrics:{...m,measurementStartedAt:begin,measurementCompletedAt:performance.now()},expectedPid:pid,expectedStart:identity,anonymousInCopy:isCopy,context:{kind:'r99-generation',phase,sampleIndex:++sampleCount}},capture);
    const row=JSON.stringify({phase,pid,measurementStartedAt:begin,measurementCompletedAt:performance.now(),metrics:m,decision})+'\n';if(fs.fstatSync(samples).size+Buffer.byteLength(row)>4*1024**2)throw Error('space-log-cap');fs.writeSync(samples,row);++seen;
    if(ack)child.stdin.write('observed\n');
  }catch(e){capture.capture(e,{phase,pid});stop(e);}finally{observing=false;}}
  function collect(b,stderr){bytes+=b.length;if(bytes>4*1024**2){stop(Error('native-log-cap'));return;}fs.writeSync(raw,b);if(stderr)return;
    pending+=b.toString();if(pending.length>65536){stop(Error('native-line-cap'));return;}let end;
    while((end=pending.indexOf('\n'))>=0){const line=pending.slice(0,end);pending=pending.slice(end+1);const match=/^\[R99-phase\] ([a-z-]+) (\d+)$/.exec(line);
      if(match){phase=match[1];pid=Number(match[2]);const ack=()=>{if(observing)setTimeout(ack,10);else void observe(true);};ack();}
    }
  }
  child.stdout.on('data',b=>collect(b,false));child.stderr.on('data',b=>collect(b,true));child.on('error',stop);
  const timer=setTimeout(()=>stop(Error('native-timeout')),180000),poll=setInterval(()=>void observe(),500);
  const result=await new Promise(resolve=>child.on('close',(code,signal)=>{closed=true;resolve({code,signal});}));clearTimeout(timer);clearInterval(poll);while(observing)await new Promise(r=>setTimeout(r,10));fs.closeSync(raw);
  if(primary)throw primary;if(result.code!==0||result.signal||seen===0)throw Error('native-child-failed:'+JSON.stringify(result));return {...result,samples:seen,bytes};
}
try{
  summary.live=await run('--mixed-generation',data,false);
  const before=tree(data);admitWorkspaceSnapshot({storage:{...named(),copyBytes:measure(data).bytes},baseline,context:{kind:'r99-copy-admission'}},capture);
  fs.cpSync(data,copy,{recursive:true,errorOnExist:true,force:false});fs.chmodSync(copy,0o700);
  if(tree(copy)!==before)throw Error('copy-bytes');summary.recovery=await run('--mixed-generation-reopen',copy,true);
  if(tree(data)!==before)throw Error('original-changed');summary.originalUnchanged=true;summary.cyclicRecoveryPass=true;summary.spacePass=true;summary.status='PASS';
}catch(e){first=e;summary.status='FAIL';summary.error=e.message;}
finally{fs.closeSync(samples);try{capture.close();}catch(e){first??=e;summary.status='FAIL';summary.error??=e.message;}summary.workspace=capture.summary();summary.sampleCount=sampleCount;summary.observationLimit='sequential 500ms samples and paused boundary samples; not instantaneous peak';fs.writeFileSync(path.join(root,'result.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify(summary));if(first)process.exitCode=1;
