#!/bin/bash
set -euo pipefail
umask 077
r=/tmp/media-server-preparation99
mkdir -p "$r/output" "$r/work"
finish(){ code=$?; printf '%s\n' "$code" > "$r/output/exit.txt"; tar -C "$r/output" --exclude='direct/live' --exclude='direct/copy' --exclude='direct/generation99' --exclude='direct/process-metrics' --exclude='generation99' -czf - .; exit "$code"; }
trap finish EXIT
export TMPDIR="$r/work" HOME="$r/work" XDG_CACHE_HOME="$r/work/cache" MEDIA_SERVER_SKIP_LOCAL_ENV=1
export LD_LIBRARY_PATH=/opt/onnxruntime-linux-aarch64-1.23.2/lib TASK_REPO=/source TASK_BUILD="$r/build"
cd /source
{ id; uname -srm; g++ --version; } > "$r/output/environment.log"
timeout 600 cmake -S /source -B "$r/build" -DMEDIA_SERVER_USE_GSTREAMER=ON -DMEDIA_SERVER_USE_ONNXRUNTIME=ON -DMEDIA_SERVER_USE_SIGLIP2=ON -DMEDIA_SERVER_ENABLE_YOUTUBE_SOURCE=OFF -DMEDIA_SERVER_ONNXRUNTIME_ROOT=/opt/onnxruntime-linux-aarch64-1.23.2 -DMEDIA_SERVER_SENTENCEPIECE_ROOT=/opt/rc58-sentencepiece > "$r/output/configure.log" 2>&1
timeout 600 cmake --build "$r/build" --target media_server_runtime -j2 > "$r/output/build.log" 2>&1
sha256sum "$r/build/libmedia_server_runtime.a" > "$r/output/runtime.sha256"
python3 /input/compile.py "$r/output" compile > "$r/output/compiler.log" 2>&1
c++ -std=c++17 -Wall -Wextra -Werror scripts/internal/recording_process_metrics.cpp -o "$r/output/process-metrics"
mkdir -m700 "$r/output/direct"
cp "$r/output/generation99" "$r/output/process-metrics" "$r/output/direct/"
node scripts/internal/recording_process_metrics.test.mjs > "$r/output/metrics.log" 2>&1
timeout 200 node scripts/internal/recording_mixed_generation_check.mjs "$r/output/direct" "$r/output/direct/generation99" "$r/output/direct/process-metrics" > "$r/output/direct-parent.log" 2>&1
sha256sum "$r/output/generation99" "$r/output/direct/live/mixed-input.mp4" > "$r/output/binary-input.sha256"
node scripts/internal/recording_longrun_progress.test.mjs > "$r/output/progress.log" 2>&1

node scripts/internal/recording_mixed_generation_check.test.mjs > "$r/output/parent-contract.log" 2>&1
