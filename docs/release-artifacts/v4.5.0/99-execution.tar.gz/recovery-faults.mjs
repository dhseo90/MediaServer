import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {spawn} from 'node:child_process';
const repo='<REPO>',root='<RUN>';
const mod=n=>import('file://'+repo+'/scripts/internal/'+n+'.mjs');
const {snapshotTree,copyVerified}=await mod('recording_archive_diagnostic_profile');
const {collectProcess}=await mod('recording_foundation_observer');
const {admitWorkspaceSnapshot,createWorkspaceFailureCapture,measureCurrentRootStable}=await mod('recording_current_observer');
const {resourceTraceCollector,collectResourceTrace,finishResourceTrace}=await mod('recording_resource_trace');
const source=fs.readFileSync(repo+'/scripts/internal/recording_mixed_generation_check.mjs','utf8');const actual=source.slice(source.indexOf('async function run('),source.indexOf('\ntry{\n  summary.live='));
const original=root+'/direct7/live',originalTree=snapshotTree(original),baseBytes=measureCurrentRootStable(original).totalBytes,results=[];
for(const fault of ['missing-original','stale-deleted-file','partial-generation']){
 const out=root+'/fault-'+fault;fs.mkdirSync(out,{mode:0o700});const copy=out+'/copy';copyVerified(original,copy,originalTree,n=>{if(baseBytes+n>=896*1024**2)throw Error('copy-budget');});
 const receipt=fs.readFileSync(copy+'/cyclic-receipt.txt','utf8').split('\n')[0],parts=[...receipt.matchAll(/"([^"]*)"|(\S+)/g)].map(m=>m[1]??m[2]);
 if(fault==='missing-original')fs.renameSync(copy+'/recordings/9101/r99-9101-20.mp4',out+'/held-original.mp4');
 if(fault==='stale-deleted-file')fs.copyFileSync(copy+'/recordings/9101/r99-9101-20.mp4',copy+'/recordings/'+parts[5]);
 if(fault==='partial-generation'){const f=copy+'/recordings/recording-generation.json';fs.writeFileSync(f,fs.readFileSync(f).subarray(0,50));}
 const capture=createWorkspaceFailureCapture(out),samples=fs.openSync(out+'/space.jsonl','wx',0o600);
 const context={root:out,repo,binary:root+'/generation99',collector:root+'/process-metrics',fs,path,spawn,process,Buffer,performance,setTimeout,clearTimeout,setInterval,clearInterval,samples,sampleCount:0,baseline:{fixedBytes:0,capBytes:448*1024**2},capture,collectProcess,admitWorkspaceSnapshot,resourceTraceCollector,collectResourceTrace,finishResourceTrace,
 named:()=>({totalBytes:baseBytes+fs.statSync(root+'/generation99').size+fs.statSync(root+'/process-metrics').size+fs.readdirSync(out).filter(n=>n!=='copy').reduce((n,f)=>n+fs.statSync(out+'/'+f).size,0),copyBytes:measureCurrentRootStable(copy).totalBytes})};
 vm.createContext(context);vm.runInContext(actual,context);let error=null;const begin=performance.now();try{await vm.runInContext("run('--mixed-generation-reopen',root+'/copy',true)",context);}catch(e){error={message:e.message,cleanupError:e.cleanupError??null};}finally{fs.closeSync(samples);capture.close();}
 if(!error)throw Error('negative escaped '+fault);
 const raw=fs.readFileSync(out+'/mixed-generation-reopen.log','utf8');const expected={'missing-original':'recovered-original-missing','stale-deleted-file':'recovered-deleted','partial-generation':'copy-reopen:'}[fault];if(!raw.includes(expected))throw Error('wrong rejection '+fault+' '+raw.slice(-500));
 const result={fault,error,elapsedMs:performance.now()-begin,expected,originalUnchanged:JSON.stringify(snapshotTree(original))===JSON.stringify(originalTree)};if(!result.originalUnchanged)throw Error('source changed');results.push(result);fs.writeFileSync(out+'/result.json',JSON.stringify(result,null,2));
}
fs.writeFileSync(root+'/recovery-faults.json',JSON.stringify({results,scope:'actual isolated copies; mutations are negative injection, never original retention or successful state'},null,2));console.log(JSON.stringify(results));
